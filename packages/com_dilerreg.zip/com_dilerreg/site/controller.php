<?php
/**
 *
 * @package Joomla.Site
 * @subpackage com_dilerreg
 *
 * @copyright Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Session\Session;
use \Joomla\CMS\Component\ComponentHelper;
use \DiLer\DMailer;

// import Joomla controller library





/**
 * dilerreg Component Controller
 */
class DilerregController extends BaseController
{

	public function sendEmail()
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		$replyEmail = $app->input->getString('userReplyEmail');
		$message = $app->input->getString('userMessage');
		$honeyPot = $app->input->getString('last_name');
        $params = ComponentHelper::getParams('com_diler');
        $loginContactformEmail = $params->get('loginContactformEmail');
		if ($honeyPot)
		{
			$result = (object) array('result' => 'error',
				'time' => Factory::getDate()->toSql(),
				'message' => 'Invalid form field');
		}
        elseif (!filter_var($loginContactformEmail, FILTER_VALIDATE_EMAIL) || DMailer::isDummyEmail($loginContactformEmail))
        {
            $result = (object) array(
                'result' => 'error',
                'time' => Factory::getDate()->toSql(),
                'message' => \DiLer\Lang\DText::_('COM_DILER_INVALID_DILER_MANAGER_CONTACT_EMAIL')
            );
        }
		else
		{
			try
			{
				$model = BaseDatabaseModel::getInstance('Login', 'DilerregModel');
				$result = $model->sendEmail($replyEmail, $message, $loginContactformEmail);
			}
			catch (Exception $e)
			{
				$result = (object) array('result' => 'error',
					'time' => Factory::getDate()->toSql(),
					'message' => $e->getMessage());
			}
		}
		echo json_encode($result);
		$app->close();
	}


	public function saveTrackingData()
	{
		$input = Factory::getApplication()->input;
		$fieldName = $input->getString('description');
		$seconds = $input->getInt('totalTime');

		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$user = Factory::getUser();
		$localTimezone = $user->getParam('timezone', Factory::getConfig()->get('offset'));

		$date = new DateTime('now', new DateTimeZone($localTimezone));
		$localDateTime = $date->format('Y-m-d H:i:s');

		$columns = array('time_of_saving', 'event_type', 'seconds');
		$values = array(
			$db->quote($localDateTime),
			$db->quote($fieldName),
			$db->quote($seconds)
		);

		$query
			->insert($db->quoteName('#__region_teacher_search_tracking'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));

		$db->setQuery($query);

		try {
			$db->execute();
			echo json_encode(['status' => 'success', 'message' => 'Data saved successfully']);
		} catch (Exception $e) {
			echo json_encode(['status' => 'error', 'message' => 'Failed to save data: ' . $e->getMessage()]);
		}

		Factory::getApplication()->close();
	}


	public function saveModalOpenCount()
	{
		$input = Factory::getApplication()->input;
		$fieldName = $input->getString('description');
		$modalOpenSession = $input->getString('modal_open_per_session');

		error_log('Received data: ' . json_encode($modalOpenSession));

		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$user = Factory::getUser();
		$localTimezone = $user->getParam('timezone', Factory::getConfig()->get('offset'));

		$date = new DateTime('now', new DateTimeZone($localTimezone));
		$localDateTime = $date->format('Y-m-d H:i:s');

		$columns = array('time_of_saving', 'event_type' , 'times');
		$values = array(
			$db->quote($localDateTime),
			$db->quote($fieldName),
			$db->quote($modalOpenSession)
		);

		$query
			->insert($db->quoteName('#__region_teacher_search_tracking'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));

		error_log('Executing query: ' . $query->__toString());

		$db->setQuery($query);

		try {
			$db->execute();
			echo json_encode(['status' => 'success', 'message' => 'Modal open count saved successfully']);
		} catch (Exception $e) {
			error_log('Failed to save modal open count: ' . $e->getMessage());
			echo json_encode(['status' => 'error', 'message' => 'Failed to save modal open count: ' . $e->getMessage()]);
		}

		Factory::getApplication()->close();
	}



	public function saveErrorData()
	{
		$input = Factory::getApplication()->input;
		$description = $input->getString('description');
		$errorCounts = $input->get('errorCounts', array(), 'array');

		error_log('Received error data: ' . json_encode(['description' => $description, 'errorCounts' => $errorCounts]));

		if (empty($description) || empty($errorCounts)) {
			echo json_encode(['status' => 'error', 'message' => 'Invalid error data received']);
			Factory::getApplication()->close();
		}

		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$user = Factory::getUser();
		$localTimezone = $user->getParam('timezone', Factory::getConfig()->get('offset'));

		$date = new DateTime('now', new DateTimeZone($localTimezone));
		$localDateTime = $date->format('Y-m-d H:i:s');

		foreach ($errorCounts as $fieldName => $times) {
			if ($times > 0) {
				$columns = array('time_of_saving', 'event_type', 'times');
				$values = array(
					$db->quote($localDateTime),
					$db->quote($fieldName),
					$db->quote($times)
				);

				$query->clear()
					->insert($db->quoteName('#__region_teacher_search_tracking'))
					->columns($db->quoteName($columns))
					->values(implode(',', $values));

				error_log('Executing query: ' . $query->__toString());

				try {
					$db->setQuery($query);
					$db->execute();
				} catch (Exception $e) {
					error_log('Failed to save error data: ' . $fieldName . ' - ' . $e->getMessage());
					echo json_encode(['status' => 'error', 'message' => 'Failed to save error data: ' . $fieldName]);
					Factory::getApplication()->close();
				}
			}
		}

		echo json_encode(['status' => 'success', 'message' => 'Data saved successfully']);
		Factory::getApplication()->close();
	}


}