<?php
/**
 *
 * @package DiLerreg.Site
 * @subpackage com_dilerreg
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

/**
 * Activity Controller
 *
 * @package Diler.site
 * @since 5.0
 */
class DilerregControllerBaseSchoolActivation extends \Audivisa\Component\DiLer\Site\Controller\DilerFormController
{

	protected $text_prefix = 'COM_DILER_LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_LABEL';

	public function checkSchoolSerialNumber()
	{
		DilerHelperUser::honeypotClose();
		$options['school_serial_number'] = Factory::getApplication()->input->get('school_serial_number');
		$this->processModel('checkSchoolSerialNumber', $options);
	}

	public function createBaseSchoolTeacherCode()
	{
		DilerHelperUser::honeypotClose();
		$app = Factory::getApplication();
		$options = $app->input->get('jform', [], 'array');
		$options['school_serial_number'] = $options['state_iso'] . $options['school_serial_number'];
		$options['itemId'] = $app->input->getUint('Itemid');
		try
		{
			/** @var DiLerregModelBaseSchoolActivation $model */
			$model = $this->getModel();
			$result = $model->createBaseSchoolTeacherCode($options);
		}
		catch (Exception $ex)
		{
			$result = (object) ['status' => 0, 'message' => $ex->getMessage()];
            $app->enqueueMessage($result->message, 'error');
			$app->redirect('index.php?option=com_dilerreg&view=baseschoolactivation&Itemid=' . $this->input->get('Itemid') . '&lang=' . $this->input->get('lang'));
		}
		$status = ($result->status === 1) ? 'success' : 'error';
		$app->enqueueMessage($result->message, $status);
		$app->redirect('index.php?option=com_diler');
	}

	/**
	 * Override parent function.
	 *
	 * @see FormController::getModel()
	 */
	public function getModel($name = 'BaseSchoolActivation', $prefix = 'DilerregModel', $config = array('ignore_request' => true))
	{
		return parent::getModel($name, $prefix, $config);
	}

}
