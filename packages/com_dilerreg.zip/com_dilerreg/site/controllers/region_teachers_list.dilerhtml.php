<?php
/**
 * @copyright Copyright (C) 2013-2023 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
class DilerregControllerRegion_Teachers_List extends BaseController
{
    public function getModel($name = '', $prefix = '', $config = array('ignore_request' => true))
    {
        $config['region_teacher_surname'] = $this->input->getString('region_teacher_surname');
        $config['region_teacher_postal_code'] = $this->input->get('region_teacher_postal_code');
        $config['region_teacher_state'] = $this->input->getString('region_teacher_state');
        $config['region_teacher_country'] = $this->input->getString('region_teacher_country', 'DE');
        $config['region_teacher_city'] = $this->input->getString('region_teacher_city');
        $config['region_teacher_notes_and_regions'] = $this->input->getString('region_teacher_notes_and_regions');
        $config['region_teacher_case_sensitive'] = $this->input->getInt('region_teacher_case_sensitive');

        return parent::getModel($name, $prefix, $config);
    }

}
