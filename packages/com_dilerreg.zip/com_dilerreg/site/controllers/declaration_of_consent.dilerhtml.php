<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use DiLer\Core\Consents\DeclarationConsent;
use DiLer\Lang\DText;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

class DilerregControllerDeclaration_of_consent extends BaseController
{
	public function getHtmlContent()
	{
		$regCodeId = $this->input->getInt('regCodeId', 0);
		$dob = $this->input->get('dob', '');
		$declarationConsentArticleId = DilerParams::init()->getDeclarationConsentArticleId();
		if ($regCodeId && $declarationConsentArticleId)
		{
			/** @var DiLerModelDeclarationConsent $declarationConsentModel */
			BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
			$declarationConsentModel = $this->getModel('DeclarationConsent', 'DilerModel',
				array('registration_code_id' => $regCodeId)
			);
			echo $declarationConsentModel->getPreparedContent($declarationConsentArticleId, $dob);
			return;
		}

		echo DText::_('SYSTEM_ERROR');
	}
}
