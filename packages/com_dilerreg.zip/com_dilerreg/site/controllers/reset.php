<?php
/**
 * @package     Dilerreg.Site
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\User\UserHelper;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Router\Route;
use Joomla\Component\Users\Site\Model\ResetModel;

class DilerregControllerReset extends FormController
{

	/**
	 * Override @see ResetController::request()
	 * 
	 * @since 6.11.0
	 * @return bool
	 * @throws Exception
	 */
	public function request()
	{
		$this->checkToken('post');
		
		Factory::getLanguage()->load('com_users');
		$app   = Factory::getApplication();
		
		/** @var ResetModel $model */
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_users/models');
		$model = Factory::getApplication()->bootComponent('com_users')->getMVCFactory()->createModel('Reset', 'Site');

		$data  = $this->input->post->get('jform', array(), 'array');
		
		// We are sending username as email as we override default layout for joomla reset password and we there
		// only changed language string to display 'Username' instead 'Email'
		$userName = $data['email'];
		
		$userId = UserHelper::getUserId($userName);

		if (!$userId)
			return $this->redirectOnFail(DText::_('INVALID_USERNAME'));
			
		$data['email'] = Factory::getUser($userId)->email;
		Form::addFormPath(JPATH_ROOT . '/components/com_users/forms');
		$return	= $model->processResetRequest($data);

		if ($return instanceof Exception)
		{
			$errorMsg = $app->get('error_reporting') ? $return->getMessage() : Text::_('COM_USERS_RESET_REQUEST_ERROR');
			$this->redirectOnFail($errorMsg);

			return false;
		}
		
		if ($return === false)
		{
			$errorMsg = Text::sprintf('COM_USERS_RESET_REQUEST_FAILED', $model->getError());
			return $this->redirectOnFail($errorMsg);
		}
		
		$this->setRedirect(Route::_('index.php?option=com_users&view=reset&layout=confirm', false));
		return true;
	}
	
	private function redirectOnFail(string $message)
	{
		$message = Text::sprintf('COM_USERS_RESET_REQUEST_FAILED', $message);
		$this->setRedirect(Route::_('index.php?option=com_users&view=reset', false), $message, 'notice');
		
		return false;
	}
}
