<?php
/**
 *
 * @package DiLerreg.Site
 * @subpackage com_dilerreg
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\Controller\FormController;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

/**
 * Activity Controller
 *
 * @package Diler.site
 * @since 5.0
 */
class DilerregControllerRegisterTeacher extends \Audivisa\Component\DiLer\Site\Controller\DilerFormController
{

	protected $text_prefix = 'COM_DILERREG_REGISTER_TEACHER_LABEL';

	public function checkRegistrationCode()
	{
		DilerHelperUser::honeypotClose();
		$input = Factory::getApplication()->input;
		$options = ['registrationCode' => $input->getString('registration_code')];
		$options['principal'] = $input->getUint('principal', 0);
		$options['baseSchool'] = $input->getUint('base_school', 0);
		$this->processModel('checkRegistrationCode', $options);
	}

	public function checkTeacherEmail()
	{
		DilerHelperUser::honeypotClose();
		$input = Factory::getApplication()->input;
		$options = ['teacherEmail' => $input->getString('teacher_email')];
		$this->processModel('checkTeacherEmail', $options);
	}

	/**
	 * Override parent function.
	 *
	 * @see FormController::getModel()
	 */
	public function getModel($name = 'RegisterTeacher', $prefix = 'DilerregModel', $config = array('ignore_request' => true))
	{
		return parent::getModel($name, $prefix, $config);
	}

	/**
	 * Either registers a new branch teacher or, if teacher already registered, creates group and assigns student and teacher to group.
	 */
	public function registerOrAssign()
	{
		DilerHelperUser::honeypotClose();
		$app = Factory::getApplication();
		$data = $app->input->get('jform', [], 'array');
		$options = ['teacherEmail' => $data['teacher_email']];
		$options['registrationCode'] = $data['registration_code'];
		$options['baseSchool'] = $app->input->getUint('base_school');
		$options['principal'] = $app->input->getUint('principal');
		$itemId = $app->input->getUint('Itemid');
		try
		{
			/** @var DiLerregModelRegisterTeacher $model */
			$model = $this->getModel();
			$result = $model->registerOrAssign($options);
		}
		catch (Exception $ex)
		{
			$app->enqueueMessage($ex->getMessage(), 'error');
			$app->redirect(Route::_('index.php?option=com_dilerreg&Itemid=' . $itemId, false));
		}
		if ($result->status === 1)
		{
			// Existing teacher
			$app->enqueueMessage($result->message, 'success');
			$app->redirect('index.php?option=com_diler');
		}
		elseif ($result->status === 2)
		{
			// New teacher. Redirect to registration
			$emailEncoded = base64_encode($options['teacherEmail']);
			$regCodedEncoded = base64_encode($options['registrationCode']);
			$link ='index.php?option=com_dilerreg&view=registration&Itemid=' . $itemId . '&registration_code=' . $regCodedEncoded .
					'&teacher_email=' . $emailEncoded . '&base_school=' . $options['baseSchool']
					. '&principal=' . $options['principal'];
			$app->redirect(Route::_($link, false));
		}
	}
}
