<?php
/**
 *
 * @package DiLerreg.Site
 * @subpackage com_dilerreg
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Audivisa\Component\DiLer\Site\Controller\DilerFormController;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

/**
 * Activity Controller
 *
 * @package Diler.site
 * @since 5.0
 */
class DilerregControllerUser extends DilerFormController
{

	protected $text_prefix = 'COM_DILERREG_REGISTER';

	public function checkRegForm()
	{
		$app = Factory::getApplication();
		$data = $app->input->get('jform', array(), 'post', 'array');
		$data['field'] = $app->input->get('field');
		try
		{
			$result = BaseDatabaseModel::getInstance('Registration', 'DiLerregModel')->checkRegForm($data);
		}
		catch (Exception $e)
		{
			header('HTTP/1.0 500 Internal Server Error');
			$response = $e->getMessage();
			echo json_encode($response);
			$app->close();
		}

		echo json_encode($result);
		$app->close();
	}

	public function redirectUser()
	{
		// Redirect newly registered user
		$app = Factory::getApplication();
		$lang = $app->input->get('lang');
		$username = $app->input->getString('loginUsername');
		$systemMessageRaw = $app->input->getString('systemMessage');
		$systemMessage = str_replace('---break---', '<br>', $systemMessageRaw);
		$errorMessage = $app->input->getString('errorMessage');
		if ($errorMessage) $app->enqueueMessage ($errorMessage, 'error');
		$message = $systemMessage . '<br><br>' . Text::_('COM_DILERREG_REGISTRATION_SUCCESSFULL') . "<h3 class=\"usernameRegSuccess\">" . $username . "</h3>";
		if (Factory::getUser()->guest)
		{
			// Redirect new users to login
			BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
			$dilerModel = MVCHelper::factory()->createModel('Diler', 'Site');
			$link = $dilerModel->getLoginLink();
            $app->enqueueMessage($message);
			$app->redirect($link, 200);
		}
		else
		{
			// Redirect existing users back to DiLer entry point
			$redirect = 'index.php?option=com_diler&lang=' . $lang;
			$app->redirect($redirect, Text::sprintf('COM_DILERREG_REGISTER_STUDENT_SUCCESS', $username), 'SUCCESS');
		}
	}

	public function registerUser()
	{
		$app = Factory::getApplication();
		$input = $app->input;
		$data = $input->get('jform', array(), 'post', 'array');
		$data['lang'] = $input->get('lang');
		$data['code'] = $input->getString('codeHidden');
		/** @var DiLerregModelRegistration $model */
		$model = BaseDatabaseModel::getInstance('Registration', 'DiLerregModel');
		try
		{
			$result = $model->registerUser($data);
		}
		catch (Exception $e)
		{
			header('HTTP/1.0 500 Internal Server Error');
			$response = $e->getMessage();
			echo json_encode($response);
			$app->close();
		}

		echo json_encode($result);
		$app->close();
	}


	/**
	 * Verifies user code and opens registration form
	 */
	public function verifyCode()
	{
		$app = Factory::getApplication();
		$args = array();
		$args['code'] = $app->input->getString('code');
		$args['Itemid'] = $app->input->getUint('Itemid');
		$args['lang'] = $app->input->get('lang');
		$args['teacherEmail'] = $app->input->get('teacherEmail');
		$model = BaseDatabaseModel::getInstance('Registration', 'DiLerregModel');

		// Get the json for this code
		try
		{
			$response = $model->getRegistrationForm($args);
		}
		catch (Exception $e)
		{
			header('HTTP/1.0 500 Internal Server Error');
			echo $e->getMessage();
			$app->close();

		}
		echo json_encode($response);
		$app->close();
	}

	public function verifyDigluRegistrationCode()
	{
		$app = Factory::getApplication();
		$args = array();
		$args['code'] = $app->input->getString('code');
		$args['Itemid'] = $app->input->getUint('Itemid');
		$args['lang'] = $app->input->get('lang');
		/** @var DiLerregModelRegistration $model */
		$model = BaseDatabaseModel::getInstance('Registration', 'DiLerregModel');

		// Get the json for this code
		try
		{
			$response = $model->getRegistrationForm($args);
		}
		catch (Exception $e)
		{
			header('HTTP/1.0 500 Internal Server Error');
			echo $e->getMessage();
			$app->close();

		}
		echo json_encode($response);
		$app->close();
	}
}
