<?php
/**
 *
 * @package DiLerreg.Site
 * @subpackage com_dilerreg
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Site\Controller\DilerFormController;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

/**
 * Activity Controller
 *
 * @package Diler.site
 * @since 5.0
 */
class DilerregControllerEnrollStudent extends DilerFormController
{

	protected $text_prefix = 'COM_DILER_LOGIN_FORM_DIGLU_ENROLL_STUDENT_LABEL';

	public function checkStudentId()
	{
		DilerHelperUser::honeypotClose();
		$input = Factory::getApplication()->input;
		$options['studentId'] = $input->input->getString('student_id');
		$options['baseSchool'] = $input->getUint('base_school', 0);
		$this->processModel('checkStudentId', $options);
	}

	public function checkSchoolSerialNumber()
	{
		DilerHelperUser::honeypotClose();
		$input = Factory::getApplication()->input;
		$options['school_serial_number'] = $input->get('school_serial_number');
		$options['baseSchool'] = $input->getUint('base_school', 0);
		$this->processModel('checkSchoolSerialNumber', $options);
	}

    public function checkIsBranchTeacherPublished()
    {
        DilerHelperUser::honeypotClose();
        $input = Factory::getApplication()->input;
        $options = ['branch_teacher_email' => $input->getString('branch_teacher_email')];
        $this->processModel('checkIsBranchTeacherPublished', $options);
    }

	public function createBranchTeacherCode()
	{
		DilerHelperUser::honeypotClose();
		$app = Factory::getApplication();
		$options = $app->input->get('jform', [], 'array');
		$options['school_serial_number'] = $options['state_iso'] . $options['school_serial_number'];
		$options['itemId'] = $app->input->getUint('Itemid');
		$options['baseSchool'] = $app->input->getUint('base_school');
		$options['report_type_id'] = $app->input->get('report_type_id', '');
		try
		{
			/** @var DiLerregModelEnrollStudent $model */
			$model = $this->getModel();
			$result = $model->createBranchTeacherCode($options);
		}
		catch (Exception $ex)
		{
			$result = (object) ['status' => 0, 'message' => $ex->getMessage()];
			$app->redirect('index.php?option=com_dilerreg&view=enrollstudent');
		}
		$status = ($result->status === 1) ? 'success' : 'error';
		$app->enqueueMessage($result->message, $status);
		$app->redirect('index.php?option=com_diler');
	}

	/**
	 * Override parent function.
	 *
	 * @see FormController::getModel()
	 */
	public function getModel($name = 'EnrollStudent', $prefix = 'DilerregModel', $config = array('ignore_request' => true))
	{
		return parent::getModel($name, $prefix, $config);
	}

}
