<?php
/**
 *
 * @package DiLerreg.Site
 * @subpackage com_dilerreg
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;
use Joomla\CMS\Factory;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
JLoader::register('DilerControllerForm', JPATH_ROOT . '/components/com_diler/controllers/form.php');

/**
 * Activity Controller
 *
 * @package Diler.site
 * @since 5.0
 */
class DilerregControllerBranchTeacherAssignStudent extends DilerControllerForm
{

	protected $text_prefix = 'COM_DILERREG_BRANCH_TEACHER_ASSIGN_STUDENT_LABEL';

	public function checkRegistrationCode()
	{
		DilerHelperUser::honeypotClose();
		$input = Factory::getApplication()->input;
		$options = ['registrationCode' => $input->get('registration_code')];
		$this->processModel('checkRegistrationCode', $options);
	}

	public function checkTeacherEmail()
	{
		DilerHelperUser::honeypotClose();
		$input = Factory::getApplication()->input;
		$options = ['teacherEmail' => $input->getString('teacher_email')];
		$this->processModel('checkTeacherEmail', $options);
	}

	/**
	 * Override parent function.
	 *
	 * @see JControllerForm::getModel()
	 */
	public function getModel($name = 'BranchTeacherAssignStudent', $prefix = 'DilerregModel', $config = array('ignore_request' => true))
	{
		return parent::getModel($name, $prefix, $config);
	}

	/**
	 * Either registers a new branch teacher or, if teacher already registered, creates group and assigns student and teacher to group.
	 */
	public function registerOrAssign()
	{
		DilerHelperUser::honeypotClose();
		$app = Factory::getApplication();
		$data = $app->input->get('jform', [], 'array');
		$options = ['teacherEmail' => $data['teacher_email']];
		$options['registrationCode'] = $data['registration_code'];
		$itemId = $app->input->getUint('Itemid');
		try
		{
			$result = $this->getModel()->registerOrAssign($options);
		}
		catch (Exception $ex)
		{
			$app->enqueueMessage($ex->getMessage(), 'error');
			$app->redirect(JRoute::_('index.php?option=com_diler&Itemid=' . $itemId, false));
		}
		if ($result->status === 1)
		{
			// Existing teacher
			$app->enqueueMessage($result->message, 'success');
			$app->redirect('index.php?option=com_diler');
		}
		elseif ($result->status === 2)
		{
			// New teacher. Redirect to registration
			$emailEncoded = base64_encode($options['teacherEmail']);
			$regCodedEncoded = base64_encode($options['registrationCode']);
			$link ='index.php?option=com_dilerreg&view=registration&Itemid=' . $itemId . '&registration_code=' . $regCodedEncoded .
					'&teacher_email=' . $emailEncoded;
			$app->redirect(JRoute::_($link, false));
		}
	}
}
