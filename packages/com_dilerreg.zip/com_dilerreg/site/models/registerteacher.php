﻿<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use DiLer\Lang\DText;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

// import Joomla modelitem library

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

class DiLerregModelRegisterTeacher extends AdminModel
{

	protected function getBaseSchoolReportType($code)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')
				->from('#__dilerreg_registration_codes')
				->where('code = ' . $db->quote($code));
		$row = $db->setQuery($query)->loadObject();
		return (isset($row->id) && $row->id && $row->report_type_id) ? $row->report_type_id : 0;
	}

	/**
	 * Checks to see if this code has a row in the map table. If so, it gets the student name and school name.
	 * If no row found, returns an error message.
	 *
	 * @param array $options: 'registration_code'
	 * @return stdClass: status (1 if success, 0 if error), message.
	 */
	public function checkRegistrationCode($options)
	{
		if ($options['principal'])
		{
			return $this->checkRegistrationCodePrincipal($options);
		}
		else
		{
			return $this->checkRegistrationCodeTeacher($options);
		}
	}

	protected function checkRegistrationCodePrincipal($options)
	{
		$result = (object) ['status' => 0, 'message' => '', 'principal' => 1];
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('c.*, s.name AS school_name, s.email as school_email, m.base_school_teacher')
			->from('#__dilerreg_registration_codes AS c')
			->leftJoin('#__diler_school AS s ON c.base_school_id = s.school_id')
			->leftJoin('#__dilerreg_registration_code_user_map AS m ON m.code_id = c.id')
			->where('c.code = ' . $db->quote($options['registrationCode']));
		$row = $db->setQuery($query)->loadObject();
		$otherGroupCatId = $this->getNewGroupCatId();
		$reportType = $this->getBaseSchoolReportType($options['registrationCode']);
		if ($otherGroupCatId && $reportType && is_object($row) && $row->id && $row->school_email)
		{
			$result->status = 1;
			$result->email = $row->school_email;
			$msg = [];
			$msg[] = DText::sprintf('GENERIC_DEFINITION', DText::_('DIGLU_BASE_SCHOOL_ACTIVATION_PRINCIPAL_HEADING'), $row->first_name . ' ' . $row->last_name);
			$msg[] = DText::sprintf('GENERIC_DEFINITION', DText::_('SCHOOL'), $row->school_name);
			$result->message = implode('<br>', $msg);
		}
		elseif (is_object($row) && $row->id)
		{
			$errorMessageTag = ($row->base_school_teacher != 1) ? 'COM_DILER_DIGLU_BRANCH_TEACHER_CODE_ENTERED' : 'COM_DILER_DIGLU_BASE_TEACHER_CODE_ENTERED';
			$errorButtonTag = ($row->base_school_teacher != 1) ? 'COM_DILER_LOGIN_FORM_DIGLU_ENROLL_STUDENT_LABEL' : 'COM_DILER_BASE_TEACHER_REG_FORM_REG_HEADING';
			$result->message = DText::sprintf($errorMessageTag, $options['registrationCode']);
			$result->header = DText::_('DIGLU_WRONG_TYPE');
			$result->messageButton = DText::_($errorButtonTag);
			$result->status = 2;
			$itemId = Factory::getApplication()->input->getUint('registration_item_id');
			$result->link = Route::_(Uri::base() . 'index.php?option=com_dilerreg&view=registerteacher&Itemid=' . $itemId
					. '&registration_code=' . base64_encode($options['registrationCode']) . '&base_school=' . $row->base_school_teacher);
		}
		else
		{
			$result->message = Text::_('COM_DILERREG_REGISTRATION_INVALID');
		}
		return $result;
	}

	protected function checkRegistrationCodeTeacher($options)
	{
		$db = Factory::getDbo();
		$result = (object) ['status' => 0, 'message' => '', 'principal' => 0];
		$errorMessageTag = $options['baseSchool'] ? 'COM_DILER_DIGLU_BRANCH_TEACHER_CODE_ENTERED' : 'COM_DILER_DIGLU_BASE_TEACHER_CODE_ENTERED';
		$errorButtonTag = $options['baseSchool'] ? 'COM_DILER_LOGIN_FORM_DIGLU_ENROLL_STUDENT_LABEL' : 'COM_DILER_BASE_TEACHER_REG_FORM_REG_HEADING';
		$query = $db->getQuery(true)->select('m.*, du.forename AS student_forename, du.surname AS student_surname')
				->select('sch.name AS school_name, c.first_name AS teacher_forename, c.last_name AS teacher_surname, c.role AS teacher_role')
				->from('#__dilerreg_registration_code_user_map AS m')
				->innerJoin('#__dilerreg_users AS du ON du.user_id = m.user_id')
				->innerJoin('#__diler_school AS sch ON sch.id = m.school_id')
				->innerJoin('#__dilerreg_registration_codes AS c ON c.id = m.code_id')
				->where('c.code = ' . $db->quote($options['registrationCode']));
		$row = $db->setQuery($query)->loadObject();
		$otherGroupCatId = $this->getNewGroupCatId();
		if ($otherGroupCatId && $row !== null && isset($row->code_id) && $row->teacher_role === 'teacher'
				&& $options['baseSchool'] == $row->base_school_teacher)
		{
			$result->status = 1;
			$studentFullName = $row->student_forename . ' ' . $row->student_surname;
			$msg = [DText::sprintf('GENERIC_DEFINITION', DText::_('STUDENT'), $studentFullName)];
			$msg[] = DText::sprintf('GENERIC_DEFINITION', DText::_('TEACHER'), $row->teacher_forename . ' ' . $row->teacher_surname);
			$msg[] = DText::sprintf('GENERIC_DEFINITION', DText::_('SCHOOL'), $row->school_name);
			$result->message = implode('<br>', $msg);
			$result->studentFullName = $studentFullName;
		}
		elseif ($otherGroupCatId && $row !== null && isset($row->code_id) && $row->teacher_role === 'teacher')
		{
			$result->message = DText::sprintf($errorMessageTag, $options['registrationCode']);
			$result->header = DText::_('DIGLU_WRONG_TYPE');
			$result->messageButton = DText::_($errorButtonTag);
			$result->status = 2;
			$itemId = Factory::getApplication()->input->getUint('registration_item_id');
			$result->link = Route::_(Uri::base() . 'index.php?option=com_dilerreg&view=registerteacher&Itemid=' . $itemId
					. '&registration_code=' . base64_encode($options['registrationCode']) . '&base_school=' . $row->base_school_teacher);
		}
		elseif ($otherGroupCatId && $reportType = $this->getBaseSchoolReportType($options['registrationCode']))
		{
			$result->message = DText::sprintf('DIGLU_BASE_CODE_ENTERED', $options['registrationCode']);
			$result->header = DText::_('DIGLU_WRONG_TYPE');
			$result->status = 2;
			$itemId = Factory::getApplication()->input->getUint('registration_item_id');
			$result->link = Route::_(Uri::base() . 'index.php?option=com_dilerreg&view=registerteacher&Itemid=' . $itemId . '&report_type_id=' . $reportType . '&registration_code=' . base64_encode($options['registrationCode']) .
					'&base_school=1&principal=1');
		}
		elseif($otherGroupCatId)
		{
			$result->message = Text::_('COM_DILERREG_REGISTRATION_INVALID');
		}
		else
		{
			$result->message = 'No Group Category has been set up for "Other" type groups. This must be done before assigning a Diglu student to a teacher.';
		}
		return $result;
	}

	// Checks to see whether teacher is already registered, based on whether the email matches an existing user.
	public function checkTeacherEmail($options)
	{
		$db = Factory::getDbo();
		$result = (object) ['status' => 0, 'message' => Text::_('COM_DILERREG_INVALID_EMAIL')];
		$query = $db->getQuery(true)->select('ju.*')
				->from('#__users AS ju')
				->where('ju.email = ' . $db->quote($options['teacherEmail']));
		$row = $db->setQuery($query)->loadObject();
		if ($row)
			$result->message = Text::_('COM_DILERREG_DUPLICATE_EMAIL');
		if ($row !== null && isset($row->id) && DilerHelperUser::getDilerRole($row->id) === 'teacher')
		{
			$result->status = 1;
			$result->message = DText::sprintf('EXISTING_TEACHER', $row->name);
			$result->data = $row;
		}
		elseif ($row === null && $this->testEmail($options['teacherEmail']))
		{
			$result->status = 2;
			$result->message = DText::_('NEW_TEACHER');
		}
		return $result;
	}

	/**
	 * Get the registration edit form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 *
	 * @since 1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_dilerreg.registerteacher', 'registerteacher', array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	protected function getMapRow($options)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('m.*')
				->from('#__dilerreg_registration_code_user_map AS m')
				->innerJoin('#__dilerreg_registration_codes AS c ON c.id = m.code_id')
				->where('c.code = ' . $db->quote($options['registrationCode']));
		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return array The data for the form.
	 * @since 5.0
	 */
	protected function loadFormData()
	{
		if (empty($data))
		{
			$data = array();
		}
		return $data;
	}

	/**
	 * Gets the first "Other" category for DiLer groups.
	 * @return int  Category id or 0 if not found.
	 */
	public function getNewGroupCatId()
	{
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$groupModel = MVCHelper::factory()->createModel('Group', 'Site');
		$groupCategories = $groupModel->getDilerGroupCategories();
		$result = (isset($groupCategories[4]) && is_array($groupCategories[4]) && count($groupCategories[4])) ? $groupCategories[4][0]->id : 0;
		return $result;
	}

	/**
	 * Check reg code and email and either redirect to registration or create group and assign teacher and student to new group.
	 * @param array $options : 'registrationCode', 'teacherEmail'
	 * @return stdClass : status, message
	 * @throws Exception
	 */
	public function registerOrAssign($options)
	{
		// check that map row exists
		$result = new stdClass();
		$mapRows = $this->getMapRow($options);
		if ($mapRows === null) throw new Exception('This registration code is not valid or has already been used.');
		// check whether email exists: exists and teacher, exists and not teacher (error), does not exist
		$teacherExistsObject = $this->checkTeacherEmail($options);
		if ($teacherExistsObject->status === 0)
		{
			// This should never happen because it is also checked during form entry.
			throw new Exception('This email is not valid.');
		}
		elseif ($teacherExistsObject->status === 1)
		{
			// New group will be created with teacher and student assigned.
			/** @var DiLerregModelRegistration $registrationModel */
			$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');
			$result = $registrationModel->processExistingTeacher($options, $mapRows, $teacherExistsObject->data);
		}
		elseif ($teacherExistsObject->status === 2)
		{
			// Controller will redirect to registration process
			$result = $teacherExistsObject;
		}
		return $result;
	}

	/**
	 * Checks that the email is valid format.
	 *
	 * @param string $email  Teacher email
	 * @return bool  true if valid, false otherwise.
	 */
	public function testEmail($email)
	{
		$rule = FormHelper::loadRuleType('email');
		$form = $this->getForm();
		$fieldXml = $form->getfieldXML('teacher_email');
		$result = $rule->test($fieldXml, $email);
		return $result === true;
	}

}
