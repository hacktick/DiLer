﻿<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Core\Diglu;
use DiLer\DataProviders\DTO\SendEmailAboutRegistrationParams;
use DiLer\DGet;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use DiLer\Lang\DText;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Uri\Uri;

// import Joomla modelitem library

JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

class DiLerregModelBaseSchoolActivation extends AdminModel
{

	/**
	 * Checks that the serial number is a valid base school that has not already been registered.
	 * Also checks that the school email is not assigned to a Joomla user.
	 * Called to validate the school id number from the form and also during the processing.
	 *
	 * @param array $options Data from form
	 * @return array: message, status, schoolRow
	 */
	public function checkSchoolSerialNumber($options)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('s.*, ju.id AS joomla_user_id')
				->from('#__diler_school AS s')
				->leftJoin('#__users AS ju ON s.email = ju.email')
				->where('s.school_id = ' . $db->quote($options['school_serial_number']))
				->where('s.published = 1');
		$row = $db->setQuery($query)->loadObject();
		if (isset($row->id) && $row->id && $row->base_school && $row->email && ! $row->contract_signed_by && ! $row->joomla_user_id)
		{
			$result = ['status' => 1, 'message' => $row->name, 'id' => $row->id, 'schoolRow' => $row];
		}
		elseif(isset($row->id) && ! $row->base_school)
		{
			$result = ['status' => 0, 'message' => DText::_('BASE_SCHOOL_FORM_NOT_BASE_SCHOOL')];
		}
		elseif (isset($row->id) && $row->contract_signed_by)
		{
			$result = ['status' => 0, 'message' => DText::sprintf('BASE_SCHOOL_FORM_CONTRACT_SIGNED', $row->name)];
		}
		elseif (isset($row->id) && ! $row->email)
		{
			$result = ['status' => 0, 'message' => DText::_('BASE_SCHOOL_FORM_NO_EMAIL')];
		}
		elseif (isset($row->id) && $row->joomla_user_id)
		{
			$result = ['status' => 0, 'message' => DText::_('BASE_SCHOOL_FORM_EMAIL_IN_USE')];
		}
		else
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_INVALID_SCHOOL')];
		}
		return $result;
	}

	/**
	 * Processes a new base school. Creates registration code and sends email to school email with link to registration for base school teacher (principal).
	 * Also updates school row with data protection office columns.
	 * @param array $options : 'school_serial_number', 'forename', 'surname'
	 * @return stdClass
	 * @throws Exception
	 */
	public function createBaseSchoolTeacherCode($options)
	{
		// Check that school serial number is valid and get school email
		$schoolValid = $this->checkSchoolSerialNumber($options);
		if (! $schoolValid['status'])
		{
			throw new RuntimeException(DText::_('BRANCH_FORM_INVALID_SCHOOL'));
		}
		$options['schoolRow'] = $schoolValid['schoolRow'];
		// Create reg code row
		$codeCreateArray = $this->createRegCodeRow($options);
		$messages[0] = $codeCreateArray['message'];
		$options['codeId'] = $codeCreateArray['codeId'];

		// Add columns to school table
		$this->updateSchoolTable($options);

		$messages[] = $this->sendBaseSchoolActivationEmail($options);

		return (object) ['status' => 1, 'message' => implode('<br><br>', $messages)];
	}

	/**
	 * Get the registration edit form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 *
	 * @since 1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_dilerreg.baseschoolactivation', 'baseschoolactivation', array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	/**
	 * Gets list of possible contract layout files
	 * @return array of stdClass row objects.
	 */
	public function getLayoutFiles()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('rt.*')
				->from('#__diler_report_type AS rt')
				->where('rt.published = 1')
				->where('rt.report_or_contract = 1');
		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Createw new row in the dilerreg_codes table for the base school principal.
	 *
	 * @param array $options
	 * @return array message, codeId (newly created registration code id)
	 * @throws Exception
	 */
	protected function createRegCodeRow($options)
	{
		$message = '';
		BaseDatabaseModel::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_dilerreg/models');
		/** @var DilerregModelCode $codeModel */
		$codeModel = BaseDatabaseModel::getInstance('Code', 'DilerregModel');
		$baseTeacherGroup = ComponentHelper::getParams('com_diler')->get('base_school_teacher_group_id', 0);
		if (! $baseTeacherGroup) throw new RuntimeException('No Base Teacher Groups setup.');
        $options['report_type_id'] = 12;
		$codeData = ['dilerrolegroup' => $baseTeacherGroup, 'first_name' => $options['forename'], 'last_name' => $options['surname'], 'lg' => '',
			'base_school_id' => $options['school_serial_number'], 'report_type_id' => $options['report_type_id']];
		$codeCreate = $codeModel->save($codeData);
		if ($codeCreate)
		{
			$message = Text::sprintf('COM_DILERREG_REGCODE_SUCCESS', $codeData['first_name'] . ' ' . $codeData['last_name']);
		}
		else
		{
			throw new RuntimeException('Unable to create new Registration Code for ' . $codeData['first_name'] . ' ' . $codeData['last_name']);
		}
		$codeId = $codeModel->getState($codeModel->getName() . '.id');
		return ['message' => $message, 'codeId' => $codeId];
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return array The data for the form.
	 * @since 5.0
	 */
	protected function loadFormData()
	{
		if (empty($data))
		{
			$data = array();
		}
		return $data;
	}

	/**
	 * Sends the email to the base school to allow the principal to register as a teacher and accept the contract.
	 *
	 * @param array $options
	 * @return string Success message
	 * @throws RuntimeException
	 */
	protected function sendBaseSchoolActivationEmail($options)
	{
		// Get code
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')->from('#__dilerreg_registration_codes')
				->where('id = ' . $db->quote($options['codeId']));
		$codeRow = $db->setQuery($query)->loadObject();
		// send school email
		// get list of teachers for student groups
		// send teacher emails
		$link = Route::_(Uri::base() . 'index.php?option=com_dilerreg&view=registerteacher&principal=1&Itemid=' . $options['itemId'] . '&report_type_id=' . $options['report_type_id']
				. '&base_school=1&registration_code=' . base64_encode($codeRow->code));
		$linkTag = '<a href="' . $link . '">' . DText::_('BASE_SCHOOL_ACTIVATION_LINK_TEXT') . '</a>';
		$principalFullName = $codeRow->first_name . ' ' . $codeRow->last_name;
		$body = DText::sprintf('BASE_SCHOOL_EMAIL_BODY',
			$linkTag,
			$codeRow->code,
			$principalFullName
		);

		/** @var DiLerregModelRegistration $registrationModel */
		$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');

		$emailParams = new SendEmailAboutRegistrationParams(DText::_('BASE_SCHOOL_EMAIL_SUBJECT'), $body);
		$emailParams->addRecipients($options['schoolRow']->email);
        $principalId = $options['schoolRow']->principal_user_id;
		if ($principalId && !DilerHelperUser::isUserBlocked($principalId))
		{
			$principal = DGet::user($principalId);
			if($principalEmail = $principal->personalData()->email())
				$emailParams->addRecipients($principalEmail);
		}
		$sendActivationSchoolEmail = $registrationModel->sendMail($emailParams);

		if (!$sendActivationSchoolEmail)
		{
			throw new RuntimeException('Error sending school notification email. Please check with your DiLer Administrator.');
		}
		else
		{
			$message = DText::sprintf('BASE_SCHOOL_EMAIL_SCHOOL_SUCCESS', $options['schoolRow']->name);
		}
		return $message;
	}

	/**
	 * Updates data protection columns in school table.
	 * @param array $options
	 * @return true if update query successful, false otherwise.
	 */
	protected function updateSchoolTable($options)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->update('#__diler_school')
			->set('principal_name = ' . $db->quote($options['forename'] . ' ' . $options['surname']))
			->set('data_protection_officer_position = ' . $db->quote($options['data_protection_officer_position']))
			->set('data_protection_officer_name = ' . $db->quote($options['data_protection_officer_name']))
			->set('data_protection_officer_address = ' . $db->quote($options['data_protection_officer_address']))
			->set('data_protection_officer_phone = ' . $db->quote($options['data_protection_officer_phone']))
			->set('data_protection_officer_email = ' . $db->quote($options['data_protection_officer_email']))
			->set('data_protection_officer_deputy_position = ' . $db->quote($options['data_protection_officer_deputy_position']))
			->set('data_protection_officer_deputy_name = ' . $db->quote($options['data_protection_officer_deputy_name']))
			->set('data_protection_officer_deputy_address = ' . $db->quote($options['data_protection_officer_deputy_address']))
			->set('data_protection_officer_deputy_phone = ' . $db->quote($options['data_protection_officer_deputy_phone']))
			->set('data_protection_officer_deputy_email = ' . $db->quote($options['data_protection_officer_deputy_email']))
			->set('school_authorizing_officer_forename = ' . $db->quote($options['school_authorizing_officer_forename']))
			->set('school_authorizing_officer_surname = ' . $db->quote($options['school_authorizing_officer_surname']))
			->set('school_authorizing_officer_department = ' . $db->quote($options['school_authorizing_officer_department']))
			->set('school_authorizing_officer_address = ' . $db->quote($options['school_authorizing_officer_address']))
			->set('school_authorizing_officer_phone = ' . $db->quote($options['school_authorizing_officer_phone']))
			->set('school_authorizing_officer_email = ' . $db->quote($options['school_authorizing_officer_email']))
			->where('school_id = ' . $db->quote($options['school_serial_number']));
		return $db->setQuery($query)->execute();
	}

	private function getBaseSchoolNameById($schoolId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('name');
		$query->from('#__diler_school');
		$query->where('school_id = ' . $db->quote($schoolId));
		return $db->setQuery($query)->loadResult();
	}

}
