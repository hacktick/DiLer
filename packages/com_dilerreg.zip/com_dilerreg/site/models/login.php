<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

// import Joomla modelitem library


class DiLerregModelLogin extends BaseDatabaseModel {

	public function checkConfiguration()
	{
		// Check that global options for roles and groups are set up
		$params = ComponentHelper::getParams('com_diler');
		$adminGroups = $params->get('admin_group_ids', array());
		$teacherGroups = $params->get('teacher_group_ids', array());
		$studentGroups = $params->get('student_group_ids', array());
		$parentGroups = $params->get('parent_group_ids', array());
		$LGGroups = $params->get('learning_group_parent_id', array());
		return count($adminGroups) && count($teacherGroups) && count($studentGroups) && count($parentGroups) && count($LGGroups);
	}

	public function getApproved($userId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('approve')
			->from('#__dilerreg_users')
			->where('user_id = ' . (int) $userId);
		return $db->setQuery($query)->loadResult();
	}

    /**
     * Gets the menu item id for the loggedout view for the current language. Used for auto logout.
     *
     * @return int  menu item id for user in logged out query.
     * @throws Exception
     */
	public function getLoggedOutMenuItem()
	{
		$return = '';
		$thisLanguage = Factory::getLanguage()->getTag();
		$items = Factory::getApplication()->getMenu()->getItems(array('component', 'language'), array('com_dilerreg', $thisLanguage), false);
		foreach ($items as $item)
		{
			if (isset($item->query['view']) && $item->query['view'] == 'loggedout')
			{
				$return = $item->id;
				break;
			}
		}
		return $return;
	}

	/**
	 * Sends email to DiLer administrator (from login screen)
	 *
	 * @param string $replyToEmail
	 * @param string $message
	 *
	 * @throws Exception
	 */
	public function sendEmail($replyToEmail, $message, $recipient)
	{
		$app = Factory::getApplication();
		// Get the Mailer
		$mailer = Factory::getMailer();
		$params = ComponentHelper::getParams('com_diler');
		$loginContactformEmail = $params->get('loginContactformEmail');

		// Build email message format.
		$mailer->setSender($replyToEmail);
		$mailer->setSubject(Text::_('COM_DILERREG_LOGIN_EMAIL_SUBJECT'));
		$mailer->setBody($message);
		$mailer->addRecipient($recipient);
		$mailer->addReplyTo($replyToEmail);

		// Send the Mail
		$rs = $mailer->Send();

		// Check for an error
		if ($rs instanceof Exception)
		{
			throw new RuntimeException($rs->getMessage());
		}
		elseif (empty($rs))
		{
			throw new RuntimeException(Text::_('COM_DILERREG_LOGIN_EMAIL_ERROR'));
		}
		else
		{
			$result = (object) array('result' => 'success');
		}

		return $result;
	}

}