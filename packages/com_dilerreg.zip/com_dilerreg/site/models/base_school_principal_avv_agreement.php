﻿<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Core\Diglu;
use Joomla\CMS\Access\Exception\NotAllowed;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormFactoryInterface;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\FormModel;

JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

class DiLerregModelBase_school_principal_avv_agreement extends FormModel
{
    private $principalId;

    public function __construct($config = [], MVCFactoryInterface $factory = null, FormFactoryInterface $formFactory = null)
    {
        parent::__construct($config, $factory, $formFactory);
        $session = Factory::getApplication()->getSession();
        $this->principalId = $session->get('principal.id');
        if(!$this->principalId)
            throw new NotAllowed();
    }

    public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_dilerreg.Avvform', 'Avvform', array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

    protected function loadFormData()
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->select('s.data_protection_officer_position as school_data_protection_officer_position');
        $query->select('s.data_protection_officer_name as school_data_protection_officer_name');
        $query->select('s.data_protection_officer_address as school_data_protection_officer_address');
        $query->select('s.data_protection_officer_phone as school_data_protection_officer_phone');
        $query->select('s.data_protection_officer_email as school_data_protection_officer_email');
        $query->select('s.data_protection_officer_deputy_name as deputy_school_data_protection_officer_name');
        $query->select('s.data_protection_officer_deputy_position as deputy_school_data_protection_officer_position');
        $query->select('s.data_protection_officer_deputy_address as deputy_school_data_protection_officer_address');
        $query->select('s.data_protection_officer_deputy_phone as deputy_school_data_protection_officer_phone');
        $query->select('s.data_protection_officer_deputy_email as deputy_school_data_protection_officer_email');
        $query->from('#__dilerreg_users as du');
        $query->join('INNER', '#__diler_school as s ON du.user_id = s.contract_signed_by');
        $query->where('du.user_id = ' . $this->principalId);
        return $db->setQuery($query)->loadAssoc();
    }
}
