﻿<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Site\DTO\School\SchoolDTO;
use Audivisa\Component\DiLer\Site\Repository\Repository;
use DiLer\Core\Diglu\Email\RegistrationNotificationHelper;
use DiLer\Core\Repositories\RepositoryFactory;
use DiLer\Core\School\School;
use DiLer\DataProviders\DTO\SendEmailAboutRegistrationParams;
use DiLer\DConst;
use DiLer\DUrl;
use DiLer\Core\Diglu;
use Joomla\CMS\Factory;
use DiLer\Lang\DText;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Component\ComponentHelper;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

// import Joomla modelitem library

JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

class DiLerregModelEnrollStudent extends AdminModel
{

	/**
	 * Reg code created after save.
	 *
	 * @var int
	 */
	public $codeId = 0;

	/**
	 * Check that student id is valid student.
	 * Also check that student has a base school and that this school has a signed contract.
	 *
	 * @param array $options
	 * @return array : 'status', message
	 */
	public function checkStudentId($options)
	{
		$studentGroups = ComponentHelper::getParams('com_diler')->get('student_group_ids', [0]);
		$db = Factory::getDbo();
		$result = [];
		$studentId = mb_substr($options['studentId'], 2);
		$subQuery = $db->getQuery(true)->select('sh.user_id, s.name AS school_name, s.school_id AS student_base_school_id, s.contract_signed_by AS school_contract_signed_by')
				->select('s.base_school AS school_base_school_allowed, s.state_iso AS school_state')
				->from('#__diler_school AS s')
				->innerJoin('#__diler_user_school_history AS sh ON sh.user_id = ' . $db->quote($studentId) . ' AND sh.base_school = 1 AND sh.school_id = s.id')
				->group('sh.user_id');
		$query = $db->getQuery(true)->select('du.*, base.student_base_school_id, base.school_base_school_allowed, base.school_contract_signed_by')
				->select('base.school_name, base.school_state')
				->from('#__dilerreg_users AS du')
				->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = du.user_id AND uum.group_id IN(' . implode(',', $studentGroups) . ')')
				->leftJoin('(' . (string) $subQuery . ') AS base ON base.user_id = du.user_id')
				->where('LPAD(du.user_id, 6, "0") = ' . $db->quote($studentId))
				->where('du.forename LIKE ' . $db->quote(mb_substr($options['studentId'], 0, 1) . '%'))
				->where('du.surname LIKE ' . $db->quote(mb_substr($options['studentId'], 1, 1) . '%'));
		$row = $db->setQuery($query)->loadObject();
		if (isset($row->user_id) && $row->user_id && $row->student_base_school_id && $row->school_base_school_allowed && $row->school_contract_signed_by)
		{
			$schoolInfo = ['name' => $row->school_name, 'state' => $row->school_state, 'schoolId' => substr($row->student_base_school_id, 2)];
			$result = ['status' => 1, 'message' => $row->forename . ' ' . $row->surname, 'user_id' => $row->user_id, 'schoolInfo' => $schoolInfo,
				'options' => $options];
		}
		elseif (! isset($row->user_id) || ! $row->user_id)
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_INVALID_VALUE')];
		}
		elseif (! $row->student_base_school_id)
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_NO_BASE_SCHOOL')];
		}
		elseif (! $row->school_base_school_allowed)
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_INVALID_BASE_SCHOOL')];
		}
		else
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_CONTRACT_UNSIGNED')];
		}
		return $result;
	}

	/**
	 * Checks that school exists and has an email address.
	 *
	 * @param array $options Fields from entry form.
	 * @return array
	 */
	public function checkSchoolSerialNumber($options)
	{
		$db = Factory::getDbo();
		$result = [];
		$query = $db->getQuery(true)->select('s.*')
				->from('#__diler_school AS s')
				->where('s.school_id = ' . $db->quote($options['school_serial_number']))
				->where('s.published = 1');
		$row = $db->setQuery($query)->loadObject();
		$baseSchoolInvalid = isset($row->id) && $options['baseSchool'] && ! $row->base_school;
		if (isset($row->id) && $row->id && $row->email && ! $baseSchoolInvalid)
		{
			$result = ['status' => 1, 'message' => $row->name, 'id' => $row->id, 'row' => $row];
		}
		elseif (! isset($row->id))
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_INVALID_SCHOOL')];
		}
		elseif ($baseSchoolInvalid)
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_NOT_BASE_SCHOOL')];
		}
		else
		{
			$result = ['status' => 0, 'message' => DText::_('BRANCH_FORM_INVALID_SCHOOL_EMAIL')];
		}
		return $result;
	}

	/**
	 * Processes a new branch teacher. creates registration code and sends emails.
	 * @param array $options : 'student_id', 'school_serial_number', 'forename', 'surname', 'salutation', 'branch_school_email'
	 * @return stdClass
	 * @throws Exception
	 */
	public function createBranchTeacherCode($options)
	{
		// Check that studentId is valid student
		$validStudent = $this->checkStudentId(['studentId' => $options['student_id']]);
		if ($validStudent['status'] !== 1)
		{
			throw new RuntimeException('This is not a valid student.');
		}
		$checkSchoolResult = $this->checkSchoolSerialNumber($options);
		if (! ($checkSchoolResult['status']))
		{
			throw new RuntimeException($checkSchoolResult['message']);
		}

		$regCodeMsg = $this->createRegCodeRow($options); // currently not used
		$mapMsg = $this->createMapRow($options, $validStudent, $checkSchoolResult);

		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')->from('#__dilerreg_registration_codes')->where('id = ' . $this->codeId);
		$codeRow = $db->setQuery($query)->loadObject();
		$school = RepositoryFactory::school()->loadById($checkSchoolResult['row']->id);
		$schoolEmailMsg = $this->sendSchoolEmail($options, $codeRow, $checkSchoolResult, $validStudent, $school);
		$teacherEmailMsg = $this->sendBranchTeacherEmail($options, $validStudent, $school) . '<br><br>';
		$this->notifiRelatedUsersOfSchool($options, $validStudent, $school);
		if (!$options['baseSchool'])
		{
			$repository = new Repository($this->getDbo());
			$schoolInfo = $validStudent['schoolInfo'];
			$schoolSerialNumber = $schoolInfo['state'] . $schoolInfo['schoolId'];
			$schoolData = (array) $repository->school()->loadBySchoolSerialNumber($schoolSerialNumber);
			$schoolDTO = new SchoolDTO($schoolData);

			if ($schoolData)
				$this->notifiBaseSchoolRelatedUsersAboutBranchSchoolEnrollment($options, $validStudent, $school, $schoolDTO);
		}
		$message = [$schoolEmailMsg, $teacherEmailMsg, $mapMsg];
		return (object) ['status' => 1, 'message' => implode('', $message)];
	}

	/**
	 * Creates new row in dilerreg_code table.
	 *
	 * @param array $options Fields from entry form.
	 * @return string Success message.
	 *
	 * @throws Exception
	 */
	protected function createRegCodeRow($options)
	{
		$message = '';
		BaseDatabaseModel::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_dilerreg/models');
		$codeModel = BaseDatabaseModel::getInstance('Code', 'DilerregModel');
		$params = ComponentHelper::getParams('com_diler');
		$teacherGroup = ($options['baseSchool']) ? $params->get('base_school_teacher_group_id', 0) : $params->get('branch_school_teacher_group_id', 0);
		if (! $teacherGroup) throw new RuntimeException('No Branch or Base Teacher Group setup.');

		$codeData = ['dilerrolegroup' => $teacherGroup, 'first_name' => $options['forename'], 'last_name' => $options['surname'], 'lg' => ''];
		$codeCreate = $codeModel->save($codeData);
		if ($codeCreate)
		{
			$message = Text::sprintf('COM_DILERREG_REGCODE_SUCCESS', $codeData['first_name'] . ' ' . $codeData['last_name']);
			$this->codeId = $codeModel->getState($codeModel->getName() . '.id');
		}
		else
		{
			throw new RuntimeException('Unable to create new Registration Code for ' . $codeData['first_name'] . ' ' . $codeData['last_name']);
		}
		return $message;
	}

	/**
	 * Creates row in dilerreg_registration_code_user_map table for student and teacher.
	 *
	 * @param array $options Fields from entry form
	 * @param stdClass $validStudent
	 * @param stdClass $checkSchoolResult
	 * @return string Success message if no exception.
	 *
	 * @throws RuntimeException
	 */
	protected function createMapRow($options, $validStudent, $checkSchoolResult)
	{
		// Create student-reg-code row
		$teacherName = $options['forename'] . ' ' . $options['surname'];
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->insert('#__dilerreg_registration_code_user_map')
				->set('code_id = ' . $this->codeId)
				->set('user_id = ' . $validStudent['user_id'])
				->set('school_id = ' . $checkSchoolResult['id'])
				->set('base_school_teacher = ' . (int) $options['baseSchool']);
		if (! empty($options['enroll_start']))
		{
			$query->set('enroll_start = ' .  $db->quote(DilerHelperUser::dateFromString($options['enroll_start'])));
		}
		if (! empty($options['enroll_end']))
		{
			$query->set('enroll_end = ' .  $db->quote(DilerHelperUser::dateFromString($options['enroll_end'])));
		}
		$mapInsert = $db->setQuery($query)->execute();
		if ($mapInsert)
		{
			$message = DText::sprintf('REGCODE_MAP_SUCCESS', $teacherName, $validStudent['message']);
		}
		else
		{
			throw new RuntimeException('Unable to create new Registration Code map row for teacher ' . $teacherName .
					' and student ' . $validStudent['message']);
		}
		return $message;
	}

	/**
	 * Gets emails for any Diglu trainers for the school's country/state.
	 *
	 * @param stdClass $schoolRow Row from school table (for student's base school)
	 * @return array of email addresses.
	 */
	protected function getDigluTrainerEmails($schoolRow)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('ju.email')
				->from('#__dilerreg_users AS du')
				->innerJoin('#__users AS ju ON ju.id = du.user_id')
				->where('du.diglu_trainer_country = ' . $db->quote($schoolRow->country_iso2))
				->where('du.diglu_trainer_state = ' . $db->quote($schoolRow->state_iso))
				->where('du.acceptedterms = "1"')
				->where('du.approve = "1"');
		return $db->setQuery($query)->loadColumn();
	}

	/**
	 * Get the registration edit form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 *
	 * @since 1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_dilerreg.enrollstudent', 'enrollstudent', array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

    /**
     *
     * @param array $options
     * @return array of email addresses
     */
	protected function getOtherTeachers(array $options, array $checkSchoolResult)
	{
		// Get base school information
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$studentId = (int) substr($options['student_id'], 2);
		$baseSchoolInfo = MVCHelper::factory()->createModel('Student', 'Site')->getStudentBaseSchool($studentId);
		// Get region teacher for branch school - region for branch school from region_id of school table, teachers for region from region_user_map
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('ju.email')
				->from('#__diler_school AS sch')
				->innerJoin('#__diler_region AS r ON sch.postal_code = r.postal_code')
				->innerJoin('#__diler_region_user_map AS rum ON rum.region_id = r.id')
				->innerJoin('#__users AS ju ON ju.id = rum.user_id')
				->where('sch.school_id = ' . $db->quote($options['school_serial_number']) . ' OR sch.school_id = ' . $db->quote($baseSchoolInfo->school_id));
		$regionTeachers = $db->setQuery($query)->loadColumn();
		$digluTrainerEmailArray = $this->getDigluTrainerEmails($baseSchoolInfo);
		$result = (is_array($regionTeachers) && count($regionTeachers)) ? $regionTeachers : [];
		if (is_array($digluTrainerEmailArray) && $digluTrainerEmailArray)
			$result = array_merge($result, $digluTrainerEmailArray);
		return array_unique($result);
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return array The data for the form.
	 * @since 5.0
	 */
	protected function loadFormData()
	{
		if (empty($data))
		{
			$data = array();
		}
		return $data;
	}

	/**
	 * Sends email to branch teacher upon branch school registration.
	 *
	 * @param array $options Fields from entry form.
	 * @return string Success message.
	 * @throws RuntimeException
	 */
	protected function sendBranchTeacherEmail($options, $validStudent, School $school)
	{
		$postalCode = $school->address()->postalCode();
		$regionTeacherUserIds = $this->getRegionTeacherUserIdBySchoolPostalCode($postalCode);
		$regionTeacherInfos = $this->getRegionTeacherInfoByUserId($regionTeacherUserIds);
		$teacherInfoStrings = [];
		if (!empty($regionTeacherInfos)) {
			foreach ($regionTeacherInfos as $teacherInfo) {
				$phone = $teacherInfo['phonemobile'] ? $teacherInfo['phonemobile'] . ', ' : '';
				$teacherInfoStrings[] = sprintf(
					'%s %s (%s%s)',
					$teacherInfo['forename'],
					$teacherInfo['surname'],
					$phone,
					$teacherInfo['email']
				);
			}
		}
		$formattedTeacherInfos = !empty($teacherInfoStrings) ? DText::sprintf('CONTACT_YOUR_REGION_TEACHER', implode(', ', $teacherInfoStrings)): '';
		if ($options['baseSchool'])
		{
			$subject = DText::_('BASE_TEACHER_EMAIL_SUBJECT');
			$body = DText::sprintf('BASE_TEACHER_EMAIL_BODY', $options['forename'] . ' ' . $options['surname']);
		}
		else
		{
			$subject = DText::_('REGCODE_BRANCH_TEACHER_EMAIL_SUBJECT');
			$body = DText::sprintf('BRANCH_TEACHER_EMAIL_BODY',
				$options['forename'] . ' ' . $options['surname'],
				$formattedTeacherInfos
			);
		}
		/** @var DiLerregModelRegistration $registrationModel */
		$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');

		$emailParams = new SendEmailAboutRegistrationParams($subject, $body);
		$emailParams->addRecipients($options['branch_teacher_email']);
		if (!$registrationModel->sendMail($emailParams))
		{
			throw new RuntimeException('Error sending Branch Teacher email. Please check with your DiLer Administrator.');
		}
		else
		{
			$result = DText::sprintf('REGCODE_EMAIL_BRANCH_TEACHER_SUCCESS', $options['forename'] . ' ' . $options['surname']);
		}
		return $result;
	}

	protected function notifiRelatedUsersOfSchool($options, $validStudent, $school)
	{
		$teacherName = $options['forename'] . ' ' . $options['surname'];
		$studentName = $validStudent['message'];
		$schoolName = $school->name();
		$schoolId = $school->id();
		$registrationNotificationHelper = new RegistrationNotificationHelper($schoolId, 0);
		$relatedUsers = $registrationNotificationHelper->getRelatedTeacherNamesAndEmailByIds();
		foreach ($relatedUsers as $relatedUser)
		{
			if ($options['baseSchool'])
			{
				$subject = DText::sprintf('DEFAULT_EMAIL_STUDENT_ENROLLMENT_BASE_SCHOOL_SUBJECT', $schoolName, $studentName);
				$body    = DText::sprintf('DEFAULT_EMAIL_STUDENT_ENROLLMENT_BASE_SCHOOL_BODY',
					$schoolName,
					$studentName,
					$teacherName,
					$school->registerNumber(),
					$school->address()->postalCode(),
					$school->address()->city(),
					$school->address()->street(),
					$relatedUser->name
				);
			}
			else
			{
				$subject = DText::sprintf('DEFAULT_EMAIL_STUDENT_ENROLLMENT_BRANCH_SCHOOL_SUBJECT', $schoolName, DText::_('STUDENT'), $studentName);
				$body    = DText::sprintf('DEFAULT_EMAIL_STUDENT_ENROLLMENT_BRANCH_SCHOOL_BODY',
					$schoolName,
					$studentName,
					$teacherName,
					DText::_('STUDENT'),
					$school->registerNumber(),
					$school->address()->postalCode(),
					$school->address()->city(),
					$school->address()->street(),
					$relatedUser->name
				);
			}

			/** @var DiLerregModelRegistration $registrationModel */
			$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');

			$emailParams = new SendEmailAboutRegistrationParams($subject, $body);
			$emailParams->setDigluRelatedRecipients($relatedUser);
			$registrationModel->sendMail($emailParams);
		}
	}


	private function notifiBaseSchoolRelatedUsersAboutBranchSchoolEnrollment($options, $validStudent, $school, SchoolDTO $baseSchool)
	{
		$teacherName                    = $options['forename'] . ' ' . $options['surname'];
		$studentName                    = $validStudent['message'];
		$branchSchoolName               = $school->name();
		$registrationNotificationHelper = new RegistrationNotificationHelper($baseSchool->id, 0);
		$relatedUsers = $registrationNotificationHelper->getRelatedTeacherNamesAndEmailByIds();
		foreach ($relatedUsers as $relatedUser)
		{
			$subject = DText::sprintf('DEFAULT_EMAIL_STUDENT_ENROLLMENT_BRANCH_SCHOOL_NOTIFICATION_TO_BASE_SCHOOL_SUBJECT', $branchSchoolName, $studentName, DText::_('STUDENT'));
			$body    = DText::sprintf('DEFAULT_EMAIL_STUDENT_ENROLLMENT_BRANCH_SCHOOL_NOTIFICATION_TO_BASE_SCHOOL_BODY',
				$branchSchoolName,
				DText::_('STUDENT'),
				$studentName,
				$teacherName,
				$studentName,
				$baseSchool->name,
				$baseSchool->postalCode,
				$baseSchool->city,
				$school->registerNumber(),
				$school->address()->postalCode(),
				$school->address()->city(),
				$school->address()->street(),
				$baseSchool->schoolId,
				$baseSchool->address,
				$relatedUser->name
			);

			/** @var DiLerregModelRegistration $registrationModel */
			$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');

			$emailParams = new SendEmailAboutRegistrationParams($subject, $body);
			$emailParams->setDigluRelatedRecipients($relatedUser);
			$registrationModel->sendMail($emailParams);
		}
	}
	/**
	 * Send school email to branch school email.
	 *
	 * @param array $options
	 * @param stdClass $codeRow
	 * @param stdClass $checkSchoolResult
	 * @return string Success message if no exception.
	 *
	 * @throws RuntimeException
	 */
	private function getRegionTeacherUserIdBySchoolPostalCode($postalCode)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('drum.user_id')
			->from('#__diler_region_user_map AS drum')
			->innerJoin('#__diler_region AS dr ON drum.region_id = dr.id')
			->innerJoin('#__diler_school AS ds ON dr.postal_code = ds.postal_code')
			->where('dr.postal_code = ' . $db->quote($postalCode));
		return $db->setQuery($query)->loadColumn();
	}

	private function getRegionTeacherInfoByUserId($userIds)
	{
		if (empty($userIds)) {
			return [];
		}

		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('du.forename, du.surname, ju.email, du.phonemobile')
			->from('#__dilerreg_users AS du')
			->innerJoin('#__users AS ju ON ju.id = du.user_id')
			->where('du.user_id IN (' . implode(',', array_map([$db, 'quote'], $userIds)) . ')');

		return $db->setQuery($query)->loadAssocList();
	}


	protected function sendSchoolEmail($options, $codeRow, $checkSchoolResult, $validStudent, School $school)
	{
		$link = DUrl::getEntrollStudentLink($options['report_type_id'], $options['itemId'], $codeRow->code, $options['baseSchool']);
		$linkTag = '<a href="' . $link . '">' . DText::_('BRANCH_TEACHER_ACTIVATION_LINK_TEXT') . '</a>';
		$postalCode = $school->address()->postalCode();
		$regionTeacherUserIds = $this->getRegionTeacherUserIdBySchoolPostalCode($postalCode);
		$regionTeacherInfos = $this->getRegionTeacherInfoByUserId($regionTeacherUserIds);
		$teacherInfoStrings = [];
		if (!empty($regionTeacherInfos)) {
			foreach ($regionTeacherInfos as $teacherInfo) {
				$phone = $teacherInfo['phonemobile'] ? $teacherInfo['phonemobile'] . ', ' : '';
				$teacherInfoStrings[] = sprintf(
					'%s %s (%s%s)',
					$teacherInfo['forename'],
					$teacherInfo['surname'],
					$phone,
					$teacherInfo['email']
				);
			}
		}
		$formattedTeacherInfos = !empty($teacherInfoStrings) ? DText::sprintf('CONTACT_YOUR_REGION_TEACHER', implode(', ', $teacherInfoStrings)): '';
		if ($options['baseSchool'])
		{
			$subject = DText::_('BASE_SCHOOL_EMAIL_SUBJECT');
			$body = DText::sprintf('BASE_SCHOOL_ENROLL_EMAIL_BODY',
				$validStudent['message'],
				$options['forename'] . ' ' . $options['surname'],
				$linkTag,
				$codeRow->code,
				$formattedTeacherInfos,
			);
		}
		else
		{
			$subject = DText::_('REGCODE_BRANCH_TEACHER_EMAIL_SUBJECT');
			$body = DText::sprintf('REGCODE_BRANCH_TEACHER_EMAIL_BODY',
				$validStudent['message'],
				$options['forename'] . ' ' . $options['surname'],
				$linkTag,
				$codeRow->code,
				$formattedTeacherInfos,
			);
		}

		/** @var DiLerregModelRegistration $registrationModel */
		$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');

		$emailParams = new SendEmailAboutRegistrationParams($subject, $body);
		$emailParams->addRecipients($school->address()->email());

		if (!$registrationModel->sendMail($emailParams))
		{
			throw new RuntimeException('Error sending school notification email. Please check with your DiLer Administrator.');
		}
		else
		{
			$result = DText::sprintf('REGCODE_EMAIL_SCHOOL_SUCCESS', $checkSchoolResult['message']);
		}
		return $result;
	}

    public function checkIsBranchTeacherPublished($options): object
    {
        $db = Factory::getDbo();
        $result = (object) ['status' => 1, 'message' => ''];
        $query = $db->getQuery(true);
        $query->select('ju.block, ju.email, ju.name, du.role');
        $query->from('#__users AS ju');
        $query->innerJoin('#__dilerreg_users du on ju.id = du.user_id');
        $query->where('ju.email =' . $db->quote($options['branch_teacher_email']));
        $row = $db->setQuery($query)->loadObject();
        if ($row->email && $row->block == 1 && $row->role == DConst::USER_ROLE_TEACHER)
        {
            $result->status = 0;
            $result->message = DText::sprintf('UNPUBLISHED_USER_EMAIL', $row->name);
            $result->data = $row;
        }
        elseif ($row->email && $row->role !== DConst::USER_ROLE_TEACHER)
        {
            $result->status = 0;
            $result->message = DText::sprintf('NOT_A_TEACHERS_EMAIL', $row->role, $row->name);
            $result->data = $row;
        }
        else
        {
            $result->status = 1;
            $result->message = '';
        }
        return $result;
    }
}
