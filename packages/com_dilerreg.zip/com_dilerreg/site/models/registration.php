<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Core\Consents\Consent;
use DiLer\Core\Consents\DeclarationConsent;
use DiLer\Core\Diglu;
use DiLer\Core\Diglu\Email\RegistrationNotificationHelper;
use DiLer\Core\Repositories\RepositoryFactory;
use DiLer\Core\School\School;
use DiLer\DataProviders\DTO\SendEmailAboutRegistrationParams;
use DiLer\DConst;
use DiLer\DDateTime;
use DiLer\DGet;
use DiLer\DMailer;
use DiLer\Formatters\EmailFooter;
use DiLer\Users\DUser;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use Joomla\CMS\User\UserHelper;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use DiLer\Lang\DText;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\Registry\Registry;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;
use \Audivisa\Component\DiLer\Site\Model;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

// import Joomla modelitem library

JLoader::register('DilerHelperPdf', JPATH_ROOT . '/components/com_diler/helpers/pdf.php');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

class DiLerregModelRegistration extends AdminModel
{
	public $messageInfo = ['teacherName' => '', 'newGroupName' => '', 'lgTeacherNames' => '', 'studentName' => '', 'studentBaseSchoolName' => '',
		'existingGroupName' => ''];

	protected $regCodeRow = null;

	protected $schoolInfo = null;

	protected $messages = [];
	protected $errors = [];
	protected $debug = 0;

    // Creates the contract pdf file.
	protected function baseSchoolCreateContractPdf($debug = false)
	{
		$contractInfo = $this->getContractText($this->regCodeRow->report_type_id, $this->regCodeRow->code);
		$contractContent = $contractInfo['html'];
		$cssLink = $contractInfo['cssLink'];
		$params = ComponentHelper::getParams('com_diler');
		$format = $params->get('printFormat', 'a4');
		if ($debug)
		{
			$baseFolder = Factory::getConfig()->get('tmp_path') . '/diler';
		}
		else
		{
			$baseFolder = $params->get('file_root_folder') . '/contracts';
		}
		if (! file_exists($baseFolder))
		{
			Folder::create($baseFolder);
		}
		$layoutInputs = DilerHelperPdf::getLayoutInputs($contractContent);
		$pageMargin = $layoutInputs->get('contractPageMargin','20mm 0mm 0mm 15mm'); // @page and html are the same entity for dompdf
		$footer = $layoutInputs->get('contractFooterText','');
		$header = $layoutInputs->get('contractHeaderText','');
		$headerPositionH = $layoutInputs->get('contractHeaderPositionH','42');
		$footerPositionH = $layoutInputs->get('contractFooterPositionH','42');
		$headerPositionV = $layoutInputs->get('contractHeaderPositionV','25');
		$footerPositionV = $layoutInputs->get('contractFooterPositionV','30');
		$headerStartPage = $layoutInputs->get('contractHeaderStartPage','1');
		$footerStartPage = $layoutInputs->get('contractFooterStartPage','1');
		$startPageCount = $layoutInputs->get('contractPageCountStart','1');
		$fileName = $this->baseSchoolGetPdfFilename();
		$nameFind = ['{SCHOOLSTATE}', '{SCHOOLCITY}', '{SCHOOLNAME}', '{SCHOOLID}'];
		$nameReplace = [$this->schoolInfo->school_state, $this->schoolInfo->school_city, $this->schoolInfo->school_name, $this->schoolInfo->school_id];
		$fileName = str_replace($nameFind, $nameReplace, $fileName);
		$fileName = substr($fileName, -4) !== '.pdf' ? $fileName . '.pdf' : $fileName;
		$dilerCssContent = DilerHelperPdf::getDilerPdfCssContent();
		$contractCssContent= DilerHelperPdf::getContractCSSContent($contractInfo['layoutFile']);

		$htmlOutput = '
			<!DOCTYPE html><html class="pdf"><head><meta content="text/html;charset=utf-8" http-equiv="Content-Type"><meta content="utf-8" http-equiv="encoding"><style>' .
				$dilerCssContent .
				$contractCssContent .
				' html {margin: ' . $pageMargin. ';}</style></head><body>' .
				str_replace('src="/', 'src="//' . $_SERVER['HTTP_HOST'] . '/', $contractContent) .
			'</body></html>';
		if ($debug)
		{
			$debugPath = Factory::getConfig()->get('tmp_path') . '/diler/pdf-output.html';
			$debugFile = fopen($debugPath, 'w');
			fwrite($debugFile, $htmlOutput);
			fclose($debugFile);
		}
		require_once ( JPATH_ROOT . '/libraries/vendor/dompdf/autoload.inc.php');
		$pdf = new Dompdf\Dompdf();
		$pdf->set_option('isHtml5ParserEnabled', true);
		$pdf->set_option("isPhpEnabled", true);
		$pdf->set_paper($format, 'portrait');

		$pdf->load_html($htmlOutput);
		$pdf->render();
		$canvas = $pdf->get_canvas();
		$canvas->set_page_count($canvas->get_page_count() + 1 - $startPageCount);
		$footerPositionV = $canvas->get_height() - $footerPositionV;
		$canvasPageScript = DilerHelperPdf::getCanvasPageScript($startPageCount, $footer, $footerStartPage, $footerPositionH, $footerPositionV, $header, $headerStartPage, $headerPositionH, $headerPositionV);
		$canvas->page_script($canvasPageScript);

        return true;
	}

	protected function baseSchoolGetPdfFilename()
	{
        return 'avv-' . $this->schoolInfo->school_state . '-' . $this->schoolInfo->school_id . '.pdf';
	}

	protected function baseSchoolSendConfirmEmails($data)
	{
		$emailDate = HTMLHelper::_('date', '', Text::_('DATE_FORMAT_LC'));
		$emailLink = '<a href="' . Route::_(Uri::base()) . '">' . DText::_('SITE_URL') . '</a>';
		// Send principal email
		$principalSubject = DText::_('BASE_SCHOOL_CONTRACT_EMAIL_SUBJECT_PRINCIPAL');
		$principalBody = DText::sprintf('BASE_SCHOOL_CONTRACT_EMAIL_BODY_PRINCIPAL', $data['forename'] . ' ' . $data['surname'], $this->regCodeRow->contract_name, $emailDate);
		$emailParams = new SendEmailAboutRegistrationParams($principalSubject, $principalBody);
		$emailParams->addRecipients($this->schoolInfo->school_email);
		$this->sendMail($emailParams);

		$registrationNotificationHelper = new RegistrationNotificationHelper($this->schoolInfo->id, 0);
		$relatedUsers = $registrationNotificationHelper->getRelatedTeacherNamesAndEmailByIds();
		foreach ($relatedUsers as $user)
		{
		// Send other emails
		$subject = DText::sprintf('BASE_SCHOOL_CONTRACT_EMAIL_SUBJECT',
			$this->schoolInfo->school_name,
			$this->schoolInfo->school_id,
			$this->schoolInfo->school_city);
		$schoolPostalCode = $this->schoolInfo->school_postal_code;
		$schoolCountInfo  = $this->getSchoolCounts(); // total_base_schools, schools_signed
			$mailerBody       = DText::sprintf('BASE_SCHOOL_CONTRACT_EMAIL_BODY',
				$emailDate,
				$this->regCodeRow->contract_name,
				$this->schoolInfo->school_name,
				$data['forename'] . ' ' . $data['surname'],
				$this->schoolInfo->school_id,
				$this->schoolInfo->school_city,
				$schoolCountInfo->schools_signed,
				$schoolCountInfo->total_base_schools,
				$this->schoolInfo->school_state,
				$schoolPostalCode,
				$this->schoolInfo->school_address,
				$user->name
			);
			$otherEmailParams = new SendEmailAboutRegistrationParams($subject, $mailerBody);
			$otherEmailParams->setDigluRelatedRecipients($user);
			$this->sendMail($otherEmailParams);
		}
		return true;
	}

	/**
	 * Updates the contract signed columns in the base school row.
	 * @param int $userId
	 * @return bool true on success.
	 */
	protected function baseSchoolUpdateSchoolColumns($userId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_school')
				->set('contract_type_id = ' . $db->quote($this->regCodeRow->report_type_id))
				->set('contract_signed_date = ' . $db->quote(Factory::getDate()->toSql()))
				->set('contract_signed_by = ' . (int) $userId)
				->set('contract_file_name = ' . $db->quote($this->baseSchoolGetPdfFilename()))
				->set('principal_name = ' . $db->quote($this->regCodeRow->first_name . ' ' . $this->regCodeRow->last_name))
                ->set('principal_user_id = ' . $db->quote($userId))
				->where('school_id = ' . $db->quote($this->schoolInfo->school_id));
		return $db->setQuery($query)->execute();
	}

	/**
	 * Assigns teacher, student, and student's LG teachers to newly created Other group
	 * @param int $newGroupId  id of group from diler_group table
	 * @param array $userIdArray  array of id's to assign to the group
	 */
	protected function branchTeacherAddUsersToGroup($newGroupId, $userIdArray)
	{
		// Remove any users who are already in this group
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('m.user_id')
				->from('#__user_usergroup_map AS m')
				->innerJoin('#__diler_group AS dg ON dg.joomla_group_id = m.group_id')
				->where('dg.id = ' . (int) $newGroupId);
		$assignedUsers = $db->setQuery($query)->loadColumn();
		$usersAlreadyAssigned = (is_array($assignedUsers) && count($assignedUsers)) ? array_intersect($userIdArray, $assignedUsers) : [];
		$usersToAssign = array_diff($userIdArray, $usersAlreadyAssigned);
		if (! $usersToAssign) return true;
		// Create group array with groupId => array of user id's
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$usergroupModel = MVCHelper::factory()->createModel('Usergroup', 'Site');
		$groupRow = MVCHelper::factory()->createModel('Group', 'Site')->getDilerGroup($newGroupId);
		$groupUserArray = [$groupRow->joomla_group_id => $usersToAssign];
		$result = $usergroupModel->addUsersToUsergroup($groupUserArray);
		return $result;
	}

	// Creates the new DiLer group in "Other" category with group name = teacher surname
	protected function branchTeacherCreateGroup($codeData, $teacherId, $newTeacher)
	{
		// If this is an existing teacher, see if we already have an "Other" group for this teacher.
		if (! $newTeacher)
		{
			$existingGroupId = $this->branchTeacherFindExistingGroup($teacherId);
			if ($existingGroupId) return $existingGroupId;
		}
		$newGroupCatId = $this->getNewGroupCatId();
		$otherGroupParentId = ComponentHelper::getParams('com_diler')->get('other_group_parent_id');
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		Table::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_diler/tables');
		$groupModel = Factory::getApplication()->bootComponent('com_diler')->getMVCFactory()->createModel('Group', 'Site', ['ignore_request' => true]);
		$groupData = [];
		$newGroupId = 0;
		if ($newGroupCatId)
		{
			$groupData['catid'] = $newGroupCatId;
			$groupData['name'] = $this->branchTeacherGetUniqueGroupName($teacherId);
			$groupData['published'] = 1;
			$groupData['description'] = Text::sprintf('COM_DILERREG_REGCODE_GROUP_CREATE_DESC', DText::_('TEACHER'), $codeData['forename'] . ' ' . $codeData['surname']);
			$groupData['group_type'] = 4;
			$groupData['id'] = 0;
			$groupData['parent_id'] = $otherGroupParentId;
			$result = $groupModel->save($groupData);
			if ($result)
			{
                if (isset($groupModel->groupId)){
                    $newGroupId = $groupModel->groupId;
                } elseif ($groupModel->getState('group.id')){
                    $newGroupId = $groupModel->getState('group.id');
                } elseif (is_object($groupModel->state) && method_exists($groupModel->state, 'get')){
                    $newGroupId = $groupModel->state->get('group.id');
                } else {
                    $stateArray = (array)$groupModel->state;
                    $newGroupId = $stateArray['group.id'] ?? 0;
                }
				$this->messageInfo['newGroupName'] = $groupData['name'];
			}
		}
		return $newGroupId;
	}

	/**
	 * Checks if there is already a group of group_type=4 (Other) for this teacher.
	 * @param int $teacherId
	 * @return int id of existing group or 0 if not found.
	 */
	protected function branchTeacherFindExistingGroup($teacherId)
	{
		$teacher = Factory::getUser($teacherId);
		$teacherGroups = $teacher->getAuthorisedGroups();
		if (! is_array($teacherGroups) || ! $teacherGroups) return 0;
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('g.name, g.id, g.joomla_group_id, c.title AS cat_title, c.params AS cat_params')
				->from('#__diler_group AS g')
				->innerJoin('#__categories AS c ON c.id = g.catid')
				->where('g.name LIKE ' . $db->quote($teacher->username . '%'))
				->where('g.joomla_group_id IN(' . implode(',', $teacherGroups) . ')');
		$dilerGroups = $db->setQuery($query)->loadObjectList();
		if (! is_array($dilerGroups) || ! $dilerGroups) return 0;
		// Find the first "Other" group (group_type=4) and return the id
		$result = 0;
		foreach ($dilerGroups as $group)
		{
			$params = new Registry($group->cat_params);
			if ($params->get('group_type', '0') === '4')
			{
				$result = $group->id;
				$this->messageInfo['existingGroupName'] = $group->name;
				break;
			}
		}
		return $result;
	}

	// Makes sure the group name is unique. Try using surname. If not unique, add extra digits.
	protected function branchTeacherGetUniqueGroupName($teacherId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('COUNT(*)')
				->from('#__diler_group');
		$count = 1;
		$loopCount = 0;
		$teacherUser = Factory::getUser($teacherId);
		$testName = $teacherUser->username;
		while ($count !== 0 && $loopCount < 99)
		{
			$query->clear('where')->where('name = ' . $db->quote($testName));
			$count = (int) $db->setQuery($query)->loadResult();
			$groupName = $testName;
			$loopCount++;
			$testName = $teacherUser->username . str_pad($loopCount, 2, '0', STR_PAD_LEFT);
		}
		return $groupName;
	}

	/**
	 * Checks that email is not already used. Called from jQuery validator.
	 *
	 * @param array $data
	 * @return string "true" if not used, error message otherwise.
	 */
	protected function checkEmail($data)
	{
		$result = "true";
		if (DMailer::isEmailInUse($data['email']))
		{
			$result = Text::_('COM_DILERREG_DUPLICATE_EMAIL');
		}
		return $result;
	}

    /**
     * Checks password using PasswordRule.
     *
     * @param array $data
     * @return string "true" if password is valid, error messages otherwise.
     * @throws Exception
     */
	protected function checkPassword($data)
	{
		$result = 'true';
		$elementString = '<field name="password" type="text" required="true" />';
		$element = new SimpleXMLElement(trim($elementString));
		$valid = (new Joomla\CMS\Form\Rule\PasswordRule())->test($element, $data['password']);
		if (! $valid)
		{
			$errorMessages = [];
			$messageQueue = Factory::getApplication()->getMessageQueue();
			foreach ($messageQueue as $queue)
			{
				$errorMessages[] = $queue['message'];
			}
			$result = implode('</br>', $errorMessages);
		}
		return $result;
	}

    /**
     * Processes jQuery Validator remote method for registration form.
     *
     * @param array $data
     * @return string "true" if valid, error message otherwise.
     * @throws Exception
     */
	public function checkRegForm($data)
	{
		return ($data['field'] === 'password') ? $this->checkPassword($data) : $this->checkEmail($data);
	}

	/**
	 * Deletes map row for code
	 * @param int $codeId
	 * @return bool true on success
	 */
	protected function deleteMapRow($codeId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
				->delete('#__dilerreg_registration_code_user_map')
				->where('code_id = ' . (int) $codeId);
		return $db->setQuery($query)->execute();
	}

	/**
	 * Deletes reg code
	 *
	 * @param string $code
	 * @return bool true on success
	 */
	protected function deleteRegistrationCode($code)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->delete('#__dilerreg_registration_codes')
			->where('code = ' . $db->quote($code));
		return $db->setQuery($query)->execute();
	}

	protected function getContractCssLink($layoutName)
	{
		$layoutPath = '/templates/diler3/html/com_diler/contract_layouts/';
		$cssSrc = $layoutPath . $layoutName . '.css';
		$mediaVersion = Factory::getDocument()->getMediaVersion();
		$cssLink = '<link rel="stylesheet" id="contractCssLink" type="text/css" href="' . Joomla\CMS\Uri\Uri::root(true) . $cssSrc . '?v=' . $mediaVersion . '" />';
		return $cssLink;
	}

	/**
	 * Gets the filled in contract from the layout and reg code.
	 *
	 * @param int $reportTypeId
	 * @param int $registrationCode
	 * @return string Contract text with fields filled in.
	 */
	public function getContractText($reportTypeId, $registrationCode)
	{
		if (! isset($this->regCodeRow->code))
		{
			$this->regCodeRow = $this->getRow(['idValue' => $registrationCode, 'table' => '#__dilerreg_registration_codes', 'idColumn' => 'code',
					'joinTable' => '#__diler_report_type AS rt ON rt.id = a.report_type_id', 'joinSelect' => 'rt.name AS contract_name']);
			if ($this->debug)
			{
				$this->baseSchoolCreateContractPdf(true);
			}
		}
		if (! isset($this->regCodeRow->base_school_id) || ! $this->regCodeRow->base_school_id || ! $this->regCodeRow->report_type_id)
		{
			// Not a valid reg code
			return '';
		}
		$reportTypeRow = $this->getRow(['idValue' => $reportTypeId, 'table' => '#__diler_report_type', 'idColumn' => 'id']);
		$this->schoolInfo = $this->getSchoolInfo($this->regCodeRow->base_school_id);
		$layoutFile = $reportTypeRow->layout_file_name;
		$cssLink = $this->getContractCssLink($reportTypeRow->layout_file_name);
		$html = LayoutHelper::render($layoutFile, ['schoolInfo' => $this->schoolInfo], JPATH_ROOT . '/templates/diler3/html/com_diler/contract_layouts');
		$result = ['html' => $html, 'name' => $reportTypeRow->name, 'cssLink' => $cssLink, 'layoutFile' => $layoutFile];
		return $result;
	}

	protected function getRow($options)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('a.*')
				->from($options['table'] . ' AS a')
				->where($db->quoteName($options['idColumn']) . ' = ' . $db->quote($options['idValue']));
		if (isset($options['joinTable']))
		{
			$query->innerJoin($options['joinTable']);
			$query->select($options['joinSelect']);
		}
		return $db->setQuery($query)->loadObject();
	}

	/**
	 * Gets count of base schools and signed schools for a state for email.
	 * @return stdClass: db row.
	 */
	protected function getSchoolCounts()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('SUM(base_school) AS total_base_schools, SUM(CASE WHEN contract_signed_date IS NULL THEN 0 ELSE 1 END) AS schools_signed')
				->from('#__diler_school')
				->where('state_iso = ' . $db->quote($this->schoolInfo->school_state));
		return $db->setQuery($query)->loadObject();
	}

	protected function getSchoolInfo($schoolId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('sch.id');
		$query->select('sch.school_id');
		$query->select('sch.name AS school_name');
		$query->select('sch.address AS school_address');
		$query->select('sch.city AS school_city');
		$query->select('sch.state_iso AS school_state');
		$query->select('sch.postal_code AS school_postal_code');
		$query->select('sch.country_iso2 AS school_country');
		$query->select('sch.phone AS school_phone');
		$query->select('sch.email AS school_email');
		$query->select('sch.contact_name AS school_contact_name');
		$query->select('sch.contact_department AS school_contact_department');
		$query->select('sch.contact_address AS school_contact_address');
		$query->select('sch.contact_city AS school_contact_city');
		$query->select('sch.contact_state_iso AS school_contact_state');
		$query->select('sch.contact_postal_code AS school_contact_postal_code');
		$query->select('sch.contact_country_iso2 AS school_contact_country');
		$query->select('sch.contact_phone AS school_contact_phone');
		$query->select('sch.contact_email AS school_contact_email');
		$query->select('sch.published AS school_published');
		$query->select('min.name AS ministry_name');
		$query->select('min.address AS ministry_address');
		$query->select('min.city AS ministry_city');
		$query->select('min.state_iso AS ministry_state');
		$query->select('min.postal_code AS ministry_postal_code');
		$query->select('min.country_iso2 AS ministry_country');
		$query->select('min.phone AS ministry_phone');
		$query->select('min.contact_email AS ministry_email');
		$query->select('min.contact_name AS ministry_contact_name');
		$query->select('min.contact_department AS ministry_contact_department');
		$query->select('min.contact_address AS ministry_contact_address');
		$query->select('min.contact_city AS ministry_contact_city');
		$query->select('min.contact_postal_code AS ministry_contact_postal_code');
		$query->select('min.contact_phone AS ministry_contact_phone');
		$query->select('min.contact_email AS ministry_contact_email');
		$query->select('min.signatory AS ministry_signatory');
		$query->select('sch.principal_name AS school_principal');
		$query->select('country.name AS school_country_name');
		$query->select('state.name AS school_state_name');
		$query->from('#__diler_school AS sch');
		$query->leftJoin('#__diler_country AS country ON country.iso2 = sch.country_iso2');
		$query->leftJoin('#__diler_school_ministry AS min ON min.state_iso = sch.state_iso');
		$query->leftJoin('#__diler_state AS state ON sch.state_iso = state.state_iso');
		$query->where('sch.school_id = ' . $db->quote($schoolId));
		$query->group('sch.id');
		return $db->setQuery($query)->loadObject();
	}

    /**
     * Tries to read existing school history row for this base school. If found, returns row.
     *
     * @param stdClass $mapRow
     * @return mixed|null
     */
	protected function getExistingBaseSchoolHistoryRow(stdClass $mapRow)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')
				->from('#__diler_user_school_history')
				->where('user_id = ' . (int) $mapRow->user_id)
				->where('school_id = ' . (int) $mapRow->school_id)
				->where('base_school = 1');
		return $db->setQuery($query)->loadObject();
	}

	/**
	 * Get the registration edit form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 *
	 * @since 1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_dilerreg.registration', 'registration', array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	// Gets the user messages for the success/error/warnings.
	protected function getMessageArray($messageOptions)
	{
		$app = Factory::getApplication();
		$success = $error = [];
		if ($messageOptions['newGroupId'] && $this->messageInfo['newGroupName']) $this->messages[] = Text::sprintf('COM_DILERREG_REGISTRATION_GROUP_CREATE', $this->messageInfo['newGroupName']);
		if (! $messageOptions['newGroupId']) $this->errors[] = 'Warning: New Group was not created. See your DiLer administrator. Check that "Other" groups category has been set up.';
		if (! $messageOptions['usersAddedResult']) $this->errors[] = 'Warning: Users were not added to the group for the new Branch Teacher.';
		if (! $messageOptions['sendEmailResult']) $this->errors[] = 'Warning: Emails were not successfully sent to teachers and student base school.';
		return true;
	}

	/**
	 * Gets the first "Other" category for DiLer groups.
	 * @return int  Category id or 0 if not found.
	 */
	public function getNewGroupCatId()
	{
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models/');
		$groupModel = MVCHelper::factory()->createModel('Group', 'Site');
		$groupCategories = $groupModel->getDilerGroupCategories();
		$result = (isset($groupCategories[4]) && is_array($groupCategories[4]) && count($groupCategories[4])) ? $groupCategories[4][0]->id : 0;
		return $result;
	}

    /**
     * Gets a list of emails for this branch teacher reg. Includes LG teachers and students base school.
     * @param $mapRow
     * @param array $lgTeacherArray Array of stdClass rows for teachers
     * @return stdClass: emailArray => {array of emails}, nameArray => {array of teacher names}
     */
	protected function getRegistrationEmailList($mapRow, $lgTeacherArray)
	{
		$studentId = $mapRow->user_id;
		$emailArray = $nameArray = [];
		if (! $mapRow->base_school_teacher)
		{
			BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
			$studentBaseSchool = MVCHelper::factory()->createModel('Student', 'Site')->getStudentBaseSchool($studentId);
			$emailArray = isset($studentBaseSchool->email) ? [$studentBaseSchool->email] : [];
			$nameArray = isset($studentBaseSchool->name) ? [$studentBaseSchool->name] : [];
		}
		$lgTeacherNames = [];
		foreach ($lgTeacherArray as $teacher)
		{
			$emailArray[] = $teacher->email;
			$nameArray[] = $teacher->forename . ' ' . $teacher->surname;
			$lgTeacherNames[] = $teacher->forename . ' ' . $teacher->surname;
		}
		$this->messageInfo['lgTeacherNames'] = implode(', ', $lgTeacherNames);
		return (object) ['emailArray' => $emailArray, 'nameArray' => $nameArray];
	}

	/**
	 * Gets array of teacher rows for a student's LG
	 *
	 * @param int $studentId
	 * @return array  array of stdClass row objects
	 */
	protected function getLgTeachers($studentId)
	{
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$usergroupModel = MVCHelper::factory()->createModel('Usergroup', 'Site');
		$studentLg = $usergroupModel->getLearningGroupForStudent($studentId);
		return $usergroupModel->getTeachersForLearninggroup($studentLg->id);
	}

	/**
	 * Gets the registration form and fills out some fields.
	 *
	 * @param array $args
	 * @return \stdClass
	 * @throws Exception
	 */
	public function getRegistrationForm($args)
	{
		$isDiglu = DilerHelperUser::isDiglu();
		$response = new stdClass();
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('c.*');
		$query->select('jug.title AS dilerrolegroup_name');
		$query->select('m.code_id AS map_code_id');
		$query->select('m.user_id AS map_user_id');
		$query->select('m.school_id AS map_school_id');
		$query->select('sch.email AS school_email');
		$query->select('sch.name AS school_name');
		$query->from('#__dilerreg_registration_codes AS c');
		$query->innerJoin('#__usergroups AS jug ON jug.id = c.dilerrolegroup');
		$query->leftJoin('#__dilerreg_registration_code_user_map AS m ON m.code_id = c.id');
		$query->leftJoin('#__diler_school AS sch ON sch.school_id = c.base_school_id');
		$query->where('c.code = ' . $db->quote($args['code']));

		if($isDiglu && !$args['teacherEmail'])
		{
			$query->select('school_for_standard_registration.state_iso as school_state_iso');
			$query->leftJoin('#__diler_school AS school_for_standard_registration ON school_for_standard_registration.id = c.base_school_id');
			$query->where('c.role IN(' . $db->quote(DConst::USER_ROLE_PARENT) . ',' . $db->quote(DConst::USER_ROLE_STUDENT) . ')');
		}
		$result = $db->setQuery($query)->loadObject();

		if ($result->role == DConst::USER_ROLE_STUDENT && !$result->dob && $isDiglu)
			throw new \Exception(DText::_('DOB_NEEDS_TO_BE_ADDED_TO_THIS_REGISTRATION_CODE'));

		if ($result->role == DConst::USER_ROLE_PARENT && !$this->doesParentRegistrationCodeHaveAssignedStudents($result->id))
			throw new \Exception(DText::_('STUDENT_NEED_TO_BE_ASSIGNED_TO_THIS_REGISTRATION_CODE'));

		if (isset($result->map_code_id) && ! $args['teacherEmail'])
		{
			// This is a Diglu registration code. Redirect to correct form.
			$response->isDiglu = 1;
			$response->code = $result->code;
			return $response;
		}

		if (isset($result))
		{
			$response->forename = $result->first_name;
			$response->nickname = $result->nickname;
			$response->surname = $result->last_name;
			$response->role = $result->role;
			$response->lg = $result->lg;
			$response->id = $result->id;
			$response->dilerrolegroup = $result->dilerrolegroup;
			$response->dilerrolegroup_name = $result->dilerrolegroup_name;
			$response->code_id = $result->id;
			$response->native_language_id = $this->getDilerLanguage($args['lang']);
			$response->first_school_enrollment_date = $result->first_school_enrollment_date;

			if ($result->base_school_id && $result->school_email)
			{
				$response->email = $result->school_email;
				if (DMailer::isEmailInUse($result->school_email))
				{
					throw new Exception(DText::_('BASE_SCHOOL_FORM_EMAIL_IN_USE'));
				}
				$response->base_school_id = $result->base_school_id;
				$response->school_name = $result->school_name;
				$contractInfo = $this->getContractText($result->report_type_id, $args['code']);
				$response->contractText = $contractInfo['html'];
				$response->contractName = $contractInfo['name'];
				$response->cssLink = $contractInfo['cssLink'];
			}

			$response->username = strtolower($this->getUsername($result->first_name, $result->last_name));
			$response->dummyEmail = DMailer::getDummyEmail($response->username);
			if ($result->dob)
				$response->dob = DDateTime::DilerDateLC4($result->dob);
			if ($result->first_school_enrollment_date)
				$response->first_school_enrollment_date = DDateTime::DilerDateLC4($result->first_school_enrollment_date);

			// Get learning group name
			$query->clear()
				->select('title')
				->from('#__usergroups')
				->where('id = ' . (int) $response->lg);

			$response->lg_name = $db->setQuery($query)->loadResult();

			if ($isDiglu)
				$response->school_state_iso = $result->school_state_iso;

			return $response;
		}
		else
		{
			return null;
		}
	}

	private function doesParentRegistrationCodeHaveAssignedStudents(int $regCodeId) : bool
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('student_id');
		$query->from('#__dilerreg_parent_student_map');
		$query->where('parent_id = ' . $regCodeId);
		$query->where('parent_id_type = 0');

		return (bool) $db->setQuery($query)->loadResult();

	}

	private function getDilerLanguage($languageCode)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_languages');
		$query->where('code = '. $db->quote($languageCode));
		return $db->setQuery($query)->loadResult();
	}

	public function getUsername($forename, $surname) : string
	{
		$username = strtolower(str_replace('.', '', $forename)) . '.'
			. strtolower(str_replace('.', '', $surname));
		$username = utf8_accents_to_ascii($username);
		$username = preg_replace('/[^A-Za-z0-9-.-_]/', '', $username);
		$username = $this->unifyUsername($username);
		return $username;
	}

	private function unifyUsername($username) : string
	{
		$testName = $username;
		$isUnique = false;
		for ($i = 1; $i < 999; $i++)
		{
			if (!$this->usernameExists($testName))
			{
				$isUnique = true;
				break;
			}
			$testName = $username . $i;
		}

		if (!$isUnique)
		{
			$microtime = (int) (microtime(true)*10000);
			$testName = $username . $microtime;
		}

		return $testName;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return array The data for the form.
	 * @since 5.0
	 */
	protected function loadFormData()
	{
		if (empty($data))
		{
			$data = array();
		}
		return $data;
	}

	/**
	 * Does extra processing for base school activation.
	 * Creates contract PDF and stores on server.
	 * Updates columns in school table to show contract accepted.
	 * Sends emails to (BCC) school, region teacher, ministry, and (main recipient) diler admin.
	 * @param int $userId user_id of the new teacher/principal
	 */
	protected function processBaseSchoolActivation($userId, $data)
	{
		if ($this->baseSchoolCreateContractPdf())
		{
			$this->messages[] = DText::sprintf('BASE_SCHOOL_CONTRACT_SUCCESS', $this->regCodeRow->contract_name);
			$this->baseSchoolUpdateSchoolColumns($userId);
			if ($this->baseSchoolSendConfirmEmails($data))
			{
				$this->messages[] = '<br>';
				$this->messages[] = DText::_('BASE_SCHOOL_CONTRACT_EMAILS_SUCCESS');
			}
		}
		else
		{
			$this->errors[] = DText::sprintf('BASE_SCHOOL_CONTRACT_ERROR', $this->regCodeRow->contract_name);
		}
		return true;
	}

	/**
	 * Adds new teacher group for branch teacher when teacher is already registered.
	 * @param array $options : 'teacherEmail', 'registrationCode'
	 * @param array $mapRows : stdClass: code_id, user_id, school_id
	 * @param stdClass $teacherRow: $row from dilerreg_users table for this teacher
	 *
	 * @return stdClass: status (1 or 0), message
	 */
	public function processExistingTeacher($options, $mapRows, $teacherRow)
	{
		$data = ['forename' => $teacherRow->name, 'surname' => '', 'email' => $teacherRow->email,
			'registration_code' => $options['registrationCode']];
		$codeId = $mapRows[0]->code_id;
		$teacherId = $teacherRow->id;
		$result = $this->processBranchTeacher($data, $codeId, $teacherId, false);
		if (! count($this->errors))
		{
			$this->deleteRegistrationCode($options['registrationCode']);
			$this->messages = DText::sprintf('REGISTRATION_EXISTING_TEACHER', $teacherRow->email);
		}
		$status = count($this->errors) ? 0 : 1;
		return (object) ['status' => $status, 'message' => $this->messages, 'errors' => $this->errors];
		return true;
	}

    /**
     * Creates or finds existing "other" group for branch teacher. Adds teacher, student, and teachers in student's LG to the group.
     * Sends emails to teachers in LG and to student base school
     * Creates row in student school history, with enroll dates
     *
     * @param array $data Data array for the code row.
     * @param $codeId
     * @param $teacherId
     * @param bool $newTeacher true if this is a new teacher, false otherwise (used to check if teacher group already exists)
     * @return true on success, false on fail
     */
	protected function processBranchTeacher($data, $codeId, $teacherId, $newTeacher = true)
	{
		// Check if row exists in map table
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('m.*, ds.name AS school_name, ds.school_id AS school_serial_number, ds.city AS school_city, ds.email AS school_email, ds.address AS address, ds.postal_code AS postal_code')
				->select('CONCAT(du.forename, " ", du.surname) AS student_name')
				->from('#__dilerreg_registration_code_user_map AS m')
				->innerJoin('#__diler_school AS ds ON ds.id = m.school_id')
				->innerJoin('#__dilerreg_users AS du ON du.user_id = m.user_id')
				->where('code_id = ' . (int) $codeId);
		$mapRow = $db->setQuery($query)->loadObject();
		if (! is_object($mapRow) || ! isset($mapRow->code_id)) return (object) ['message' => [], 'errors' => []]; // Nothing to do.

		$this->messageInfo['studentBaseSchoolName'] = $mapRow->school_name;
		$this->messageInfo['studentName'] = $mapRow->student_name;
		$newGroupId = $this->branchTeacherCreateGroup($data, $teacherId, $newTeacher);
		$lgTeachers = $this->getLgTeachers($mapRow->user_id);
		$lgTeachersIdArray = ArrayHelper::getColumn($lgTeachers, 'user_id');
		$userIdsForGroup = array_merge($lgTeachersIdArray, [$mapRow->user_id, $teacherId]);
		$messageOptions = [];
		$messageOptions['newGroupId'] = $newGroupId;
		$messageOptions['usersAddedResult'] = ($newGroupId && count($userIdsForGroup)) ? $this->branchTeacherAddUsersToGroup($newGroupId, $userIdsForGroup) : 0;
		$messageOptions['studentSchoolHistoryResult'] = $this->updateStudentSchoolHistory($mapRow, $teacherId);
		$messageOptions['teacherBaseSchoolResult'] = $this->updateTeacherBaseSchool($teacherId, $mapRow->school_id);
		$messageOptions['sendEmailResult'] = $this->sendNotifyEmails($mapRow, $data);
		$messageArray = $this->getMessageArray($messageOptions);
		$this->deleteMapRow($codeId);
		return true;
	}

	/**
	 * Tries to register a new user based on the registration form.
	 *
	 * @param    array     $data         Data from the form
	 * @param    bool      $checkRegCode true if we are checking the registration code for this user. True when manually registering a new user, false when importing.
	 *
	 * @return stdClass    status => 1 (success), 0 (fail), markup => HTML markup for the system message.
	 */
	public function registerUser($data, $checkRegCode = true)
	{
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$isDiglu = DilerHelperUser::isDiglu();
		// Create array for multiple error messages
		$errorMessages = [];
		$db = Factory::getDbo();
		// Check that role is valid from form matches role from code
		if ($checkRegCode)
		{
			$query = $db->getQuery(true)
				->select('c.*, rt.name AS contract_name, sch.id AS school_table_id, sch.school_id')
				->from('#__dilerreg_registration_codes AS c')
				->leftJoin('#__diler_school AS sch ON sch.school_id = c.base_school_id')
				->leftJoin('#__diler_report_type AS rt ON rt.id = c.report_type_id')
				->where('code = ' . $db->quote($data['code']));
			$regTable = $db->setQuery($query)->loadObject();
			if ((! isset($regTable->role)))
			{
				$errorMessages[] = Text::_('COM_DILERREG_REGISTRATION_INVALID');
			}
			$data['role'] = $regTable->role;
			$this->regCodeRow = $regTable;

			// Check that the code is not already registered
			$query->clear()
				->select('*')
				->from('#__dilerreg_users')
				->where('registercode = ' . $db->quote($data['code']));
			$codeExists = $db->setQuery($query)->loadObjectList();
			if (is_array($codeExists) && $codeExists)
			{
				$errorMessages[] = Text::_('COM_DILERREG_REGISTRATION_EXISTS');
			}
		}

		if (DMailer::isEmailInUse($data['email']))
		{
			$errorMessages[] = Text::_('COM_DILERREG_DUPLICATE_EMAIL');
		}

		// Do form validation
		$form = $this->getForm($data, true);
		if (!$isDiglu)
		{
			$form->setFieldAttribute('address', 'required', false);
			$form->setFieldAttribute('state_iso', 'required', false);
			$form->setFieldAttribute('portalcode', 'required', false);
			$form->setFieldAttribute('city', 'required', false);
			$form->setFieldAttribute('swimmer', 'required', false);
		}

		// Remove fields based on role (so required fields don't show errors)
		if ($data['role'] != 'student')
		{
			$form->removeField('dob');
			$form->removeField('gender');
			$form->removeField('pob');
			$form->removeField('swimmer');
			$form->removeField('native_language_id');
		}
		if ($data['role'] != 'teacher')
		{
			$form->removeField('salutation');
		}

		if ($data['role'] == 'teacher')
		{
			$form->removeField('country_iso2');
			$form->removeField('state_iso');
			$form->removeField('address');
			$form->removeField('portalcode');
			$form->removeField('city');
			$form->removeField('citizenship_iso2');
		}

		$validData = $form->validate($data);

		if (! $validData)
		{
			$errors = $form->getErrors();
			/** @var Exception $error */
			foreach ($errors as $error)
			{
				$errorMessages[] = $error->getMessage();
			}
		}

		if ($errorMessages)
		{
			$displayData = array('message' => implode('<br>', $errorMessages), 'heading' => Text::_('ERROR'), 'status' => '0');
			$messageHtml = LayoutHelper::render('simple_system_message', $displayData, JPATH_BASE . '/components/com_diler/layouts');
			$result = (object) ['status' => '0', 'successMessage' => '', 'errorMessage' => $messageHtml];
			return $result;
		}

		$returnUrl = base64_encode('index.php?option=com_diler&view=diler');
		$data['params'] = ["return_url" => $returnUrl,
			"numMessages" => 5,
			"texterFullMessage" => 0,
			"texterButtons" => 0,
			"loginRedirect" => 3,
			"expertMode" => 2,
			"paginationLimit" => 10,
			"autoassignLG" => 2,
			"autoassignSG" => 2,
			"autoassignEG" => 2,
			"autoassignOG" => 2,
			"cloudNotify" => [1,2,3]];
		$user = new Joomla\CMS\User\User;
		if (! $user->bind($data))
		{
			throw new RuntimeException('Unable to creat Joomla user.');
		}

		$user->name = $data['forename'] . " " .$data['surname'];
		$user->block = 0;
		$user->sendEmail = 0;

		$user->registerDate = Factory::getDate()->toSql();
		$saveResult = $user->save();
		if (! $saveResult)
		{
			$displayData = ['message' => 'Failed to save new Joomla user! See your DiLer administrator.<br/>' . $user->getError(), 'status' => '0'];
			$messageHtml = LayoutHelper::render('simple_system_message', $displayData, JPATH_BASE . '/components/com_diler/layouts');
			$result = (object) ['status' => '0', 'successMessage' => '', 'errorMessage' => $messageHtml];
			return $result;
		}

		$id = $user->id;
        $newRegisteredUserEmail = $user->email;

        $tempDeclarationOfConsentPath = Factory::getConfig()->get('tmp_path') . '/declaration_of_consent_' . $data['code'] . '.pdf';
        if (File::exists($tempDeclarationOfConsentPath))
		{
			$this->saveAcceptedConsentOnRegister(Consent::getConsentTypeByClass(DeclarationConsent::class), $id, $user->registerDate);
			$this->moveTempDeclarationPdfToUserFolder($tempDeclarationOfConsentPath, $id, $user->registerDate);
		}

		if (in_array($data['role'], ['teacher', 'student']))
		{
			$groupIds = [$data['dilerrolegroup']];
			if ($data['lg'])
			{
				array_push($groupIds, $data['lg']);
			}
			UserHelper::setUserGroups($id, $groupIds);
			$role1 = $data['role'];
		}
		else if (in_array($data['role'], array('parent', 'mother', 'father')))
		{
			UserHelper::setUserGroups($id, [$data['dilerrolegroup']]);
			$role1 = 'parent';
		}

		$this->insertIntoDilerregTable($id, $data, $role1);

		if ($checkRegCode && in_array($data['role'], array('student', 'parent', 'mother', 'father')))
			$this->changeFamilyMappingTableFromCodeToUserForStudentsAndParents($id, $data, $regTable);

		// Create Branch Teacher Group if needed.
		$branchProcessResult = $checkRegCode ? $this->processBranchTeacher($data, $regTable->id, $id, true) : (object) ['message' => [], 'errors' => []];

		// Process base school if needed
		if ($checkRegCode && $this->regCodeRow->base_school_id && $this->regCodeRow->report_type_id)
			$this->processBaseSchoolActivation($id, $data);

		if ($isDiglu && $this->regCodeRow->base_school_id && $this->regCodeRow->role == DConst::USER_ROLE_STUDENT)
			$this->insertSchoolHistory($user);

		$dUser = DGet::user($id);

		// Send welcome email if not activation base school or teacher registration on diglu
		$this->sendMailNotificationsAboutRegistration($dUser, $regTable);

		$this->deleteRegistrationCode($data['code']);

		// Log registration action
		$logType = in_array($data['role'], array('student', 'teacher')) ? $data['role'] : 'misc_users';
		$role = ($logType == 'misc_users') ? 'parent' : $logType;
		if (DilerLogger::doLog($logType))
		{
			if (Factory::getUser()->guest)
			{
				$logMessage = Text::sprintf('COM_DILERREG_LOG_SELF_REGISTER', $data['forename'] . ' ' . $data['surname'],
					$data['username'], $role);
				$logData = array('message' => $logMessage, 'extension' => 'com_dilerreg');
			}
			else
			{
				$logMessage = DText::sprintf('LOG_REGISTER_USER', Factory::getUser()->username, $data['forename'] . ' ' . $data['surname'],
					$data['username'], $role);
				$logData = array('message' => $logMessage, 'extension' => 'com_dilerreg');
			}
			$logger = new DilerLogger('user', 'register');
			$logger->addAction($logData);
		}

		// Set the redirect in the response
		$status = $this->errors ? 0 : 1;
		$errorMessage = '';
		if (! $status)
		{
			$displayData = array('message' => implode(' ', $this->errors), 'heading' => Text::_('ERROR'), 'status' => 0);
			$errorMessage = LayoutHelper::render('simple_system_message', $displayData, JPATH_BASE . '/components/com_diler/layouts');
		}
		$messagesRaw = implode('<br>', $this->messages);
		$messagesEncoded = str_replace('<br>', '---break---', $messagesRaw);
		$result = (object) array('status' => $status, 'messages' => $messagesEncoded, 'username' => $data['username'], 'user_id' => $id,
			'errorMessage' => $errorMessage);
		return $result;
	}

	private function insertIntoDilerregTable($id, $data, $role)
	{
		$isDiglu = DilerHelperUser::isDiglu();
		$db = $this->getDbo();
		// insert into extended reg users
		$query = $db->getQuery(true)
			->insert('#__dilerreg_users')
			->set('user_id = ' . $id)
			->set('acceptedterms = "1"')
			->set('approve = "1"')
            ->set('student_alert_note = ""')
            ->set('student_alert_note_teacher = ""')
			->set('registercode = ' . $db->quote($data['code']))
			->set('forename = ' . $db->quote($data['forename']))
			->set('nickname = ' . $db->quote($data['nickname']))
			->set('surname = ' . $db->quote($data['surname']))
			->set('role = ' . $db->quote($data['role']));

		if (in_array($role, array('student', 'parent')))
		{
			$query->set('country_iso2 = ' . $db->quote($data['country_iso2']));
			$query->set('state_iso = ' . $db->quote($data['state_iso']));
			$query->set('address = ' . $db->quote($data['address']));
			$query->set('portalcode = ' . $db->quote($data['portalcode']));
			$query->set('city = ' . $db->quote($data['city']));
			$query->set('citizenship_iso2 = ' . $db->quote($data['citizenship_iso2']));
		}

		if ($role == 'student' && $this->regCodeRow)
		{
            $studentPhaseActual = $this->regCodeRow->student_phase_actual ?: 0;
            $studentPhaseTarget = $this->regCodeRow->student_phase_target ?: 0;
            $query->set('student_phase_actual = ' . $db->quote($studentPhaseActual));
            $query->set('student_phase_target = ' . $db->quote($studentPhaseTarget));
		}

		if (!$isDiglu && $role == 'student' && $this->regCodeRow)
			$query->set('first_school_enrollment_date = ' . $db->quote($this->regCodeRow->first_school_enrollment_date ?: '0000-00-00 00:00:00'));

		if ($role == 'student')
		{
			$query->set('params = ' . $db->quote(json_encode(array('display_mark' => 1))));
			$query->set('dob = ' . $db->quote(Factory::getDate($data['dob'])->toSql()));
			$query->set('gender = ' . $db->quote($data['gender']));
			$query->set('pob = ' . $db->quote($data['pob']));
			$query->set('native_language_id = ' . $db->quote($data['native_language_id']));
			$query->set('swimmer = ' . $db->quote($data['swimmer']));
            if ($isDiglu)
                $query->set('first_school_enrollment_date = ' . $db->quote(Factory::getDate($data['first_school_enrollment_date'])->toSql()));
		}
		elseif ($role == 'teacher' && $this->regCodeRow->base_school_id)
		{
			$query->set('salutation = ' . $db->quote($data['salutation']));
			$query->set('base_school_id = ' . (int) $this->regCodeRow->school_table_id);
		}
		elseif ($role == 'teacher')
		{
			$query->set('salutation = ' . $db->quote($data['salutation']));
		}
		elseif ($role == 'parent')
		{
			$query->set('phonehome = ' . $db->quote($data['phonehome']));
			$query->set('phonework = ' . $db->quote($data['phonework']));
			$query->set('phonemobile = ' . $db->quote($data['phonemobile']));
		}

		$db->setQuery($query)->execute();
	}

	private function changeFamilyMappingTableFromCodeToUserForStudentsAndParents($id, $data, $regTable)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->update ('#__dilerreg_parent_student_map');

		if ($data['role'] == 'student')
		{
			$query->set ('student_id_type = 1');
			$query->set ('student_id = ' . $id);
			$query->where ('student_id = ' . $regTable->id);
			$query->where('student_id_type = 0');
		}
		else
		{
			$query->set ('parent_id_type = 1');
			$query->set ('parent_id = ' . $id);
			$query->where ('parent_id = ' . $regTable->id);
			$query->where('parent_id_type = 0');
		}
		$db->setQuery($query)->execute();
	}

	private function insertSchoolHistory($user)
	{
		$db = $this->getDbo();
		$insertSchoolHistoryQuery = $db->getQuery(true);
		$insertSchoolHistoryQuery->insert('#__diler_user_school_history');
		$insertSchoolHistoryQuery->set('user_id = ' . (int) $user->id);
		$insertSchoolHistoryQuery->set('school_id = ' . (int) $this->regCodeRow->base_school_id);
		$insertSchoolHistoryQuery->set('base_school = 1');
		// For Diglu we do not store "first_school_enrollment_date" to #__dilerreg_users.first_school_enrollment_date
		// Instead we store it to '#__diler_user_school_history'
		// We should do the same for standard diler installation but at the momemnt it's not easy as we do not
		// store School details to `#__diler_school` for standard Diler, but we read it from Global configuration
		$insertSchoolHistoryQuery->set('enroll_start = '. $db->quote(Factory::getDate($this->regCodeRow->first_school_enrollment_date)->toSql()));
		$db->setQuery($insertSchoolHistoryQuery)->execute();
		$insertedId = $db->insertid();
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		/** @var Model\Regional_teachers_at_time_of_enrolmentModel $regionalTeachersModel */
		$regionalTeachersModel = MVCHelper::factory()->createModel(
			'Regional_teachers_at_time_of_enrolment',
			'Site',
			array('student_id' => (int) $user->id)
		);
		$regionalTeachersModel->saveRelatedRegionTeachers($this->regCodeRow->base_school_id);
	}

	private function sendMailNotificationsAboutRegistration(DUser $dUser, $regTable)
	{
		if (!DilerHelperUser::isDiglu())
			return;

		$schools = RepositoryFactory::school()->loadSchoolsForRegistrationEmailNotification($dUser, (int) $this->regCodeRow->base_school_id);
		if (!$schools->isSchoolListEmpty())
		{
			$this->sendMailToSchoolsAboutNewUserRegistration($dUser, $regTable->created_by, $schools->getFirst());
			$this->sendMailToRegionTeachersAboutNewUserRegistration($dUser, $regTable->created_by, $schools->getFirst());
            $this->sendWelcomeEmail($dUser, $schools->getFirst());
		}
	}

	private function sendMailToSchoolsAboutNewUserRegistration(DUser $user, $regTableCreatedById, School $school)
	{
			$schoolName = $school->name();
			$subject = DText::sprintf('DIGLU_NEW_USER_REGISTERED_EMAIL_SUBJECT',
                DText::_(strtoupper($user->role())),
				$user->personalData()->fullName(),
				$schoolName,
				$school->address()->city()
			);
			$digluId = strtoupper(DGet::user($user->id())->digluId());
			$studentId = $user->role() == DConst::USER_ROLE_STUDENT ? $digluId : $user->id();
			$schoolAddress = $school->address();
			$schoolPostalCode =$schoolAddress->postalCode();
			$schoolCity = $schoolAddress->city();
			$body = DText::sprintf('DIGLU_NEW_USER_REGISTERED_EMAIL_BODY',
				DText::_(strtoupper($user->role())),
				$user->personalData()->fullName(),
				$studentId,
				$this->getRelatedLearningGroups($user),
				$schoolName,
				$school->registerNumber(),
				$schoolPostalCode,
				$schoolCity,
				$schoolAddress->street(),
				$this->getRegistrationCodeAuthorFullName($regTableCreatedById),
				EmailFooter::schoolInfo($school)
			);
			$emailParams = new SendEmailAboutRegistrationParams($subject, $body);
			$emailParams->addRecipients($school->address()->email());
			$this->sendMail($emailParams);
	}

	private function sendMailToRegionTeachersAboutNewUserRegistration(DUser $user, $regTableCreatedById, School $school)
	{
			$registrationNotificationHelper = new RegistrationNotificationHelper($school->Id(), 0);
			$relatedUsers                   = $registrationNotificationHelper->getRelatedTeacherNamesAndEmailByIds();
			foreach ($relatedUsers as $relatedUser)
			{
				$schoolName = $school->name();
				$subject    = DText::sprintf('DIGLU_NEW_USER_REGISTERED_EMAIL_SUBJECT',
					DText::_(strtoupper($user->role())),
					$user->personalData()->fullName(),
					$schoolName,
					$school->address()->city()
				);
				$digluId = strtoupper(DGet::user($user->id())->digluId());
				$studentId = $user->role() == DConst::USER_ROLE_STUDENT ? $digluId : $user->id();
				$schoolAddress    = $school->address();
				$schoolPostalCode = $schoolAddress->postalCode();
				$schoolCity       = $schoolAddress->city();
				$body             = DText::sprintf('DIGLU_REGION_TEACHER_NOTIFICATION_ABOUT_NEW_USER_REGISTERED_EMAIL_BODY',
					DText::_(strtoupper($user->role())),
					$user->personalData()->fullName(),
					$studentId,
					$this->getRelatedLearningGroups($user),
					$schoolName,
					$school->registerNumber(),
					$schoolPostalCode,
					$schoolCity,
					$schoolAddress->street(),
					$this->getRegistrationCodeAuthorFullName($regTableCreatedById),
					EmailFooter::schoolInfo($school),
					$relatedUser->name
				);
				$emailParams      = new SendEmailAboutRegistrationParams($subject, $body);
				if (DilerHelperUser::isDiglu())
					$emailParams->setDigluRelatedRecipients($relatedUser);
				$this->sendMail($emailParams);
			}
	}

	private function getRegistrationCodeAuthorFullName($userId)
	{
		try {
			$dUser = DGet::user($userId);
			return $dUser->personalData()->fullName();
		}catch (\Exception $exception)
		{
			return Text::_('JADMINISTRATOR');
		}
	}

	private function getRelatedLearningGroups(DUser $user) : string
	{
		if ($user->isParent())
			return $this->getStudentsLearningGroupsNamesForParent($user);

		if ($user->isStudent())
			return $this->getStudentLearningGroupName($user);

		return "";
	}

	private function getStudentLearningGroupName(DUser $user) : string
	{
		return RepositoryFactory::learningGroup()->loadByStudentId($user->id())->name();
	}

	private function getStudentsLearningGroupsNamesForParent(DUser $user) : string
	{
		$relatedStudents = $user->relatedUsers()->students();
		$learningGroupRepo = RepositoryFactory::learningGroup();
		$groupList = $learningGroupRepo->loadByParentForUnregisteredKids($user->id());
		foreach ($relatedStudents as $student)
			$groupList->add($learningGroupRepo->loadByStudentId($student->id()));

		return  implode(", ", ArrayHelper::arrayUnique($groupList->getOnlyNames()));
	}


	private function getRegistrationCodeIdByCode($code)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id');
		$query->from('#__dilerreg_registration_codes');
		$query->where('code = ' . $db->quote($code));
		return $db->setQuery($query)->loadResult();
	}

	private function saveAcceptedConsentOnRegister(string $type, int $userId, string $signedDate)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->insert('#__diler_consents');
		$query->set('created_by = ' .  $userId);
		$query->set('type = ' .  $db->quote($type));
		$query->set('created = ' .  $db->quote($signedDate));

		$db->setQuery($query)->execute();
	}

	private function moveTempDeclarationPdfToUserFolder($tempPath, $userId, $signDate)
	{
		$finalDirPath = Consent::getPdfPath($userId, Consent::getConsentTypeByClass(DeclarationConsent::class));
		$fileName = Factory::getDate($signDate)->toUnix();
		Folder::create($finalDirPath);
		File::move($tempPath, "$finalDirPath/$fileName.pdf");
	}

	private function getSchoolIdOfChildFromRegCode($parentId)
	{
		// First we try to find school ID by student who not registered yet and it's related to parent
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('ds.school_id');
		$query->from('#__dilerreg_parent_student_map AS psm');
		$query->innerJoin('#__dilerreg_registration_codes AS rc ON psm.student_id = rc.id AND psm.parent_id_type = 1');
		$query->innerJoin('#__diler_school AS ds ON rc.base_school_id = ds.id AND psm.student_id_type = 0');
		$query->where('psm.parent_id = ' . $parentId);

		$schoolId = $db->setQuery($query)->loadResult();
		if ($schoolId)
			return $schoolId;

		// If school id does not exist, let's try to find school ID by registered student
		$query = $db->getQuery(true);
		$query->select('ds.school_id');
		$query->from('#__dilerreg_parent_student_map AS psm');
		$query->innerJoin('#__diler_user_school_history AS ush ON ush.user_id = psm.student_id AND psm.student_id_type = 1');
		$query->innerJoin('#__diler_school AS ds ON ds.id = ush.school_id');
		$query->where('psm.parent_id = ' . $parentId);
		$query->where('ds.base_school = 1');
		$query->order('ush.id DESC');

		$schoolId = $db->setQuery($query)->loadResult();
		return $schoolId;
	}

	private function getSchoolIdFromStudentsRegCode($code)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		$query->select('ds.school_id');
		$query->from('#__dilerreg_registration_codes AS rc');
		$query->innerJoin('#__diler_school AS ds ON rc.base_school_id = ds.id');
		$query->where('rc.code = ' . $db->quote($code));

		return $db->setQuery($query)->loadResult();
	}

	protected function seems_utf8($str)
	{
		$length = strlen($str);
		for ($i = 0; $i < $length; $i ++)
		{
			$c = ord($str[$i]);
			if ($c < 0x80)
				$n = 0; // 0bbbbbbb
			elseif (($c & 0xE0) == 0xC0)
				$n = 1; // 110bbbbb
			elseif (($c & 0xF0) == 0xE0)
				$n = 2; // 1110bbbb
			elseif (($c & 0xF8) == 0xF0)
				$n = 3; // 11110bbb
			elseif (($c & 0xFC) == 0xF8)
				$n = 4; // 111110bb
			elseif (($c & 0xFE) == 0xFC)
				$n = 5; // 1111110b
			else
				return false; // Does not match any model
			for ($j = 0; $j < $n; $j ++)
			{ // n bytes matching 10bbbbbb follow ?
				if ((++ $i == $length) || ((ord($str[$i]) & 0xC0) != 0x80))
					return false;
			}
		}
		return true;
	}

	public function sendMail(SendEmailAboutRegistrationParams $params)
	{
		$body =  $params->getBody() . $this->getEmailFooter();
		$mailer = DMailer::getInstance();
		foreach ($params->getRecipients() as $recipient)
		{
			$mailer->clearAllRecipients();
			$mailer->isHTML(true);
			$mailer->Encoding = 'base64';
			$mailer->setSubject($params->getSubject());
			$mailer->setBody($body);
			$mailer->addRecipient($recipient);
			$mailer->Send();
		}
		return true;
	}

	private function sendWelcomeEmail(DUser $dUser, School $school)
	{
		$role = DText::_(strtoupper($dUser->role()));
		$linkToHomePage = '<a href="' . Route::_(Uri::base()) . '">' . DText::_('SITE_URL') . '</a>';

		$subject = DText::sprintf('NEW_USER_REGISTERED_EMAIL_SUBJECT',
			$role, $dUser->personalData()->fullName(), $school->name(), $school->address()->city()
		);

		$body = DText::sprintf('NEW_USER_REGISTERED_EMAIL_BODY',
			$dUser->personalData()->fullName(),
			$linkToHomePage,
			$dUser->personalData()->username(),
			EmailFooter::schoolInfo($school)
		);
		$emailParams = new SendEmailAboutRegistrationParams($subject, $body);
		$emailParams->addRecipients($dUser->personalData()->email());
		$this->sendMail($emailParams);
	}

	private function getEmailFooter()
	{
		$termsAndConditionsId = DilerParams::init()->getTermsAndConditionsId();
		$imprintId = DilerParams::init()->getImprintId();
		$linkToImprint = '<a href="' . Route::_(Uri::base() . 'index.php?option=com_content&view=article&id=' . $imprintId , false ) . '">' . DText::_('LINK_TO_IMPRINT') . '</a>';
		$linkToTermsAndConditions = '<a href="' . Route::_(Uri::base() . 'index.php?option=com_content&view=article&id=' . $termsAndConditionsId , false ) . '">' . DText::_('LINK_TO_TERMS_AND_CONDITIONS') . '</a>';
		return DText::sprintf('DIGLU_EMAIL_FOOTER', $linkToImprint, $linkToTermsAndConditions);
	}

	/**
	 * Send emails to the student LG teachers and the student base school
	 * @param stdClass $mapRow  stdClass with student and school info
	 * @param array $lgTeacherArray Array of teacher rows
	 * @param array $data assoc array of data from form

	 */
	protected function sendNotifyEmails($mapRow, $data)
	{
		$registrationNotificationHelper = new RegistrationNotificationHelper($mapRow->school_id, $mapRow->user_id);
		$relatedUsers                   = $registrationNotificationHelper->getRelatedTeacherNamesAndEmailByIds();
		foreach ($relatedUsers as $relatedUser)
		{
			if ($mapRow->base_school_teacher)
			{
				$subject    = DText::_('REGCODE_BASE_TEACHER_EMAIL_SUBJECT');
				$mailerBody = DText::sprintf('REGCODE_BASE_TEACHER_EMAIL_BODY',
					$mapRow->student_name,
					$mapRow->school_name,
					$mapRow->school_serial_number,
					$mapRow->school_city,
					$data['forename'] . ' ' . $data['surname'],
					$data['email'],
					$mapRow->postal_code,
					$mapRow->address,
					$relatedUser->name
				);
			}
			else
			{
				$subject    = DText::_('REGCODE_TEACHER_EMAIL_SUBJECT');
				$mailerBody = DText::sprintf('REGCODE_TEACHER_EMAIL_BODY',
					$mapRow->student_name,
					$mapRow->school_name,
					$mapRow->school_serial_number,
					$mapRow->school_city,
					$data['forename'] . ' ' . $data['surname'],
					$data['email'],
					$mapRow->postal_code,
					$mapRow->address,
					$relatedUser->name
				);
			}
			$emailParams = new SendEmailAboutRegistrationParams($subject, $mailerBody);
			$emailParams->setDigluRelatedRecipients($relatedUser);
			$this->sendMail($emailParams);
		}
		return true;
	}

	/**
	 * Converts all accent characters to ASCII characters.
	 *
	 * If there are no accent characters, then the string given is just returned.
	 *
	 * @param string $string Text that might have accent characters
	 * @return string Filtered string with replaced "nice" characters.
	 */
	protected function remove_accents($string)
	{
		if (! preg_match('/[\x80-\xff]/', $string))
			return $string;

		if ($this->seems_utf8($string))
		{
			$chars = array(
				// Decompositions for Latin-1 Supplement
				chr(195) . chr(128) => 'AE',chr(195) . chr(129) => 'AE',chr(195) . chr(130) => 'AE',chr(195) . chr(131) => 'AE',chr(195) . chr(132) => 'AE',chr(195) . chr(133) => 'AE',chr(195) . chr(135) => 'C',chr(195) . chr(136) => 'E',chr(195) . chr(137) => 'E',chr(195) . chr(138) => 'E',chr(195) . chr(139) => 'E',chr(195) . chr(140) => 'I',chr(195) . chr(141) => 'I',chr(195) . chr(142) => 'I',chr(195) . chr(143) => 'I',chr(195) . chr(145) => 'N',chr(195) . chr(146) => 'OE',chr(195) . chr(147) => 'OE',chr(195) . chr(148) => 'OE',chr(195) . chr(149) => 'OE',chr(195) . chr(150) => 'OE',chr(195) . chr(153) => 'UE',chr(195) . chr(154) => 'UE',chr(195) . chr(155) => 'UE',chr(195) . chr(156) => 'UE',chr(195) . chr(157) => 'Y',chr(195) . chr(159) => 'ss',chr(195) . chr(160) => 'ae',chr(195) . chr(161) => 'ae',chr(195) . chr(162) => 'ae',chr(195) . chr(163) => 'ae',chr(195) . chr(164) => 'ae',chr(195) . chr(165) => 'ae',chr(195) . chr(167) => 'c',chr(195) . chr(168) => 'e',chr(195) . chr(169) => 'e',chr(195) . chr(170) => 'e',chr(195) . chr(171) => 'e',chr(195) . chr(172) => 'i',chr(195) . chr(173) => 'i',chr(195) . chr(174) => 'i',chr(195) . chr(175) => 'i',chr(195) . chr(177) => 'n',chr(195) . chr(178) => 'oe',chr(195) . chr(179) => 'oe',chr(195) . chr(180) => 'oe',chr(195) . chr(181) => 'oe',chr(195) . chr(182) => 'oe',chr(195) . chr(182) => 'oe',chr(195) . chr(185) => 'ue',chr(195) . chr(186) => 'ue',chr(195) . chr(187) => 'ue',chr(195) . chr(188) => 'ue',chr(195) . chr(189) => 'y',chr(195) . chr(191) => 'y',
				// Decompositions for Latin Extended-A
				chr(196) . chr(128) => 'AE',chr(196) . chr(129) => 'ae',chr(196) . chr(130) => 'AE',chr(196) . chr(131) => 'ae',chr(196) . chr(132) => 'AE',chr(196) . chr(133) => 'ae',chr(196) . chr(134) => 'C',chr(196) . chr(135) => 'c',chr(196) . chr(136) => 'C',chr(196) . chr(137) => 'c',chr(196) . chr(138) => 'C',chr(196) . chr(139) => 'c',chr(196) . chr(140) => 'C',chr(196) . chr(141) => 'c',chr(196) . chr(142) => 'D',chr(196) . chr(143) => 'd',chr(196) . chr(144) => 'D',chr(196) . chr(145) => 'd',chr(196) . chr(146) => 'E',chr(196) . chr(147) => 'e',chr(196) . chr(148) => 'E',chr(196) . chr(149) => 'e',chr(196) . chr(150) => 'E',chr(196) . chr(151) => 'e',chr(196) . chr(152) => 'E',chr(196) . chr(153) => 'e',chr(196) . chr(154) => 'E',chr(196) . chr(155) => 'e',chr(196) . chr(156) => 'G',chr(196) . chr(157) => 'g',chr(196) . chr(158) => 'G',chr(196) . chr(159) => 'g',chr(196) . chr(160) => 'G',chr(196) . chr(161) => 'g',chr(196) . chr(162) => 'G',chr(196) . chr(163) => 'g',chr(196) . chr(164) => 'H',chr(196) . chr(165) => 'h',chr(196) . chr(166) => 'H',chr(196) . chr(167) => 'h',chr(196) . chr(168) => 'I',chr(196) . chr(169) => 'i',chr(196) . chr(170) => 'I',chr(196) . chr(171) => 'i',chr(196) . chr(172) => 'I',chr(196) . chr(173) => 'i',chr(196) . chr(174) => 'I',chr(196) . chr(175) => 'i',chr(196) . chr(176) => 'I',chr(196) . chr(177) => 'i',chr(196) . chr(178) => 'IJ',chr(196) . chr(179) => 'ij',chr(196) . chr(180) => 'J',chr(196) . chr(181) => 'j',chr(196) . chr(182) => 'K',chr(196) . chr(183) => 'k',chr(196) . chr(184) => 'k',chr(196) . chr(185) => 'L',chr(196) . chr(186) => 'l',chr(196) . chr(187) => 'L',chr(196) . chr(188) => 'l',chr(196) . chr(189) => 'L',chr(196) . chr(190) => 'l',chr(196) . chr(191) => 'L',chr(197) . chr(128) => 'l',chr(197) . chr(129) => 'L',chr(197) . chr(130) => 'l',chr(197) . chr(131) => 'N',chr(197) . chr(132) => 'n',chr(197) . chr(133) => 'N',chr(197) . chr(134) => 'n',chr(197) . chr(135) => 'N',chr(197) . chr(136) => 'n',chr(197) . chr(137) => 'N',chr(197) . chr(138) => 'n',chr(197) . chr(139) => 'N',chr(197) . chr(140) => 'OE',chr(197) . chr(141) => 'oe',chr(197) . chr(142) => 'OE',chr(197) . chr(143) => 'oe',chr(197) . chr(144) => 'OE',chr(197) . chr(145) => 'oe',chr(197) . chr(146) => 'OE',chr(197) . chr(147) => 'oe',chr(197) . chr(148) => 'R',chr(197) . chr(149) => 'r',chr(197) . chr(150) => 'R',chr(197) . chr(151) => 'r',chr(197) . chr(152) => 'R',chr(197) . chr(153) => 'r',chr(197) . chr(154) => 'SS',chr(197) . chr(155) => 'ss',chr(197) . chr(156) => 'SS',chr(197) . chr(157) => 'ss',chr(197) . chr(158) => 'SS',chr(197) . chr(159) => 'ss',chr(197) . chr(160) => 'SS',chr(197) . chr(161) => 'ss',chr(197) . chr(162) => 'T',chr(197) . chr(163) => 't',chr(197) . chr(164) => 'T',chr(197) . chr(165) => 't',chr(197) . chr(166) => 'T',chr(197) . chr(167) => 't',chr(197) . chr(168) => 'UE',chr(197) . chr(169) => 'ue',chr(197) . chr(170) => 'UE',chr(197) . chr(171) => 'ue',chr(197) . chr(172) => 'UE',chr(197) . chr(173) => 'ue',chr(197) . chr(174) => 'UE',chr(197) . chr(175) => 'ue',chr(197) . chr(176) => 'UE',chr(197) . chr(177) => 'ue',chr(197) . chr(178) => 'UE',chr(197) . chr(179) => 'ue',chr(197) . chr(180) => 'W',chr(197) . chr(181) => 'w',chr(197) . chr(182) => 'Y',chr(197) . chr(183) => 'y',chr(197) . chr(184) => 'Y',chr(197) . chr(185) => 'Z',chr(197) . chr(186) => 'z',chr(197) . chr(187) => 'Z',chr(197) . chr(188) => 'z',chr(197) . chr(189) => 'Z',chr(197) . chr(190) => 'z',chr(197) . chr(191) => 'ss',
				// Euro Sign
				chr(226) . chr(130) . chr(172) => 'E',
				// GBP (Pound) Sign
				chr(194) . chr(163) => '');

			$string = strtr($string, $chars);
		}
		else
		{
			// Assume ISO-8859-1 if not UTF-8
			$chars['in'] = chr(128) . chr(131) . chr(138) . chr(142) . chr(154) . chr(158) . chr(159) . chr(162) . chr(165) . chr(181) . chr(192) . chr(193) . chr(194) . chr(195) . chr(196) . chr(197) . chr(199) . chr(200) . chr(201) . chr(202) . chr(203) . chr(204) . chr(205) . chr(206) . chr(207) . chr(209) . chr(210) . chr(211) . chr(212) . chr(213) . chr(214) . chr(216) . chr(217) . chr(218) . chr(219) . chr(220) . chr(221) . chr(224) . chr(225) . chr(226) . chr(227) . chr(228) . chr(229) . chr(231) . chr(232) . chr(233) . chr(234) . chr(235) . chr(236) . chr(237) . chr(238) . chr(239) . chr(241) . chr(242) . chr(243) . chr(244) . chr(245) . chr(246) . chr(248) . chr(249) . chr(250) . chr(251) . chr(252) . chr(253) . chr(255);

			$chars['out'] = "EfSZszYcYuAAAAAACEEEEIIIINOOOOOOUUUUYaaaaaaceeeeiiiinoooooouuuuyy";

			$string = strtr($string, $chars['in'], $chars['out']);
			$double_chars['in'] = array(chr(140),chr(156),chr(198),chr(208),chr(222),chr(223),chr(230),chr(240),chr(254));
			$double_chars['out'] = array('OE','oe','AE','DH','TH','ss','ae','dh','th');
			$string = str_replace($double_chars['in'], $double_chars['out'], $string);
		}

		return $string;
	}

	/**
	 * Sets the base_school_id column for the new or existing teacher.
	 * @param int $teacherId
	 * @param int $schoolId
	 * @return bool true on success
	 */
	protected function updateTeacherBaseSchool($teacherId, $schoolId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__dilerreg_users')
				->set('base_school_id = ' . (int) $schoolId)
				->where('user_id = ' . (int) $teacherId);
		return $db->setQuery($query)->execute();
	}

    /**
     * Inserts new row into student school history for this new assignment.
     * If this is a base school teacher, check for existing base school row for this student. If found,
     * update this row instead of inserting a new row.
     *
     * @param stdClass $mapRow object with student and school info
     * @param int $teacherId Id of branch teacher
     * @return bool|mixed
     */
	protected function updateStudentSchoolHistory(stdClass $mapRow, int $teacherId)
	{
		$baseSchoolRow = null;
		if ($mapRow->base_school_teacher)
		{
			$baseSchoolRow = $this->getExistingBaseSchoolHistoryRow($mapRow);
		}

		if (! empty($baseSchoolRow->id))
		{
			return $this->updateExistingHistoryRow($baseSchoolRow, $teacherId);
		}
		else
		{
			return $this->insertNewHistoryRow($mapRow, $teacherId);
		}
	}

    /**
     *
     * @param stdClass $baseSchoolRow Columns from existing row
     * @param int $teacherId
     * @return mixed
     */
	protected function updateExistingHistoryRow(stdClass $baseSchoolRow, int $teacherId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_user_school_history')
				->set('branch_teacher = ' . (int) $teacherId)
				->where('id = ' . (int) $baseSchoolRow->id);
		return $db->setQuery($query)->execute();
	}

	/**
	 * Inserts new row into user_school_history table.
	 *
	 * @param stdClass $mapRow Row from map table
	 * @param int $teacherId
	 * @return bool true on success.
	 */
	protected function insertNewHistoryRow(stdClass $mapRow, int $teacherId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->insert('#__diler_user_school_history')
				->set('user_id = ' . (int) $mapRow->user_id)
				->set('school_id = ' . (int) $mapRow->school_id)
				->set('branch_teacher = ' . (int) $teacherId);
		if (isset($mapRow->enroll_start))
		{
			$query->set('enroll_start = ' . $db->quote($mapRow->enroll_start));
		}
		if (isset($mapRow->enroll_end))
		{
			$query->set('enroll_end = ' . $db->quote($mapRow->enroll_end));
		}
		$db->setQuery($query)->execute();
		$insertedId = $db->insertid();
		/** @var Model\Regional_teachers_at_time_of_enrolmentModel $regionalTeachersModel */
		$regionalTeachersModel =MVCHelper::factory()->createModel(
			'Regional_teachers_at_time_of_enrolment',
			'Site',
			array('student_id' => $mapRow->user_id)
		);
		$regionalTeachersModel->saveRelatedRegionTeachers($mapRow->school_id);
		return $insertedId;
	}

	/**
	 * Checks whether a user name already exists.
	 *
	 * @param    string   username to check
	 *
	 * @return   bool     true if exists, false otherwise
	 *
	 */
	protected function usernameExists($username)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('username')
			->from('#__users')
			->where('username = ' . $db->quote($username));
		$r1 = $db->setQuery($query)->loadResult();
		return isset($r1);
	}
}
