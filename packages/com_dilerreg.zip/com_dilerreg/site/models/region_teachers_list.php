<?php
/**
 * @copyright	Copyright (C) 2013-2023 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file

use DiLer\Core\User\Privacy\Contact\TeacherContactVisiblePrivateFields;
use DiLer\DConst;
use DiLer\Lang\DText;
use DiLer\Users\Params;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\Registry\Registry;

defined('_JEXEC') or die('Restricted access');

class DiLerregModelRegion_Teachers_List extends ListModel
{
    private $region_teacher_surname;
    private $region_teacher_postal_code;
    private $region_teacher_state;
    private $region_teacher_country;
    private $region_teacher_city;
    private $region_teacher_notes_and_regions;
    private $region_teacher_case_sensitive;

    public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);

		$this->region_teacher_surname = $config['region_teacher_surname'];
        $this->region_teacher_postal_code = $config['region_teacher_postal_code'];
        $this->region_teacher_state = $config['region_teacher_state'];
        $this->region_teacher_country = $config['region_teacher_country'];
        $this->region_teacher_city = $config['region_teacher_city'];
        $this->region_teacher_notes_and_regions = $config['region_teacher_notes_and_regions'];
		$this->region_teacher_case_sensitive = $config['region_teacher_case_sensitive'];
	}

	public function getItems()
	{
		$items = parent::getItems();
		return array_map(array($this, 'prepareItems'), $items);
	}

	private function prepareItems($item)
	{
		$params              = new Params(new Registry($item->joomla_user_params));
		$teacherPrivacy      = new TeacherContactVisiblePrivateFields($params->hiddenContactFields());
		$phones = [];
		foreach ($teacherPrivacy->publicFields() as $fieldName)
		{
			if (!str_contains($fieldName, 'phone'))
				continue;

			if ($phone = $item->{$fieldName})
			{
				$phoneLink           = '<a href="tel:' . $phone . '">' . $phone . '</a>';
				$phones[] = DText::_($teacherPrivacy->fieldLanguageString($fieldName)) . ': ' . $phoneLink;
			}
		}

		$item->phone_contact = $phones ? implode(', ', $phones) : "";
		return $item;
	}
	protected function getListQuery()
	{
        $region_teachers_group_id = ComponentHelper::getParams('com_diler')->get('region_teacher_group_id', 0);

		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('du.user_id');
		$query->select('du.forename');
		$query->select('du.surname');
		$query->select('du.salutation');
		$query->select('du.phonehome');
		$query->select('du.phonework');
		$query->select('du.phonemobile');
		$query->select('du.phonework2');
		$query->select('du.phonemobile2');
		$query->select('du.contact_note AS remark');
		$query->select('u.email AS email');
		$query->select('u.params as joomla_user_params');
        $query->select('dr.community');
        $query->select('dr.city');
		$query->select('dr.postal_code');
		$query->select('du.portalcode as region_teacher_personal_postal_code');
		$query->select('du.city as region_teacher_personal_city');
        $query->from('#__dilerreg_users AS du');
        $query->innerJoin('#__user_usergroup_map AS uum on uum.user_id = du.user_id');
        $query->innerJoin('#__users AS u on u.id = du.user_id');
        $query->leftJoin('#__diler_region_user_map AS drum on drum.user_id = du.user_id');
        $query->leftJoin('#__diler_region AS dr on dr.id = drum.region_id');
        $query->where('uum.group_id = ' . (int) $region_teachers_group_id);
        $query->where('u.block = 0');


        $query_conditions = [];
        if ($this->region_teacher_surname && $this->region_teacher_case_sensitive)
            $query_conditions[] = 'du.surname COLLATE utf8_german2_ci LIKE ' . $db->quote('%' . trim($this->region_teacher_surname) . '%')
	            . ' AND CONVERT(du.surname USING utf8) COLLATE utf8_bin LIKE ' . $db->quote('%' . trim( $this->region_teacher_surname) . '%');
		if ($this->region_teacher_surname && !$this->region_teacher_case_sensitive)
			$query_conditions[] = 'du.surname COLLATE utf8_german2_ci LIKE' . $db->quote('%' . trim($this->region_teacher_surname) . '%');

        if ($this->region_teacher_postal_code)
            $query_conditions[] = 'dr.postal_code = ' . $db->quote($this->region_teacher_postal_code);

		if ($this->region_teacher_city && $this->region_teacher_case_sensitive)
			$query_conditions[] = 'dr.city COLLATE utf8mb4_german2_ci LIKE ' . $db->quote('%' . trim($this->region_teacher_city) . '%')
				. ' AND CONVERT(dr.city USING utf8mb4) COLLATE utf8mb4_bin LIKE ' . $db->quote('%' . trim( $this->region_teacher_city) . '%');
		if ($this->region_teacher_city && !$this->region_teacher_case_sensitive)
			$query_conditions[] = 'dr.city COLLATE utf8mb4_german2_ci LIKE ' . $db->quote('%' . trim($this->region_teacher_city) . '%');

		if ($this->region_teacher_notes_and_regions && $this->region_teacher_case_sensitive)
			$query_conditions[] = 'du.contact_note COLLATE utf8_german2_ci LIKE ' . $db->quote('%' . trim($this->region_teacher_notes_and_regions) . '%')
				. ' AND CONVERT(du.contact_note USING utf8) COLLATE utf8_bin LIKE ' . $db->quote('%' . trim( $this->region_teacher_notes_and_regions) . '%')
				. 'OR dr.community COLLATE utf8mb4_german2_ci LIKE '. $db->quote('%' . trim($this->region_teacher_notes_and_regions) . '%')
				. ' AND CONVERT(dr.community USING utf8) COLLATE utf8_bin LIKE ' . $db->quote('%' . trim( $this->region_teacher_notes_and_regions) . '%');
		if ($this->region_teacher_notes_and_regions && !$this->region_teacher_case_sensitive)
			$query_conditions[] = 'du.contact_note COLLATE utf8_german2_ci LIKE '. $db->quote('%' . trim($this->region_teacher_notes_and_regions) . '%') .
				'OR dr.community COLLATE utf8mb4_german2_ci LIKE '. $db->quote('%' . trim($this->region_teacher_notes_and_regions) . '%');

		if ($this->region_teacher_country && $this->region_teacher_state)
        {
            $sub_condition = 'dr.country_iso2 = ' . $db->quote($this->region_teacher_country);

            if($this->region_teacher_state)
                $sub_condition .= ' AND dr.state_iso = ' . $db->quote($this->region_teacher_state);

            $query_conditions[] = '('.$sub_condition.')';
        }

        if ($query_conditions)
            $query->where($query_conditions);
		$query->andWhere('du.role = ' . $db->quote(DConst::USER_ROLE_TEACHER));
        $query->group('du.user_id');

		return $query;
	}

	public function getIsAnyFilterApplied() : bool
	{
		return
			$this->region_teacher_surname ||
			$this->region_teacher_postal_code ||
			$this->region_teacher_city ||
			$this->region_teacher_notes_and_regions ||
			($this->region_teacher_state && $this->region_teacher_country);
	}

	private function buildSearchQueryByCity($query, $db): void
	{
		$trimmedCity = $db->quote('%' . trim($this->region_teacher_city) . '%');
		if ($this->region_teacher_case_sensitive) {
			$query->where('dr.city COLLATE utf8mb4_german2_ci LIKE ' . $trimmedCity
				. ' AND CONVERT(dr.city USING utf8mb4) COLLATE utf8mb4_bin LIKE ' . $trimmedCity);
		} else {
			$query->where('dr.city COLLATE utf8mb4_german2_ci LIKE ' . $trimmedCity);
		}
	}

	private function buildSearchQueryBySurname($query, $db): void
	{
		$trimmedSurname = $db->quote('%' . trim($this->region_teacher_surname) . '%');
		if ($this->region_teacher_case_sensitive) {
			$query->where('du.surname COLLATE utf8_german2_ci LIKE ' . $trimmedSurname
				. ' AND CONVERT(du.surname USING utf8) COLLATE utf8_bin LIKE ' . $trimmedSurname);
		} else {
			$query->where('du.surname COLLATE utf8_german2_ci LIKE' . $trimmedSurname);
		}
	}

	private function buildSearchQueryByNotesAndRegions($query, $db) : void
	{
		$trimmedNotesAndRegions = $db->quote('%' . trim($this->region_teacher_notes_and_regions) . '%');
		if ($this->region_teacher_case_sensitive)
			$query->where('du.contact_note COLLATE utf8_german2_ci LIKE ' . $trimmedNotesAndRegions
				. ' AND CONVERT(du.contact_note USING utf8) COLLATE utf8_bin LIKE ' . $trimmedNotesAndRegions
				. 'OR dr.community COLLATE utf8mb4_german2_ci LIKE ' . $trimmedNotesAndRegions
				. ' AND CONVERT(dr.community USING utf8) COLLATE utf8_bin LIKE ' . $trimmedNotesAndRegions);
		else
			$query->where('du.contact_note COLLATE utf8_german2_ci LIKE ' . $trimmedNotesAndRegions
				. 'OR dr.community COLLATE utf8mb4_german2_ci LIKE '. $trimmedNotesAndRegions);
	}

	public function buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $searchField)
	{
		if ($searchField == $this->region_teacher_city)
			$this->buildSearchQueryByCity($query, $db);

		elseif ($searchField == $this->region_teacher_surname)
			$this->buildSearchQueryBySurname($query, $db);

		elseif ($searchField == $this->region_teacher_notes_and_regions)
			$this->buildSearchQueryByNotesAndRegions($query, $db);

		return $query;
	}

    public function getStates()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('name, state_iso');
		$query->from('#__diler_state');

        if ($this->region_teacher_country)
        {
            $query->where('country_iso2 = '.$db->quote($this->region_teacher_country));
        }
        else
        {
            $query->where('country_iso2 = "DE"');
        }

		return $db->setQuery($query)->loadObjectList();
	}

    public function getCountries()
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        $query->select('name, iso2');
        $query->from('#__diler_country');

        return $db->setQuery($query)->loadObjectList();
    }

    public function getIsPostalCodeSet()
    {
        return (bool) $this->region_teacher_postal_code;
    }

	public function getPostalCode()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('postal_code');
		$query->from('#__diler_region');
        $query->where('postal_code =' .  $db->quote($this->region_teacher_postal_code));

		return $db->setQuery($query)->loadResult();
	}

	public function getStateNameAndStateIsoByPostalCode()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('dr.state_iso, s.name, dr.postal_code');
		$query->from('#__diler_region AS dr');
		$query->innerJoin('#__diler_state AS s ON s.state_iso = dr.state_iso');
        $query->where('postal_code =' .  $db->quote($this->region_teacher_postal_code));

		return $db->setQuery($query)->loadObject();
	}

	public function getRegionTeacherIdByPostalCode()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('drum.user_id');
		$query->from('#__dilerreg_users AS du');
		$query->innerJoin('#__diler_region_user_map AS drum ON du.user_id = drum.user_id');
		$query->innerJoin('#__diler_region AS dr ON drum.region_id = dr.id');
		if ($this->region_teacher_postal_code)
			$query->where('postal_code =' . $db->quote($this->region_teacher_postal_code));
		return $db->setQuery($query)->loadObject();
	}

	public function getRegionTeacherCity()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('dr.city');
		$query->from('#__dilerreg_users AS du');
		$query->innerJoin('#__diler_region_user_map AS drum ON du.user_id = drum.user_id');
		$query->innerJoin('#__diler_region AS dr ON drum.region_id = dr.id');
		$query = $this->buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $this->region_teacher_city);

		return $db->setQuery($query)->loadResult();
	}

	public function getCity()
	{
		return $this->region_teacher_city;
	}

	public function getNotesAndRegions()
	{
		return $this->region_teacher_notes_and_regions;
	}

	public function getRegionTeacherNotesAndRegions()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('du.contact_note, dr.community');
		$query->from('#__dilerreg_users AS du');
		$query->innerJoin('#__diler_region_user_map AS drum ON du.user_id = drum.user_id');
		$query->innerJoin('#__diler_region AS dr ON drum.region_id = dr.id');
		$this->buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $this->region_teacher_notes_and_regions);

		return $db->setQuery($query)->loadObject();
	}

	public function getRegionTeacherSurname()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('du.surname');
		$query->from('#__dilerreg_users AS du');
		$query->innerJoin('#__diler_region_user_map AS drum ON du.user_id = drum.user_id');
		$query->innerJoin('#__diler_region AS dr ON drum.region_id = dr.id');
		$this->buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $this->region_teacher_surname);

		return $db->setQuery($query)->loadResult();
	}

	public function getSurname()
	{
		return $this->region_teacher_surname;
	}

	public function getStateIsoByCityAndStateIso()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('dr.state_iso');
		$query->from('#__diler_region AS dr');
		$query->innerJoin('#__diler_state AS s ON s.state_iso = dr.state_iso');
		$query = $this->buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $this->region_teacher_city);

		if ($this->region_teacher_state)
			$query->where('dr.state_iso =' .  $db->quote($this->region_teacher_state));

		return $db->setQuery($query)->loadObject();
	}

	public function getStateNameByCityName()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('s.name');
		$query->from('#__diler_region AS dr');
		$query->innerJoin('#__diler_state AS s ON s.state_iso = dr.state_iso');
		$query = $this->buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $this->region_teacher_city);

		return $db->setQuery($query)->loadObjectList();
	}

	public function getStateIsoBySurnameAndStateIso()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('dr.state_iso');
		$query->from('#__dilerreg_users AS du');
		$query->innerJoin('#__diler_region_user_map AS drum ON du.user_id = drum.user_id');
		$query->innerJoin('#__diler_region AS dr ON drum.region_id = dr.id');
		$query->innerJoin('#__diler_state AS s ON s.state_iso = dr.state_iso');
		$this->buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $this->region_teacher_surname);

		if ($this->region_teacher_state)
			$query->where('s.state_iso = ' . $db->quote($this->region_teacher_state));

		return $db->setQuery($query)->loadObject();
	}

	public function getStateNameBySurname()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('s.name');
		$query->from('#__dilerreg_users AS du');
		$query->innerJoin('#__diler_region_user_map AS drum ON du.user_id = drum.user_id');
		$query->innerJoin('#__diler_region AS dr ON drum.region_id = dr.id');
		$query->innerJoin('#__diler_state AS s ON s.state_iso = dr.state_iso');
		$this->buildRegionTeacherSearchQueryIfCaseSensitive($query, $db, $this->region_teacher_surname);

		return $db->setQuery($query)->loadObjectList();
	}
}