<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;

// import joomla controller library


// Get an instance of the controller prefixed by dilerreg
$controller = BaseController::getInstance('dilerreg');

// Load Diler logger
JLoader::register('DilerLogger', JPATH_ROOT .  '/components/com_diler/helpers/logger.php');
JLoader::register('DilerParams', JPATH_ROOT .  '/components/com_diler/helpers/dilerparams.php');
JLoader::registerNamespace('Audivisa\\Component\\DiLer\\Site', JPATH_ROOT . '/components/com_diler/src', false, false, 'psr4');

//load com_diler language file
$language = Factory::getLanguage();
$language->load('com_diler', JPATH_SITE . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_diler', null, true);

// Perform the Request task
$controller->execute(Factory::getApplication()->input->get('task'));

// Redirect if set by the controller
$controller->redirect();
