<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Factory;

// import Joomla view library


class DilerregViewRegion_Teachers_List extends HtmlView
{
    private array $items = [];
    private array $states = [];
    private array $countries = [];
	private bool $isAnyFilterApplied;
    private $menu_item_id;
    private $selected_state;
	private $postalCode;
    private $isPostalCodeSet;

	private $stateNameAndStateIsoByPostalCode;
	private $regionTeacherIdByPostalCode;
	private $regionTeacherCity;
	private $city;
	private $notesAndRegions;
	private $regionTeacherNotesAndRegions;
	private $regionTeacherSurname;
	private $surname;
	private $stateIsoByCityAndStateIso;
	private $stateNameByCityName;
	private $stateIsoBySurnameAndStateIso;
	private $stateNameBySurname;


    public function display($tpl = null)
    {
        $app = Factory::getApplication();

        $this->items = $this->get('Items');
        $this->states = $this->get('States');
        $this->countries = $this->get('Countries');
        $this->isPostalCodeSet = $this->get('isPostalCodeSet');
		$this->postalCode = $this->get('PostalCode');
		$this->stateNameAndStateIsoByPostalCode = $this->get('StateNameAndStateIsoByPostalCode');
		$this->regionTeacherIdByPostalCode = $this->get('RegionTeacherIdByPostalCode');
		$this->isAnyFilterApplied = $this->get('IsAnyFilterApplied');
        $this->menu_item_id = $app->input->getString('menu_item_id');
        $this->selected_state = $app->input->getString('region_teacher_state');
		$this->regionTeacherCity = $this->get('RegionTeacherCity');
		$this->city = $this->get('City');
		$this->notesAndRegions = $this->get('NotesAndRegions');
		$this->regionTeacherNotesAndRegions = $this->get('RegionTeacherNotesAndRegions');
		$this->regionTeacherSurname = $this->get('RegionTeacherSurname');
		$this->surname = $this->get('Surname');
		$this->stateIsoByCityAndStateIso = $this->get('StateIsoByCityAndStateIso');
		$this->stateNameByCityName = $this->get('StateNameByCityName');
		$this->stateIsoBySurnameAndStateIso = $this->get('StateIsoBySurnameAndStateIso');
		$this->stateNameBySurname = $this->get('StateNameBySurname');

        return parent::display($tpl);
    }

    public function getItems()
    {
        return $this->items;
    }

    public function getCountries()
    {
        return $this->countries;
    }
    public function getStates()
    {
        return $this->states;
    }
    public function getMenuItemId()
    {
        return $this->menu_item_id;
    }
    public function getSelectedState()
    {
        return $this->selected_state;
    }
	public function getPostalCode()
	{
		return $this->postalCode;
	}

    public function isPostalCodeSet()
    {
        return $this->isPostalCodeSet;
    }

	public function getStateNameAndStateIsoByPostalCode()
	{
		return $this->stateNameAndStateIsoByPostalCode;
	}

	public function getRegionTeacherIdByPostalCode()
	{
		return $this->regionTeacherIdByPostalCode;
	}

	public function getRegionTeacherCity()
	{
		return $this->regionTeacherCity;
	}

	public function getCity()
	{
		return $this->city;
	}

	public function getNotesAndRegions()
	{
		return $this->notesAndRegions;
	}

	public function getRegionTeacherNotesAndRegions()
	{
		return $this->regionTeacherNotesAndRegions;
	}

	public function getRegionTeacherSurname()
	{
		return $this->regionTeacherSurname;
	}

	public function getSurname()
	{
		return $this->surname;
	}

	public function getStateNameAndStateIsoByCity()
	{
		return $this->stateIsoByCityAndStateIso;
	}

	public function getStateNameByCityName()
	{
		return $this->stateNameByCityName;
	}

	public function getStateIsoBySurnameAndStateIso()
	{
		return $this->stateIsoBySurnameAndStateIso;
	}

	public function getStateNameBySurname()
	{
		return $this->stateNameBySurname;
	}
}