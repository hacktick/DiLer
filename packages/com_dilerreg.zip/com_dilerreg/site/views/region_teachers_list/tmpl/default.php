<?php
/**
 * @copyright	Copyright (C) 2023 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;


// No direct access to this file
defined('_JEXEC') or die('Restricted access');
/** @var DilerregViewRegion_Teachers_List $this */
$app = Factory::getApplication();
$items = $this->getItems();
$menu_item_id = $this->getMenuItemId();
$postalCode = $this->getPostalCode();
$stateNameAndStateIsoByPostalCode = $this->getStateNameAndStateIsoByPostalCode();
$selectedState = $this->getSelectedState();
$regionTeacherIdByPostalCode = $this->getRegionTeacherIdByPostalCode();
$regionTeacherCity = $this->getRegionTeacherCity();
$regionTeacherNotesAndRegions = $this->getRegionTeacherNotesAndRegions();
$notesAndRegions = $this->getNotesAndRegions();
$regionTeacherSurname = $this->getRegionTeacherSurname();
$stateIsoByCityAndStateIso = $this->getStateNameAndStateIsoByCity();
$stateIsoBySurnameAndStateIso = $this->getStateIsoBySurnameAndStateIso();
$stateNameByNotesAndRegions = $this->getStateNameBySurname();
BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/administrator/components/com_diler/models/');
/** @var DilerregViewRegion_Teachers_List $this */
if (!$this->get('IsAnyFilterApplied'))
{
	echo "<p>" . DText::_('REGION_TEACHER_SEARCH_PLEASE_USE_FILTERS_ABOVE_TO_GET_RESULTS') . "</p>";
    return;
}

if (!$regionTeacherCity)
{
    echo "<p>" . DText::sprintf('CITY_DOES_NOT_EXIST_IN_DATABASE', $this->getCity()) . "</p>";
}

if ($regionTeacherCity && $stateIsoByCityAndStateIso->state_iso != $selectedState && $this->getCity() && $selectedState)
{
	$stateNameByCity = $this->getStateNameByCityName();
    foreach ($stateNameByCity as $state)
    {
        $names[] = $state->name;
    }
    $uniqueNames = array_unique($names);

    echo "<p>" . DText::sprintf('CITY_IS_IN_DATABASE_BUT_IN_DIFFERENT_STATE', $this->getCity(), implode(', ', $uniqueNames)) . "</p>";
}

if ($regionTeacherSurname && $stateIsoBySurnameAndStateIso->state_iso != $selectedState && $this->getSurname() && $selectedState)
{
	$stateNameBySurname = $this->getStateNameBySurname();
	foreach ($stateNameBySurname as $state)
	{
		$names[] = $state->name;
	}
	$uniqueNames = array_unique($names);

	echo "<p>" . DText::sprintf('SURNAME_IS_IN_DATABASE_BUT_IN_DIFFERENT_STATE', $this->getSurname(), implode(', ', $uniqueNames)) . "</p>";
}


if (!$regionTeacherNotesAndRegions)
{
	echo "<p>" . DText::sprintf('DISTRICT_DOES_NOT_EXIST_IN_DATABASE', $this->getNotesAndRegions()) . "</p>";
}

if (!$regionTeacherSurname)
{
	echo "<p>" . DText::sprintf('SURNAME_DOES_NOT_EXIST_IN_DATABASE', $this->getSurname()) . "</p>";
}

if ($this->isPostalCodeSet() && !$postalCode)
{
	echo "<p>" . DText::_('REGION_TEACHER_SEARCH_POSTAL_CODE_DOES_NOT_EXIST') . "</p>";
}

if($this->isPostalCodeSet() && $stateNameAndStateIsoByPostalCode->state_iso != $selectedState && $selectedState && $postalCode)
{
    echo DText::sprintf('THIS_POSTAL_CODE_BELONGS_TO_ANOTHER_STATE', $stateNameAndStateIsoByPostalCode->name);
    return;
}

if (!$regionTeacherIdByPostalCode->user_id && $postalCode)
{
	echo "<p>" . DText::_('THIS_POSTAL_CODE_HAS_CURRENTLY_NO_REGION_TEACHER_ASSIGNED') . "</p>";
}

if (!$items)
{
	echo "<p>" . Text::_('JGLOBAL_NO_MATCHING_RESULTS') . "</p>";

	return;
}
?>

<ul class="unstyled" style="margin: 2rem 0 0;">
    <?php foreach($items as $item): ?>
        <li style="padding: 1rem; border-top: thin solid #ddd; font-size: 1.1rem; line-height: 1.5;">
            <i class="fal fa-user fa-fw muted"></i>
            <?php if (Factory::getUser()->authorise('contacts.view.teachers', 'com_diler')): ?>
                <a href="<?php echo Route::_('index.php?option=com_diler&view=' . DilerHelperUser::getDilerRole() . '_contacts&user_id='. $item->user_id.'&Itemid='.$menu_item_id); ?>">
                    <?php echo $item->salutation; ?> <?php echo $item->forename; ?> <?php echo $item->surname; ?>
                </a>
            <?php else: ?>
                <?php echo $item->salutation; ?> <?php echo $item->forename; ?> <?php echo $item->surname; ?>
            <?php endif; ?>
            <br><i class="fal fa-envelope fa-fw muted"></i> <?php echo '<a href=mailto:"' . $item->email . '">' . $item->email . '</a>'; ?>
	        <?php if ($item->phone_contact) : ?>
                <br><i class="fal fa-phone fa-fw muted"></i> <?php echo $item->phone_contact; ?>
	        <?php endif; ?>
	        <?php if ($item->region_teacher_personal_city): ?>
                <br><i class="fal fa-city fa-fw muted"></i> <?php echo $item->region_teacher_personal_postal_code . ' ' . $item->region_teacher_personal_city; ?>
	        <?php endif; ?>
            <?php if ($item->remark) : ?>
                <br><i class="fal fa-sticky-note fa-fw muted"></i> <?php echo $item->remark; ?>
            <?php endif; ?>
            <?php $regionCommunitiesOfTeacher = MVCHelper::factory()->createModel('Regions', 'Administrator')->getRegionForTeacher($item->user_id); ?>
            <?php if ($regionCommunitiesOfTeacher) : ?>
                <br><i class="fal fa-poll-h fa-fw muted"></i> <?php echo implode(', ', $regionCommunitiesOfTeacher); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>
</ul>
