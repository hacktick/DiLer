<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\View\HtmlView;

// import Joomla view library


class DilerregViewActivation extends HtmlView
{
	/**
	 * DiLers view display method
	 * @param string $tpl A string to view tmpl.
	 * @return void
	 */
	function display($tpl = null) {
		
		// Display the view
		parent::display($tpl);	
	}
}