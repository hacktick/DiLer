<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Session\Session;
if (!\Audivisa\Component\DiLer\Site\Helper\VersionHelper::isJoomla4())
    HTMLHelper::_('behavior.framework');
HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('bootstrap.popover');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/diler.js');

$isDiglu = DilerHelperUser::isDiglu();
if (!$isDiglu) die('Restricted access');
$form = $this->form;
// load language file from com_users
$skLanguage = Factory::getLanguage();
$skLanguage->load('com_users', JPATH_SITE, $skLanguage->getTag(), true);
?>
<div id="system-message-container"></div>
<form action="index.php?option=com_dilerreg" method="post" id="dilerBaseSchoolActivation" name="dilerBaseSchoolActivation"  class="form-validate form-horizontal"  enctype="multipart/form-data">
	<fieldset>
		<legend><?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_LABEL');?></legend>
		<div id="dilerRegBody">
			<div class="row-fluid">
				<?php if (is_array($this->layoutFiles) && $this->layoutFiles) : ?>
					<?php echo DilerHelperUser::honeypotGetInput(); ?>
					<div class="control-group">
						<div class="control-label"> </div>
						<div class="controls">
							<a href="#base-school-activation-welcome" role="button" class="btn btn-small" data-toggle="modal"><?php echo DText::_('DIGLU_BASE_SCHOOL_ACTIVATION_MODAL_TRIGGER');?></a>
						</div>
					</div>
					<?php echo $this->form->renderField('state_iso'); ?>
					<?php echo $this->form->renderField('school_serial_number'); ?>
					<?php if (is_array($this->layoutFiles) && count($this->layoutFiles) > 1) :?>
						<div class="control-label">
							<label class="hastooltip required" title="" data-trigger="hover" data-original-title="<?php echo DText::_('LOGIN_FORM_SCHOOL_CONTRACT_LAYOUT_DESC'); ?>">
							<?php echo DText::_('LOGIN_FORM_SCHOOL_CONTRACT_LAYOUT_LABEL');?><span class="star">&nbsp;*</span></label>
						</div>
						<div class="controls">
							<?php echo HTMLHelper::_('select.genericlist', $this->layoutFiles, 'jform[report_type_id]', ['id' => 'jform_report_type_id', 'disabled' => 'disabled'], 'id', 'name'); ?>
						</div>
					<?php elseif (is_array($this->layoutFiles) && count($this->layoutFiles) === 1) :?>
						<input type="hidden" id="jform_report_type_id" name="jform[report_type_id]" value="<?php echo $this->layoutFiles[0]->id;?>">
					<?php endif;?>
					<div class="control-group heading">
						<div class="control-label"> </div>
						<div class="controls"><?php echo DText::_('DIGLU_BASE_SCHOOL_ACTIVATION_PRINCIPAL_HEADING'); ?></div>
					</div>
					<?php echo $this->form->renderField('forename'); ?>
					<?php echo $this->form->renderField('surname'); ?>
					<div class="form-actions">
						<button id="saveButton" type="button" class="btn btn-primary submit saveButton" disabled onclick="Joomla.submitbutton()">
							<i class="fal fa-check"></i><?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_LABEL'); ?></button>
						<a id="cancelButton" type="button" class="btn btn-small" href="index.php?option=com_diler"><?php echo Text::_('JCANCEL'); ?></a>
						<input id="Itemid"  type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
						<input id="lang"  type="hidden" name="lang" value="<?php echo $this->lang; ?>" />
						<input id="task"  type="hidden" name="task" value="baseschoolactivation.createBaseSchoolTeacherCode" />
						<input id="option"  type="hidden" name="option" value="com_dilerreg" />
						<input  name="formToken" type="hidden" value="<?php echo Session::getFormToken();?>">
					</div>
				<?php else : ?>
                    <div class="row-fluid">
                        <?php echo $this->form->renderField('state_iso'); ?>
                        <?php echo $this->form->renderField('school_serial_number'); ?>
                        <div class="control-group heading">
                            <div class="control-label"> </div>
                            <div class="controls"><?php echo DText::_('DIGLU_BASE_SCHOOL_ACTIVATION_PRINCIPAL_HEADING'); ?></div>
                        </div>
                        <?php echo $this->form->renderField('forename'); ?>
                        <?php echo $this->form->renderField('surname'); ?>
                        <div class="form-actions">
                            <button id="saveButton" type="button" class="btn btn-primary submit saveButton" disabled onclick="Joomla.submitbutton()">
                                <i class="fal fa-check"></i><?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_LABEL'); ?></button>
                            <a id="cancelButton" type="button" class="btn btn-small" href="index.php?option=com_diler"><?php echo Text::_('JCANCEL'); ?></a>
                            <input id="Itemid"  type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
                            <input id="lang"  type="hidden" name="lang" value="<?php echo $this->lang; ?>" />
                            <input id="task"  type="hidden" name="task" value="baseschoolactivation.createBaseSchoolTeacherCode" />
                            <input id="option"  type="hidden" name="option" value="com_dilerreg" />
                            <input  name="formToken" type="hidden" value="<?php echo Session::getFormToken();?>">
                        </div>
                    </div>
				<?php endif; ?>
			</div>
	</fieldset>
</form>
<div id="base-school-activation-welcome" class="modal hide fade">
  <div class="modal-header">
    <h3><?php echo DText::_('DIGLU_BASE_SCHOOL_ACTIVATION_MODAL_HEADING');?></h3>
  </div>
  <div class="modal-body">
    <p><?php echo DText::_('DIGLU_BASE_SCHOOL_ACTIVATION_MODAL_BODY');?></p>
  </div>
  <div class="modal-footer">
	<button type="button" class="btn btn-primary" data-dismiss="modal" aria-hidden="true"><?php echo Text::_('JNEXT');?></button>
  </div>
</div>
<script>
	Joomla.submitbutton = function (task)
	{
		if (document.formvalidator.isValid(document.getElementById('dilerBaseSchoolActivation')))
		{
			dilerSystem.spinner('start');
			Joomla.submitform(task, document.getElementById('dilerBaseSchoolActivation'));
		}
	};

	jQuery(document).ready(function ($) {
		$('#base-school-activation-welcome').modal("show");
		dilerSystem.delayedOnInput('jform_state_iso', checkState, 500);
		dilerSystem.delayedOnInput('jform_school_serial_number', checkSchoolSerialNumber, 500);
	});

	function checkError(data) {
		alert('There is a problem with your DiLer database. Please check with the DiLer administrator.');
	};

	function checkSchoolSerialNumber() {
		let schoolSN = jQuery('#jform_state_iso').val() + jQuery('#jform_school_serial_number').val();
		let myData = {
			option: 'com_dilerreg',
			task: 'baseschoolactivation.checkSchoolSerialNumber',
			school_serial_number: schoolSN
		};
		let honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
		myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
		myData[jQuery('input[name="formToken"]').val()] = 1;
		dilerSystem.doAjax(myData, 'json', checkSchoolSerialNumberSuccess, checkError);
	};

	function checkSchoolSerialNumberSuccess(data) {
		jQuery('#jform_school_serial_number_message').remove();
		if (data.status !== 1) {
			jQuery('#jform_school_serial_number').after('<span id="jform_school_serial_number_message" class="error">&nbsp;' + data.message + '</span>');
			jQuery('#jform_school_serial_number').addClass('invalid');
			jQuery('#dilerBaseSchoolActivation').find('input').prop('disabled', true);
			jQuery('#jform_school_serial_number').prop('disabled', false);
			jQuery('#jform_school_serial_number').prop('disabled', false);
			jQuery('#saveButton').prop('disabled', true);
			jQuery('select[name="jform[report_type_id]"]').prop('disabled', true);
		} else {
			jQuery('#jform_school_serial_number').after('<span id="jform_school_serial_number_message">&nbsp;' + data.message + '</span>');
			jQuery('#jform_school_serial_number').removeClass('invalid');
			jQuery('#dilerBaseSchoolActivation').find('input').prop('disabled', false);
			jQuery('#saveButton').prop('disabled', false);
			jQuery('select[name="jform[report_type_id]"]').prop('disabled', false);
		}

	};

	function checkState() {
		if (jQuery('#jform_state_iso').val() > ' ') {
			jQuery('#jform_school_serial_number').prop('disabled', false);
			jQuery('#jform_school_serial_number').focus();
		} else {
			jQuery('#jform_school_serial_number').prop('disabled', true);
		}
		if (jQuery('#jform_school_serial_number').val() === '') {
			return true;
		} else {
			checkSchoolSerialNumber();
		}
	};

	function disableDates(action) {
		jQuery('#jform_enroll_start').prop('disabled', action);
		jQuery('#jform_enroll_start_btn').prop('disabled', action);
		jQuery('#jform_enroll_end').prop('disabled', action);
		jQuery('#jform_enroll_end_btn').prop('disabled', action);
	};


</script>
