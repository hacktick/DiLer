<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Session\Session;

JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');
if(!\Audivisa\Component\DiLer\Site\Helper\VersionHelper::isJoomla4())
    HTMLHelper::_('behavior.framework');
HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('bootstrap.popover');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/diler.js');

$isDiglu = DilerHelperUser::isDiglu();
if (!$isDiglu) die('Restricted access');
$form = $this->form;
// load language file from com_users
$skLanguage = Factory::getLanguage();
$skLanguage->load('com_users', JPATH_SITE, $skLanguage->getTag(), true);
$legendTag = $this->baseSchool ? 'LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_LEGEND' : 'LOGIN_FORM_DIGLU_BRANCH_SCHOOL_ACTIVATION_LEGEND';
$teacherDesc = $this->baseSchool ? 'COM_DILER_DIGLU_BASE_TEACHER_REG_FORM_NAME_DESC' : 'COM_DILER_DIGLU_BRANCH_TEACHER_REG_FORM_NAME_DESC';

?>
<div id="system-message-container"></div>
<form action="index.php?option=com_dilerreg" method="post" id="dilerBranchRegForm" name="dilerBranchRegForm"  class="form-validate form-horizontal"  enctype="multipart/form-data">
	<fieldset>
		<legend>
			<?php echo DText::_($legendTag);?>
		</legend>
		<div id="dilerRegBody">
			<div class="row-fluid">
				<?php echo DilerHelperUser::honeypotGetInput(); ?>
				<div class="control-group student-id">
					<div class="control-label"><?php echo $this->form->getLabel('student_id'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('student_id'); ?>
						<p class="help-block"><?php echo Text::sprintf('COM_DILERREG_STUDENT_ID_DESC', DText::_('STUDENT'));?></p>
					</div>
				</div>
				<?php if (! $this->baseSchool) : ?>
					<div class="control-group heading">
						<div class="control-label"> </div>
						<div class="controls"><?php echo DText::_('BRANCH_TEACHER_REG_FORM_FROM_TO_HELP', DText::_('STUDENT'));?></div>
					</div>
					<?php echo $form->renderField('enroll_start'); ?>
					<?php echo $form->renderField('enroll_end'); ?>
				<?php endif; ?>
				<div class="control-group heading">
					<div class="control-label"> </div>
					<div class="controls"><?php echo DText::_('DIGLU_BRANCH_TEACHER_REG_FORM_SCHOOL_HEADING');?></div>
				</div>
				<?php if ($this->baseSchool) :  ?>
					<div class="control-label"><?php echo $this->form->getLabel('state_iso'); ?></div>
					<div class="controls"><input id="jform_state_iso" type="text" name="jform[state_iso]" value="" class="disabled" disabled></div>
					<div class="control-label"><?php echo $this->form->getLabel('school_serial_number'); ?></div>
					<div class="controls"><input id="jform_school_serial_number" type="text" name="jform[school_serial_number]" value="" class="disabled" disabled>
						<p id="school_name"></p>
					</div>
				<?php else : ?>
					<?php echo $form->renderField('country_iso2'); ?>
					<?php echo $form->renderField('state_iso'); ?>
					<?php echo $form->renderField('school_serial_number'); ?>
				<?php endif; ?>
				<div class="control-group heading">
					<div class="control-label"> </div>
					<div class="controls"><?php echo DText::_($teacherDesc);?></div>
				</div>
				<?php echo $form->renderField('forename'); ?>
				<?php echo $form->renderField('surname'); ?>
				<?php echo $form->renderField('branch_teacher_email'); ?>
			</div>
			<div class="form-actions">
				<p class="help-block">
					<?php if ($this->baseSchool) : ?>
						<?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_HELP');?>
					<?php else : ?>
						<?php echo DText::_('LOGIN_FORM_DIGLU_BRANCH_SCHOOL_ACTIVATION_HELP');?>
					<?php endif; ?>
				</p>
				<button id="saveButton" type="button" class="btn btn-primary submit saveButton" disabled onclick="Joomla.submitbutton()">
					<i class="fal fa-check"></i><?php echo Text::_('COM_DILERREG_SCHOOL_CREATE_CODE_LABEL'); ?></button>
				<a id="cancelButton" type="button" class="btn btn-small" href="index.php?option=com_diler"><?php echo Text::_('JCANCEL'); ?></a>
				<input id="Itemid"  type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
				<input id="lang"  type="hidden" name="lang" value="<?php echo $this->lang; ?>" />
				<input id="task"  type="hidden" name="task" value="enrollstudent.createBranchTeacherCode" />
				<input id="option"  type="hidden" name="option" value="com_dilerreg" />
				<input id="base_school"  type="hidden" name="base_school" value="<?php echo $this->baseSchool; ?>" />
				<input  name="formToken" type="hidden" value="<?php echo Session::getFormToken();?>">
			</div>
		</div>
	</fieldset>
</form>


<script>
	Joomla.submitbutton = function (task)
	{
		if (document.formvalidator.isValid(document.getElementById('dilerBranchRegForm')))
		{
			dilerSystem.spinner('start');
			jQuery('#jform_state_iso').prop('disabled', false);
			jQuery('#jform_school_serial_number').prop('disabled', false);
			Joomla.submitform(task, document.getElementById('dilerBranchRegForm'));
		}
	};

	jQuery(document).ready(function ($) {
		dilerSystem.delayedOnInput('jform_student_id', checkStudentId, 500);
		<?php if (! $this->baseSchool) : ?>
			dilerSystem.delayedOnInput('jform_state_iso', checkState, 500);
			dilerSystem.delayedOnInput('jform_school_serial_number', checkSchoolSerialNumber, 500);
		<?php endif; ?>
		dilerSystem.delayedOnInput('jform_forename', checkForm, 500);
		dilerSystem.delayedOnInput('jform_surname', checkForm, 500);
		dilerSystem.delayedOnInput('jform_branch_teacher_email', checkIsBranchTeacherPublished, 500);
		disableDates(true);
        updateCountryStateList(document.getElementById('jform_country_iso2'));
	});

	function checkState() {
		if (jQuery('#jform_state_iso').val() > ' ') {
			jQuery('#jform_school_serial_number').prop('disabled', false);
			jQuery('#jform_school_serial_number').focus();
		} else {
			jQuery('#jform_school_serial_number').prop('disabled', true);
		}
		if (jQuery('#jform_school_serial_number').val() === '') {
			return true;
		} else {
			checkSchoolSerialNumber();
		}
	};

	function checkStudentId(el) {
		var myData = {option: 'com_dilerreg',
			task: 'enrollstudent.checkStudentId',
			student_id: jQuery(el).val(),
			base_school: <?php echo $this->baseSchool; ?>
		};
		var honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
		myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
		myData[jQuery('input[name="formToken"]').val()] = 1;
		dilerSystem.doAjax(myData, 'json', checkStudentIdSuccess, checkError);
	};

	function checkStudentIdSuccess(data) {
		jQuery('#jform_student_id_message').remove();
		if (data.status !== 1) {
			jQuery('#jform_student_id').parent().append('<p id="jform_student_id_message" class="error">' + data.message + '</p>');
			jQuery('#jform_student_id').addClass('invalid');
			jQuery('#jform_state_iso').prop('disabled', true);
			jQuery('#jform_state_iso').val('');
			jQuery('#jform_school_serial_number').val('');
			jQuery('#school_name').text('');
			disableDates(true);
		} else {
			jQuery('#jform_student_id').parent().append('<p id="jform_student_id_message">' + data.message + '</p>');
			jQuery('#jform_student_id').removeClass('invalid');
			disableDates(false);
			if (data.options.baseSchool == 1) {
				jQuery('#jform_state_iso').val(data.schoolInfo.state);
				jQuery('#jform_country_iso2').val(data.schoolInfo.country);
				jQuery('#jform_school_serial_number').val(data.schoolInfo.schoolId);
				jQuery('#school_name').text(data.schoolInfo.name);
			} else {
				jQuery('#jform_state_iso').prop('disabled', false);
				jQuery('#jform_country_iso2').prop('disabled', false);
			}
		}
		checkForm();
	};

	function checkForm() {
		if (jQuery('#jform_student_id').hasClass('invalid') || jQuery('#jform_student_id').val() < ' '
				|| jQuery('#jform_school_serial_number').hasClass('invalid') || jQuery('#jform_school_serial_number').val() < ' '
				|| jQuery('#jform_state_iso').hasClass('invalid') || jQuery('#jform_state_iso').val() < ' ') {
			jQuery('#jform_forename,#jform_surname').prop('disabled', true);
			jQuery('#jform_forename,#jform_branch_teacher_email').prop('disabled', true);
		} else {
			jQuery('#jform_forename,#jform_surname').prop('disabled', false);
			jQuery('#jform_forename,#jform_branch_teacher_email').prop('disabled', false);
			if (jQuery('#jform_forename').val() <= ' ' || jQuery('#jform_surname').val() <= ' '
                || jQuery('#jform_branch_teacher_email').hasClass('invalid'))  {
				jQuery('#saveButton').prop('disabled', true);
			} else {
				jQuery('#saveButton').prop('disabled', false);
			}
		}
	};

	function checkError(data) {
		alert('There is a problem with your DiLer database. Please check with the DiLer administrator.');
	};

	function checkSchoolSerialNumber() {
		let schoolSN = jQuery('#jform_state_iso').val() + jQuery('#jform_school_serial_number').val();
		let myData = {
			option: 'com_dilerreg',
			task: 'enrollstudent.checkSchoolSerialNumber',
			school_serial_number: schoolSN,
			base_school: <?php echo $this->baseSchool; ?>
		};
		let honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
		myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
		myData[jQuery('input[name="formToken"]').val()] = 1;
		dilerSystem.doAjax(myData, 'json', checkSchoolSerialNumberSuccess, checkError);
	};

    function checkIsBranchTeacherPublished(el) {
        var myData = {
            option: 'com_dilerreg',
            task: 'enrollstudent.checkIsBranchTeacherPublished',
            branch_teacher_email: jQuery(el).val()
        };
        var honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
        myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
        myData[jQuery('input[name="formToken"]').val()] = 1;
        dilerSystem.doAjax(myData, 'json', checkIsBranchTeacherPublishedSuccess, checkError);
    };

    function checkIsBranchTeacherPublishedSuccess(data) {
        jQuery('#jform_branch_teacher_email_message').remove();
        if (data.status !== 1) {
            jQuery('#jform_branch_teacher_email').parent().append('<p id="jform_branch_teacher_email_message" class="error">' + data.message + '</p>');
            jQuery('#jform_branch_teacher_email').addClass('invalid');
        } else {
            jQuery('#jform_branch_teacher_email').parent().append('<p id="jform_branch_teacher_email_message">' + data.message + '</p>');
            jQuery('#jform_branch_teacher_email').removeClass('invalid');
        }
        checkForm();
    };

	function checkSchoolSerialNumberSuccess(data) {
		jQuery('#jform_school_serial_number_message').remove();
		if (data.status !== 1) {
			jQuery('#jform_school_serial_number').parent().append('<p id="jform_school_serial_number_message" class="error">' + data.message + '</p>');
			jQuery('#jform_school_serial_number').addClass('invalid');
		} else {
			jQuery('#jform_school_serial_number').parent().append('<p id="jform_school_serial_number_message">' + data.message + '</p>');
			jQuery('#jform_school_serial_number').removeClass('invalid');
		}
		checkForm();
	};

	function disableDates(action) {
		jQuery('#jform_enroll_start').prop('disabled', action);
		jQuery('#jform_enroll_start_btn').prop('disabled', action);
		jQuery('#jform_enroll_end').prop('disabled', action);
		jQuery('#jform_enroll_end_btn').prop('disabled', action);
	};

    function updateCountryStateList(element)
    {
        var stateField = jQuery('#jform_state_iso');
        var countryIso = element.value;
        if (countryIso) {
            var ajaxObject = {
                'task': 'country.getCountryStates',
                'option': 'com_diler',
                'iso' : countryIso
            };
            dilerSystem.doAjax(ajaxObject, 'json', onSuccessGetStates);
            return;
        }

        jQuery('select[name="jform_state_iso"] option[value=""]').prop("selected", true);
        stateField.prop('disabled', true);
    }

    function onSuccessGetStates(response)
    {
        jQuery('#jform_state_iso option:gt(0)').remove();
        var stateField = jQuery("#jform_state_iso");
        jQuery.each(response, function(iso,name) {
            stateField.append(jQuery("<option></option>")
                .attr("value", iso).text(name));
        });
    }

</script>
