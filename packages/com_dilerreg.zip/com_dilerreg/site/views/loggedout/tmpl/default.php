<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// no direct access

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Language\Text;

?>
<h3><?php echo Text::sprintf('COM_DILERREG_LOGGED_OUT_HEADING', Text::_('COM_DILER')); ?></h3>
<p><?php echo Text::_('COM_DILERREG_LOGGED_OUT_MESSAGE'); ?></p>
<a class="btn btn-large btn-primary" href="index.php?option=com_diler"><?php echo Text::_('JLOGIN'); ?></a>
