<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\MVC\View\HtmlView;
use DiLer\Display\DContent;

class DilerregViewRegistrationDigluUser extends HtmlView
{
	public function display($tpl = null)
	{

		$registrationModel        = BaseDatabaseModel::getInstance('Registration', 'DiLerregModel');
		$input                    = Factory::getApplication()->input;
		$this->form               = $registrationModel->getForm(array(), false);
		$this->Itemid             = $input->getUint('Itemid');
		$this->lang               = $input->get('lang');
		$this->termsAndConditions = DContent::getTermsAndConditions();
		$this->registrationCode   = base64_decode($input->getString('registration_code', ''));
		$this->enrollStart        = $input->get('first_school_enrollment_date', '');
		$this->enrollEnd          = $input->get('enroll_end', '');
		parent::display($tpl);
	}
}
