<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Site\Helper\VersionHelper;
use DiLer\DPath;
use DiLer\Lang\DText;
use Joomla\CMS\Form\Form;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

$token = '&' . Session::getFormToken() . '=1';
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

/** @var DilerregViewRegistration $this */

if (!VersionHelper::isJoomla4())
    HTMLHelper::_('behavior.framework');

HTMLHelper::addIncludePath(JPATH_ROOT . '/components/com_diler/helpers/html');
HTMLHelper::_('jquery.framework', false);
HTMLHelper::_('diler.jqvalidate');
HTMLHelper::_('bootstrap.popover');
HTMLHelper::_('bootstrap.tooltip', '.hastooltip');
if (!VersionHelper::isJoomla4())
    HTMLHelper::_('behavior.calendar');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/diler.js');
Factory::getDocument()->addScriptOptions('PDF_WORKER_SRC', Uri::base() . '/media/com_diler/js/mozilla/pdf.worker.js');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/mozilla/pdf-service.js');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/mozilla/pdf.js');



$app = Factory::getApplication();
$componentParams = $app->getParams('com_diler');
$screenkeyboard = $componentParams->get('screenkeyboard_password', 1);
$readonly = $screenkeyboard ? 'readonly' : '';
/** @var Form $form */
$form = $this->form;
// load language file from com_users
$skLanguage = Factory::getLanguage();
$skLanguage->load('com_users', JPATH_SITE, $skLanguage->getTag(), true);
$passwordHintLayout = new FileLayout('password_hint', DPath::LAYOUTS_FIELDS);
$passwordHintButtonLayout = new FileLayout('password_hint_button', DPath::LAYOUTS_FIELDS);
$isDiglu = (bool) DilerHelperUser::isDiglu();
$isBaseSchool = $this->isBaseSchool;
$regType = Text::_('COM_DILERREG_REGISTRATION');
if ($isDiglu && $isBaseSchool && $this->principal)
{
	$regType = DText::_('DIGLU_REGISTER_PRINCIPAL');
}
elseif ($isDiglu && $isBaseSchool)
{
	$regType = DText::_('BASE_TEACHER_REG_FORM_REG_HEADING');
}
elseif ($isDiglu)
{
	$regType = DText::_('BRANCH_TEACHER_REG_FORM_REG_HEADING');
}

if(!$isDiglu)
{
    $form->setFieldAttribute('address', 'required', false);
	$form->setFieldAttribute('state_iso', 'required', false);
	$form->setFieldAttribute('portalcode', 'required', false);
	$form->setFieldAttribute('city', 'required', false);
	$form->setFieldAttribute('swimmer', 'required', false);
	$form->setFieldAttribute('dob', 'required', true);
}
?>
<div id="system-message-container"></div>
<form action="index.php?option=com_dilerreg&task=user.redirectUser&lang=<?php echo $this->lang;?>" method="post" id="dilerRegForm" name="dilerRegForm"  class="form-validate form-horizontal"  enctype="multipart/form-data">
	<fieldset>
		<legend><?php echo $regType;?></legend>
		<div id="enterRegistrationCode" class="control-group hidden">
			<div class="control-label"> </div>
			<div class="controls">
				<div class="input-append">
					<input id="registercode" placeholder="<?php echo Text::_('COM_DILERREG_REGISTRATION_CODE_DESC');?>" tabindex="1" class="" type="text" name="jform[registercode]" required>
					<button id="registerCodeOk" class="btn btn-primary saveButton" type="button" onclick="verifyCode();"><i class="fal fa-ok"></i></button>
					<button id="registerCodeCancel" type="button" class="btn goback visible480"><i class="fal fa-times"></i></button>
				</div>
			</div>
		</div>
		<div id="dilerRegBody" class="hide">
			<div class="row-fluid">
				<?php if (!DilerHelperUser::isDiglu()) : ?>
					<?php echo $form->renderField('role', null, null, array('position' => 'top')); ?>
					<?php echo $form->renderField('dilerrolegroup_name'); ?>
				<?php endif; ?>
				<?php echo $form->renderField('forename'); ?>
                <div class="showForStudent">
				    <?php echo $form->renderField('nickname'); ?>
                </div>
				<?php echo $form->renderField('surname'); ?>
				<?php echo $form->renderField('username'); ?>
				<div id="showForTeacher">
					<?php echo $form->renderField('salutation'); ?>
				</div>
				<div id="showForParentsTeachers">
					<?php echo $form->renderField('title'); ?>
				</div>
                <div id="showForParentAndStudent">
	                <?php echo $form->renderField('country_iso2'); ?>
	                <?php echo $form->renderField('state_iso'); ?>
	                <?php echo $form->renderField('address'); ?>
	                <?php echo $form->renderField('city'); ?>
	                <?php echo $form->renderField('portalcode'); ?>
	                <?php echo $form->renderField('citizenship_iso2'); ?>
                </div>
                <div id="showForParent">
					<?php echo $form->renderField('phonehome'); ?>
					<?php echo $form->renderField('phonemobile'); ?>
					<?php echo $form->renderField('phonework'); ?>
                </div>
				<div class="showForStudent">
					<?php echo $form->renderField('lg_name'); ?>
					<?php echo $form->renderField('gender'); ?>
					<?php echo $form->renderField('dob'); ?>
					<?php echo $form->renderField('pob'); ?>
                    <?php echo $form->renderField('swimmer'); ?>
                    <?php echo $form->renderField('native_language_id'); ?>
				</div>
				<?php echo $form->renderField('email'); ?>
				<div class="control-group">
					<div class="control-label">
						<?php echo $passwordHintButtonLayout->render(); ?>
					</div>
					<div class="controls">
						<div class="input-append">
							<input type="password" name="jform[password]" id="jform_password" value="" class="validate-password required "
								maxlength="99" autocomplete="off" required aria-required="true">
							<a class="btn" onclick="dilerSystem.backspaceKeyboardInput('#jform_password');" title="<?php echo Text::_('COM_DILERREG_SCREENKEYBOARD_DELETE'); ?>"><i class="fal fa-long-arrow-left"></i></a>
							<a class="btn" onclick="dilerSystem.resetKeyboardInput('#jform_password');" title="<?php echo Text::_('COM_DILERREG_SCREENKEYBOARD_DELETE_ALL'); ?>"><i class="fal fa-times"></i></a>
							<a id="jform_passwordKeyboard" class="btn btn-warning" title="<?php echo Text::_('COM_DILERREG_VIRTUALKEYBOARD_SWITCHER'); ?>">
								<i class="fal fa-keyboard"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="control-group">
					<div class="control-label">
						<label id="jform_password2-lbl" for="jform_password2" class="hastooltip required"
							title="<?php echo HTMLHelper::tooltipText(trim(Text::_('COM_DILERREG_USER_FIELD_PASSWORD2_LABEL'), ':'), Text::_('COM_DILERREG_USER_FIELD_PASSWORD2_DESC'), 0); ?>"
						><?php echo Text::_('COM_DILERREG_USER_FIELD_PASSWORD2_LABEL'); ?><span class="star">&nbsp;*</span>
						</label>
					</div>
					<div class="controls">
						<div class="input-append">
							<input type="password" name="jform[password2]" id="jform_password2" value="" class="validate-password required screenkeyboardButtons"
								maxlength="99" autocomplete="off" required aria-required="true" aria-invalid="true">
							<a class="btn" onclick="dilerSystem.backspaceKeyboardInput('#jform_password2');" title="<?php echo Text::_('COM_DILERREG_SCREENKEYBOARD_DELETE'); ?>"><i class="fal fa-long-arrow-left"></i></a>
							<a class="btn" onclick="dilerSystem.resetKeyboardInput('#jform_password2');" title="<?php echo Text::_('COM_DILERREG_SCREENKEYBOARD_DELETE_ALL'); ?>"><i class="fal fa-times"></i></a>
						</div>
					</div>
				</div>
				<?php require("components/com_diler/helpers/screenkeyboardregistration.php"); ?>
				<?php echo $form->renderField('acceptedterms'); ?>
			</div>
			<div class="form-actions">
				<button id="registerButton" type="button" class="btn btn-primary submit saveButton" onclick="registerUser()"><?php echo Text::_('COM_USERS_REGISTER_DEFAULT_LABEL');?></button>
				<button id="registerCodeCancel2" type="button" class="btn btn-small" onclick="cancelRegisterCode()"><?php echo Text::_('JCANCEL'); ?></button>
				<span class="reginfo small"><?php echo Text::_('COM_DILERREG_FIELDS_MARKED_WITH');?></span>

				<input id="Itemid"  type="hidden" name="Itemid" value="<?php echo $this->Itemid;?>" />
				<input id="lang"  type="hidden" name="lang" value="<?php echo $this->lang;?>" />
				<input id="task"  type="hidden" name="task" value="user.registerUser" />
				<input id="option"  type="hidden" name="option" value="com_dilerreg" />
				<input id="codeHidden"  type="hidden" name="codeHidden" value="" />
                <input id="regCodeId"  type="hidden" name="regCodeId" value="" />
				<input id="teacherEmail"  type="hidden" name="teacherEmail" value="<?php echo $this->teacherEmail; ?>" />
				<input id="jform_lg"  type="hidden" name="jform[lg]" value="" />
				<input id="jform_dilerrolegroup"  type="hidden" name="jform[dilerrolegroup]" value="<?php echo ''; ?>" />
				<input id="jform_registration_code"  type="hidden" name="jform[registration_code]" value="<?php echo $this->registrationCode; ?>" />
				<input id="jform_enroll_start"  type="hidden" name="jform[enroll_start]" value="<?php echo $this->enrollStart; ?>" />
				<input id="jform_enroll_end"  type="hidden" name="jform[enroll_end]" value="<?php echo $this->enrollEnd; ?>" />
				<input id="from_branch_school"  type="hidden" name="from_branch_school" value="<?php echo $this->fromBranchSchool; ?>" />
			</div>
		</div>
	</fieldset>
</form>
<div id="tandcModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="tandcLabel" aria-hidden="true">
	<div class="modal-body">
        <input  name="formToken" type="hidden" value="<?php echo Session::getFormToken(); ?>">
    </div>
	<div class="modal-footer"><button type="button" class="btn errorClose" data-dismiss="modal" aria-hidden="true"><?php echo Text::_('JLIB_HTML_BEHAVIOR_CLOSE')?></button></div>
</div>
<?php
echo LayoutHelper::render('base-school-registration-info', null, DPath::LAYOUTS);
?>
<form id="userLogin" name="userLogin" action="index.php?option=com_dilerreg&task=user.redirectUser&lang=<?php echo $this->lang;?>" method="post" enctype="multipart/form-data">
	<input type="hidden" id="loginUsername" name="loginUsername" value="">
	<input type="hidden" id="systemMessage" name="systemMessage" value="">
	<input type="hidden" id="errorMessage" name="errorMessage" value="">
	<input type="hidden" id="isGuest" name="isGuest" value="<?php echo (int) Factory::getUser()->guest; ?>">
</form>
<?php echo $passwordHintLayout->render(); ?>
<div id="attachmentPdfModal" data-modal-id="contract" class="fullSize modal hide fade" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div id="attachmentPdfModal-Body" class="modal-body mediaDisplayWrapper">
        <div id="attachmentPdfModal-SystemMessageWrapper" class="system-message-container hide"></div>
    </div>
    <div id="attachmentPdfModal-Footer" class="modal-footer">
        <div class="form-inline">
            <button class="btn closeButton" data-dismiss="modal" aria-hidden="true"><?php echo DText::_('CLOSE'); ?></button>
        </div>
    </div>
</div>
<style>
    #pdf-container canvas {
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    #pdf-container {
        max-height: 100%;
    }
    .pdf-buttons {
        display: inline-block;
    }
    .pdf-buttons button {
        margin: 0px 3px;
    }
</style>
<script>
    var isDiglu = <?php echo (int) $isDiglu ?>;
	jQuery( document ).ready(function( $ ) {
		<?php if ($this->canDisplayRegistrationInfo()) : ?>
			jQuery('#base-school-registration-info').modal("show");
		<?php endif; ?>
        $('#jform_acceptedterms').after(
            '<a type="button" ' +
            'id="view-terms-and-conditions" ' +
            'class="view-terms-and-conditions" ' +
            'is_diglu="' + <?php echo json_encode($isDiglu); ?> + '" ' +
            'data-media-folder="6" ' +
            'onclick="dpdf.displayTermsAndConditions(this);" ' +
            'title="' + <?php echo json_encode(DText::_('DISPLAY')); ?> + '" ' +
            'data-modal-id="attachmentPdfModal">' +
            '<?php echo Text::_('COM_DILERREG_TERMS_AND_CONDITIONS'); ?>' +
            '</a>'
        );
        let registrationCode = jQuery('#jform_registration_code').val();
		let fromBranchSchool = jQuery('#from_branch_school').val();
		if (registrationCode > ' ' && fromBranchSchool !== '1') {
			var teacherEmail = jQuery('#teacherEmail').val();
			verifyCode(registrationCode, teacherEmail);
			jQuery('#registercode').val(registrationCode);
			jQuery('#jform_email').val(teacherEmail);
		}
		if (fromBranchSchool === '1') {
			jQuery('#registercode').val(registrationCode);
		}
		jQuery('#enterRegistrationCode').removeClass('hidden');
		jQuery.validator.addMethod("passwordEqual", function(value, element) {
				return (value === jQuery('#jform_password').val());
			}, "<?php echo DText::_('ERROR_MSG_PASSWORD_CONFIRMED'); ?>");
		jQuery.validator.addMethod("acceptedTerms", function(value, element) {
				return jQuery('#jform_acceptedterms').prop('checked');
			}, "<?php echo DText::_('ERROR_MSG_ACCEPTED_TERMS'); ?>");
		jQuery.validator.addMethod("acceptedContract", function(value, element) {
				return jQuery('#jform_acceptedcontract').prop('checked');
			}, "<?php echo DText::_('ERROR_MSG_ACCEPTED_CONTRACT'); ?>");

		let validator = jQuery("#dilerRegForm").validate({
			rules: {
				"jform[password]": {
					required: true,
					remote: {
						url: "index.php",
						type: "post",
						data: {
							option: 'com_dilerreg',
							task: 'user.checkRegForm',
							field: 'password'
						}
					}
				},
				"jform[password2]": {
					required: true,
					passwordEqual: true
				},
				"jform[email]": {
					required: true,
					email: true,
					remote: {
						url: "index.php",
						type: "post",
						data: {
							option: 'com_dilerreg',
							task: 'user.checkRegForm',
							field: 'email'
						}
					}
				},
				"jform[acceptedterms]": {
					acceptedTerms: true
				},
				"jform[acceptedcontract]": {
					acceptedContract: true
				}
			}
		});
	});

	Joomla.submitbutton = function(task) {
		if (jQuery('#dilerRegForm').valid()) {
			Joomla.submitform(task, document.getElementById('dilerRegForm'));
		}
	};

	var dummyEmail;
	function verifyCode(regCode, teacherEmail){
		if (typeof regCode === 'undefined') {
			regCode = jQuery('#registercode').val();
		}
		if (typeof teacherEmail === 'undefined') {
			teacherEmail = teacherEmail = '';
		}
		dilerSystem.actionIcon('registerCodeOk', 'start');
		var myData = {'option': 'com_dilerreg',
				'task': 'user.verifyCode',
				'code': regCode,
				'teacherEmail': teacherEmail
	    	};
		var verifyCode = jQuery.ajax({
			url: 'index.php',
			data: myData,
			dataType: 'json',
			async: true,
			cache: false
		});

		verifyCode.done(function(data) {
			if (data == null) {
				dilerSystem.actionIcon('registerCodeOk','stop');
				options = {
						header: "<?php echo Text::_('ERROR'); ?>",
						body: "<?php echo htmlspecialchars(Text::_('COM_DILERREG_REGISTRATION_CODE_ERROR')); ?>",
						closeButton: "<?php echo DText::_('CLOSE'); ?>"
					};
				dilerSystem.modalCreate(options);
				return true;
			} else if (typeof data.isDiglu !== 'undefined') {
				// Need to redirect to Diglu form
				window.location.href = 'index.php?option=com_dilerreg&view=registerteacher&registration_code=' + data.code + '&Itemid=' +
						jQuery('#Itemid').val();
				return true;
			}
			dilerSystem.actionIcon('registerCodeOk','stop');
			// Remove fields based on role
			if (data.role == 'student') {
				jQuery('#showForTeacher').remove();
				jQuery('#showForParentsTeachers').remove();
                jQuery('#showForParent').remove();
			} else if(data.role == 'parent'){

				jQuery('.showForStudent').remove();
				jQuery('#showForTeacher').remove();
			} else if (data.role == 'teacher') {
				jQuery('.showForStudent').remove();
				jQuery('#showForParentAndStudent').remove();
                jQuery('.showForParentAndStudent').remove();
				jQuery('#showForParent').remove();
			}
			if (data.role == 'teacher' && data.base_school_id > ' ') {
				jQuery('#jform_acceptedcontract').after('<a href="#contractModal" id="contractread" class="" data-toggle="modal">' + data.contractName + '</a>');
				// make email read only
				jQuery('#jform_email').val(data.email);
				jQuery('#jform_email').prop('disabled', true);
				jQuery('head').append(data.cssLink);
				jQuery('#contractModalBody').html(data.contractText);
				// set flag for create account
			} else {
				jQuery('#jform_acceptedcontract').prop('checked', true);
				jQuery('#acceptedcontract').hide();
			}

			if (data.role == 'teacher' && isDiglu)
			{
				jQuery('#jform_email').prop('disabled', true);
            }

			// Fill in read-only fields from data
			jQuery('#jform_lg_name').val(data.lg_name);
			jQuery('#jform_section_name').val(data.section_name);
			jQuery('#jform_role').val(data.role);
			jQuery('#jform_dilerrolegroup_name').val(data.dilerrolegroup_name);
			jQuery('#jform_dilerrolegroup').val(data.dilerrolegroup);
			jQuery('#jform_forename').val(data.forename);
			jQuery('#jform_nickname').val(data.nickname);
			jQuery('#jform_surname').val(data.surname);
			jQuery('#jform_username').val(data.username);
			jQuery('#jform_lg').val(data.lg);
            jQuery('#jform_dob').val(data.dob).prop('readonly', true).prop('required', false);
            if (!isDiglu && !data.dob)
            {
                jQuery('#jform_dob').prop('disabled', false).prop('readonly', true).prop('required', true);
                jQuery('#jform_dob').css('background', 'white');
                jQuery('#jform_dob').click(function() {
                    jQuery('#jform_dob_btn').trigger('click');
                });
                jQuery('#jform_dob_btn').removeClass('hidden');
            }
			jQuery('#registercode').prop('disabled', true);
			jQuery('#registerCodeOk').prop('disabled', true);
			jQuery('#registerCodeCancel').prop('disabled', true);
			jQuery('#dilerRegBody').slideDown();
			jQuery('#regCodeId').val(data.code_id);
			jQuery('#jform_native_language_id').val(data.native_language_id);
			if (isDiglu)
			    jQuery('#declarationOfConsentModalBody').val(data.declartion_of_consent_html);

			dummyEmail = data.dummyEmail;
			if (data.role != 'teacher')
			    updateCountryStateList(document.getElementById('jform_country_iso2'));
		});

		verifyCode.fail(function(data){
			dilerSystem.actionIcon('registerCodeOk','stop');
			options = {
				header: "<?php echo Text::_('ERROR'); ?>",
				body: data.responseText,
				closeButton: "<?php echo DText::_('CLOSE'); ?>"
			};
			dilerSystem.modalCreate(options);
		});
	};

	function registerUser() {
		jQuery('#registerButton').prop('disabled', true);
		var errors = false;
		dilerSystem.actionIcon('registerButton', 'start');
		// Create dummy email if email is blank.
		if (jQuery("#jform_email").val() == '') {
			dilerSystem.actionIcon('registerButton', 'stop');
			jQuery('#registerButton').prop('disabled', false);
			jQuery("#jform_email").val(dummyEmail);
			options = {
					header: "<?php echo Text::_('NOTICE'); ?>",
					body: "<?php echo Text::_('COM_DILERREG_REGISTRATION_EMAIL_CREATED'); ?>",
					closeButton: "<?php echo DText::_('CLOSE'); ?>"
				};
				dilerSystem.modalCreate(options);
				errors = true;
		}

		jQuery('#system-message-container').html(jQuery(''));
		if (! jQuery('#dilerRegForm').valid()) {
			errors = true;
		}

		var enteredPassword = jQuery('#password').val();

		if (errors) {
			dilerSystem.actionIcon('registerButton', 'stop');
			jQuery('#registerButton').prop('disabled', false);
			return true;
		}

		// Do ajax to validate form on server. Redirect to login if successful, otherwise return error to form.
		jQuery('#registercode').prop('disabled', false);
		jQuery('#codeHidden').val(jQuery('#registercode').val());
		jQuery('#registercode').prop('disabled', true);
		jQuery('#jform_email').prop('disabled', false);
		var formData = jQuery('#dilerRegForm').serialize();
		var registerUser = jQuery.ajax({
			url: 'index.php',
			type: 'POST',
			data: formData,
			dataType: 'json',
			async: true,
			cache: false
		});

		// data.status is 0 or 1. data.messageArray is array: messages=>{success messages}, errors=>{error messages}
		registerUser.done(function(data) {
			if (data.status == '0') {
				dilerSystem.actionIcon('registerButton', 'stop');
				jQuery('#registerButton').prop('disabled', false);
				jQuery('#system-message-container').html(data.errorMessage);
			} else {
				jQuery('form').addClass('hide');
				if (jQuery('#isGuest').val() == '1') {
					dilerSystem.addResponseContainer('#dilerMain', '<?php echo Text::_('COM_DILERREG_LOGIN_REDIRECT'); ?>', '4x');
				} else {
					dilerSystem.addResponseContainer('#dilerMain', '<?php echo Text::_('COM_DILERREG_DILER_REDIRECT'); ?>', '4x');
				}
				jQuery('#loginUsername').val(data.username);
				jQuery('#systemMessage').val(data.messages);
				jQuery('#errorMessage').val(data.errors);
				jQuery('#userLogin').submit();
			}
		});

		registerUser.fail(function(data){
			dilerSystem.actionIcon('registerButton', 'stop');
			jQuery('#registerButton').prop('disabled', false);
	    	alert(data.responseText);
		});
	};

	function cancelRegisterCode() {
		window.onbeforeunload = null;
		if (history.length <= 1) {
			window.close();
		} else {
			history.back();
		}
	};

	jQuery("#registercode").on('keyup', function (e) {
	    if (e.keyCode == 13) {
	        jQuery('#registerCodeOk')[0].click();
	    }
	});

	 function updateCountryStateList(element)
	 {
		 var stateField = jQuery('#jform_state_iso');
		 var countryIso = element.value;
		 if (countryIso) {
             stateField.prop('disabled', false);
			 var ajaxObject = {
                 'task': 'country.getCountryStates',
                 'option': 'com_diler',
                 'iso' : countryIso,
				 'lang' : "<?php echo $this->lang;?>",
				 'Itemid' : "<?php echo $this->Itemid;?>"
             };
			 dilerSystem.doAjax(ajaxObject, 'json', onSuccessGetStates);
			 return;
		 }

		 jQuery('select[name="jform_state_iso"] option[value=""]').prop("selected", true);
		 stateField.prop('disabled', true);
     }

	 function onSuccessGetStates(response)
	 {
		 jQuery('#jform_state_iso option:gt(0)').remove();
		 var stateField = jQuery("#jform_state_iso");
		 jQuery.each(response, function(iso,name) {
			 stateField.append(jQuery("<option></option>")
				 .attr("value", iso).text(name));
		 });
     }

</script>

