<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\MVC\View\HtmlView;
use DiLer\Display\DContent;

// import Joomla view library


class DilerregViewRegistration extends HtmlView
{
    /**
     * DiLers view display method
     * @param string $tpl A string to view tmpl.
     * @return void
     * @throws Exception
     */
	function display($tpl = null) {

		$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DiLerregModel');
		$input = Factory::getApplication()->input;
		$this->form = $registrationModel->getForm(array(), false);
		$this->Itemid = $input->getUint('Itemid');
		$this->lang = $input->get('lang');
		$this->termsAndConditions = DContent::getTermsAndConditions();
		$this->registrationCode = base64_decode($input->getString('registration_code', ''));
		$this->enrollStart = $input->get('enroll_start', '');
		$this->enrollEnd = $input->get('enroll_end', '');
		$this->teacherEmail = base64_decode($input->getString('teacher_email', ''));
		$this->reportTypeId = $input->getUint('report_type_id');
		$this->isBaseSchool = $input->getUint('base_school', 0);
		$this->fromBranchSchool = $input->getUint('from_branch_school', 0);
		$this->principal = $input->getUint('principal', 0);
		parent::display($tpl);
	}

	public function canDisplayRegistrationInfo() : bool
	{
		return DilerHelperUser::isDiglu() && $this->isBaseSchool && $this->principal;
	}
}
