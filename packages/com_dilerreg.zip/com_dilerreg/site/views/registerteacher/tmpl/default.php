<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\DPath;
use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Session\Session;

if(!\Audivisa\Component\DiLer\Site\Helper\VersionHelper::isJoomla4())
    HTMLHelper::_('behavior.framework');
HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('bootstrap.popover');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js');
Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/diler.js');

$isDiglu = DilerHelperUser::isDiglu();
if (!$isDiglu) die('Restricted access');
$form = $this->form;
// load language file from com_users
$skLanguage = Factory::getLanguage();
$skLanguage->load('com_users', JPATH_SITE, $skLanguage->getTag(), true);
if ($this->baseSchool && $this->principal)
{
	$legendTag = 'COM_DILER_DIGLU_REGISTER_PRINCIPAL';
}
else
{
	$legendTag = $this->baseSchool ? 'COM_DILER_BASE_TEACHER_REG_FORM_REG_HEADING' : 'COM_DILER_BRANCH_TEACHER_REG_FORM_REG_HEADING';

}
?>

<div id="system-message-container"></div>
<form action="index.php?option=com_dilerreg" method="post" id="dilerBranchRegForm" name="dilerBranchRegForm"  class="form-validate form-horizontal"  enctype="multipart/form-data">
	<fieldset>
		<legend><?php echo DText::_($legendTag);?></legend>
		<?php if ($this->baseSchool && $this->principal) : ?>
			<div class="control-group">
				<div class="control-label"> </div>
				<div class="controls">
					<a href="#base-school-registration-info" role="button" class="btn btn-small" data-toggle="modal"><?php echo DText::_('DIGLU_BASE_SCHOOL_REGISTRATION_MODAL_TRIGGER');?></a>
				</div>
			</div>
		<?php endif; ?>
		<div id="dilerRegBody">
			<div class="row-fluid">
				<?php echo DilerHelperUser::honeypotGetInput(); ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('registration_code'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('registration_code'); ?>
						<?php if (empty($this->registration_code)) : ?>
							<p class="help-block"><?php echo DText::_('BRANCH_TEACHER_REG_FORM_REG_CODE_HELP');?></p>
						<?php endif; ?>
					</div>
				</div>
				<?php if (empty($this->principal)) : ?>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('teacher_email'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('teacher_email'); ?>
							<?php if ($this->baseSchool && $this->principal) :?>
								<p class="help-block"><?php echo DText::_('BASE_SCHOOL_ACT_FORM_EMAIL_HELP');?></p>
							<?php else :?>
								<p class="help-block-teacher-email"><?php echo DText::_('BRANCH_TEACHER_REG_FORM_EMAIL_HELP');?></p>
							<?php endif;?>
							<p id="email_check_response"></p>
						</div>
					</div>
				<?php else : ?>
					<input type="hidden" id="jform_teacher_email" name="jform[teacher_email]" value="">
				<?php endif; ?>
			</div>
			<div class="form-actions">
				<button id="saveButton"
					type="button"
					class="btn btn-primary submit saveButton"
					disabled onclick="Joomla.submitbutton()"
					>
					<i class="fal fa-check"></i> <?php echo DText::_($legendTag); ?>
				</button>
				<a id="cancelButton" type="button" class="btn btn-small" href="index.php?option=com_diler"><?php echo Text::_('JCANCEL'); ?></a>
				<input id="Itemid"  type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
				<input id="lang"  type="hidden" name="lang" value="<?php echo $this->lang; ?>" />
				<input id="principal"  type="hidden" name="principal" value="<?php echo $this->principal; ?>" />
				<input id="base_school"  type="hidden" name="base_school" value="<?php echo $this->baseSchool; ?>" />
				<input id="task"  type="hidden" name="task" value="registerteacher.registerOrAssign" />
				<input id="option"  type="hidden" name="option" value="com_dilerreg" />
				<input id="default_registration_code"  type="hidden" name="default_registration_code" value="<?php echo $this->registration_code; ?>" />
				<input  name="formToken" type="hidden" value="<?php echo Session::getFormToken();?>">
			</div>
		</div>
	</fieldset>
</form>
<div id="dilerModalTarget" ></div>
<?php
echo LayoutHelper::render('base-school-registration-info', null, DPath::LAYOUTS);
?>
<script>
	let modalData = {};
	Joomla.submitbutton = function (task)
	{
		if (document.formvalidator.isValid(document.getElementById('dilerBranchRegForm')))
		{
			dilerSystem.spinner('start');
			jQuery('#jform_teacher_email').prop('disabled', false);
			Joomla.submitform(task, document.getElementById('dilerBranchRegForm'));
		}
	};

	jQuery(document).ready(function ($) {
		<?php if ($this->baseSchool && $this->principal && $this->registration_code) : ?>
			$('#base-school-registration-info').modal("show");
		<?php endif; ?>
		dilerSystem.delayedOnInput('jform_registration_code', checkRegistrationCode, 500);
		dilerSystem.delayedOnInput('jform_teacher_email', checkTeacherEmail, 500);
		if (jQuery('#default_registration_code').val() > ' ') {
			jQuery('#jform_registration_code').val(jQuery('#default_registration_code').val());
			checkRegistrationCode(document.getElementById('jform_registration_code'));
		}
	});

	function checkRegistrationCode(el) {
		var myData = {option: 'com_dilerreg',
			task: 'registerteacher.checkRegistrationCode',
			registration_code: jQuery(el).val(),
			registration_item_id: jQuery('#Itemid').val(),
			principal: jQuery('#principal').val(),
			base_school: jQuery('#base_school').val()
		};
		var honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
		myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
		myData[jQuery('input[name="formToken"]').val()] = 1;
		dilerSystem.doAjax(myData, 'json', checkRegistrationCodeSuccess, checkError);
	};

	function checkRegistrationCodeSuccess(data) {
		jQuery('#jform_registration_code_message').remove();
		if (data.status === 1 && data.principal === 0) { // Valid code
			jQuery('#jform_registration_code').next().after('<div id="jform_registration_code_message" class="small">' + data.message + '</div>');
			jQuery('#jform_registration_code').removeClass('invalid');
			jQuery('#enrollPeriodHelp').html(DilerSprintJs('COM_DILER_BRANCH_TEACHER_REG_FORM_FROM_TO_HELP', data.studentFullName));
			jQuery('#jform_teacher_email').prop('disabled', false);
            jQuery('.help-block').hide();
		} else if (data.status === 1 && data.principal === 1) {
			jQuery('#jform_registration_code').after('<div id="jform_registration_code_message" class="small">' + data.message + '</div>');
			jQuery('#jform_registration_code').removeClass('invalid');
			jQuery('#enrollPeriodHelp').html(DilerSprintJs('COM_DILER_BRANCH_TEACHER_REG_FORM_FROM_TO_HELP', data.studentFullName));
			jQuery('#jform_teacher_email').val(data.email);
			jQuery('#jform_teacher_email').removeClass('invalid');
			jQuery('#saveButton').removeClass('invalid').prop('disabled', false);
            jQuery('.help-block').hide();
		} else if (data.status === 2) { // Not valid for branch, but valid for base school.
			jQuery('#jform_registration_code').addClass('invalid');
			let options = {
				header: data.header,
				body: data.message,
				confirmButton: data.messageButton,
				confirmOnclick: 'redirectToCorrectForm()',
				cancelButton: '<?php echo Text::_('JCANCEL'); ?>'
			};
			modalData = data;
			dilerSystem.modalCreate(options);
		} 	else {
			jQuery('#jform_registration_code').after('<div id="jform_registration_code_message" class="small">' + data.message + '</div>');
			jQuery('#jform_registration_code').addClass('invalid');
			jQuery('#enrollPeriodHelp').html(DilerSprintJs('COM_DILER_BRANCH_TEACHER_REG_FORM_FROM_TO_HELP', DilerTranslateJs('COM_DILER_STUDENT')));
			jQuery('#jform_teacher_email').prop('disabled', true);
            jQuery('.help-block').show();
		}

		checkForm(data);
	};

	function checkForm(data) {
		if (jQuery('#jform_teacher_email').val() < ' ') {
			jQuery('#jform_teacher_email').addClass('invalid');
		}
		if (jQuery('#jform_registration_code').val() < ' ') {
			jQuery('#jform_registration_code').addClass('invalid');
		}
		if (jQuery('#jform_registration_code').hasClass('invalid') || jQuery('#jform_teacher_email').hasClass('invalid')) {
			jQuery('#saveButton').prop('disabled', true);
		} else {
			jQuery('#saveButton').prop('disabled', false);
		}
	};

	function checkError(data) {
        jQuery('#jform_teacher_email_message').remove();
        jQuery('#email_check_response').text('');
        if (data.status === 0) {
            jQuery('#jform_teacher_email').next().after('<div id="jform_teacher_email_message" class="alert alert-error">&nbsp;' + data.message + '</div>');
            jQuery('#jform_teacher_email').addClass('invalid');
            jQuery('.help-block-teacher-email').show();
        } else {
            jQuery('#jform_teacher_email').removeClass('invalid');
            jQuery('#email_check_response').text(data.message);
            jQuery('.help-block-teacher-email').hide();
        }
        checkForm(data);
	};

	function checkTeacherEmail(el) {
		var myData = {option: 'com_dilerreg',
			task: 'registerteacher.checkTeacherEmail',
			teacher_email: jQuery(el).val()
		};
		var honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
		myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
		myData[jQuery('input[name="formToken"]').val()] = 1;
		dilerSystem.doAjax(myData, 'json', checkTeacherEmailSuccess, checkError);
	};

    function checkTeacherEmailSuccess(data) {
        jQuery('#jform_teacher_email_message').remove();
        jQuery('#email_check_response').text('');
        if (data.status === 0) {
            jQuery('#jform_teacher_email').next().after('<div id="jform_teacher_email_message" class="alert alert-error">&nbsp;' + data.message + '</div>');
            jQuery('#jform_teacher_email').addClass('invalid');
            jQuery('.help-block-teacher-email').show();
        } else {
            jQuery('#jform_teacher_email').removeClass('invalid');
            jQuery('#email_check_response').text(data.message);
            jQuery('.help-block-teacher-email').hide();
        }
        checkForm(data);
    };

	function redirectToCorrectForm() {
		window.location.href = modalData.link;
	};

</script>
