<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Uri\Uri;

// import Joomla view library


class DilerregViewRegisterTeacher extends HtmlView
{
    /**
     * DiLers view display method
     * @param string $tpl A string to view tmpl.
     * @return void
     * @throws Exception
     */
	function display($tpl = null) {

		$registrationModel = BaseDatabaseModel::getInstance('RegisterTeacher', 'DiLerregModel');
		$input = Factory::getApplication()->input;
		$this->form = $registrationModel->getForm(array(), false);
		$this->Itemid = $input->getUint('Itemid');
		$this->baseSchool = $input->getUint('base_school', 0);
		$this->principal = $input->getUint('principal', 0);
		$this->lang = $input->get('lang');
		$this->registration_code = base64_decode($input->getString('registration_code'));
		$this->prepareDocument();
		parent::display($tpl);
	}

	protected function prepareDocument()
	{
		HTMLHelper::_('jquery.framework', false);
		$document = Factory::getDocument();
		$document->addScript(Uri::root(true) . '/media/com_diler/js/moment-with-locales.min.js');
		$document->addScript(Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js');
		$document->addScript(Uri::root(true) . '/media/com_diler/js/diler.js');
		$document->addStyleSheet(Uri::root(true) . '/media/com_diler/css/diler.css');
		DText::script('BRANCH_TEACHER_REG_FORM_FROM_TO_HELP');
		DText::script('STUDENT');
	}
}
