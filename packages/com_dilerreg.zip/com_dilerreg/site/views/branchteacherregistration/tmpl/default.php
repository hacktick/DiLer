<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use DiLer\Lang\DText;
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

JHtml::_('behavior.framework');
JHtml::_('behavior.formvalidation');
JHtml::_('bootstrap.popover');
JFactory::getDocument()->addScript(JURI::root(true) . '/media/com_diler/js/jquery.fitvids.js');
JFactory::getDocument()->addScript(JURI::root(true) . '/media/com_diler/js/diler.js');

$isDiglu = DilerHelperUser::isDiglu();
if (!$isDiglu) die('Restricted access');
$form = $this->form;
// load language file from com_users
$skLanguage = JFactory::getLanguage();
$skLanguage->load('com_users', JPATH_SITE, $skLanguage->getTag(), true);
?>
<div id="system-message-container"></div>
<form action="index.php?option=com_dilerreg" method="post" id="dilerBranchRegForm" name="dilerBranchRegForm"  class="form-validate form-horizontal"  enctype="multipart/form-data">
	<fieldset>
		<legend>
			<?php echo DText::sprintf('LOGIN_FORM_DIGLU_BRANCH_SCHOOL_ACTIVATION_LEGEND', DText::_('STUDENT'));?>
		</legend>
		<div id="dilerRegBody">
			<div class="row-fluid">
				<?php echo DilerHelperUser::honeypotGetInput(); ?>
				<div class="control-group student-id">
					<div class="control-label"><?php echo $this->form->getLabel('student_id'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('student_id'); ?>
						<p class="help-block"><?php echo JText::sprintf('COM_DILERREG_STUDENT_ID_DESC', DText::_('STUDENT'));?></p>
					</div>
				</div>
				<div class="control-group heading">
					<div class="control-label"> </div>
					<div class="controls"><?php echo DText::sprintf('BRANCH_TEACHER_REG_FORM_FROM_TO_HELP', DText::_('STUDENT'));?></div>
				</div>
				<?php echo $form->renderField('enroll_start'); ?>
				<?php echo $form->renderField('enroll_end'); ?>
				<div class="control-group heading">
					<div class="control-label"> </div>
					<div class="controls"><?php echo DText::sprintf('DIGLU_BRANCH_TEACHER_REG_FORM_SCHOOL_HEADING');?></div>
				</div>
				<?php echo $form->renderField('state_iso'); ?>
				<?php echo $form->renderField('school_serial_number'); ?>
				<div class="control-group heading">
					<div class="control-label"> </div>
					<div class="controls"><?php echo DText::sprintf('DIGLU_BRANCH_TEACHER_REG_FORM_NAME_DESC', DText::_('STUDENT'));?></div>
				</div>
				<?php echo $form->renderField('forename'); ?>
				<?php echo $form->renderField('surname'); ?>
				<?php echo $form->renderField('branch_teacher_email'); ?>
			</div>
			<div class="form-actions">
				<p class="help-block"><?php echo DText::_('LOGIN_FORM_DIGLU_BRANCH_SCHOOL_ACTIVATION_HELP');?></p>
				<button id="saveButton" type="button" class="btn btn-primary submit saveButton" disabled onclick="Joomla.submitbutton()">
					<i class="fal fa-check"></i><?php echo JText::_('COM_DILERREG_SCHOOL_CREATE_CODE_LABEL'); ?></button>
				<a id="cancelButton" type="button" class="btn btn-small" href="index.php?option=com_diler"><?php echo JText::_('JCANCEL'); ?></a>
				<input id="Itemid"  type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
				<input id="lang"  type="hidden" name="lang" value="<?php echo $this->lang; ?>" />
				<input id="task"  type="hidden" name="task" value="branchTeacherRegister.createBranchTeacherCode" />
				<input id="option"  type="hidden" name="option" value="com_dilerreg" />
				<input  name="formToken" type="hidden" value="<?php echo JSession::getFormToken();?>">
			</div>
		</div>
	</fieldset>
</form>


<script>
	Joomla.submitbutton = function (task)
	{
		if (document.formvalidator.isValid(document.id('dilerBranchRegForm')))
		{
			dilerSystem.spinner('start');
			Joomla.submitform(task, document.getElementById('dilerBranchRegForm'));
		}
	};

	jQuery(document).ready(function ($) {
		dilerSystem.delayedOnInput('jform_student_id', checkStudentId, 500);
		dilerSystem.delayedOnInput('jform_state_iso', checkState, 500);
		dilerSystem.delayedOnInput('jform_school_serial_number', checkSchoolSerialNumber, 500);
		dilerSystem.delayedOnInput('jform_forename', checkForm, 500);
		dilerSystem.delayedOnInput('jform_surname', checkForm, 500);
		disableDates(true);
	});

	function checkState() {
		if (jQuery('#jform_state_iso').val() > ' ') {
			jQuery('#jform_school_serial_number').prop('disabled', false);
			jQuery('#jform_school_serial_number').focus();
		} else {
			jQuery('#jform_school_serial_number').prop('disabled', true);
		}
		if (jQuery('#jform_school_serial_number').val() === '') {
			return true;
		} else {
			checkSchoolSerialNumber();
		}
	};

	function checkStudentId(el) {
		var myData = {option: 'com_dilerreg',
			task: 'branchteacherregister.checkStudentId',
			student_id: jQuery(el).val()
		};
		var honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
		myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
		myData[jQuery('input[name="formToken"]').val()] = 1;
		dilerSystem.doAjax(myData, 'json', checkStudentIdSuccess, checkError);
	};

	function checkStudentIdSuccess(data) {
		jQuery('#jform_student_id_message').remove();
		if (data.status !== 1) {
			jQuery('#jform_student_id').parent().append('<p id="jform_student_id_message" class="error">' + data.message + '</p>');
			jQuery('#jform_student_id').addClass('invalid');
			jQuery('#jform_state_iso').prop('disabled', true);
			disableDates(true);
		} else {
			jQuery('#jform_student_id').parent().append('<p id="jform_student_id_message">' + data.message + '</p>');
			jQuery('#jform_student_id').removeClass('invalid');
			jQuery('#jform_state_iso').prop('disabled', false);
			disableDates(false);
		}
		checkForm();
	};

	function checkForm() {
		if (jQuery('#jform_student_id').hasClass('invalid') || jQuery('#jform_student_id').val() < ' '
				|| jQuery('#jform_school_serial_number').hasClass('invalid') || jQuery('#jform_school_serial_number').val() < ' '
				|| jQuery('#jform_state_iso').hasClass('invalid') || jQuery('#jform_state_iso').val() < ' ') {
			jQuery('#jform_forename,#jform_surname').prop('disabled', true);
			jQuery('#jform_forename,#jform_branch_teacher_email').prop('disabled', true);
		} else {
			jQuery('#jform_forename,#jform_surname').prop('disabled', false);
			jQuery('#jform_forename,#jform_branch_teacher_email').prop('disabled', false);
			if (jQuery('#jform_forename').val() <= ' ' || jQuery('#jform_surname').val() <= ' ') {
				jQuery('#saveButton').prop('disabled', true);
			} else {
				jQuery('#saveButton').prop('disabled', false);
			}
		}
	};

	function checkError(data) {
		alert('There is a problem with your DiLer database. Please check with the DiLer administrator.');
	};

	function checkSchoolSerialNumber() {
		let schoolSN = jQuery('#jform_state_iso').val() + jQuery('#jform_school_serial_number').val();
		let myData = {
			option: 'com_dilerreg',
			task: 'branchteacherregister.checkSchoolSerialNumber',
			school_serial_number: schoolSN,
		};
		let honeypotName = "<?php echo DilerHelperUser::$honeypotFieldName; ?>";
		myData[honeypotName] = jQuery('input[name="' + honeypotName + '"]').prop('checked') ? 1 : 0;
		myData[jQuery('input[name="formToken"]').val()] = 1;
		dilerSystem.doAjax(myData, 'json', checkSchoolSerialNumberSuccess, checkError);
	};

	function checkSchoolSerialNumberSuccess(data) {
		jQuery('#jform_school_serial_number_message').remove();
		if (data.status !== 1) {
			jQuery('#jform_school_serial_number').parent().append('<p id="jform_school_serial_number_message" class="error">' + data.message + '</p>');
			jQuery('#jform_school_serial_number').addClass('invalid');
		} else {
			jQuery('#jform_school_serial_number').parent().append('<p id="jform_school_serial_number_message">' + data.message + '</p>');
			jQuery('#jform_school_serial_number').removeClass('invalid');
		}
		checkForm();
	};

	function disableDates(action) {
		jQuery('#jform_enroll_start').prop('disabled', action);
		jQuery('#jform_enroll_start_btn').prop('disabled', action);
		jQuery('#jform_enroll_end').prop('disabled', action);
		jQuery('#jform_enroll_end_btn').prop('disabled', action);
	};

</script>
