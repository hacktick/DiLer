<?php

defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Pathway\Pathway;
use Joomla\CMS\MVC\View\HtmlView;

class DilerregViewBase_school_principal_avv_agreement extends HtmlView
{
    protected $form;
	public function display($tpl = null)
	{
        /** @var Pathway $pathWay */
        $pathWay = Factory::getApplication()->getPathway();
        $pathWay->addItem(DText::_('BASE_SCHOOL_TEACHER_AVV_WARNING_TITLE'));
		parent::display($tpl);
	}
}