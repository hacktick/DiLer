<?php
// No direct access to this file
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

Factory::getApplication()->getDocument()->getWebAssetManager()
    ->useStyle('webcomponent.joomla-alert')
    ->useScript('messages');
$session = Factory::getApplication()->getSession();
/** @var DilerregViewBase_school_principal_avv_agreement $this */
/** @var \Joomla\CMS\Form\Form $form */
$form = $this->getForm();
$showFormRightAway = Factory::getApplication()->input->get('showFormRightAway', false);
?>

<?php if (!$showFormRightAway): ?>
    <div id="accept_consent_buttons" class="text-center" style="margin-bottom: 100px">
        <div class="alert-wrapper">
            <div class="alert-message"><?php echo DText::_('COM_DILER_BASE_SCHOOL_PRINCIPAL_AVV_WARNING_MESSAGE'); ?></div>
            <div class="alert-message"><?php echo DText::_('COM_DILER_BASE_SCHOOL_PRINCIPAL_AVV_CONSENT_MESSAGE'); ?></div>
        </div>
        <div class="form-actions">
            <button id="openAvvVvtForm" type="button" class="btn btn-primary submit saveButton"
                    onclick="openAvvVvtForm()"><i class="fas fa-check"></i>
                <?php echo DText::_('BASE_SCHOOL_PRINCIPAL_AVV_WARNING_MESSAGE_YES'); ?>
            </button>
            <a id="cancelButton" type="button" class="btn"
               href="<?php echo Uri::base() ?>/index.php?option=com_diler&task=AvvConsentDeclined.informRelatedUsers">
                <?php echo DText::_('BASE_SCHOOL_PRINCIPAL_AVV_WARNING_MESSAGE_NO'); ?>
            </a>
        </div>
    </div>
<?php endif; ?>
<form action="<?php echo Route::_('index.php'); ?>" method="post" id="avv-vvt-agreement" name="avv-vvt-agreement"
      class="form-validate form-horizontal <?php echo $showFormRightAway ? '' : 'hide'; ?>">
    <fieldset>
        <legend><?php echo DText::_('AVV_AND_VVT_AGREEMENT_FORM'); ?></legend>
        <div class="row-fluid">
            <?php foreach ($form->getFieldsets() as $fieldset) : ?>
                <?php if ($fieldset->label) : ?>
                    <h5><?php echo DText::_($fieldset->label) ?></h5>
                <?php endif; ?>
                <?php foreach ($form->getFieldset($fieldset->name) as $field) : ?>
                    <?php echo $form->renderField($field->getAttribute('name')); ?>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </fieldset>
    <div class="form-actions">
        <button id="saveButton" type="submit" class="btn btn-primary submit saveButton"><i class="fas fa-check"></i>
            <?php echo DText::_('AVV_AND_VVT_AGREEMENT_SUBMIT_BUTTON'); ?>
        </button>
        <a id="cancelButton" type="submit" class="btn"
           href="<?php echo Uri::base() ?>">
            <?php echo Text::_('JCANCEL'); ?>
        </a>
        <input type="hidden" name="option" value="com_diler"/>
        <input type="hidden" name="task" value="DigluAgreements.saveAgreement"/>
    </div>
</form>
<script type="text/javascript">
    function openAvvVvtForm() {
        jQuery('#avv-vvt-agreement').show();
        jQuery('#accept_consent_buttons').hide();
    }

    jQuery(document).ready(function () {
        jQuery('#avv-vvt-agreement').on('submit', function (e) {
            dilerSystem.spinner('start');
            jQuery('#saveButton').prop('disabled', true);
        });
    });

</script>
<style>
    #avv-vvt-agreement .form-check.form-check-inline {
        float: left;
        margin-right: 10px;
    }

    #avv-vvt-agreement #jform_accepted_contract_avv-desc, #avv-vvt-agreement #jform_accepted_contract_vvt-desc {
        float: left;
    }

    #avv-vvt-agreement .text-area-school-ministry {
        width: -moz-available;
        height: 150px;
    }
</style>
