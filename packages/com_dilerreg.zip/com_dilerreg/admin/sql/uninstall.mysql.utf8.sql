DROP TABLE IF EXISTS `#__dilerreg_families`;
DROP TABLE IF EXISTS `#__dilerreg_linkids`;
DROP TABLE IF EXISTS `#__dilerreg_registration_codes`;
DROP TABLE IF EXISTS `#__dilerreg_users`;
