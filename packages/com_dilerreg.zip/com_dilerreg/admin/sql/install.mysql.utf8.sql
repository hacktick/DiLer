SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- --------------------------------------------------------

--
-- Table structure for table `#__dilerreg_registration_codes`
--
CREATE TABLE IF NOT EXISTS `#__dilerreg_registration_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `fam_id` int(11) NOT NULL,
  `role` text NOT NULL,
  `lg` int(11) NOT NULL,
  `code` text NOT NULL,
  `activation_code` text NOT NULL,
  `registration_attempts` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fam_id` (`fam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__dilerreg_users`
--
CREATE TABLE IF NOT EXISTS `#__dilerreg_users` (
  `user_id` int(11) unsigned NOT NULL,
  `acceptedterms` enum('0','1') NOT NULL DEFAULT '0',
  `approve` enum('0','1') NOT NULL DEFAULT '0',
  `overage` enum('0','1') NOT NULL DEFAULT '0',
  `ip_addr` varchar(15) NOT NULL DEFAULT '',
  `form_id` int(11) DEFAULT NULL,
  `notes` text,
  `last_activation_request` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `approve_hash` varchar(32) DEFAULT NULL,
  `terminate_hash` varchar(32) DEFAULT NULL,
  `block_tstamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `family_id` int(11) NOT NULL,
  `forename` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `salutation` tinytext,
  `title` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `portalcode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phonehome` varchar(255) DEFAULT NULL,
  `phonework` varchar(255) DEFAULT NULL,
  `phonemobile` varchar(255) DEFAULT NULL,
  `qualifications` text,
  `registercode` varchar(255) DEFAULT NULL,
  `country` tinytext,
  `phonework2` varchar(255) DEFAULT NULL,
  `phonemobile2` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gender` tinytext,
  `dob` text,
  `picture` varchar(255) DEFAULT NULL,
  `notebyteacherptm` text,
  `notebyteacherptmprivate` text,
  `studenthealthissues` text,
  `phase` tinytext,
  `role` varchar(255) DEFAULT NULL,
  `function` text NOT NULL,
  `parent_association` text NOT NULL,
  `association_chairman` text NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `idx_family_id` (`family_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET FOREIGN_KEY_CHECKS=1;
