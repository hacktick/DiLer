<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

// Include the HTML helpers.
HTMLHelper::addIncludePath(JPATH_COMPONENT.'/helpers/html');

HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('jquery.framework');
$isDiglu = DilerHelperUser::isDiglu();
?>
<script type="text/javascript">
    $(document).ready(function() {
        jQuery(".custom-selectbox>#jform_base_school_id_chosen").hide();
    })
    Joomla.submitbutton = function(task)
    {
        if (task == 'code.cancel' || document.formvalidator.isValid(document.getElementById('code-form')))
        {
            Joomla.submitform(task, document.getElementById('code-form'));
        }
    };

    function DilerTranslateJs(languageString) {
        if (typeof Joomla.Text == 'object' && typeof Joomla.Text._ == 'function' && typeof Joomla.Text._(languageString) != 'undefined') {
            return Joomla.Text._(languageString);
        } else if (typeof Joomla.Text == 'object' && typeof Joomla.Text[languageString] == 'string') {
            return Joomla.Text[languageString];
        } else {
            return languageString;
        }
    };

    function changeRole() {
        var roleListString = atob(jQuery('#rolelist').val());
        var roleList = JSON.parse(roleListString);
        var groupId = jQuery('#jform_dilerrolegroup').val();
        var role = roleList[groupId];
        var isDiglu = <?php echo (int) DilerHelperUser::isDiglu() ?>;
        if (role != 'student') {
            jQuery('#showForStudent').hide();
            jQuery('#lg_group').hide();
            jQuery('#jform_lg').prop('required', false);
            jQuery('#lg_dob').prop('required', false);
            jQuery('#jform_lg').removeClass('required');
            jQuery('#jform_base_school_id').prop('required', false);
            jQuery('#jform_base_school_id').removeClass('required');
            if (!isDiglu)
            {
                jQuery('#jform_first_school_enrollment_date').prop('required', false);
                jQuery('#jform_first_school_enrollment_date').removeClass('required');
                jQuery('#jform_student_phase_actual').prop('required', false);
                jQuery('#jform_student_phase_actual').removeClass('required');
                jQuery('#jform_student_phase_target').prop('required', false);
                jQuery('#jform_student_phase_target').removeClass('required');
            }
            jQuery('#showNicknameForStudent').hide();
        } else {
            jQuery('#lg_group').show();
        }

        if (role != 'parent' && role != 'mother' && role != 'father') {
            jQuery('#parentRelationshipContainer').hide();
        } else {
            jQuery('#parentRelationshipContainer').show();
        }
        if (role == 'student') {
            jQuery('#jform_lg').prop('required', true);
            jQuery('#jform_lg').addClass('required');
            jQuery('#jform_base_school_id').prop('required', true);
            jQuery('#jform_base_school_id').addClass('required');
            jQuery('#studentRelationshipContainer').show();
                jQuery('#studentSchoolContainer').show();

            jQuery('#showForStudent').show();
            jQuery('#jform_dob').prop('readonly', true);
            jQuery('#jform_dob').click(function() {
                jQuery('#jform_dob_btn').click();
            });
            jQuery('#jform_first_school_enrollment_date').prop('readonly', true);
            jQuery('#jform_first_school_enrollment_date').click(function (){
                jQuery('#jform_first_school_enrollment_date_btn').click();
            });
            if (isDiglu)
            {
                jQuery('#jform_first_school_enrollment_date').prop('required', true).addClass('required');
                jQuery('#jform_student_phase_actual').prop('required', true).addClass('required');
                jQuery('#jform_student_phase_target').prop('required', true).addClass('required');
                jQuery('#jform_dob').prop('required', true).addClass('required');
                jQuery('.required-asterisk').remove();
                jQuery('#jform_base_school_id-lbl, ' +
                    '#jform_first_school_enrollment_date-lbl, ' +
                    '#jform_student_phase_actual-lbl, ' +
                    '#jform_student_phase_target-lbl,' +
                    '#jform_dob-lbl').append(jQuery("<span>", {"class": "star required-asterisk"}).text(" *"));
            }
            jQuery('#showNicknameForStudent').show();
        } else {
            jQuery('#studentRelationshipContainer').hide();
            jQuery('#studentSchoolContainer').hide();

        }
    };

    (function ($){
        $(document).ready(function () {
            changeRole();
        });

    })(jQuery);

</script>

<style>
    #jform_dob{
        background-color: white;
    }
    #jform_first_school_enrollment_date{
        background-color: white;
    }
    .table-responsive{
        overflow-x: unset;
    }
    .choices__input.choices__input--cloned{
        min-width: 28ch;
        width: 1ch;
        cursor: pointer;
    }
</style>

<form action="<?php echo Route::_('index.php?option=com_dilerreg&id='.(int) $this->item->id); ?>" method="post" name="adminForm"  id="code-form" class="form-validate form-horizontal">
    <fieldset>
        <?php echo HTMLHelper::_('bootstrap.startTabSet', 'myTab', array('active' => 'basic')); ?>

        <?php echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'basic', empty($this->item->id) ? Text::_('COM_DILERREG_NEW_LINK', true) : Text::sprintf('COM_DILERREG_EDIT_LINK', $this->item->id, array('jsSafe' => true))); ?>
        <div class="control-group">
            <div class="control-label"><?php echo $this->form->getLabel('dilerrolegroup'); ?></div>
            <div class="controls" onChange="changeRole()"><?php echo $this->form->getInput('dilerrolegroup'); ?></div>
        </div>
        <?php if ($isDiglu) : ?>
        <div id="studentSchoolContainer">
                <div class="control-group">
                    <div class="control-label"><?php echo $this->form->getLabel('base_school_id'); ?></div>
                    <div class="controls custom-selectbox" ><?php echo $this->form->getInput('base_school_id'); ?></div>
                </div>
        </div>
        <?php endif; ?>
        <div class="control-group">
            <div class="control-label"><?php echo $this->form->getLabel('first_name'); ?></div>
            <div class="controls"><?php echo $this->form->getInput('first_name'); ?></div>
        </div>
        <div class="control-group" id="showNicknameForStudent">
            <div class="control-label"><?php echo $this->form->getLabel('nickname'); ?></div>
            <div class="controls"><?php echo $this->form->getInput('nickname'); ?></div>
        </div>
        <div class="control-group">
            <div class="control-label"><?php echo $this->form->getLabel('last_name'); ?></div>
            <div class="controls"><?php echo $this->form->getInput('last_name'); ?></div>
        </div>
        <div class="control-group" id="lg_group">
            <div class="control-label"><?php echo $this->form->getLabel('lg'); ?></div>
            <div class="controls" ><?php echo $this->form->getInput('lg'); ?></div>
        </div>
        <div class="control-group">
            <div class="control-label"><?php echo $this->form->getLabel('id'); ?></div>
            <div class="controls"><?php echo $this->form->getInput('id'); ?></div>
        </div>
        <div class="control-group" id="showForStudent">
            <div class="control-group">
                <div class="control-label"><?php echo $this->form->getLabel('dob'); ?></div>
                <div class="controls"><?php echo $this->form->getInput('dob'); ?></div>
            </div>
            <div class="control-group">
                <div class="control-label"><?php echo $this->form->getLabel('first_school_enrollment_date'); ?></div>
                <div class="controls"><?php echo $this->form->getInput('first_school_enrollment_date'); ?></div>
            </div>

            <div class="control-group">
                <div class="control-label"><?php echo $this->form->getLabel('student_phase_actual'); ?></div>
                <div class="controls"><?php echo $this->form->getInput('student_phase_actual'); ?></div>
            </div>

            <div class="control-group">
                <div class="control-label"><?php echo $this->form->getLabel('student_phase_target'); ?></div>
                <div class="controls"><?php echo $this->form->getInput('student_phase_target'); ?></div>
            </div>
        </div>
        <div class="table-responsive">
            <div class="control-group" id="parentRelationshipContainer">

                    <div class="control-label"><?php echo $this->form->getLabel('students'); ?></div>
                    <div class="controls"><?php echo $this->form->getInput('students'); ?></div>

            </div>
            <div class="control-group" id="studentRelationshipContainer">
                <div class="control-label"><?php echo $this->form->getLabel('parents'); ?></div>
                <div class="controls"><?php echo $this->form->getInput('parents'); ?></div>
            </div>
        </div>
        <?php echo HTMLHelper::_('bootstrap.endTab'); ?>

        <?php echo HTMLHelper::_('bootstrap.endTabSet'); ?>

        <input type="hidden" name="task" value="" />
        <input type="hidden" name="rolelist" id="rolelist" value="<?php echo base64_encode(json_encode($this->roleList)); ?>">
        <?php echo HTMLHelper::_('form.token'); ?>
    </fieldset>
</form>