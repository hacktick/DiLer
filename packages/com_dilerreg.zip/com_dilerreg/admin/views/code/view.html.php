<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Helper\ContentHelper;

// import Joomla view library


JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

class DilerregViewCode extends HtmlView
{
	protected $item;

	protected $form;

	protected $state;

	function display($tpl = null)
	{
		$this->form		= $this->get('Form');
		$this->item		= $this->get('Item');
		$this->state	= $this->get('State');
		$this->sectionIds = $this->get('SectionIds');
		$this->roleList = $this->get('RoleList');

		$this->addToolbar();
		parent::display($tpl);
	}

	public function addToolbar()
	{
		ToolbarHelper::title(Text::_('COM_DILERREG'), '');

		$canDo = ContentHelper::getActions('com_dilerreg');
		if ($canDo->get('core.edit'))
		{
			ToolbarHelper::apply('code.apply');
			ToolbarHelper::save('code.save');
		}

		// This component does not support Save as Copy due to uniqueness checks.
		// While it can be done, it causes too much confusion if the user does
		// not change the Old URL.

		if ($canDo->get('core.edit') && $canDo->get('core.create'))
		{
			ToolbarHelper::save2new('code.save2new');
		}

		if (empty($this->item->id))
		{
			ToolbarHelper::cancel('code.cancel');
		}
		else
		{
			ToolbarHelper::cancel('code.cancel', 'JTOOLBAR_CLOSE');
		}
		$bar = Toolbar::getInstance();
		$helpHtml = HTMLHelper::_('diler.helpButton', 'Code', 'btn btn-small', true, 'icon-question-sign');
		$bar->appendButton('Custom', $helpHtml, 'help');
	}
}