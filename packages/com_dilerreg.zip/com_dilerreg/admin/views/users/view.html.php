<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\DiLerToolbarHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Helper\ContentHelper;

// import Joomla view library


JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

class DilerregViewUsers extends HtmlView
{
	public $filterForm;
	public $activeFilters;

	function display($tpl = null)
	{
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');
		$this->state		= $this->get('State');
		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');

		$this->addToolbar();
		parent::display($tpl);
	}

	public function addToolbar()
	{
		$document = Factory::getDocument();
		$document->addScript(Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js');
		$document->addScript(Uri::root(true) . '/media/com_diler/js/diler.js');
		$document->addScript(Uri::root(true) . '/media/com_diler/administrator/js/import.js');
		ToolbarHelper::title(Text::_('COM_DILERREG_USERS'), 'diler');
		$canDo	= ContentHelper::getActions('com_dilerreg');

		if ($canDo->get('core.edit'))
		{
			ToolbarHelper::editList('user.edit');
		}

		if ($canDo->get('core.delete'))
		{
			ToolbarHelper::deleteList('', 'users.delete');
			$bar = Toolbar::getInstance();
			$bar->appendButton('Confirm', 'COM_DILER_CLOUD_DELETE_MESSAGE', 'delete', 'COM_DILER_CLOUD_DELETE', 'users.deletePrivateCloud', true);
		}

		$title = "<span aria-hidden='true' class='icon-'>3</span>".Text::_('COM_DILERREG_IMPORT_LABEL');

		$layout = new FileLayout('import_modal_button', JPATH_ROOT . '/components/com_diler/layouts');

		$importHtml = $layout->render((object) ['title' => $title, 'dataTarget' => 'importModal']);
		$checkHtml = $layout->render((object) ['title' => "<span aria-hidden='true' class='icon-'>1</span>".Text::_('COM_DILERREG_CHECK_LABEL'),
			'dataTarget' => 'checkModal']);
		$viewLogHtml = $layout->render((object) ['title' => Text::_('COM_DILERREG_IMPORT_VIEW_CHECK_LOG'), 'dataTarget' => 'viewLogModal']);
		$bar = Toolbar::getInstance();
		if ($canDo->get('core.create'))
		{
			$bar->appendButton('Custom', $checkHtml, 'check-import');
			$logCheckModalHtml = '<button class="btn btn-default btn-small" onclick="di.modal(\'check-log\', \'users\')"><span aria-hidden="true" class="icon-">2</span>' .
				Text::_('COM_DILERREG_IMPORT_VIEW_CHECK_LOG') .
				'</button>';
			$bar->appendButton('Custom', $logCheckModalHtml, 'viewLog-import');
			$bar->appendButton('Custom', $importHtml, 'import-import');
			$logImportModalHtml = '<button class="btn btn-default btn-small" onclick="di.modal(\'import-log\', \'users\')"><span aria-hidden="true" class="icon-">4</span>' .
				Text::_('COM_DILERREG_IMPORT_VIEW_IMPORT_LOG') .
				'</button>';
			$bar->appendButton('Custom', $logImportModalHtml, 'viewLog-import');
			$rejectsModalHtml = '<button class="btn btn-default btn-small" onclick="di.modal(\'rejects\', \'users\')"><span aria-hidden="true" class="icon-">5</span>' .
				Text::_('COM_DILERREG_IMPORT_VIEW_REJECTS') .
				'</button>';
			$bar->appendButton('Custom', $rejectsModalHtml, 'viewRejects-import');
			$sampleDownload = '<a class="btn btn-default btn-small" href="index.php?option=com_dilerreg&task=import.downloadFile&fileType=sample&view=users"><span aria-hidden="true" class="icon-info"></span>' . Text::_('COM_DILERREG_IMPORT_DOWNLOAD_SAMPLE_FILE') . '</a>';
			$bar->appendButton('Custom', $sampleDownload, 'sampleDownload-import');
		}
		if (Factory::getUser()->authorise('core.admin', 'com_dilerreg'))
		{
			ToolbarHelper::preferences('com_diler');
			ToolbarHelper::divider();
			DiLerToolbarHelper::addPermissionsToolbarButton();
		}
		$helpHtml = HTMLHelper::_('diler.helpButton', 'Users', 'btn btn-small', true, 'icon-question-sign');
		$bar->appendButton('Custom', $helpHtml, 'help');
	}

}