<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\DConst;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

/** @var Session $session */
$session = Factory::getApplication()->getSession();
$user		= Factory::getUser();
$userId		= $user->get('id');
$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));
$roleName = array(
	'teacher' => 'COM_DILERREG_TEACHER',
	'student' => 'COM_DILERREG_STUDENT',
	'parent' => 'COM_DILER_PARENT',
	);
$canEdit = $user->authorise('core.edit','com_dilerreg');
$importDisplayData = ['title' => Text::sprintf('COM_DILERREG_IMPORT_LABEL', Text::_('COM_DILERREG')), 'body' => Text::_('COM_DILERREG_CODES_IMPORT_DESC'), 'modalId' => 'importModal',
	'task' => 'import.import', 'saveLabel' => DText::_('IMPORT'), 'subtask' => 'import',
	'showDuplicateNames' => false, 'view' => 'users'];

$checkLabel = Text::sprintf('COM_DILERREG_CHECK_LABEL', Text::_('COM_DILERREG'), Text::_('COM_DILERREG_IMPORT_FILE'));
$checkDisplayData = ['title' => $checkLabel, 'body' => Text::_('COM_DILERREG_CODES_IMPORT_CHECK_DESC'), 'modalId' => 'checkModal',
	'task' => 'import.import', 'saveLabel' => $checkLabel, 'subtask' => 'check', 'showDuplicateNames' => false,
	'view' => 'users'];
if (!DilerHelperUser::extendedFeatures())
{
	$checkDisplayData['body'] = DText::_('EXTENDED_FEATURES_NOT_AVAILABLE');
	$checkDisplayData['task'] = '';
	$importDisplayData['body'] = DText::_('EXTENDED_FEATURES_NOT_AVAILABLE');
	$importDisplayData['task'] = '';
}
$layout = new FileLayout('import_modal', JPATH_ADMINISTRATOR . '/components/com_dilerreg/layouts');
$isDiglu = DilerHelperUser::isDiglu();
?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task !== 'users.delete') {
			Joomla.submitform(task);
			return;
		}

		jQuery('#deleteModal').modal('show');
		jQuery('.hastooltip').tooltip();

		var deleteParentsCheckbox = '#deleteParentsCheckbox';
		jQuery(deleteParentsCheckbox).hide();

		var selectedIds = jQuery('input[name="cid[]"]:checked');
		for (var id = 0; id < selectedIds.length; id++)
        {
        	if(jQuery('#' + selectedIds[id].value + "_role").val() === 'student')
            {
				jQuery(deleteParentsCheckbox).show();
				return;
            }
        }
	};
	dilerDeleteUsers = function ()
	{
		var deleteParents = jQuery('#deleteParents').prop('checked') ? 1 : 0;
		jQuery('input[name="deleteParents"]').val(deleteParents);
		Joomla.submitform('users.delete');
	};
</script>

<form action="<?php echo Route::_('index.php?option=com_dilerreg&view=users'); ?>" method="post" name="adminForm" id="adminForm">
	<div id="j-main-container" class="span10">
	<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
			<table class="table table-striped">
				<thead>
					<tr>
						<th width="1%">
							<?php echo HTMLHelper::_('grid.checkall'); ?>
						</th>
						<th width="1%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_FIRST_NAME', 'a.forename', $listDirn, $listOrder); ?>
						</th>
						<th width="1%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILER_NICKNAME_LABEL', 'a.nickname', $listDirn, $listOrder); ?>
						</th>
						<th width="1%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_LAST_NAME', 'a.surname', $listDirn, $listOrder); ?>
						</th>
						<th width="10%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_ROLE', 'a.role', $listDirn, $listOrder); ?>
						</th>
	 					<th width="20%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_LEARNING_GROUP_LABEL', 'learning_group', $listDirn, $listOrder); ?>
						</th>
						<th width="30%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_USER_ID', 'a.user_id', $listDirn, $listOrder); ?>
						</th>
						<th width="30%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_CLOUD_SIZE', 'cloud.total_size', $listDirn, $listOrder); ?>
						</th>
                        <?php if(DilerHelperUser::isDiglu()) : ?>
                        <th width="30%" class="nowrap">
                            <?php echo DText::_('DIGLU_BLOCKED_STATUS') ?>
                        </th>
                        <?php endif; ?>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<td colspan="7">
							<?php echo $this->pagination->getListFooter(); ?>
						</td>
					</tr>
				</tfoot>

				<tbody>
				<?php foreach ($this->items as $i => $item) :
					?>
					<tr class="row<?php echo $i % 2; ?>">
						<td >
							<?php echo HTMLHelper::_('grid.id', $i, $item->user_id); ?>
						</td>
						<td>
							<?php echo $this->escape($item->forename); ?>
						</td>
						<td>
							<?php echo $this->escape($item->nickname); ?>
						</td>
						<td>
							<div class="pull-left">
								<?php if ($canEdit && (in_array($item->role, ['parent', 'student']) || $isDiglu)) : ?>
									<a href="<?php echo Route::_('index.php?option=com_dilerreg&view=user&layout=edit&user_id=' . (int) $item->user_id); ?>">
									<?php echo $this->escape($item->surname); ?></a>
								<?php else : ?>
									<?php echo $this->escape($item->surname); ?>
								<?php endif; ?>
							</div>
						</td>
						<td>
							<?php echo $this->escape(Text::_($roleName[$item->role])); ?>
                            <input type="hidden" id="<?php echo $item->user_id ?>_role" value="<?php echo $item->role ?>" />
						</td>
						<td>
							<?php if ($item->learning_group && strlen($item->learning_group) > 50) : ?>
								<?php echo substr($this->escape($item->learning_group), 0, 50) . '...'; ?>
							<?php else : ?>
								<?php echo ($item->learning_group) ? $this->escape($item->learning_group) : '&times;'; ?>
							<?php endif; ?>
						</td>
						<td>
							<?php echo $item->user_id; ?>
						</td>
						<td>
							<?php $displaySize = isset($item->total_size) ? number_format($item->total_size / 1048576, 1, '.', ',') : 0; ?>
							<?php echo DText::sprintf('CLOUD_SIZE_MB', $displaySize); ?>
						</td>
                        <?php if(DilerHelperUser::isDiglu()) : ?>
                        <td>
                            <?php if ($item->is_student_blocked) : ?>
                                <a class="btn btn-danger" href="<?php echo Uri::base() ?>index.php?option=com_dilerreg&task=users.unblockStudentAndParentsOfStudent&id=<?php echo $item->user_id ?>&<?php echo $session->getFormToken() ?>=1"><?php echo DText::_('DIGLU_UNBLOCK_USER') ?></a>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>

					</tr>
				<?php endforeach; ?>
				</tbody>

			</table>
		<?php endif; ?>

	</div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="deleteParents" value="0" />
		<?php echo HTMLHelper::_('form.token'); ?>
</div>
</form>
<div id="deleteModal" class="modal hide fade" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">

    <div class="modal-dialog">
        <div class="modal-content">
    <form>
		<fieldset>
			<div id="deleteModalHeader" class="modal-header">
				<h2><?php echo Text::_('COM_DILERREG_DELETE_USERS'); ?></h2>
				<p id="deleteModalSubheading"></p>
			</div>
			<div id="deleteModalBody" class="modal-body">
				<p><?php echo Text::_('COM_DILERREG_USERS_CONFIRM_DELETE'); ?></p>
				<label class="control-label hastooltip" data-placement="bottom" id="deleteParentsCheckbox"
				   data-original-title="<?php echo Text::sprintf('COM_DILERREG_DELETE_PARENTS_DESC', DText::_('PARENTS'), DText::_('STUDENTS'));?>">
					<?php echo Text::sprintf( 'COM_DILERREG_DELETE_PARENTS_LABEL', DText::_('PARENTS'));?>
					<input id="deleteParents" type="checkbox" value="1" checked>
				</label>
			</div>
			<div id="compcharEditModalFooter " class="modal-footer">
				<button type="button" id="deleteModalSaveButton" class="btn btn-primary saveButton" data-bs-dismiss="modal" aria-hidden="true" onclick="dilerDeleteUsers()">
					<?php echo Text::_( 'COM_DILERREG_DELETE_USERS'); ?>
				</button>
				<button type="button" id="deleteModalCloseButton" class="btn" data-bs-dismiss="modal" aria-hidden="true">
					<?php echo Text::_( 'JCANCEL'); ?>
				</button>
			</div>
		</fieldset>
		<input  type="hidden" name="formToken" value="<?php echo Session::getFormToken();?>">
	</form>
        </div>
    </div>
</div>
<div id="rejectsViewFileModalContainer" class="modal"></div>
<div id="check-logViewFileModalContainer" class="modal"></div>
<div id="import-logViewFileModalContainer" class="modal"></div>
<?php echo $layout->render($importDisplayData); ?>
<?php echo $layout->render($checkDisplayData); ?>
