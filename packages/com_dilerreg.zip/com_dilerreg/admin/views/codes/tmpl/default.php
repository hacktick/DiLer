<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Session\Session;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

$user		= Factory::getUser();
$userId		= $user->get('id');
$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));

$roles = array(
	'parent' => 'COM_DILER_PARENT',
	'mother' => 'COM_DILERREG_MOTHER',
	'father' => 'COM_DILERREG_FATHER',
	'teacher' => 'COM_DILER_TEACHER',
	'student' => 'COM_DILER_STUDENT',
	'' => ''
);
$importDisplayData = ['title' => Text::sprintf('COM_DILERREG_IMPORT_LABEL', Text::_('COM_DILERREG')), 'body' => Text::_('COM_DILERREG_CODES_IMPORT_DESC'), 'modalId' => 'importModal',
	'task' => 'import.import', 'saveLabel' => DText::_('IMPORT'), 'subtask' => 'import', 'view' => 'codes'];

$checkLabel = Text::sprintf('COM_DILERREG_CHECK_LABEL', Text::_('COM_DILERREG'), Text::_('COM_DILERREG_IMPORT_FILE'));
$checkDisplayData = ['title' => $checkLabel, 'body' => Text::_('COM_DILERREG_CODES_IMPORT_CHECK_DESC'), 'modalId' => 'checkModal',
	'task' => 'import.import', 'saveLabel' => $checkLabel, 'subtask' => 'check', 'view' => 'codes'];
if (!DilerHelperUser::extendedFeatures())
{
	$checkDisplayData['body'] = DText::_('EXTENDED_FEATURES_NOT_AVAILABLE');
	$checkDisplayData['task'] = '';
	$importDisplayData['body'] = DText::_('EXTENDED_FEATURES_NOT_AVAILABLE');
	$importDisplayData['task'] = '';
}
$layout = new FileLayout('import_modal', JPATH_ADMINISTRATOR . '/components/com_dilerreg/layouts');
?>

<form action="<?php echo Route::_('index.php?option=com_dilerreg&view=codes'); ?>" method="post" name="adminForm" id="adminForm">
<?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
<?php else : ?>
	<div id="j-main-container">
<?php endif;?>
		<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
			<table class="table">
				<thead>
					<tr>
						<th width="1%">
							<?php echo HTMLHelper::_('grid.checkall'); ?>
						</th>
						<th width="1%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_FIRST_NAME', 'a.first_name', $listDirn, $listOrder); ?>
						</th>
						<th width="1%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILER_NICKNAME_LABEL', 'a.nickname', $listDirn, $listOrder); ?>
						</th>
						<th width="1%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_LAST_NAME', 'a.last_name', $listDirn, $listOrder); ?>
						</th>
						<th width="10%" class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_DILERREG_ROLE', 'a.role', $listDirn, $listOrder); ?>
						</th>
						<th width="20%" class="nowrap">
							<?php echo DText::_('REGCODES_RELATED') . '<br>' . Text::_('COM_DILERREG_UNREGISTERED'); ?>
						</th>
						<th width="20%" class="nowrap">
							<?php echo DText::_('REGCODES_RELATED') . '<br>' . Text::_('COM_DILERREG_REGISTERED'); ?>
						</th>
						<th width="20%" class="nowrap">
							<?php echo Text::_('COM_DILERREG_CODE'); ?>
						</th>
						<th width="20%" class="nowrap">
							<?php echo Text::_('COM_DILERREG_LEARNING_GROUP'); ?>
						</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<td colspan="9">
							<?php echo $this->pagination->getListFooter(); ?>
						</td>
					</tr>
				</tfoot>

				<tbody>
				<?php foreach ($this->items as $i => $item) :
					$canCreate = $user->authorise('core.create',     'com_dilerreg');
					$canEdit   = $user->authorise('core.edit',       'com_dilerreg');
					$canChange = $user->authorise('core.edit.state', 'com_dilerreg');
					?>
					<tr class="row<?php echo $i % 2; ?>">
						<td class="center">
							<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
						</td>
						<td class="nowrap"><?php echo $this->escape($item->first_name); ?></td>
						<td class="nowrap"><?php echo $this->escape($item->nickname); ?></td>
						<td class="nowrap">
							<?php if ($canEdit) : ?>
								<a href="<?php echo Route::_('index.php?option=com_dilerreg&task=code.edit&id='.$item->id);?>" ><?php echo $this->escape($item->last_name); ?></a>
							<?php endif; ?>
						</td>
						<td class="nowrap">
							<?php echo Text::_($roles[$item->role]); ?>
						</td>
						<td>
							<?php echo $item->unregistered_family_names; ?>
						</td>
						<td>
							<?php echo $item->registered_family_names; ?>
						</td>
						<td class="registrationCodes nowrap">
							<div class="input-append">
							<input id="<?php echo $this->escape($item->code);?>" type="text" readonly value="<?php echo $this->escape($item->code);?>">
							<button class="btn" type="button" title="highlight registration code" onclick="highlightRegistrationCode('<?php echo $this->escape($item->code);?>');"><i class="icon-lamp"></i></button>
							</div>
						</td>
						<td class="nowrap"><?php echo $this->escape($item->learning_groups); ?></td>


					</tr>
				<?php endforeach; ?>
				</tbody>

			</table>
		<?php endif; ?>

	</div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<?php echo HTMLHelper::_('form.token'); ?>
		<input  type="hidden" name="formToken" value="<?php echo Session::getFormToken();?>">
</div>
</form>
<div id="rejectsViewFileModalContainer" class="modal" tabindex="-1"></div>
<div id="check-logViewFileModalContainer" class="modal" tabindex="-1"></div>
<div id="import-logViewFileModalContainer" class="modal" tabindex="-1"></div>
<?php echo $layout->render($importDisplayData); ?>
<?php echo $layout->render($checkDisplayData); ?>

<script>
	Joomla.submitbutton = function(task){
		if (task != 'codes.delete' || confirm('<?php echo DText::sprintf('CONFIRM_DELETE', Text::_('COM_DILERREG'));?>'))
		{
			Joomla.submitform(task);
		}
	};

	function highlightRegistrationCode(e){
		jQuery('#'+e).focus();
		jQuery('#'+e).select();
		document.execCommand("copy");
	}

	function printPdf(){
		var n = jQuery( 'input[name="cid[]"]:checked' ).length;
		if (n == 0) {
			alert('<?php echo Text::_('JLIB_HTML_PLEASE_MAKE_A_SELECTION_FROM_THE_LIST'); ?>');
		}
		else {
			// Submit the form and clear out the checkboxes and task
			Joomla.submitbutton('codes.printPdf');
			jQuery("input:checked").removeAttr('checked');
			jQuery("input[name=task]").val(' ');
		}
	}
</script>
