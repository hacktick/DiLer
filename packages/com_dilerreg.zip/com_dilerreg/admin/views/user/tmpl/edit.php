<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013-16 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

// Include the HTML helpers.
HTMLHelper::addIncludePath(JPATH_COMPONENT.'/helpers/html');

HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('jquery.framework');
$role = DilerHelperUser::getDilerRole($this->item->user_id);
?>
<style>
    #jform_dob{
        background-color: white;
    }
    #jform_first_school_enrollment_date{
        background-color: white;
    }
    .table-responsive{
        overflow-x: unset;
    }
    .choices__input.choices__input--cloned{
        min-width: 28ch;
        width: 1ch;
        cursor: pointer;
    }
</style>

<form action="<?php echo Route::_('index.php?option=com_dilerreg&view=users'); ?>" method="post" name="adminForm" id="user-form" class="form-validate form-horizontal">
	<fieldset>
		<?php if (in_array($role, array('student', 'parent'))) :?>
			<h2><?php echo Text::sprintf('COM_DILERREG_EDIT_USER', $this->item->forename . ' ' . $this->item->surname);?></h2>
			<?php if ($this->item->role == 'parent') : ?>
			<div id="parentRelationshipContainer">
				<?php echo $this->form->getInput('students'); ?>
			</div>
			<?php endif; ?>
			<?php if ($this->item->role == 'student') : ?>
			<div id="studentRelationshipContainer">
				<?php echo $this->form->getInput('parents'); ?>
			</div>
			<?php endif; ?>
		<?php elseif ($role === 'teacher' && DilerHelperUser::isDiglu()) : ?>
			<h2><?php echo Text::sprintf('COM_DILERREG_EDIT_USER', $this->item->forename . ' ' . $this->item->surname);?></h2>
			<p><?php echo DText::_('DIGLU_TRAINER_HEADING'); ?></p>
			<?php echo $this->form->renderField('diglu_trainer_country'); ?>
			<?php echo $this->form->renderField('diglu_trainer_state'); ?>
			<?php echo $this->form->renderField('salutation'); ?>
		<?php else : ?>
			<h2><?php echo Text::sprintf('COM_DILERREG_EDIT_USER_NOT_ALLOWED', $this->item->forename . ' ' . $this->item->surname);?></h2>
		<?php endif; ?>
        <?php if ($this->item->role == 'student') : ?>
		    <div class="control-group">
		    	<div class="control-label"><?php echo $this->form->getLabel('nickname'); ?></div>
		    	<div class="controls"><?php echo $this->form->getInput('nickname'); ?></div>
		    </div>
        <?php endif; ?>
		<?php echo $this->form->renderField('forename'); ?>
		<?php echo $this->form->renderField('surname'); ?>
		<?php echo $this->form->renderField('username'); ?>
		<?php echo $this->form->renderField('email'); ?>
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="user_id" value="<?php echo $this->item->user_id;?>" />
			<?php echo HTMLHelper::_('form.token'); ?>
	</fieldset>
</form>