<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
use DiLer\DConst;
use DiLer\DUrl;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Helper\ContentHelper;

defined('_JEXEC') or die('Restricted access');

// import Joomla view library


JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

class DilerregViewUser extends HtmlView
{
	protected $item;

	protected $form;

	protected $state;

	function display($tpl = null)
	{
		$this->form		= $this->get('Form');
		$this->item		= $this->get('Item');
		$this->state	= $this->get('State');

		$this->addToolbar();
		$this->loadMedia();
		parent::display($tpl);
	}

	private function loadMedia()
	{
		$this->document->addScript(Uri::root() . DUrl::MEDIAL_PATH . '/administrator/js/edit_user.js', array('version' => 'auto'));
		$this->setFamilySelectorName();
	}
	
	private function setFamilySelectorName()
	{
		$role = $this->item->role;
		$familyMemberSelector = '';
		if ($role == DConst::USER_ROLE_STUDENT)
			$familyMemberSelector = '.parent_ids';
		
		if ($role == DConst::USER_ROLE_PARENT)
			$familyMemberSelector = '.student_ids';

		$this->document->addScriptOptions('COM_DILERREG.FAMILY_SELECTOR_NAME', $familyMemberSelector);
	}
	
	private function addToolbar()
	{
		ToolbarHelper::title(Text::_('COM_DILERREG_USERS'), '');

		$canDo = ContentHelper::getActions('com_dilerreg');
		$role = DilerHelperUser::getDilerRole($this->item->user_id);
		if ($canDo->get('core.edit'))
		{
			ToolbarHelper::apply('user.apply');
			ToolbarHelper::save('user.save');
		}

		if (empty($this->item->id))
		{
			ToolbarHelper::cancel('user.cancel');
		}
		else
		{
			ToolbarHelper::cancel('user.cancel', 'JTOOLBAR_CLOSE');
		}
		$bar = Toolbar::getInstance();
		$helpHtml = HTMLHelper::_('diler.helpButton', 'User', 'btn btn-small', true, 'icon-question-sign');
		$bar->appendButton('Custom', $helpHtml, 'help');
	}
}