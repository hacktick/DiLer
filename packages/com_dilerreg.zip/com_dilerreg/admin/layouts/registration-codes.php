<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');
$index = 0;

$reportHeading = $this->escape(Factory::getApplication()->input->getString('report_heading'));
$digLuParentsHelpLink = DilerHelperUser::isDiglu() ? Text::_('COM_DILERREG_REGCODE_PARENTS_PRINT_HELP_LINK') : '';

$role_notes = array(
	'parent' => 'COM_DILERREG_REGCODE_PRINT_HINT_PARENTS',
	'teacher' => 'COM_DILERREG_REGCODE_PRINT_HINT_TEACHERS',
	'student' => 'COM_DILERREG_REGCODE_PRINT_HINT_STUDENTS',
	'' => ''
);
$rowNumber = 0;
?>

<html>
    <style>
        @page {margin: 5mm !important}
        table {border-collapse: collapse;color:#000000;}
	th {text-align:left!important; font-family:sans-serif; font-weight: normal;font-size: 8pt; vertical-align:top;}
        td {border-top: .25pt dotted #000000; border-bottom: .25pt dotted #000000; padding: 10pt 5pt 10pt 0; font-family: sans-serif; font-size: 8pt; font-weight: normal; vertical-align: top;}
    </style>
    <head>
    	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    </head>
    <body>
    <table border="0" style="width: 100%">
	    <thead>
	    <tr>
            <th><?php echo TEXT::_('COM_DILERREG_PDF_COLUMN_NAME_ROW'); ?></th>
            <th><?php echo TEXT::_('COM_DILERREG_PDF_COLUMN_NAME_NAME'); ?></th>
            <th><?php echo TEXT::_('COM_DILERREG_PDF_COLUMN_NAME_DESCRIPTION'); ?></th>
            <th><?php echo TEXT::_('COM_DILERREG_PDF_COLUMN_NAME_ROLE'); ?></th>
            <th><?php echo DText::_('REGCODES_RELATED') . ' ' . Text::_('COM_DILERREG_UNREGISTERED') ?></th>
            <th><?php echo DText::_('REGCODES_RELATED') . ' ' . Text::_('COM_DILERREG_REGISTERED') ?></th>
            <th><?php echo TEXT::_('COM_DILERREG_PDF_COLUMN_NAME_REG_CODE'); ?></th>
            <th><?php echo TEXT::_('COM_DILERREG_LEARNING_GROUP'); ?></th>
	    </tr>
	    </thead>
	    <?php foreach ($displayData as $family) : ?>
			<?php foreach ($family['parents'] as $row) : ?>
				<tr>
					<td><?php echo ++$rowNumber; ?></td>
					<td><?php echo $row->last_name . ', ' . $row->first_name; ?></td>
					<td><?php echo Text::sprintf($role_notes[$row->role], str_replace("/administrator/", "", str_replace("https://", "", Uri::base())), $digLuParentsHelpLink); ?></td>
					<td><b><?php echo $row->role; ?></b></td>
					<td><?php echo $row->unregistered_family_names ?></td>
					<td><?php echo $row->registered_family_names ?></td>
					<td><?php echo $row->code; ?></td>
					<td><?php echo $row->learning_groups; ?></td>
				</tr>
			<?php endforeach; ?>
			<?php foreach ($family['students'] as $row) : ?>
				<tr>
					<td><?php echo ++$rowNumber; ?></td>
					<td><?php echo $row->last_name . ', ' . $row->first_name; ?></td>
					<td><?php echo Text::sprintf($role_notes[$row->role], str_replace("/administrator/", "", str_replace("https://", "", Uri::base()))); ?></td>
					<td><b><?php echo $row->role; ?></b></td>
					<td><?php echo $row->unregistered_family_names ?></td>
					<td><?php echo $row->registered_family_names ?></td>
					<td><?php echo $row->code; ?></td>
					<td><?php echo $row->learning_groups; ?></td>
				</tr>
			<?php endforeach; ?>
			<tr><td colspan="8" style=" border-bottom: 0.25pt solid #000000;"></td></tr>
		<?php endforeach; ?>
    </table>
    </body>
</html>
