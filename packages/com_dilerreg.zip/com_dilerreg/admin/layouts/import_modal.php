<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_banners
 *
 * @copyright   Copyright (C) 2013 - 2019 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
extract($displayData);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

?>

<div id="<?php echo $modalId; ?>" class="modal hide fade" tabindex="-1" role="dialog"
     aria-labelledby="<?php echo $modalId; ?>Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form enctype="multipart/form-data" id="<?php echo $modalId; ?>Form"
                  action="<?php echo Route::_('index.php?option=com_dilerreg'); ?>" method="post">
                <div class="modal-header">
                    <h3 id="<?php echo $modalId; ?>Label"><?php echo $title; ?></h3>
                </div>
                <div id="<?php echo $modalId; ?>Body" class="modal-body">
                    <div id="systemMessageWrapper" class="hide"></div>
                    <div class="text">
                        <p id="<?php echo $modalId; ?>Text"><?php echo $body; ?></p>
                    </div>
					<?php if ((!isset($displayData['view']) || $displayData['view'] === 'codes') && DilerHelperUser::extendedFeatures()) : ?>
                        <div class="group_entry mb-3">
                            <div class="control-label">
                                <label id="allow_duplicates-lbl" for="allow_duplicates<?php echo $modalId; ?>"
                                       class="hasPopover required" title="" data-trigger="hover"
                                       data-content="<?php echo Text::_('COM_DILERREG_CODES_IMPORT_ALLOW_DUPLICATES_DESC'); ?>"><?php echo Text::_('COM_DILERREG_CODES_IMPORT_ALLOW_DUPLICATES_LABEL'); ?>
                                </label>
                            </div>
                            <div class="controls input-append">
                                <fieldset id="allow_duplicates<?php echo $modalId; ?>" class="btn-group radio" role="group">
                                    <input type="radio" id="allow_duplicates<?php echo $modalId; ?>0"
                                           name="allow_duplicates" value="1" class="btn-check" autocomplete="off">
                                    <label for="allow_duplicates<?php echo $modalId; ?>0"
                                           class="btn btn-outline-primary" style="margin-inline-end: 0"><?php echo Text::_('JYES'); ?></label>
                                    <input type="radio" id="allow_duplicates<?php echo $modalId; ?>1"
                                           name="allow_duplicates" value="2" checked="checked" class="btn-check" autocomplete="off">
                                    <label for="allow_duplicates<?php echo $modalId; ?>1"
                                           class="btn btn-outline-primary active"><?php echo Text::_('JNO'); ?></label>
                                </fieldset>
                            </div>
                        </div>
                        <div class="group_entry mb-3">
                            <div class="control-label">
                                <label id="skip_first_line-lbl" for="skip_first_line<?php echo $modalId; ?>"
                                       class="hasPopover required" title="" data-trigger="hover"
                                       data-content="<?php echo Text::_('COM_DILERREG_CODES_IMPORT_SKIP_FIRST_LINE_DESC'); ?>"><?php echo Text::_('COM_DILERREG_CODES_IMPORT_SKIP_FIRST_LINE_LABEL'); ?>
                                </label>
                            </div>
                            <div class="controls input-append">
                                <div id="skip_first_line<?php echo $modalId; ?>" class="btn-group">
                                    <input type="radio" id="skip_first_line<?php echo $modalId; ?>0"
                                           name="skip_first_line" value="1" class="btn-check" >
                                    <label for="skip_first_line<?php echo $modalId; ?>0"
                                           class="btn btn-outline-primary" style="margin-inline-end: 0"><?php echo Text::_('JYES'); ?></label>
                                    <input type="radio" id="skip_first_line<?php echo $modalId; ?>1"
                                           name="skip_first_line" value="2" checked="checked" class="btn-check" >
                                    <label for="skip_first_line<?php echo $modalId; ?>1"
                                           class="btn btn-outline-primary active"><?php echo Text::_('JNO'); ?></label>
                                </div>
                            </div>
                        </div>
					<?php endif; ?>
					<?php if ($task) : ?>
                    <div class="mb-3">
                        <input class="input_box form-control" id="import_file" name="import_file" type="file" size="57"
                               onchange="di.checkFormActions(this);">
                        <label for="import_file" class="form-label"></label>
                    </div>
                        <input type="hidden" name="task" value="<?php echo $task; ?>"/>
                        <input type="hidden" name="view" value="<?php echo $view; ?>"/>
                        <input type="hidden" name="subtask" value="<?php echo $subtask; ?>"/>
						<?php echo HTMLHelper::_('form.token'); ?>
					<?php endif; ?>
                </div>
                <div class="modal-footer">
                    <div class="form-inline">
						<?php if ($task) : ?>
                            <button onclick="di.import(this, '<?php echo $task; ?>');" class="btn disabled modalAction"
                                    disabled><?php echo $saveLabel; ?></button>
						<?php endif; ?>
                        <button type="button" class="btn btn-small closeButton" data-bs-dismiss="modal"
                                aria-hidden="true"
                                data-close="<?php echo Text::_("JTOOLBAR_CANCEL"); ?>"><?php echo Text::_("JCANCEL"); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
