<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;

/**
 * Link Table for Redirect.
 *
 * @package Dilerreg.Administrator
 * @subpackage com_dilerreg
 * @since 1.6
 */
class DilerregTableCode extends Table
{

	/**
	 * Constructor
	 *
	 * @param
	 *        	object	Database object
	 *
	 * @return void
	 * @since 1.6
	 */
	public function __construct(&$db)
	{
		parent::__construct('#__dilerreg_registration_codes', 'id', $db);
	}

	/**
	 * Override parent save method
	 *
	 * @see Table::save()
	 */
	public function store($updateNulls = false)
	{
		// Create registration code
		if (!$this->code)
		{
			$this->code = $this->getRegistrationCode();
		}

		return parent::store($updateNulls);
	}

	/**
	 * Set registration code based on name and random letters
	 */
	protected function getRegistrationCode()
	{
		$input = Factory::getApplication()->input;
		$code = str_replace(array(" ", "'", '"',".") , "_", $this->first_name . '_');
		$code .= str_replace(array(" ", "'", '"',"."), "_", $this->last_name) . '_';

		$string = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';

		for ($i = 0; $i < 4; $i ++)
		{
			$code .= $string[rand(0, strlen($string) - 1)];
		}
		return $code;
	}
}
