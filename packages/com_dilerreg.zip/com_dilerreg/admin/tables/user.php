<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('_JEXEC') or die();

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\DataProviders\Database\User\PersonalData\PersonalDataDTOInterface;
use DiLer\DConst;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
/**
 * Link Table for Redirect.
 *
 * @since 1.6
 * @property $user_id
 * @property $acceptedterms               
 * @property $approve                     
 * @property $family_id                   
 * @property $forename                    
 * @property $surname
 * @property $nickname
 * @property $salutation
 * @property $address2                    
 * @property $portalcode                  
 * @property $city                        
 * @property $state_iso                   
 * @property $country_iso2                
 * @property $base_school_id              
 * @property $phonehome                   
 * @property $phonework                   
 * @property $phonemobile                 
 * @property $qualifications              
 * @property $registercode                
 * @property $citizenship_iso2            
 * @property $phonework2                  
 * @property $phonemobile2                
 * @property $address                     
 * @property $gender                      
 * @property $dob                         
 * @property $pob                         
 * @property $picture                     
 * @property $notebyteacherptmprivate     
 * @property $student_alert_note          
 * @property $student_alert_note_teacher  
 * @property $contact_note                
 * @property $role                        
 * @property $family_email_user_id        
 * @property $params                      
 * @property $first_school_enrollment_date
 * @property $student_phase_target        
 * @property $student_phase_actual        
 * @property $parent_function             
 * @property $student_permission_level    
 * @property $student_function            
 * @property $teacher_function            
 * @property $teacher_department          
 * @property $teacher_role                
 * @property $default_section_id          
 * @property $created                     
 * @property $created_by                  
 * @property $modified                    
 * @property $modified_by                 
 * @property $checked_out                 
 * @property $checked_out_time;
 * @property $pep_enabled
 * @property $student_section_id
 * @property $username
 * @package Dilerreg.Administrator
 * @subpackage com_dilerreg
 */
class DilerregTableUser extends Table implements PersonalDataDTOInterface
{
	protected $_jsonEncode = array('params','parent_function','student_function','student_particulars','teacher_function','student_permission_level', 'teacher_role', 'teacher_department');

	protected $_dateFormat = 'DATE_FORMAT_LC4';

	/**
	 * Constructor
	 *
	 * @param  object	Database object
	 *
	 * @return void
	 * @since 1.6
	 */
	public function __construct(&$db)
	{
		parent::__construct('#__dilerreg_users', 'user_id', $db);
	}

	public function load($keys = null, $reset = true)
	{
		parent::load($keys, $reset);

		if ($this->user_id)
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true)
				->select('*')
				->from('#__users')
				->where('id = ' . (int) $this->user_id);
			$userData = $db->setQuery($query)->loadAssoc();

			if ($userData)
				foreach ($userData as $key => $value)
				{
					$this->name = isset($this->name) ? $this->name . ' ' . $value : $value;

					$this->$key = $value;
				}

		}

		$params = json_decode($this->params);
		if ($params && !isset($params->studentAssessmentInfo))
			$params->studentAssessmentInfo = 0;
		$this->params = json_encode($params);
		return $this;
	}

	public function store($updateNulls = false)
	{
		$result = parent::store($updateNulls);

		if ($result && $this->user_id)
		{
			$db = Factory::getDbo();

			$fieldsToSync = ['username', 'email', 'name'];
			$dataToUpdate = [];

			foreach ($fieldsToSync as $field)
			{
				if (isset($this->$field))
				{
					$dataToUpdate[$field] = $db->quote($this->$field);
				}
			}

			if (isset($this->forename) && isset($this->surname))
				$name = trim($this->forename . ' ' . $this->surname);
				$dataToUpdate['name'] = $db->quote($name);


			if (!empty($dataToUpdate))
			{
				$query = $db->getQuery(true)
					->update('#__users')
					->set(array_map(fn($key, $value) => "$key = $value", array_keys($dataToUpdate), $dataToUpdate))
					->where('id = ' . (int) $this->user_id);
				$db->setQuery($query)->execute();
			}
		}

		return $result;
	}

	public function checkout($userId, $pk = null)
	{
		$checkOut = parent::checkOut($userId, $pk);

		if($checkOut)
			$this->deleteUnusedMedia($userId);
        return $checkOut;
	}

	private function deleteUnusedMedia($userId)
	{
		// @todo we should get $studentId passed from controller and not to read it directly here.
		$studentId = Factory::getApplication()->input->getUint('id');

		if ($studentId)
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true);
			$query->select('gm.id')
				->from('#__diler_grid_media as gm')
				->leftJoin('#__diler_user_grid_media_map AS ugmm ON gm.id = ugmm.grid_media_id AND ugmm.user_id = '. $studentId)
				->where('created_by = '. $userId)
				->where('published = 0');

			$unusedMediaIds = $db->setQuery($query)->loadColumn();
			if ($unusedMediaIds)
			{
				/** @var DilerModelGridFile $modelGridFile */
				$modelGridFile = MVCHelper::factory()->createModel('Gridfile', 'Site');
				$modelGridFile->deleteGridFiles($unusedMediaIds, null, null, null, null, true);
			}
		}
	}

	public function getRelatedUsers(int $userId, string $currentUserRole, string $relatedUsersRole)
	{
		if (!in_array($this->role, array(DConst::USER_ROLE_STUDENT, DConst::USER_ROLE_PARENT)))
			return array();
		
		// map using: student_id || parent_id
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('du.user_id, u.name, u.email')
			->from('#__dilerreg_parent_student_map AS dpsm')
			->innerJoin('#__dilerreg_users AS du ON dpsm.' . $relatedUsersRole . '_id = du.user_id')
			->innerJoin('#__users AS u ON dpsm.' . $relatedUsersRole . '_id = u.id')
			->where('dpsm.' . $currentUserRole . '_id = ' . (int) $userId)
			->where('dpsm.parent_id_type = 1 AND dpsm.student_id_type = 1');

		if ($relatedUsersRole === DConst::USER_ROLE_PARENT)
		{
			$query->select('c.title as relationshipTitle');
			$query->innerJoin('#__categories as c ON c.id = dpsm.relationship');

		}
		$result = $db->setQuery($query)->loadObjectList();
		return $result;
	}

	public function forename(): string
	{
		return $this->get('forename', '');
	}

	public function surname(): string
	{
		return $this->get('surname', '');
	}

	public function nickname(): ?string
	{
		return $this->get('nickname', '');
	}

	public function qualifications(): string
	{
		return $this->get('qualifications', '');
	}

	public function address(): string
	{
		return $this->get('address');
	}

	public function address2(): string
	{
		return $this->get('address2', '');
	}

	public function postcode(): string
	{
		return $this->get('portalcode');
	}

	public function city(): string
	{
		return $this->get('city');
	}

	public function baseSchoolId(): ?int
	{
		return $this->get('base_school_id');
	}

	public function stateIso()
	{
		return $this->get('state_iso');
	}

	public function countryIso2()
	{
		return $this->get('country_iso2', '');
	}

	public function phoneWork(): string
	{
		return $this->get('phonework', '');
	}

	public function phoneWork2(): string
	{
		return $this->get('phonework2', '');
	}

	public function phoneMobile(): string
	{
		return $this->get('phonemobile', '');
	}

	public function phoneMobile2(): string
	{
		return $this->get('phonemobile2', '');
	}

	public function phoneHome(): string
	{
		return $this->get('phonehome', '');
	}

	public function contactNote(): string
	{
		return $this->get('contact_note', '');
	}

	public function dateOfBirth(): string
	{
		return $this->get('dob', '');
	}

	public function salutation(): string
	{
		return $this->get('salutation', '');
	}

	public function email(): string
	{
		return $this->get('email');
	}

	public function username(): string
	{
		return $this->get('username');
	}

	public function picture(): string
	{
		return $this->get('picture', '');
	}
}
