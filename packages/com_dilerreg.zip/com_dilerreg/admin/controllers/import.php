<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

/**
 * Redirect link list controller class.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregControllerImport extends \Audivisa\Component\DiLer\Site\Controller\DilerFormController
{
	protected $view_list = 'codes';
	/**
	 * Method to update a record.
	 * @since   1.6
	 */

	public function import()
	{
		Session::checkToken() or die(Text::_('JINVALID_TOKEN'));
		if (! DilerHelperUser::extendedFeatures())
		{
			throw new RuntimeException(strip_tags(DText::_('EXTENDED_FEATURES_NOT_AVAILABLE')));
		}
		$app = Factory::getApplication();
		$options['skipFirstLine'] = $app->input->getInt('skip_first_line');
		$options['allowDuplicates'] = $app->input->getInt('allow_duplicates');
		$options['subtask'] = $app->input->get('subtask');
		$options['view'] = $app->input->get('view');
		$this->view_list = $options['view'];
		$options['fileInfo'] = isset($_FILES['import_file']) ? $_FILES['import_file'] : [];
		$redirectOption = $options['view'] === 'schools' ? 'com_diler' : 'com_dilerreg';
		try
		{
            /** @var DilerregModelImport $model */
            $model = $this->getModel();
			$model->import($options);
		}
		catch (Exception $ex)
		{
			$this->setMessage(DText::sprintf('REPORT_TYPE_IMPORT_FAIL', $ex->getMessage()), 'error');
			$this->setRedirect(Route::_('index.php?option=' . $redirectOption . '&view=' . $this->view_list, false));
			return false;
		}
		$this->setRedirect(Route::_('index.php?option=' . $redirectOption . '&view=' . $this->view_list, false));
		return true;
	}

	public function downloadFile()
	{
		$app = Factory::getApplication();
		$type = $app->input->get('fileType');
		$view = $app->input->get('view');
		$logPath = Factory::getConfig()->get('log_path');
		$baseName = $this->getModel()->getLogFileName($type, $view);
		$ext = ($type === 'rejects' ? '.csv' : '.php');
		$fullName = $logPath . '/' . $baseName . $ext;
		if ($type === 'sample')
		{
			$fullName = $baseName;
			$options['newExtension'] = 'zip';
		}
		else
		{
			$options['newExtension'] = $ext == '.php' ? 'log' : 'csv';
		}

		if (file_exists($fullName))
		{
			DiLerHelper::downloadFile($fullName, $options);
		}
		else
		{
			$app->enqueueMessage(DText::sprintf('NOT_FOUND', Text::_('COM_DILERREG_IMPORT_FILE')), 'error');
			$app->redirect('index.php?option=com_dilerreg&view=' .  $view);
		}
	}

	public function displayFile()
	{
		$input = Factory::getApplication()->input;
		$options['type'] = $input->get('type');
		$options['view'] = $input->get('view');
		$this->processModel('displayFile', $options);
	}

	/**
	 * Proxy for getModel.
	 * @since   1.6
	 */
	public function getModel($name = 'Import', $prefix = 'DilerregModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}

}
