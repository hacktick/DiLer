<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/**
 * Redirect link controller class.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregControllerUser extends FormController
{
	protected $context = 'user';

}
