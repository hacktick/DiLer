<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\MVC\Controller\AdminController;


/**
 * Redirect link list controller class.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregControllerCodes extends AdminController
{

	/**
	 * Proxy for getModel.
	 * @since   1.6
	 */
	public function getModel($name = 'Code', $prefix = 'DilerregModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}

	public function printPdf()
	{
		$input = Factory::getApplication()->input;
		$model = $this->getModel('Codes', 'DilerregModel');
		$ids = $input->get('cid', array(), 'array');
		$items = $model->getReportItems($ids);
		$displayArray = $model->groupByFamily($items);

		ini_set('display_errors', '1');
		ini_set("memory_limit", "512M");

		$pdfLayout = new FileLayout('registration-codes', JPATH_COMPONENT . '/layouts/');
		$html = $pdfLayout->render($displayArray);

		require_once ( JPATH_ROOT . '/libraries/vendor/dompdf/autoload.inc.php');
		$pdf = new Dompdf\Dompdf();
		$pdf->set_paper('a4', 'portrait');
		$pdf->load_html($html);
		$pdf->render();
		$this->doLogForCreatePdf();
		$pdf->stream("registration.pdf");

		Factory::getApplication()->close();
	}

    /**
     * Function to do standard controller tasks. Saves duplicate code in each controller function.
     *
     * @param string $function Name of model function to call.
     * @param array $options Associative array of options to pass to model. Depends on model.
     * @throws Exception
     */
	public function processModel($function, $options)
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		try
		{
			$result = $this->getModel()->$function($options);
		}
		catch (Exception $e)
		{
			header('HTTP/1.0 500 Internal Server Error');
			$response = $e->getMessage();
			echo json_encode($response);
			$app->close();
		}
		echo json_encode($result);
		$app->close();
	}

    private function doLogForCreatePdf() : void
    {
	    $logger = new DilerLogger('code', DilerLogger::ACTION_TYPE_CREATE_PDF);
	    $logData = array(
		    'username'  => Factory::getUser()->username,
	    );
	    $logger->addAction($logData, 'COM_DILER_LOG_REGISTRATION_CODES_CREATED_PDF_WITH_CODES');
    }
}
