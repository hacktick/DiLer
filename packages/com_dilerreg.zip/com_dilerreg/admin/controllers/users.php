<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Site\Model\UnblockDigluUsersModel;
use DiLer\Constants\ResponseCode;
use Joomla\CMS\Access\Exception\NotAllowed;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\Database\DatabaseInterface;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\MVC\Controller\AdminController;

/**
 * Redirect link list controller class.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregControllerUsers extends AdminController
{
	/**
	 * Method to update a record.
	 * @since   1.6
	 */

	/**
	 * Proxy for getModel.
	 * @since   1.6
	 */
	public function getModel($name = 'User', $prefix = 'DilerregModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);

		return $model;
	}

	public function delete()
	{
		// Check for request forgeries
		Session::checkToken() or die(Text::_('JINVALID_TOKEN'));

		// Get items to remove from the request.
		$input = Factory::getApplication()->input;
		$deleteParents = $input->getUint('deleteParents', 0);
		$cid = $input->get('cid', array(), 'array');
		$cid = ArrayHelper::toInteger($cid);

		// Remove current user from array
		$myId = Factory::getUser()->id;
		if (in_array($myId, $cid))
		{
			$cid = array_diff($cid, array($myId));
		}
		if (!is_array($cid) || !$cid)
		{
			$this->setMessage(Text::_('COM_DILERREG_DELETE_SELF_ERROR'), 'error');
			$this->setRedirect(Route::_('index.php?option=com_dilerreg&view=users', false));
			return;
		}

		if (! Factory::getUser()->authorise('core.admin'))
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		$app = Factory::getApplication();
		/** @var DilerregModelUser $model */
		$model = $this->getModel();
		try
		{
			$usersByRole = $model->getUsersByRole($cid);
			if ($deleteParents && $usersByRole['student'])
			{
				$usersByRole = $model->addParentsToDelete($usersByRole);
			}
			$result = $model->deleteDilerUsers($usersByRole);
		}
		catch (Exception $ex)
		{
			$app->enqueueMessage($ex->getMessage(), 'error');
			$this->setRedirect(Route::_('index.php?option=com_dilerreg&view=users', false));
		}
		$message = '';
		foreach ($result['counts'] as $role => $count)
		{
            if ($count > 0) {
                $roleText = is_array($result['roles'][$role])
                    ? implode(',', $result['roles'][$role]) : $result['roles'][$role];

                $messageType = ($role === 'teacher')
                    ? 'COM_DILERREG_N_USERS_BLOCKED' : 'COM_DILERREG_N_USERS_DELETED';

                $message .= Text::plural($messageType, $count, Text::_($roleText)) . '</br>';
            }
		}
		$this->setMessage($message);
		$this->setRedirect(Route::_('index.php?option=com_dilerreg&view=users', false));
	}

	/**
	 * Delete private cloud files for selected users
	 */
	public function deletePrivateCloud()
	{
		// Check for request forgeries
		Session::checkToken() or die(Text::_('JINVALID_TOKEN'));

		// Get items to remove from the request.
		$input = Factory::getApplication()->input;
		$cid = $input->get('cid', array(), 'array');
		$cid = ArrayHelper::toInteger($cid);
		if (! Factory::getUser()->authorise('core.admin'))
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		$app = Factory::getApplication();
		$model = $this->getModel();
		try
		{
			$result = $model->deletePrivateCloud($cid);
		}
		catch (Exception $ex)
		{
			$app->enqueueMessage($ex->getMessage(), 'error');
			$this->setRedirect(Route::_('index.php?option=com_dilerreg&view=users', false));
		}

		$message =  Text::plural('COM_DILERREG_N_USERS_CLOUD_DELETED', $result['count'], $result['size']);
		$this->setMessage($message);
		$this->setRedirect(Route::_('index.php?option=com_dilerreg&view=users', false));
	}

    public function unblockStudentAndParentsOfStudent() :void
    {
        if (!DilerHelperUser::isDiglu())
            throw new NotAllowed();

        Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));

        $studentId = Factory::getApplication()->input->getInt('id', 0);
        if(!$studentId)
            throw new Exception('Invalid user ID');

        /** @var UnblockDigluUsersModel $unblocker */
        $unblocker = MVCHelper::factory()->createModel('UnblockDigluUsers', 'Site');
        $unblocker->unblockUsersByStudentId($studentId);
        $this->setRedirect(Route::_('index.php?option=com_dilerreg&view=users', false));
        $this->redirect();
    }

    private function unblockUser(int $userId)
    {
        try {
            $this->unblockFromJoomlaUsers($userId);
            $this->removeFromBlockedDigluUsersTable($userId);
        }
        catch (Exception $ex)
        {
            Factory::getApplication()->enqueueMessage($ex->getMessage(), 'error');
        }
    }

    private function unblockFromJoomlaUsers(int $user) : void
    {

        /** @var DatabaseInterface $db */
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true);
        $query->update('#__users');
        $query->set('block = 0');
        $query->where('id = ' . $db->quote($user));

        $db->setQuery($query)->execute();
    }

    private function removeFromBlockedDigluUsersTable(int $user)
    {
        /** @var DatabaseInterface $db */
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true);
        $query->delete('#__diler_diglu_blocked_users');
        $query->where('user_id = ' . $db->quote($user));

        $db->setQuery($query)->execute();
    }
}
