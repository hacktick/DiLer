<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Constants\ResponseCode;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Language\Text;

// Import joomla controller library

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
JLoader::register('DiLerHelper', JPATH_ROOT . '/administrator/components/com_diler/helpers/diler.php');
JLoader::register('DilerLogger', JPATH_ROOT . '/components/com_diler/helpers/logger.php');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');
JLoader::registerNamespace('Audivisa\\Component\\DiLer\\Site', JPATH_ROOT . '/components/com_diler/src', false, false, 'psr4');

// Access check: is this user allowed to access the backend of this component?
if (!Factory::getUser()->authorise('core.manage', 'com_dilerreg'))
	throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

DilerHelper::checkRequiredPhpVersion();

// Get an instance of the controller prefixed by Dilerreg
$controller = BaseController::getInstance('Dilerreg');

//load com_diler language file
$language = Factory::getLanguage();
$language->load('com_diler', JPATH_SITE . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_diler', null, true);
$language->load('com_diler', JPATH_ROOT . '/administrator/components/com_diler', null, true);

// Perform the Request task
$input = Factory::getApplication()->input;

//execute obtain task
$controller->execute($input->getCmd('task'));

// Redirect if set by the controller
$controller->redirect();