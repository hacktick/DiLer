<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// Turn off all error reporting
// error_reporting(0);

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Uri\Uri;

// import Joomla controller library


class DilerregController extends BaseController
{

	protected $default_view = 'codes';

	/**
	 * Method to display a view.
	 *
	 * @param string $cachable String to get view.
	 * @return void
	 * @since 2.5
	 */
	function display($cachable = false, $urlparams = false)
	{
		HTMLHelper::_('bootstrap.framework');
		$document = Factory::getDocument();
		$v = $document->getMediaVersion();
		$document->addStyleSheet(Uri::root(true) . '/media/com_diler/administrator/css/diler.css?v=' . $v);
		parent::display();
	}

	function printReport()
	{
		ini_set('display_errors', '1');
		ini_set("memory_limit", "512M");
		$htmlOutput = '
			<html>
				<head>
					<link rel="stylesheet" href="' . Uri::base() . 'templates/isis/css/template.css" type="text/css" />
				</head>
				<body>
					' . str_replace('src="/', 'src="http://' . $_SERVER['HTTP_HOST'] . '/', Factory::getApplication()->input->getHtml('htmlContent', '')) . '
				</body>
			</html>';

		require_once ( JPATH_ROOT . '/libraries/vendor/dompdf/autoload.inc.php');
		$pdf = new Dompdf\Dompdf();
		$pdf->set_paper('a4', 'portrait');
		$pdf->load_html(utf8_decode($htmlOutput));
		$pdf->render();
		$pdf->stream("registration.pdf");

		die("pdftable");
	}

}