<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;

/**
 * Dilerreg User model.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregModelUser extends AdminModel
{
	/**
	 * @var        string    The prefix to use with controller messages.
	 * @since   1.6
	 */
	protected $text_prefix = 'COM_DILERREG';

	/**
	 * Adds parents of students to the array of parents to delete. Note that parents will only be deleted if they not mapped to any students.
	 * Students are deleted before parents, so if all students of a parent are selected, the parents may be deleted.
	 *
	 * @param array $usersByRole  Associative array of user ids by role: {role} => array of user id's for that role
	 */
	public function addParentsToDelete($usersByRole)
	{
		// Get parents for all of the students
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$studentRows = [];
		foreach ($usersByRole['student'] as $id)
		{
			$studentRows[] = (object) ['user_id' => $id];
		}
		$allParents = MVCHelper::factory()->createModel('Usergroup', 'Site')->getParentsForStudents($studentRows);
		$allParentIds = ArrayHelper::getColumn($allParents, 'user_id');
		$usersByRole['parent'] = array_unique(array_merge($usersByRole['parent'], $allParentIds));

		return $usersByRole;
	}

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param   object    $record    A record object.
	 *
	 * @return  boolean  True if allowed to delete the record. Defaults to the permission set in the component.
	 * @since   1.6
	 */
	protected function canDelete($record)
	{
		$user = Factory::getUser();
		return $user->authorise('core.admin', 'com_dilerreg');
	}

	/**
	 * Method to test whether a record can have its state edited.
	 *
	 * @param   object    $record    A record object.
	 *
	 * @return  boolean  True if allowed to change the state of the record. Defaults to the permission set in the component.
	 * @since   1.6
	 */
	protected function canEditState($record)
	{
		$user = Factory::getUser();

		// Check the component since there are no categories or other assets.
		return $user->authorise('core.admin', 'com_dilerreg');
	}

	/**
	 * Get an array of tables from which to delete user data.
	 *
	 * @return array Associative array: name => {table name}, column => {column name}
	 */
	protected function getTablesForAllUsers()
	{
		// Build array of table and column names
		return [
			['name' => '#__contact_details', 'column' => 'user_id'],
			['name' => '#__dilerreg_registration_codes', 'column' => 'user_id'],
			['name' => '#__dilerreg_registration_code_user_map', 'column' => 'user_id'],
			['name' => '#__diler_user_school_history', 'column' => 'user_id'],
			['name' => '#__dpcalendar_bookings', 'column' => 'user_id'],
			['name' => '#__messages', 'column' => 'user_id_from'],
			['name' => '#__messages', 'column' => 'user_id_to'],
			['name' => '#__messages_cfg', 'column' => 'user_id'],
			['name' => '#__session', 'column' => 'userid'],
			['name' => '#__user_notes', 'column' => 'user_id'],
			['name' => '#__user_usergroup_map', 'column' => 'user_id'],
			['name' => '#__user_profiles', 'column' => 'user_id'],
			['name' => '#__diler_user_phase_map', 'column' => 'user_id'],
			['name' => '#__diler_user_extra_curricular_map', 'column' => 'user_id'],
			['name' => '#__dilerreg_users', 'column' => 'user_id'],
			['name' => '#__privacy_consents', 'column' => 'user_id'],
			['name' => '#__action_logs', 'column' => 'user_id'],
			['name' => '#__action_logs_users', 'column' => 'user_id'],
		];
	}

	/**
	 * Get an array of tables from which to delete student data.
	 *
	 * @return array Associative array: name => {table name}, column => {column name}
	 */
	protected function getTablesForStudents()
	{
		return [
			['name' => '#__diler_activity_completed', 'column' => 'student_id'],
			['name' => '#__diler_activity_task_completed', 'column' => 'student_id'],
			['name' => '#__diler_report_field_history', 'column' => 'student_id'],
			['name' => '#__diler_student_compchar_status', 'column' => 'student_id'],
			['name' => '#__diler_student_competence_status', 'column' => 'student_id'],
			['name' => '#__diler_student_subject_phase_status', 'column' => 'student_id'],
			['name' => '#__diler_marks_history', 'column' => 'student_id'],
			['name' => '#__diler_stored_report', 'column' => 'student_id'],
			['name' => '#__diler_studentrecord', 'column' => 'student_id'],
			['name' => '#__diler_teacher_mynotes', 'column' => 'student_id'],
		];
	}

	// Deletes rows from tables based on table column IN array of $pks
	protected function deleteRowsFromTables($tables, $pks)
	{
		// Delete any rows from mapping table
		$db = Factory::getDbo();
		$pks = ArrayHelper::toInteger($pks);
		$pkString = ' IN(' . implode(',', $pks) . ')';
		foreach ($tables as $table)
		{
			$query = $db->getQuery(true)
				->delete($db->quoteName($table['name']))
				->where($db->quoteName($table['column']) .  $pkString);
			$db->setQuery($query)->execute();
		}
		return true;
	}

	public function deleteDilerUsers($usersByRole)
	{
		$counts = ['parent' => 0, 'student' => 0, 'teacher' => 0];
		$roles = ['parent' => 'COM_DILER_PARENTS', 'student' => 'COM_DILER_STUDENTS', 'teacher' => 'COM_DILER_TEACHERS'];

		// Start a transaction so we either delete all 3 rows or delete none.
		$db = Factory::getDbo();
		$db->transactionStart();
		$pks = array_merge($usersByRole['parent'], $usersByRole['student'], $usersByRole['teacher']);

		try
		{
			if (! is_array($pks) || ! $pks) throw new RuntimeException ('No valid DiLer users are selected.');
			// Delete texter, cloud, user keys, pictures for all users;
			$this->deleteTexter($pks);
			$this->deleteCloud($pks);
			$this->deleteUserKeys($pks);
			$this->deletePicture($pks);

			// Do role-specific deletes
			if ($usersByRole['student']) $counts['student'] = $this->deleteStudents($usersByRole['student']);
			if ($usersByRole['parent']) $counts['parent'] = $this->deleteParents($usersByRole['parent']);
			if ($usersByRole['teacher']) $counts['teacher'] = $this->deleteTeachers($usersByRole['teacher']);
		}
		catch (Exception $ex)
		{
			$db->transactionRollback();
			throw $ex;
		}

		$db->transactionCommit();
		return ['counts' => $counts, 'roles' => $roles];
	}

	/**
	 * Checks if parents are mapped to students.
	 *
	 * @param array $pks Array of user id's for parents
	 * @return array of stdClass row objects for parents with existing students
	 */
	protected function checkParentsForStudents($pks)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('du.user_id, CONCAT(du.forename, " ", du.surname) AS name, c.title AS relationship')
				->from('#__dilerreg_users AS du')
				->innerJoin('#__dilerreg_parent_student_map AS m ON m.parent_id = du.user_id AND m.parent_id_type = 1 AND m.student_id_type = 1')
				->innerJoin('#__categories AS c ON c.id = m.relationship')
				->where('du.user_id IN(' . implode(',', $pks) . ')');
		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Deletes private cloud files and rows in diler_cloud table.
	 *
	 * @param array $pks user_id's to delete
	 * @return boolean true on success
	 */
	protected function deleteCloud($pks)
	{
		$result = true;
		$cloudIds = $this->getCloudPrivateIdArray($pks);

		if (is_array($cloudIds) && $cloudIds)
		{
			$result = MVCHelper::factory()->createModel('File', 'Site')->deleteCloudFiles($cloudIds);
		}

		return $result;
	}

    /**
     * Deletes private cloud files for an array of users.
     *
     * @param $pks
     * @return array  Associative array: {userName} => ['count' => {count of files}, 'size' => {total size of files}]
     */
	public function deletePrivateCloud($pks)
	{
		$result = ['count' => 0, 'size' => '0'];
		$cloudIds = $this->getCloudPrivateIdArray($pks);

		if (is_array($cloudIds) && $cloudIds)
		{
			$result = MVCHelper::factory()->createModel('File', 'Administrator')->deletePrivateCloud($cloudIds);
		}
		return $result;
	}


    /**
     * Deletes DiLer user and Joomla user for set of parent user_id's
     *
     * @param array $pks user_id values
     * @throws Exception
     */
	protected function deleteParents($pks)
	{
		// No delete if parent is mapped to any students
		$noDeleteParents = $this->checkParentsForStudents($pks);
		$goodPks = $pks;
		$app = Factory::getApplication();
		if (is_array($noDeleteParents) && $noDeleteParents)
		{
			$badPks = ArrayHelper::getColumn($noDeleteParents, 'user_id');
			$goodPks = array_diff($pks, $badPks);
			$msg = [];
			foreach($noDeleteParents as $parent)
			{
				$msg[] = Text::sprintf('COM_DILERREG_PARENT_USER_DELETE_FAIL', $parent->name, $parent->relationship, DText::_('STUDENTS'));
			}
			$app->enqueueMessage(implode('</br>', $msg), 'warning');
			if (! $goodPks) return 0;
		}

		$this->logUserDelete($goodPks);
		$this->deleteParentStudentMap($goodPks);
		$tables = $this->getTablesForAllUsers();
		$this->deleteRowsFromTables($tables, $goodPks);
		$this->deleteUserObjects($goodPks);
		return count($goodPks);
	}

	/**
	 * Deletes rows from diler_user_grid_media_map and diler_grid_media.
	 * Also deletes physical media files for these rows.
	 *
	 * @param array $pks
	 */
	protected function deleteStudentGridMedia(array $pks)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('grid_media_id')->from('#__diler_user_grid_media_map')->where('user_id IN(' . implode(',', $pks) . ')');
		$mediaIds = $db->setQuery($query)->loadColumn();
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		/** @var DiLerModelGridFile $model */
		$model = MVCHelper::factory()->createModel('Gridfile', 'Site');
		$delete = $model->deleteGridFiles($mediaIds, 0, 0, 0, 0, true);
	}

	protected function deleteStudents($pks)
	{
		$this->logUserDelete($pks);
		$this->deleteParentStudentMap($pks);
		$this->deleteStudentRecord($pks);
		$this->deleteStudentGridMedia($pks);
		$studentTables = $this->getTablesForStudents();
		$this->deleteRowsFromTables($studentTables, $pks);
		$tables = $this->getTablesForAllUsers();
		$this->deleteRowsFromTables($tables, $pks);
		$this->deleteUserObjects($pks);
		return count($pks);
	}

	/**
	 * Deletes diler_studentrecord rows and related tables.
	 *
	 * @param array $pks  Array of student user_id's
	 * @return boolean  true on success
	 */
	protected function deleteStudentRecord($pks)
	{
		$result = true;
		// Get id's from studentrecord table
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')->from('#__diler_studentrecord')->where('student_id IN(' . implode(',', $pks) . ')');
		$studentRecordIds = $db->setQuery($query)->loadColumn();
		// Delete any diler_studentrecord_group_map rows
		if (is_array($studentRecordIds) && $studentRecordIds)
		{
			$query->clear()->delete('#__diler_studentrecord_group_map')
					->where('studentrecord_id IN(' . implode(',', $studentRecordIds) . ')');
			$result = $db->setQuery($query)->execute();
			$result = $result && MVCHelper::factory()->createModel('Studentrecord', 'Site')->delete($studentRecordIds);
		}
		return $result;
	}

	/**
	 * NOTE: This does NOT delete teachers from dilerreg_users or users table.
	 * Teachers user is needed to access student data (e.g., tests, comments, student report data).
	 * So teachers are not deleted, just set to inactive in #__users table so they can't log in.
	 * Texter messages, pictures, and private cloud files are deleted for all users, including teachers.
	 *
	 * @param array $pks
	 * @return int Count of teachers processed
	 */
	protected function deleteTeachers($pks)
	{
		// Set teacher to blocked
		$db = Factory::getDbo();
		$this->logUserDelete($pks);
		$query = $db->getQuery(true)->update('#__users')->set('block = 1')->where('id IN(' . implode(',', $pks) . ')');
		$result = $db->setQuery($query)->execute();
		// Delete from diler groups
		$groupDelete = $this->deleteUsersFromDilerGroups($pks);
		return ($result && $groupDelete) ? count($pks) : 0;
	}

	/**
	 * Deletes array of users from all Diler groups. Used to remove teachers from Diler groups.
	 * Note that this NOT remove user from non-Diler groups, so teachers still have the role of teacher
	 * based on row in user_usergroup_map table.
	 *
	 * @param array $pks Array of user ids.
	 */
	protected function deleteUsersFromDilerGroups($pks)
	{
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$dilerGroupCategoryRows = MVCHelper::factory()->createModel('Group', 'Site')->getDilerGroupCategories();
		$groupCategoryArray = [];
		foreach ($dilerGroupCategoryRows as $type => $rowArray)
		{
			$groupCategoryArray = array_merge($groupCategoryArray, ArrayHelper::getColumn($rowArray, 'id'));
		}
		// delete rows from user_usergroup_map table for all $pks and diler group categories.
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->delete('#__user_usergroup_map')
				->where('user_id IN(' . implode(',', $pks) . ')');
		$subquery = $db->getQuery(true)->select('joomla_group_id')
				->from('#__diler_group')
				->where('catid IN(' . implode(',', $groupCategoryArray) . ')');
		$query->where('group_id IN(' . (string) $subquery . ')');
		$result = $db->setQuery($query)->execute();
		return $result;
	}

	protected function deleteParentStudentMap($pks)
	{
		// Delete parent map rows
		if (! (is_array($pks) && $pks))
		{
			return true;
		}
		$db = Factory::getDbo();
		$pkString = implode(',', $pks);
		$query = $db->getQuery(true)->delete('#__dilerreg_parent_student_map')
				->where('(student_id IN( ' . $pkString . ') AND student_id_type = 1)', 'OR')
				->where('(parent_id IN( ' . $pkString . ') AND parent_id_type = 1)', 'OR');
		$result = $db->setQuery($query)->execute();
		return $result;
	}

	/**
	 * Deletes the personal picture for the user
	 */
	protected function deletePicture($pks)
	{
		
		
		JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
		$rootFolder = DilerHelperUser::getRootFileFolder();

		// Pictures will be in profilepictures folder, with name as $pk plus the extension (e.g., 123.jpg).
		foreach ($pks as $pk)
		{
			$path = $rootFolder . '/profilepictures';
			$filter = $pk . '.*';
			if (file_exists($path))
			{
				$fileArray = Folder::files($path, $filter, 0, true);
				foreach ($fileArray as $file)
				{
					File::delete($file);
				}
			}

			$noteMediaFolders = array(
				'student_alert_note_media',
				'student_alert_note_teacher_media',
				'private_note_teacher_media',
				'student_alert_my_note_media',
			);

			foreach($noteMediaFolders as $folder) {
				$noteMediaPath = $rootFolder . '/studentmedia/' . $folder . '/student-' . $pk;
				if (file_exists($noteMediaPath))
					Folder::delete($noteMediaPath);
			}
		}
	}

	/**
	 * Deletes rows in user_keys table based on usernames for given user_id values.
	 *
	 * @param array $pks  Array of user_id values
	 * @return boolean true on success
	 */
	protected function deleteUserKeys($pks)
	{
		$db = Factory::getDbo();
		$subQuery = $db->getQuery(true)->select('username')->from('#__users')->where('id IN(' . implode(',', $pks) . ')');
		$query = $db->getQuery(true)->delete('#__user_keys')
				->where('user_id IN(' . (string) $subQuery . ')');
		return $db->setQuery($query)->execute();
	}

	/**
	 * Deletes the user object. This fires the onUserBeforeDelete and onUserAfterDelete plugin events.
	 * @param array $goodPks
	 */
	protected function deleteUserObjects($goodPks)
	{
		foreach ($goodPks as $id)
		{
			$user = Factory::getUser($id);
			$user->delete();
		}
	}

	/**
	 * Override parent method. Add code to get map table information for form.
	 *
	 * {@inheritDoc}
	 * @see AdminModel::getItem()
	 */
	public function getItem($pk = null)
	{
		$item = parent::getItem($pk);
		$item->students = array();
		$item->parents = array();

		$role = DilerHelperUser::getDilerRole($item->user_id);
		if ($role == 'parent')
		{
			$item->students = DiLerHelper::getStudentsForParent($item->user_id, '1');
		}

		if ($role == 'student')
		{
			$item->parents = DiLerHelper::getParentsForStudent($item->user_id, '1');
		}

		return $item;
	}

	public function getTable($type = 'User', $prefix = 'DilerregTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Flags texter rows for deletion for ids.
	 *
	 * @param array $pks user_id's to delete
	 * @throws RuntimeException
	 */
	protected function deleteTexter($pks)
	{
		$db	= Factory::getDBO();
		$pks = ArrayHelper::toInteger($pks);
		$query = $db->getQuery(true);
		$query->update('#__diler_texter')
			->set('receiver_status = CASE WHEN receiver IN( ' . implode(',', $pks) . ') THEN 2 ELSE receiver_status END')
			->set('sender_status = CASE WHEN sender IN( ' . implode(',', $pks) . ') THEN 2 ELSE sender_status END')
			->where('(receiver IN( ' . implode(',', $pks) . ') OR sender IN( ' . implode(',', $pks) . '))');
		$db->setQuery($query)->execute();

		// Now delete any of these users messages that are flagged for deletion
		$query = $db->getQuery(true);
		$query->delete('#__diler_texter')
			->where('(receiver IN( ' . implode(',', $pks) . ') OR sender IN( ' . implode(',', $pks) . '))')
			->where('receiver_status = 2')
			->where('sender_status = 2');
		$db->setQuery($query)->execute();
		return true;
	}

	/**
	 * Get the private cloud file id's for an array of user ids
	 *
	 * @return array  catid's for private cloud categories
	 */
	protected function getCloudPrivateIdArray($pks)
	{
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$cloudCategories = MVCHelper::factory()->createModel('Cloud', 'Site')->getMediaCategories();
		$privateCategories = [];
		foreach ($cloudCategories as $cat)
		{
			if ($cat->mediaType == 3) $privateCategories[] = $cat->id;
		}
		if (! $privateCategories) return [];

		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('cl.id')
				->from('#__diler_cloud AS cl')
				->where('catid IN(' . implode(',', $privateCategories) . ')')
				->where('owned_by IN(' . implode(',', $pks) . ')');
		return $db->setQuery($query)->loadColumn();
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   array      $data        Data for the form.
	 * @param   boolean    $loadData    True if the form is to load its own data (default case), false if not.
	 * @return  Form    A Form object on success, false on failure
	 * @since   1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_dilerreg.user', 'user', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	public function getUsersByRole($pks)
	{
		$usersByRole = ['parent' => [], 'student' => [], 'teacher' => []];
		foreach ($pks as $pk)
		{
			$role = DilerHelperUser::getDilerRole($pk);
			if ($role) $usersByRole[$role][] = $pk;
		}
		return $usersByRole;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return  mixed  The data for the form.
     * @throws  Exception
     * @since   1.6
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_dilerreg.edit.user.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		$this->preprocessData('com_dilerreg.user', $data);

		return $data;
	}

    /**
     * Log admin delete of DiLer user
     *
     * @param $userIds
     */
	protected function logUserDelete($userIds)
	{
		if (DilerLogger::doLog('admin') && is_array($userIds) && $userIds)
		{
			$myName = Factory::getUser()->username;
			$db = Factory::getDbo();
			// Get LG categories
			$query = $db->getQuery(true)->select('id')->from('#__categories')->where('extension = "com_diler.group"')->where('params LIKE \'%"group_type":"1"%\'');
			$catIds = $db->setQuery($query)->loadColumn();
			$query = $db->getQuery(true)
					->select('u.username, u.id, GROUP_CONCAT(DISTINCT g.title SEPARATOR ", ") AS ' . $db->quoteName('groups'))
					->from('#__users AS u')
					->leftJoin('#__user_usergroup_map AS m ON m.user_id = u.id')
					->leftJoin('#__usergroups AS g ON m.group_id = g.id')
					->leftJoin('#__diler_group AS dg ON dg.joomla_group_id = m.group_id')
					->where('u.id IN(' . implode(',', $userIds) . ')')
					->where('(dg.catid IN(' . implode(',', $catIds) . ') OR ISNULL(dg.catid))')
					->group('u.id');
			$users = $db->setQuery($query)->loadAssocList();
			// @TODO Why we including following models??? Remove it if not needed.
			BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
			foreach ($users as $user)
			{
				$logMessage = DText::sprintf('LOG_USER_DELETE_MESSAGE', $myName, $user['username'], $user['groups']);
				$logData = array('message' => $logMessage, 'extension' => 'com_users');
				$logger = new DilerLogger('user', 'delete');
				$logger->addAction($logData);
			}

		}
	}

	/**
	 * Override parent data method.
	 *
	 * {@inheritDoc}
	 * @see AdminModel::save()
	 */
	public function save($data)
	{
		if (parent::save($data))
		{
			$role = DilerHelperUser::getDilerRole($data['user_id']);
			// Update map table rows for the user, based on role
			if ($role =='parent')
			{
				DilerHelper::saveParentStudentMapRows($data['user_id'], 'parent', '1', $data['students']);
			}
			elseif ($role =='student')
			{
				DilerHelper::saveParentStudentMapRows($data['user_id'], 'student', '1', $data['parents']);
			}
		}

		return true;
	}

}
