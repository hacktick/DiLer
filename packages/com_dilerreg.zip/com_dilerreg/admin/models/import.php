<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;
require JPATH_ADMINISTRATOR . '/components/com_diler/vendor/autoload.php';

use DiLer\DConst;
use DiLer\DMailer;
use DiLer\DPath;
use DiLer\ImportLog\ImportLogCollectionFromFile;
use DiLer\Layouts\FileViewModal;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Log\Log;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\Utilities\ArrayHelper;
use DiLer\Lang\DText;

JLoader::register('DilerHelper', JPATH_ADMINISTRATOR . '/components/com_diler/helpers/diler.php');

/**
 * Dilerreg Code model.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregModelImport extends BaseDatabaseModel
{
	/**
	 * @var        string    The prefix to use with controller messages.
	 * @since   1.6
	 */
	protected $text_prefix = 'COM_DILERREG';

	/**
	 * Assoc array to hold group id's for parent, student, teacher
	 * @var array: 'parent' => parent id array, 'student' => student id array, 'teacher' => teacher group id array
	 */
	public $roleGroupIds = [];

	public $fullNameArray = [];

	public $roleNames = [];

	public $familyIdCount = [];
	public $familyEmailArray = [];

	public $logFile = '';

	private $rejectsFile = '';

	public $rejectsFileCsv = '';

	/**
	 * Array of required import columns that must be present in all import files. Note that the order is not important.
	 * @var array
	 */
	public $requiredUserColumns = [
        'role',
        'user group',
        'learning group',
        'forename', 'surname',
        'country state',
        'gender',
        'dob',
        'email',
        'family id',
        'native language',
        'swimmer',
        'citizenship',
        'salutation'
    ];

	/**
	 * Additional required columns only for Diglu schools.
	 * @var array
	 */
	public $requiredUserColumnsDiglu = ['base school by school number'];

	public $allUserColumns = ['role', 'user group', 'learning group', 'salutation', 'forename', 'nickname', 'surname', 'dob',  'pob', 'gender', 'family id', 'email',
		'date of enrollment', 'current grade', 'target grade', 'swimmer', 'native language', 'street', 'zip code', 'city', 'citizenship', 'phone private',
		'phone mobile', 'phone work', 'assigned region teacher - Bereichslehrkraft', 'assigned base school teacher - Stammschullehrkraft',
		'country state', 'assigned base school teacher email - Stammschullehrkraft', 'password'];

    // Additional all columns only for Diglu schools.
	public $allUserColumnsDiglu = ['base school by school number'];

	/**
	 * Array of optional columns that require special function to validate.
	 * @var array: {import column heading} => {validate function name}
	 */
	public $specialColumns = ['date of enrollment' => 'checkEnrollmentDate'];

	public $specialColumnsDiglu = [];

	/**
	 * List of future import columns that are ignored for now. (No column in dilrereg_users to put them.)
	 * @var array
	 */
	public $ignoreColumns = [
        'assigned region teacher - Bereichslehrkraft',
        'assigned base school teacher - Stammschullehrkraft',
		'assigned base school teacher email - Stammschullehrkraft',
        'password'
    ];

	public $optionalColumnArray = [];

	public $emailArray = [];

	public $lgNameArray = [];

	/**
	 * Maps import column headings to the column name in the dilerreg_users table
	 * @var array: {import column heading} => {dilerreg_users table column name}
	 */
    public $optionalColumns = [
        'pob' => 'pob',
        'city' => 'city',
        'date of enrollment' => 'first_school_enrollment_date',
        'current grade' => 'student_phase_actual',
        'target grade' => 'student_phase_target',
        'street' => 'address',
        'zip code' => 'portalcode',
        'phone private' => 'phonehome',
        'phone mobile' => 'phonemobile',
        'phone work' => 'phonework',
        'nickname' => 'nickname'
    ];

	/**
	 * Valid header columns for the user import file being checked.
	 * @var array
	 */
	public $userHeaderColumns = [];

	/**
	 * File lines read from Excel/CSV file. Updated to show string value of dates.
	 * @var array
	 */
	public $fileLinesArray = [];

	public $isDiglu = false;

	/**
	 * Override parent construct -- add diglu columns if needed.
	 *
	 */
	public function __construct($config = array())
	{
		parent::__construct($config);
		$this->isDiglu = DilerHelperUser::isDiglu();
		if ($this->isDiglu)
		{
			$this->allUserColumns = array_merge($this->allUserColumns, $this->allUserColumnsDiglu);
			$this->requiredUserColumns = array_merge($this->requiredUserColumns, $this->requiredUserColumnsDiglu);
			$this->specialColumns = array_merge($this->specialColumns, $this->specialColumnsDiglu);
		}
	}

    //Check dob: acceptable formats: dd.mm.yyyy, mm/dd/yyyy, mm-dd-yyyy, yyyy-mm-dd
	protected function checkDate($rawData, $result, $columnName, $languageTag)
	{
		if ($result->value['role'] !== 'student')
		{
			$result->value[$columnName] = '';
			return;
		}
		if (gettype($rawData) !== 'string')
		{
			$phpDate = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($rawData);
			$rawData = $phpDate->format('Y-m-d');
		}
		$regEx1 = '#[\d]{4}[\.|\-|\/]{1}[\d]{1,2}[\.|\-|\/]{1}[\d]{1,2}#';
		$regEx2 = '#[\d]{1,2}[\.|\-|\/]{1}[\d]{1,2}[\.|\-|\/]{1}[\d]{4}#';
		$match1 = preg_match($regEx1, $rawData, $matches1);
		$match2 = preg_match($regEx2, $rawData, $matches2);
		if (! ($match1 || $match2))
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_FIELD', Text::_($languageTag), $rawData);
			$result->value[$columnName] = false;
			return;
		}
		$rawDataSlashes = str_replace('-', '/', $rawData);
		$date = strtotime($rawDataSlashes);
		$newValue = date('Y-m-d', $date);
		$today = Factory::getDate()->toSql();
		if ($date && strlen($newValue) === 10)
		{
			$result->value[$columnName] = $newValue;
		}
		else
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_FIELD', Text::_($languageTag), $rawData);
			$result->value[$columnName] = false;
		}
	}

	protected function checkUserFileRows($options)
	{
		$count = count($this->fileLinesArray);
		$start = 1;
		$errorLog = [];
		$successLog = [];
		$warningLog = [];
		$warningRows = [];
		$validData = [];
		$rowCheck = $this->checkUserFileHeader($this->fileLinesArray[0]);
		if ($rowCheck->error)
		{
			return (object) ['error' => $rowCheck->error, 'successRows' => $successLog, 'warning' => $warningLog, 'warningRows' => $warningRows, 'validData' => $validData];
		}
		$this->setExistingEmails();
		$columnCount = count($rowCheck->columns);
		for ($i = $start; $i < $count; $i++)
		{
			$rowCheck = $this->checkUserRow($options, $i, $columnCount);
			// Status: 1=success, 0=error, -1=warning
			if ($rowCheck->status === 0)
			{
				$errorLog[$i] = $rowCheck->error;
			}
			elseif ($rowCheck->status === 1)
			{
				$successLog[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
			elseif ($rowCheck->status === -1)
			{
				$warningLog[$i] = $rowCheck->warning;
				$warningRows[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
		}
		$result = (object) ['error' => $errorLog, 'successRows' => $successLog, 'warning' => $warningLog, 'warningRows' => $warningRows, 'validData' => $validData];
		return $result;
	}

	protected function checkUserFileHeader($columnArray)
	{
		$result = (object) ['error' => [], 'warning' => [], 'value' => [], 'columns' => $columnArray];
		$missingColumns = [];
		foreach ($this->requiredUserColumns as $column)
		{
			if (! in_array($column, $columnArray)) $missingColumns[] = $column;
		}
		$unmatchedColumns = [];
		foreach ($columnArray as $fileColumn)
		{
			if (! in_array($fileColumn, $this->allUserColumns)) $unmatchedColumns[] = $fileColumn;
		}
		$errors = [];
		if ($missingColumns) $errors[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_MISSING_COLUMNS', implode(', ', $missingColumns));
		if ($unmatchedColumns) $errors[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_UNKNOWN_COLUMNS', implode(', ', $unmatchedColumns));
		if ($errors)
		{
			$errors[] = Text::_('COM_DILERREG_IMPORT_ERROR_HEADER');
			$result->error[0] = array_reverse($errors);

		}
		else
		{
			$this->userHeaderColumns = $columnArray;
			$this->optionalColumnArray = array_diff($this->userHeaderColumns, $this->requiredUserColumns);
		}
		return $result;
	}

	private function checkEmail($userDataArray, $result)
	{
		$email = $userDataArray['email'];

		if (! $email)
		{
			$result->value['email'] = null;
			return $result;
		}
		if (! filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_FIELD',
				DText::_('CONFIG_SCHOOLEMAIL_LABEL'),
				$email);
			$result->value['email'] = false;
			return $result;
		}
		$inJoomla = in_array($email, $this->emailArray['joomla']);
		$duplicate = ($this->emailArray['importFile'][$email] > 1);
		if ($inJoomla || $duplicate)
		{
			if ($inJoomla)
			{
				$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_EMAIL_EXISTS', $email);
			}
			if ($duplicate)
			{
				$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_EMAIL_DUPLICATE',
					$this->emailArray['importFile'][$email],
					$email);
			}
			$result->value['email'] = false;
			return $result;
		}
		$result->value['email'] = $email;
		return $result;
	}

	protected function checkEnrollmentDate($rawValue, $result)
	{
		$this->checkDate($rawValue, $result, 'date of enrollment', 'COM_DILERREG_IMPORT_ENROLLMENT_DATE');
	}

	protected function checkUserRow($options, $i, $columnCount)
	{
		$columnArray = $this->fileLinesArray[$i];
		if (count($columnArray) !== $columnCount)
		{
			$msg = Text::sprintf('COM_DILERREG_IMPORT_ERROR_BAD_COLUMN_COUNT', $i+1, $columnCount, count($columnArray));
			return (object) ['status' => 0, 'error' => [$msg]];
		}
		$result = (object) ['error' => [], 'warning' => [], 'value' => []];
		$userDataArray = $this->createUserDataArray($columnArray);
		$this->checkRole($userDataArray['role'], $result);
		$this->checkDilerRoleGroup($userDataArray['user group'], $result);
		$userDataArray['dob'] = $this->convertExcelDate($userDataArray['dob']);
		$position = array_search('dob', $this->userHeaderColumns);
		$this->fileLinesArray[$i][$position] = $userDataArray['dob'];
		$this->checkDate($userDataArray['dob'], $result, 'dob', 'COM_DILER_DOB');
		$result = $this->checkEmail($userDataArray, $result);
		$this->checkFamilyId($userDataArray['family id'], $result);
        $this->checkState($userDataArray['country state'], $result);
        $this->checkNativeLanguage($userDataArray['native language'], $result);
        $this->checkCitizenship($userDataArray['citizenship'], $result);
        $this->checkSwimmer($userDataArray['swimmer'], $result);
		$this->checkRequired($userDataArray, $result, 'forename', 'COM_DILERREG_FIRST_NAME');
		$this->checkRequired($userDataArray, $result, 'surname', 'COM_DILERREG_LAST_NAME');
		$this->checkGender($userDataArray['gender'], $result);
        $this->checkSalutation($userDataArray['salutation'], $result);
        $userDataArray['password'] = isset($userDataArray['password']) ? $userDataArray['password'] : "";
        $this->checkPassword($userDataArray['password'], $result);
		if ($this->isDiglu)
		{
			$this->checkBaseSchool($userDataArray['base school by school number'], $result);
		}
		// Process optional columns, if any
		$this->checkUserOptionalColumns($userDataArray, $result, $i);
		$this->checkLg($userDataArray['learning group'], $result, $options);
		$result->status = 1;
		if ($result->error)
		{
			$result->status = 0;
		} elseif ($result->warning)
		{
			$result->status = -1;
		}
		return $result;
	}

	protected function checkUserOptionalColumns($userDataArray, $result, $i)
	{
		foreach ($this->optionalColumnArray as $columnName)
		{
			if (key_exists($columnName, $this->specialColumns) && $userDataArray[$columnName])
			{
				$functionName = $this->specialColumns[$columnName];
				if ($functionName === 'checkEnrollmentDate')
				{
					$userDataArray[$columnName] = $this->convertExcelDate($userDataArray[$columnName]);
					$position = array_search($columnName, $this->userHeaderColumns);
					$this->fileLinesArray[$i][$position] = $userDataArray[$columnName];
				}
				$this->$functionName($userDataArray[$columnName], $result);
			}
            elseif ($columnName == 'password')
            {
                // skip validation of password as we already checked it before calling this method
                continue;
            }
			else
			{
				$this->checkTextField($userDataArray, $columnName, $result);
			}
		}
	}

	protected function checkTextField($userDataArray, $columnName, $result)
	{
		$result->value[$columnName] = ($userDataArray[$columnName]) ? $userDataArray[$columnName] : '';
	}

	protected function checkState($rawValue, $result)
	{
        if (strlen($rawValue) !== 5 && ($result->value['role'] == DConst::USER_ROLE_STUDENT || $result->value['role'] == DConst::USER_ROLE_PARENT))
        {
            $result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_COUNTRY_STATE', DText::_('STATE_ISO_LABEL'), $rawValue);
            return;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true);
        $query->select('s.*')
            ->from('#__diler_state AS s')
            ->where('s.country_iso2 = ' . $db->quote(substr($rawValue, 0, 2)))
            ->where('s.state_iso = ' . $db->quote(substr($rawValue, -2)));
        $row = $db->setQuery($query)->loadObject();
        if (is_object($row) && $row->id) {
            $result->value['state_iso'] = $row->state_iso;
            $result->value['country_iso2'] = $row->country_iso2;
        } else {
            if ($result->value['role'] == DConst::USER_ROLE_STUDENT || $result->value['role'] == DConst::USER_ROLE_PARENT)
            {
                $result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_COUNTRY_STATE', DText::_('STATE_ISO_LABEL'), $rawValue);
            }
            else
            {
                $result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_COUNTRY_STATE', DText::_('STATE_ISO_LABEL'), $rawValue);
                $result->value['state_iso'] = '';
                $result->value['country_iso2'] = '';
            }
        }
	}
    public function loadLanguageIdByLanguageName($languageName)
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        $query->select('id')
            ->from('#__diler_languages')
            ->where($db->quoteName('language_name') . ' = ' . $db->quote($languageName));
        return $db->setQuery($query)->loadResult();
    }

    public function checkNativeLanguage($rawValue, $result)
    {
        $languageId = $this->loadLanguageIdByLanguageName($rawValue);
        $isStudent = $result->value['role'] == DConst::USER_ROLE_STUDENT;

        if ($isStudent && !$languageId) {
            $result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_NATIVE_LANGUAGE', DText::_('NATIVE_LANGUAGE'), $rawValue);
            return;
        }

        if (!$isStudent && !empty($rawValue) && !$languageId) {
            $result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_NATIVE_LANGUAGE', DText::_('NATIVE_LANGUAGE'), $rawValue);
        }

        $result->value['native_language_id'] = $languageId;

    }

	protected function checkSwimmer($rawValue, $result)
	{
		if ($result->value['role'] === 'student' && in_array($rawValue, ['1','2','3']))
		{
			$result->value['swimmer'] = (int) $rawValue;
		}
		elseif ($result->value['role'] === 'student' )
		{
            $result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_SWIMMER', $rawValue);
			$result->value['swimmer'] = 3;
		}
		else
		{
			$result->value['swimmer'] = 3;
		}
	}

	protected function checkGender($rawValue, $result)
	{
		$valid = true;
		if ($result->value['role'] === 'student')
		{
			$valid = in_array($rawValue, ['0','1','2']);
		}
		else
		{
			$valid = in_array($rawValue, ['0','1','2']) || ! $rawValue;
		}
		if (! $valid)
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_GENDER', $rawValue);
			$result->value['gender'] = false;
		}
		else
		{
			$result->value['gender'] = $rawValue;
		}
	}

    protected function checkSalutation($rawValue, $result)
    {
        if ($result->value['role'] != DConst::USER_ROLE_TEACHER)
        {
            $result->value['salutation'] = "";
            return;
        }

        if (!$rawValue)
        {
            $result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_SALUTATION', $rawValue);
            return;
        }

        $result->value['salutation'] = $rawValue;
    }

    private function checkPassword($rawValue, $result)
    {
        if (!$rawValue)
        {
            $randomPassword = $this->getPassword();
            $result->value['password'] = $randomPassword;
            $result->value['password2'] = $randomPassword;
            return;
        }

        $elementString = '<field name="password" type="text" required="true" />';
        $element = new SimpleXMLElement(trim($elementString));
        $valid = (new Joomla\CMS\Form\Rule\PasswordRule())->test($element, $rawValue);
        if (! $valid)
        {
            $errorMessages = [];
            $messageQueue = Factory::getApplication()->getMessageQueue(true);
            foreach ($messageQueue as $queue)
            {
                $errorMessages[] = $queue['message'];
            }


            $result->error[] = implode(', ', $errorMessages);
            return;
        }

        $result->value['password'] = $rawValue;
        $result->value['password2'] = $rawValue;
    }
	protected function checkRequired($userDataArray, $result, $columnName, $columnLanguageTag)
	{
		if (! $userDataArray[$columnName])
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_REQUIRED_FIELD', Text::_($columnLanguageTag));
			$result->value[$columnName] = false;
		}
		else
		{
			$result->value[$columnName] = $userDataArray[$columnName];
		}
	}

	protected function createUserDataArray($columnArray)
	{
		$result = [];
		$i = 0;
		foreach ($this->userHeaderColumns as $colName)
		{
			$result[$colName] = $columnArray[$i];
			$i++;
		}
		return $result;
	}


	/**
	 * Checks if a proposed group name already exists in the db. LG groups must be unique. We only do db query once and save the result.
	 * Note that we add any new group names to this array when a new group is created.
	 * @param string $testName  Proposed group name to check
	 * @param BasedatabaseModel $groupModel  Model function from com_diler
	 * @return bool true if group exists, false otherwise
	 */
	protected function existsLgName($testName, $groupModel)
	{
		if (! $this->lgNameArray)
		{
			$groupCategoryRows = $groupModel->getDilerGroupCategories();
			$lgCatIdArray = ArrayHelper::getColumn($groupCategoryRows[1], 'id');
			$db = Factory::getDbo();
			$query = $db->getQuery(true)->select('name')
					->from('#__diler_group')
					->where('catid IN(' . implode(',', $lgCatIdArray) . ')');
			$this->lgNameArray = $db->setQuery($query)->loadColumn();
		}
		return in_array($testName, $this->lgNameArray);
	}

	/**
	 * Gets the first LG category for DiLer groups.
	 * @return int  Category id or 0 if not found.
	 */
	public function getLgCatId($groupModel)
	{
		$groupCategories = $groupModel->getDilerGroupCategories();
		$result = (isset($groupCategories[1]) && is_array($groupCategories[1]) && count($groupCategories[1])) ? $groupCategories[1][0]->id : 0;
		return $result;
	}

	private function setExistingEmails() : void
	{
		$this->emailArray = array(
			'joomla' => DMailer::getEmailsFromJoomlaUsers(),
			'importFile' => $this->getEmailsFromImportedFile()
		);
	}

	private function getEmailsFromImportedFile() : array
	{
		$columnCount = count($this->userHeaderColumns);
		$emails = array();
		foreach ($this->fileLinesArray as $columnArray)
		{
			if (count($columnArray) === $columnCount)
			{
				$userDataArray = $this->createUserDataArray($columnArray);
				if (filter_var($userDataArray['email'], FILTER_VALIDATE_EMAIL))
				{
					if (isset($emails[$userDataArray['email']]))
					{
						$emails[$userDataArray['email']]++;
						continue;
					}
					$emails[$userDataArray['email']] = 1;
				}
			}
		}

		return $emails;
	}

	protected function getFamilyIdColumnNumber()
	{
		$columnNames = $this->fileLinesArray[0];
		return array_search('family id', $columnNames);
	}

	protected function getEmailColumnNumber()
	{
		$columnNames = $this->fileLinesArray[0];
		return array_search('email', $columnNames);
	}

    protected function getFirstValidSheet($spreadsheet)
	{
		$sheetCount = $spreadsheet->getSheetCount();
		for ($i = 0; $i < $sheetCount; $i++)
		{
			$testSheet = $spreadsheet->getSheet($i);
			$range = $testSheet->calculateWorksheetDataDimension();
			$fileArray = $testSheet->rangeToArray($range);
			$testResult = $this->checkUserFileHeader($fileArray[0]);
			if (! $testResult->error) break;
		}
		return $testSheet;
	}

	protected function getImportFile($options)
	{
		$fileName = $options['fileInfo']['tmp_name'];
		$fileArray = [];
		$fileInfo = new finfo(FILEINFO_MIME);
		$mimeType = $fileInfo->buffer(file_get_contents($fileName));
		$okTypes = [
			'application/vnd.oasis.opendocument.spreadsheet; charset=binary',
			'application/octet-stream; charset=binary',
			'text/plain; charset=utf-8',
			'text/csv; charset=utf-8',
			'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=binary',
			'application/vnd.ms-excel; charset=binary'
		];
		if (! in_array($mimeType, $okTypes))
		{
			throw new Exception(Text::sprintf('COM_DILERREG_IMPORT_BAD_FORMAT', $options['fileInfo']['name'], $mimeType));
		}
		if (true || strpos($mimeType, 'charset=binary'))
		{
			// Should be Excel file
			$reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($fileName);
			$reader->setReadDataOnly(true);
			$spreadsheet = $reader->load($fileName);
			$activeSheet = $this->getFirstValidSheet($spreadsheet);
			$range = $activeSheet->calculateWorksheetDataDimension();
			$fileArray = $activeSheet->rangeToArray($range);
			if (is_array($fileArray) && count($fileArray) === 1 && is_array($fileArray[0]) && count($fileArray[0]) === 1 &&
					$fileArray[0][0] === null)
			{
				throw new Exception(Text::_('COM_DILERREG_IMPORT_ERROR_NO_DATA'));
			}
		}
		else
		{
			$fileArray = file($fileName);
		}

		if ((! is_array($fileArray)) || ! $fileArray)
		{
			throw new Exception(DText::sprintf('NOT_FOUND', Text::_('COM_DILERREG_IMPORT_FILE')));
		}
		return $fileArray;
	}

    /**
     * Converts Excel numeric date to string formatted date.
     * @param mixed $dateValue
     * @throws Exception
     */
	protected function convertExcelDate($dateValue)
	{
		if (gettype($dateValue) !== 'string')
		{
			$phpDate = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($dateValue);
			$dateValue = $phpDate->format('Y-m-d');
		}
		return $dateValue;
	}

	public function displayFile($options): object
	{
		$logFileName     = $this->getLogFileName($options['type'], $options['view']) . '.php';
		$fullLogFilePath = Factory::getConfig()->get('log_path') . '/' . $logFileName;

		$importedLogRows = new ImportLogCollectionFromFile($fullLogFilePath);
		$fileViewModal   = new FileViewModal($options['type'], $importedLogRows, $options['view'], $this->option);

		$displayData     = array(
			'html'    => $fileViewModal->render(new FileLayout('file_view_modal', DPath::LAYOUTS)),
			'status'  => $importedLogRows->loadStatus(),
			'modalId' => $fileViewModal->modalId()
		);

		return (object) $displayData;
	}

	public function getLogFileName($type, $view) : string
	{
		$fileName = 'diler-import-users-' . $type;
		if ($view === 'codes') {
			$fileName = 'diler-import-registration-codes-' . $type . '-' . Factory::getUser()->id;
		}
		$isDiglu = DilerHelperUser::isDiglu();
		if ($type === 'sample' && $view === 'users' && ! $isDiglu)
		{
			$fileName = JPATH_ROOT . '/media/com_diler/administrator/images/sample-user-import-profiles.zip';
		}
		elseif ($type === 'sample' && $view === 'users' && $isDiglu)
		{
			$fileName = JPATH_ROOT . '/media/com_diler/administrator/images/sample-user-import-profiles-diglu.zip';
		}
		elseif ($type === 'sample' && $view === 'codes')
		{
			$fileName = JPATH_ROOT . '/media/com_diler/administrator/images/sample-user-import-regcodes.zip';
		}
		return $fileName;
	}

	protected function getPassword()
	{
		$result[0] = $this->getPasswordChar(2, '0123456789');
		$result[] = $this->getPasswordChar(2, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ');
		$result[] = $this->getPasswordChar(2, 'abcdefghijklmnopqrstuvwxyz');
		$result[] = $this->getPasswordChar(2, '!@#$%^&*()_+-=');
		shuffle($result);
		return implode('', $result);
	}

	protected function getPasswordChar (int $length = 8, string $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+-='): string
	{
		if ($length < 1) {
			throw new \RangeException("Length must be a positive integer");
		}
		$pieces = [];
		$max = strlen($keyspace) - 1;
		for ($i = 0; $i < $length; ++$i) {
			$pieces []= $keyspace[random_int(0, $max)];
		}
		return implode('', $pieces);
	}

		protected function initializeFields($options)
	{
		$params = ComponentHelper::getParams('com_diler');
		$this->roleGroupIds['parent'] = $params->get('parent_group_ids');
		$this->roleGroupIds['student'] = $params->get('student_group_ids');
		$this->roleGroupIds['teacher'] = $params->get('teacher_group_ids');
		$this->roleGroupIds['lgParentId'] = $params->get('learning_group_parent_id');
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('CONCAT(first_name, "_", last_name) AS fullName, dilerrolegroup')
				->from('#__dilerreg_registration_codes')->order('last_name, first_name');
		$rows = $db->setQuery($query)->loadObjectList();
		$this->fullNameArray = ['parent' => [], 'student' => [], 'teacher' => []];
		foreach ($rows as $row)
		{
			 $role = false;
			 if (in_array($row->dilerrolegroup, $this->roleGroupIds['parent'])) $role = 'parent';
			 if (in_array($row->dilerrolegroup, $this->roleGroupIds['student'])) $role = 'student';
			 if (in_array($row->dilerrolegroup, $this->roleGroupIds['teacher'])) $role = 'teacher';
			 if ($role) $this->fullNameArray[$role][] = $row->fullName;
		}
		$this->roleNames = ['parent' => DText::_('PARENT'), 'student' => DText::_('STUDENT'), 'teacher' => DText::_('TEACHER')];
		$this->familyIdCount = $this->buildFamilyIdCount($options);
		$this->buildFamilyEmailArray($options);
	}

    /**
     * Import file
     * @param array $options : view, skipFirstLine, allowDuplicates, subtask (check vs. import), fileInfo (array for viewing logs)
     * @throws Exception
     */
	public function import($options)
	{
		$this->isDiglu = DilerHelperUser::isDiglu();
		$this->logPrepare($options);
		$this->fileLinesArray = $this->getImportFile($options);
		$this->initializeFields($options);
		$rowResults = [];
		if ($options['view'] === 'codes')
		{
			$rowResults = $this->checkCodeFileRows($options);
		}
		elseif ($options['view'] === 'users')
		{
			$rowResults = $this->checkUserFileRows($options);
		}

		if ($options['subtask'] === 'import' && $options['view'] === 'codes')
		{
			$rowResults->insertedCount = $this->insertCodeRows($options, $rowResults);
		}
		elseif ($options['subtask'] === 'import' && $options['view'] === 'users')
		{
			$rowResults->insertedCount = $this->insertUserRows($options, $rowResults);
		}
		if ($rowResults->error && $options['subtask'] === 'import')
		{
			$this->createRejectsFiles($options, $rowResults);
		}
		$this->logResults($options, $rowResults);
		$this->showMessages($options, $rowResults);
	}

	protected function createRejectsFiles($options, $rowResults)
	{
		$rejectsArray = [];
		if ($options['view'] !== 'codes' || $options['skipFirstLine'] != '2')
		{
			$rejectsArray[] = '"' . implode('","', $this->fileLinesArray[0]) . '"' . "\n";
		}
		$badRows = array_keys($rowResults->error);
		foreach ($badRows as $i => $rowIndex)
		{
			$formattedRow = '"' . implode('","', $this->fileLinesArray[$rowIndex]) . '"' . "\n";
			$rejectsArray[] = $formattedRow;
		}
		$logPath = Factory::getConfig()->get('log_path');
		$write = File::write($logPath . '/' . $this->rejectsFileCsv, implode('', $rejectsArray), true);
	}

	/**
	 * Sets the family_email_user_id value for family members who will use another family member's email address for all Joomla email.
	 *
	 * @param array $userIdsToUpdate Assoc array: {user id for family email} => {array of family user_ids to set to this value}
	 */
	protected function updateFamilyEmails($userIdsToUpdate)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		foreach ($userIdsToUpdate as $familyEmailId => $memberArray)
		{
			if (! is_array($memberArray) || ! $memberArray) continue;
			$query->clear()->update('#__dilerreg_users')
					->set('family_email_user_id = ' . $familyEmailId)
					->where('user_id IN(' . implode(',', $memberArray) . ')');
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}

	protected function showMessages($options, $rowResults)
	{
		$insertedCount = ($options['subtask'] === 'import') ? $rowResults->insertedCount : 0;
		$countAllRows = count($this->fileLinesArray);
		$summary = array(
			'errorCount' => count($rowResults->error),
			'successCount' => count($rowResults->successRows),
			'warningCount' => count($rowResults->warningRows),
			'insertedCount' => $insertedCount,
			'totalRows' => ($options['view'] === 'users' || $options['skipFirstLine'] != '2') ? $countAllRows - 1 : $countAllRows,
		);
		$app = Factory::getApplication();
		$alertType = $this->getAlertType($options, $summary);

		$this->displayMessageHead($options, $summary, $alertType);
		if ($options['subtask'] == 'check' && $alertType == 'success' || $alertType == 'success' && $summary['successCount'] == $summary['insertedCount'])
			return;
		$app->enqueueMessage('<hr class="dashed_hr_line import_after_head"/>', $alertType);
		$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_ROWS_OK', $summary['successCount']), $alertType);
		$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_ROWS_WITH_WARNINGS', $summary['warningCount']), $alertType);
		$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_ROWS_WITH_ERRORS', $summary['errorCount']), $alertType);
		if ($options['subtask'] === 'check')
		{
			$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_ROWS_READY_TO_IMPORT', $summary['successCount'] + $summary['warningCount']), $alertType);
		}
		else
		{
			$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_ROWS_IMPORTED', $summary['insertedCount']), $alertType);
		}
		$app->enqueueMessage('<hr class="dashed_hr_line import_after_summary"/>', $alertType);
		$app->enqueueMessage(Text::_('COM_DILERREG_IMPORT_ALERT_SEE_THE_LOG_FILE_FOR_DETAILS'), $alertType);
	}

	private function displayMessageHead($options, $summary, $alertType)
	{
		$app = Factory::getApplication();
		$tag = ($options['subtask'] === 'import') ? 'COM_DILERREG_IMPORT_ROWS_IMPORT_RESULTS' : 'COM_DILERREG_IMPORT_ROWS_CHECK_RESULTS';
		$message = Text::sprintf($tag, $summary['totalRows']);
		if ($alertType == 'success')
		{
			$message = $message . ' ' .  Text::_('COM_DILERREG_IMPORT_NO_ERRORS');
		}
		$app->enqueueMessage($message, $alertType);
	}

	private function getAlertType($options, $summary)
	{
		if ($options['subtask'] == 'import' && $summary['insertedCount'] && ($summary['errorCount'] || $summary['warningCount']))
			return 'warning';

		if ($summary['errorCount'])
			return 'error';

		if ($summary['warningCount'])
			return 'warning';

		return "success";
	}

	protected function insertCodeRows($options, $rowResults)
	{
		$inserted = 0;
		foreach ($rowResults->validData as $i => $data)
		{
			$data['id'] = '0';
			$data['students'] = [];
			$data['parents'] = [];
			/** @var DilerregModelCode $codeModel */
			$codeModel = BaseDatabaseModel::getInstance('Code', 'DilerregModel');
			$codeModel->setState('code.id', 0);
			$result = $codeModel->save($data);
			if ($result)
			{
				$stateIdName = 'code.id';
				$rowResults->validData[$i]['id'] = $codeModel->state->$stateIdName;
				$inserted++;
			}
		}
		$this->importParentStudentMapRows($rowResults, $options);
		return $inserted;
	}

	protected function insertUserRows($options, $rowResults)
	{
		$inserted = 0;
		foreach ($rowResults->validData as $i => $data)
		{
			BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_dilerreg/models');
			/** @var DiLerregModelRegistration $registrationModel */
			$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');
			$data['user_id'] = '0';
			$data['students'] = [];
			$data['parents'] = [];
			$data['username'] = $registrationModel->getUsername($data['forename'], $data['surname']);
			if ($data['email'] === null)
			{
				$data['email'] = DMailer::getDummyEmail($data['username']);
			}

			$data['acceptedterms'] = 1;
			$data['acceptedcontract'] = 1;
			$data['code'] = 'from-import';
			Form::addFormPath(JPATH_ROOT . '/components/com_dilerreg/models/forms');
			$result = $registrationModel->registerUser($data, false);
			if ($result->status)
			{
				$rowResults->validData[$i]['user_id'] = $result->user_id;
				$data['user_id'] = $result->user_id;
				$this->updateOptionalUserColumns($data);
				$inserted++;
			}
		}
		$this->importParentStudentMapRows($rowResults, $options);
		if ($this->isDiglu)
		{
			$this->importUserSchoolHistoryRows($rowResults, $options);
		}
		$this->importFamilyEmails($rowResults);
		return $inserted;
	}

	protected function importFamilyEmails($rowResults)
	{
		$familyIdToUserIdArray = [];
		foreach ($this->familyIdCount as $familyId => $rowArray)
		{
			foreach ($rowArray as $rowNumber)
			{
				$data = $rowResults->validData[$rowNumber];
				if (empty($familyIdToUserIdArray['familyId']) && ! empty($data['email'] && ! DMailer::isDummyEmail($data['email'])))
				{
					$familyIdToUserIdArray[$familyId] = $data['user_id'];
				}
			}
		}
		// At this point we have array of family id's and corresponding user_id for family_email_user_id
		// Now we loop through again to get a list of user_ids to update by family email user id
		$userIdsToUpdate = [];
		foreach ($this->familyIdCount as $familyId => $rowArray)
		{
			foreach ($rowArray as $rowNumber)
			{
				$data = $rowResults->validData[$rowNumber];
				if (isset($familyIdToUserIdArray[$familyId]))
				{
					if (! isset($userIdsToUpdate[$familyIdToUserIdArray[$familyId]]))
					{
						$userIdsToUpdate[$familyIdToUserIdArray[$familyId]] = [];
					}
					$userIdsToUpdate[$familyIdToUserIdArray[$familyId]][] = $data['user_id'];
				}
			}
		}
		return $this->updateFamilyEmails($userIdsToUpdate);
	}

	protected function importParentStudentMapRows($rowResults, $options)
	{
		$type = $options['view'] === 'codes' ? '0' : '1';
		// Get catId for relationship
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('id')->from('#__categories')->where('extension = ' . $db->quote('com_diler.relationships' ))
				->where('published = 1');
		$relationshipId = $db->setQuery($query)->loadResult();
		if (! $relationshipId) return 0;
		$studentParentArray = $this->createStudentParentArray($rowResults, $options);
		foreach ($studentParentArray as $studentId => $familyInfo)
		{
			$parentArray = ['parents0' => ['parent_id' => [], 'relationship' => $relationshipId]];
			foreach ($familyInfo['parentArray'] as $parentId)
			{
				$parentArray['parents0']['parent_id'][] = $type . ':' . $parentId;
			}
		DilerHelper::saveParentStudentMapRows($studentId, 'student', $type, $parentArray);
		}
	}

	protected function importUserSchoolHistoryRows($rowResults, $options)
	{
		foreach ($rowResults->validData as $i => $data)
		{
			if ($data['role'] !== 'student') continue;
			// Get school table id
			$db = Factory::getDbo();
			$query = $db->getQuery(true)->select('id')
					->from('#__diler_school')
					->where('school_id = ' . $db->quote($data['base school by school number']));
			$schoolIdForTable = $db->setQuery($query)->loadResult();
			if ($schoolIdForTable)
			{
				$query->clear()->insert('#__diler_user_school_history')
						->set('user_id = ' . (int) $data['user_id'])
						->set('school_id = ' . (int) $schoolIdForTable)
						->set('base_school = 1');
				if ($this->isDiglu && $data['date of enrollment'])
				{
					$query->set('enroll_start = ' . $db->quote($data['date of enrollment']));
				}
				$historyInsert = $db->setQuery($query)->execute();
			}
		}
	}

	protected function createStudentParentArray($rowResults, $options)
	{
		$id = $options['view'] === 'codes' ? 'id' : 'user_id';
		$result = $parents = $students = [];
		foreach ($this->familyIdCount as $familyId => $userRowArray)
		{
			$parents[$familyId] = $students[$familyId] = [];
			foreach ($userRowArray as $rowId)
			{
				if (isset($rowResults->validData[$rowId]) && $rowResults->validData[$rowId]['role'] === 'student')
				{
					$students[$familyId][] = $rowResults->validData[$rowId][$id];
				}
				elseif (isset($rowResults->validData[$rowId]) && $rowResults->validData[$rowId]['role'] === 'parent')
				{
					$parents[$familyId][] = $rowResults->validData[$rowId][$id];
				}
			}
		}
		foreach ($students as $famId => $studentIdArray)
		{
			foreach ($studentIdArray as $studentId)
			{
				$result[$studentId] = ['familyId' => $famId, 'parentArray' => $parents[$famId]];
			}
		}
		return $result;
	}

	/**
	 * Builds an array of first valid email for each family id. Used to check that this family id has at least one valid email address.
	 * Sets value of $this->familyEmailArray for use in validating family members' email.
	 *
	 * @param int $options
	 */
	protected function buildFamilyEmailArray($options)
	{
		if ($options['view'] !== 'users') return true;
		$emailColumnNumber = $this->getEmailColumnNumber();

		// Get list of family id's with no valid email
		foreach ($this->familyIdCount as $familyId => $rowArray)
		{
			$this->familyEmailArray[$familyId] = '';
			foreach ($rowArray as $rowNumber)
			{
				$data = $this->fileLinesArray[$rowNumber];
				if ($data[$emailColumnNumber] && filter_var($data[$emailColumnNumber], FILTER_VALIDATE_EMAIL) && ! DMailer::isDummyEmail($data[$emailColumnNumber]))
				{
					$this->familyEmailArray[$familyId] = $data[$emailColumnNumber];
					continue;
				}
			}
		}
	}

	protected function buildFamilyIdCount($options)
	{
		$result = [];
		$familyIdColumnNumber = 6;
		if ($options['view'] === 'users')
		{
			$familyIdColumnNumber = $this->getFamilyIdColumnNumber();
		}

		foreach ($this->fileLinesArray as $id => $columnArray)
		{
			$familyId = ($familyIdColumnNumber && isset($columnArray[$familyIdColumnNumber])) ? $columnArray[$familyIdColumnNumber] : false;
			if ($familyId && isset($result[$familyId]) && intval($familyId))
			{
				$result[$familyId][] = $id;
			}
			elseif ($familyId && intval($familyId))
			{
				$result[$familyId] = [$id];
			}
		}
		return $result;
	}

	protected function logPrepare($options)
	{
		$this->logFile = $this->getLogFileName(($options['subtask']) . '-log', $options['view']) . '.php';
		$this->rejectsFile = $this->getLogFileName('rejects', $options['view']) . '.php';
		$this->rejectsFileCsv = $this->getLogFileName('rejects', $options['view']) . '.csv';
		// Clear out old files.
		DiLerHelper::logDelete($this->logFile);
		DiLerHelper::logDelete($this->rejectsFile);
		DiLerHelper::logDelete($this->rejectsFileCsv);

		$logOptions = ['message' => '', 'status' => Log::INFO, 'type' => 'FILE', 'logFile' => $this->logFile, 'categories' => ['FILE', 'ROW', 'COLUMN']];
		$messageType = ($options['view'] === 'codes') ? Text::_('COM_DILERREG_REGISTRATION_CODES') : DText::_('DASHBOARD_HEADING_USER_MANAGEMENT');
		$logOptions['message'] = Text::sprintf('COM_DILERREG_CODES_LOG_CHECK_START', $messageType, $options['fileInfo']['name']);
		DilerHelper::logEvent($logOptions);


			$allowDupes = ($options['allowDuplicates']) == '1' ? 'JYES' : 'JNO';


		$skipFirst = $options['skipFirstLine'] == '1' ? 'JYES' : 'JNO';
		$action = $options['subtask'] === 'check' ? 'COM_DILERREG_IMPORT_ACTION_CHECK' : 'COM_DILERREG_IMPORT_ACTION_IMPORT';
		$msg = '';
		if ($options['view'] === 'codes')
		{
			$msg .= Text::_('COM_DILERREG_CODES_IMPORT_SKIP_FIRST_LINE_LABEL') . '=' . Text::_($skipFirst) . '. ';
			$msg .= Text::_('COM_DILERREG_CODES_IMPORT_ALLOW_DUPLICATES_LABEL') . '=' . Text::_($allowDupes) . '. ';
		}
		$msg .= DText::_('TASK') . '=' . Text::_($action) . '. ';
		$logOptions['message'] = $msg;
		DilerHelper::logEvent($logOptions);
	}

	protected function logResults($options, $rowResults)
	{
		$logOptions = ['message' => '', 'status' => Log::INFO, 'type' => 'FILE', 'logFile' => $this->logFile, 'categories' => ['FILE', 'ROW', 'COLUMN']];
		$logOptions['message'] = Text::_('COM_DILERREG_IMPORT_COMPLETE');
		DilerHelper::logEvent($logOptions);

		$logOptions['status'] = Log::ERROR;
		if ($rowResults->error)
		{
			$countErrors = count($rowResults->error);
			$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ERROR_HEADING', $countErrors);

			$logRejectOptions = array(
				'message' => Text::sprintf('COM_DILERREG_IMPORT_VIEW_REJECTED_ROWS', $countErrors),
				'status' => Log::ERROR,
				'type' => 'REJECT',
				'logFile' => $this->rejectsFile,
				'categories' => ['REJECT']
			);
			DilerHelper::logEvent($logRejectOptions);
			DilerHelper::logEvent($logOptions);
		}
		foreach ($rowResults->error as $i => $msgArray)
		{
			$count = ($options['view'] === 'codes' && $options['skipFirstLine'] == 1) ? $i : $i + 1 ;
			foreach ($msgArray as $msg)
			{
				$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ROW_ERRORS', $count, $msg);
				$logRejectOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ROW_ERRORS', $count, $msg);
				DilerHelper::logEvent($logOptions);
				DilerHelper::logEvent($logRejectOptions);
			}
			$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_DUMP', $count, '"' . implode('","', $this->fileLinesArray[$i]) . '"');
			DilerHelper::logEvent($logOptions);
		}
		$logOptions['status'] = Log::WARNING;
		if ($rowResults->warning)
		{
			$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_WARNING_HEADING', count($rowResults->warning));
			DilerHelper::logEvent($logOptions);

			foreach ($rowResults->warning as $i => $msgArray)
			{
				$count = ($options['view'] === 'codes' && $options['skipFirstLine'] == 1) ? $i : $i + 1 ;
				foreach ($msgArray as $msg)
				{
					$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ROW_WARNINGS', $count, $msg);
					DilerHelper::logEvent($logOptions);
				}
				$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_DUMP', $count, '"' . implode('","', $this->fileLinesArray[$i]) . '"');
				DilerHelper::logEvent($logOptions);
			}
		}
		if ($options['subtask'] === 'import' && $rowResults->insertedCount)
		{
			$successLangString = 'COM_DILERREG_REGISTRATION_CODES';
			if ($options['view'] == 'users')
				$successLangString = 'COM_DILER_USERS';

			$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_SUCCESS', Text::_($successLangString), $rowResults->insertedCount);
			$logOptions['status'] = Log::INFO;
			DilerHelper::logEvent($logOptions);
		}
		elseif ($options['subtask'] === 'import')
		{
			$logOptions['message'] = Text::_('COM_DILERREG_IMPORT_ERROR');
			$logOptions['status'] = Log::ERROR;
			DilerHelper::logEvent($logOptions);
		}
	}

	/**
	 * Check base school serial number.
	 *
	 * @param string $rawValue
	 * @param stdClass $result
	 * @return null
	 */
	protected function checkBaseSchool($rawValue, $result)
	{
		if ($result->value['role'] !== 'student')
		{
			$result->value['base school by school number'] = '';
			return;
		}
		if (! $rawValue)
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_REQUIRED_FIELD', 'base school by school number');
			$result->value[$columnName] = false;
			return;
		}
		// Base school must be set up and must be base school
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('school_id, base_school')
				->from('#__diler_school')
				->where('school_id = ' . $db->quote($rawValue));
		$row = $db->setQuery($query)->loadObject();
		if (is_object($row) && $row->school_id && $row->base_school)
		{
			$result->value['base school by school number'] = $rawValue;
		}
		elseif (! is_object($row))
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('SCHOOL'), $rawValue);
		}
		else
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_NOT_BASE_SCHOOL', $rawValue);
		}
	}

	protected function checkCitizenship($rawValue, $result)
	{

		if (strlen($rawValue) === 2)
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true);
			$query->select('c.*')
					->from('#__diler_country AS c')
					->where('c.iso2 = ' . $db->quote($rawValue));
			$row = $db->setQuery($query)->loadObject();
		}
		if (is_object($row) && $row->id)
		{
			$result->value['citizenship_iso2'] = $row->iso2;
		}
		else
		{
            if($result->value['role'] == DConst::USER_ROLE_STUDENT || $result->value['role'] == DConst::USER_ROLE_PARENT)
            {
                $result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('CITIZENSHIP'), $rawValue);
            }
            else
            {
                $result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('CITIZENSHIP'), $rawValue);
                $result->value['citizenship_iso2'] = '';
            }
		}
	}

	protected function checkCodeFileRows($options)
	{
		$count = count($this->fileLinesArray);
		$start = ($options['skipFirstLine'] == '1') ? 1 : 0;
		$errorLog = [];
		$successLog = [];
		$warningLog = [];
		$warningRows = [];
		$validData = [];
		$columnCount = 11;
		for ($i = $start; $i < $count; $i++)
		{
			$rowCheck = $this->checkCodeRow($options, $this->fileLinesArray[$i], $i, $columnCount);
			// Status: 1=success, 0=error, -1=warning
			if ($rowCheck->status === 0)
			{
				$errorLog[$i] = $rowCheck->error;
			}
			elseif ($rowCheck->status === 1)
			{
				$successLog[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
			elseif ($rowCheck->status === -1)
			{
				$warningLog[$i] = $rowCheck->warning;
				$warningRows[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
		}
		$result = (object) ['error' => $errorLog, 'successRows' => $successLog, 'warning' => $warningLog, 'warningRows' => $warningRows, 'validData' => $validData];
		return $result;
	}

	protected function checkCodeRow($options, $columnArray, $i, $columnCount)
	{
		// Check Count
		if (count($columnArray) !== $columnCount)
		{
			$msg = Text::sprintf('COM_DILERREG_IMPORT_ERROR_BAD_COLUMN_COUNT', $i, $columnCount, count($columnArray));
			return (object) ['status' => 0, 'error' => [$msg]];
		}
		$result = (object) ['error' => [], 'warning' => [], 'value' => []];
		$this->checkRole($columnArray[0], $result);
		$this->checkDilerRoleGroup($columnArray[1], $result);
		$this->checkFirstLastName($options, $columnArray, $result);
		$this->checkLg($columnArray[2], $result, $options);
		$this->checkFamilyId($columnArray[6], $result, 'code');
		$this->checkAndSetDob($columnArray[7], $result);
		$this->checkAndSetSchoolEnrollment($columnArray[8], $result);
		$this->checkAndSetGradeLevel($columnArray[9], $result, 'student_phase_actual');
		$this->checkAndSetGradeLevel($columnArray[10], $result, 'student_phase_target');

		$result->status = 1;
		if ($result->error)
		{
			$result->status = 0;
		} elseif ($result->warning)
		{
			$result->status = -1;
		}
		// Check each column
		return $result;
	}

	protected function checkFamilyId($rawValue, $result, $type = 'user')
	{
		if ((! $rawValue) || ! in_array($result->value['role'], ['student', 'parent']))
		{
			$result->value['family_id'] = '';
		}
		elseif ($rawValue && ! intval($rawValue))
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_FAMILY_ID_INVALID', $rawValue);
			$result->value['family_id'] = false;
		}
		elseif ($rawValue && ! $this->familyEmailArray[$rawValue] && $type === 'user')
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_FAMILY_ID_INVALID_EMAIL', $rawValue);
			$result->value['family_id'] = false;
		}
		elseif (is_countable($this->familyIdCount[$rawValue]) && count($this->familyIdCount[$rawValue]) <= 1)
		{
			$result->value['family_id'] = '';
		}
		else
		{
			$result->value['family_id'] = intval($rawValue);
		}
	}

	private function checkAndSetDob($rawValue, $result)
	{
		$result->value['dob'] = "";
		if ($result->value['role'] == DConst::USER_ROLE_STUDENT && $rawValue)
		{
			try {
				$dobDate = Factory::getDate($rawValue)->toSql();
				$result->value['dob'] = $this->convertExcelDate($dobDate);
			}
			catch (\Exception $exception)
			{
				$result->value['dob'] = false;
				$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_DOB_FIELD_INVALID_FORMAT', $rawValue);
			}
		}
	}

	private function checkAndSetSchoolEnrollment($rawValue, $result)
	{
		$result->value['first_school_enrollment_date'] = "";
		if ($result->value['role'] == DConst::USER_ROLE_STUDENT && $rawValue)
		{
			try {
				$enrolmentSchoolDate = Factory::getDate($rawValue)->toSql();
				$result->value['first_school_enrollment_date'] = $this->convertExcelDate($enrolmentSchoolDate);
			}
			catch (\Exception $exception)
			{
				$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_SCHOOL_ENROLLMENT_DATE_FIELD_INVALID_FORMAT', $rawValue);
				$result->value['first_school_enrollment_date'] = false;
			}
		}
	}

	private function checkAndSetGradeLevel($rawValue, $result, $studentPhase)
	{
		if ($result->value['role'] == DConst::USER_ROLE_STUDENT && $rawValue)
		{
			$phaseId = $this->getGradeLevelIdByName($rawValue);
			if (!$phaseId)
			{
				$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_STUDENT_ACTUAL_PHASE', $rawValue);
				$result->value[$studentPhase] = false;
			}
			if ($phaseId)
				$result->value[$studentPhase] = $phaseId;
		}
	}

	private function getGradeLevelIdByName($rawValue)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_phase');
		$query->where('value = ' . $db->quote($rawValue));
		return $db->setQuery($query)->loadResult();
	}

	protected function checkFirstLastName($options, $columnArray, $result)
	{
		$result->value['first_name'] = $columnArray[3];
		$result->value['nickname'] = $columnArray[4];
		$result->value['last_name'] = $columnArray[5];
		if ($columnArray[3] <= '')
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_REQUIRED_MISSING', Text::_('COM_DILERREG_FIRST_NAME_LABEL'));
			$result->value['first_name'] = false;
		}
		if ($columnArray[5] <= '')
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_REQUIRED_MISSING', Text::_('COM_DILERREG_LAST_NAME_LABEL'));
			$result->value['last_name'] = false;
		}
		if (! $result->value['dilerrolegroup'])
		{
			$result->error[] = Text::_('COM_DILERREG_IMPORT_ERROR_ROLE_NAME');
			$result->value['first_name'] = false;
			$result->value['last_name'] = false;
		}
		if ($columnArray[3] <= '' || $columnArray[5] <= '' || ! $result->value['dilerrolegroup']) return;
		// At this point we have two names. Check for duplicates (only if we have a role!)
		$isDuplicate = in_array($columnArray[3] . '_' . $columnArray[5], $this->fullNameArray[$result->value['role']]);
		if ($isDuplicate && $options['allowDuplicates'] == '2')
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_DUPLICATE_NAME', $this->roleNames[$result->value['role']], $columnArray[3] . ' ' . $columnArray[5]);
			$result->value['first_name'] = false;
			$result->value['last_name'] = false;
		}
		elseif ($isDuplicate)
		{
			$result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_DUPLICATE_NAME', $this->roleNames[$result->value['role']], $columnArray[3] . ' ' . $columnArray[5]);
		}
	}

    // LG is not allowed for parents, is optional for teacher and required for students.
	protected function checkLg($rawValue, $result, $options)
	{
		if ($result->value['role'] === DConst::USER_ROLE_PARENT || $result->value['role'] === DConst::USER_ROLE_TEACHER)
		{
			$result->value['lg'] = '';
			return;
		}

		if (! $rawValue && $result->value['role'] == 'teacher')
		{
			$result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_MISSING_VALUE', DText::_('CONFIG_LEARNING_GROUPS_LABEL'));
			$result->value['lg'] = '';
			return;
		}

		if (! $rawValue && $result->value['role'] == 'student')
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_MISSING_VALUE', DText::_('CONFIG_LEARNING_GROUPS_LABEL'));
			$result->value['lg'] = '';
			return;
		}
		// At this point we are looking up the group by name for teachers and non-Diglu students
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('jug.id')
				->from('#__usergroups AS jug')
				->where('jug.title = ' . $db->quote($rawValue))
				->where('jug.parent_id = ' . (int) $this->roleGroupIds['lgParentId']);
		$id = $db->setQuery($query)->loadResult();
		if ($id)
		{
			$result->value['lg'] = $id;
		}
		// for teacher it's optional
		elseif ($result->value['role'] == 'teacher')
		{
			$result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('CONFIG_LEARNING_GROUPS_LABEL'), $rawValue);
			$result->value['lg'] = '';
		}
		// for student it's required
		elseif ($result->value['role'] == 'student')
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('CONFIG_LEARNING_GROUPS_LABEL'), $rawValue);
			$result->value['lg'] = '';
		}
	}

    /**
     * Checks if role column 0 is valid. Updates $result object.
     * @param $rawValue
     * @param stdClass $result (updated with results of check)
     */
	protected function checkRole($rawValue, $result)
	{
		if (! in_array($rawValue, ['1','2','3']))
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_ROLE', $rawValue);
			$result->value['role'] = false;
		}
        if (! in_array($rawValue, ['1']) && DilerHelperUser::isDiglu())
            $result->error[] = Text::_('COM_DILERREG_IMPORT_ERROR_ONLY_TEACHER_CAN_BE_IMPORTED_VIA_REGISTRATION_CODES');

		else
		{
			$roles = [1 => 'teacher', 2 => 'student', 3 => 'parent'];
			$result->value['role'] = $roles[$rawValue];
		}
	}

    /**
     * Checks if dilerrolegroup column 1 is valid. Updates $result object.
     * @param $rawValue
     * @param stdClass $result
     */
	protected function checkDilerRoleGroup($rawValue, $result)
	{
		// Cannot be valid if role is invalid
		if (! $result->value['role'])
		{
			$result->error[] = Text::_('COM_DILERREG_IMPORT_ERROR_ROLE_GROUP');
			$result->value['dilerrolegroup'] = false;
			return;
		}

		$idArray = $this->roleGroupIds[$result->value['role']];

		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')->from('#__usergroups')->where('title = ' . $db->quote($rawValue))
				->where('id IN(' . implode(',', $idArray) . ')');
		$id = $db->setQuery($query)->loadResult();
		if ($id)
		{
			$result->value['dilerrolegroup'] = $id;
		}
		else
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('GROUP'), $rawValue);
			$result->value['dilerrolegroup'] = false;
		}
	}

	protected function updateOptionalUserColumns($data)
	{
		$columnsToUpdate = 0;
		$result = true;
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__dilerreg_users');
		$query->where('user_id = ' . (int) $data['user_id']);
		foreach ($this->optionalColumnArray as $columnName)
		{
			if ($columnName === 'country state')
			{
				if ($data['state_iso']) $query->set($db->quoteName('state_iso') . '=' . $db->quote($data['state_iso']));
				if ($data['country_iso2']) $query->set($db->quoteName('country_iso2') . '=' . $db->quote($data['country_iso2']));
			}
			elseif (! empty($data[$columnName]) && ! in_array($columnName, $this->ignoreColumns))
			{
				$query->set($db->quoteName($this->optionalColumns[$columnName]) . '=' . $db->quote($data[$columnName]));
				$columnsToUpdate++;
			}
		}
		if ($columnsToUpdate)
		{
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}

}
