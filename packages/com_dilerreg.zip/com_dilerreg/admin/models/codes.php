<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\MVC\Model\ListModel;

/**
 * Methods supporting a list of registration codes.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregModelCodes extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  An optional associative array of configuration settings.
	 * @see     ListModel
	 * @since   1.6
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'first_name', 'a.first_name',
				'nickname', 'a.nickname',
				'last_name', 'a.last_name',
				'role', 'a.role',
				'lg', 'learning_group',
				'a.fam_id',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// Load the filter state.
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$state = $this->getUserStateFromRequest($this->context . '.filter.state', 'filter_state', '', 'string');
		$this->setState('filter.state', $state);

		$learningGroup = $this->getUserStateFromRequest($this->context . '.filter.learning_group', 'filter_learning_group');
		$this->setState('filter.learning_group', $learningGroup);

		$role = $this->getUserStateFromRequest($this->context . '.filter.role', 'filter_role');
		$this->setState('filter.role', $role);

		// Load the parameters.
		$params = ComponentHelper::getParams('com_dilerreg');
		$this->setState('params', $params);

		// List state information.
		parent::populateState('a.first_name', 'asc');
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string    A prefix for the store id.
	 *
	 * @return  string    A store id.
	 * @since   1.6
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 * @since   1.6
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$lgParentId = ComponentHelper::getParams('com_diler')->get('learning_group_parent_id', 0);
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select('a.*');
		$query->from($db->quoteName('#__dilerreg_registration_codes') . ' AS a');
		$query->select('g1.title AS student_learning_group');

		$query->leftJoin('#__usergroups AS g1 ON a.lg = g1.id');
		$query->leftJoin('#__diler_group AS dg ON dg.joomla_group_id = g1.id');
		$subquery = $db->getQuery(true)
			->select('m.parent_id AS parent_id, GROUP_CONCAT(g2.id) AS parent_group_ids, GROUP_CONCAT(DISTINCT dg2.name SEPARATOR ", ") AS parent_group_titles, GROUP_CONCAT(m.student_id) as studentIds')
			->from('#__dilerreg_parent_student_map AS m')
			->leftJoin('#__dilerreg_registration_codes AS a2 ON m.student_id = a2.id')
			->innerJoin('#__usergroups AS g2 ON a2.lg = g2.id')
			->innerJoin('#__diler_group AS dg2 ON dg2.joomla_group_id = g2.id')
			->where('m.parent_id_type = 0 AND m.student_id_type = 0')
			->group('m.parent_id');
		$subquery2 = $db->getQuery(true)
			->select('m.parent_id AS parent_id, GROUP_CONCAT(g2.id) AS parent_group_ids, GROUP_CONCAT(DISTINCT dg3.name SEPARATOR ", ") AS parent_group_titles')
			->from('#__dilerreg_parent_student_map AS m')
			->leftJoin('#__dilerreg_users AS a2 ON m.student_id = a2.user_id')
			->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = a2.user_id')
			->innerJoin('#__usergroups AS g2 ON uum.group_id = g2.id AND g2.parent_id=' . (int) $lgParentId)
			->innerJoin('#__diler_group AS dg3 ON dg3.joomla_group_id = g2.id')
			->where('m.parent_id_type = 0 AND m.student_id_type = 1')
			->group('m.parent_id');
		$query->leftJoin('(' . (string) $subquery . ') AS pg ON a.id = pg.parent_id AND a.role = "parent"' );
		$query->leftJoin('(' . (string) $subquery2 . ') AS pg_user ON a.id = pg_user.parent_id AND a.role = "parent"' );
		$query->select('(CASE WHEN a.role = "parent" AND pg.parent_id IS NOT NULL THEN pg.parent_group_titles WHEN a.role = "parent" AND pg.parent_id IS NULL THEN pg_user.parent_group_titles '
				. ' ELSE dg.name END) AS ' . $db->quoteName('learning_groups') . ', pg.studentIds');
		// Get related reg-code and user names for parents and students
		$famQuery1 = $db->getQuery(true)
				->select('map.parent_id, GROUP_CONCAT(CONCAT(rc.first_name, " ", rc.last_name) SEPARATOR ", ") AS family_names, GROUP_CONCAT(DISTINCT rc.id ORDER BY rc.id) AS family_ids')
				->from('#__dilerreg_parent_student_map AS map')
				->innerJoin('#__dilerreg_registration_codes AS rc ON map.student_id = rc.id AND map.student_id_type = 0')
				->where('map.parent_id_type=0')
				->group('map.parent_id');
		$query->leftJoin('(' . (string) $famQuery1 . ') AS fq1 ON a.id = fq1.parent_id');
		$query->select('fq1.family_names AS student_code_names, fq1.family_ids AS student_code_ids');

		$famQuery2 = $db->getQuery(true)
				->select('map.student_id, GROUP_CONCAT(CONCAT(rc.first_name, " ", rc.last_name) SEPARATOR ", ") AS family_names, GROUP_CONCAT(DISTINCT rc.id ORDER BY rc.id) AS family_ids')
				->from('#__dilerreg_parent_student_map AS map')
				->innerJoin('#__dilerreg_registration_codes AS rc ON map.parent_id = rc.id AND map.parent_id_type = 0')
				->where('map.student_id_type=0')
				->group('map.student_id');
		$query->leftJoin('(' . (string) $famQuery2 . ') AS fq2 ON a.id = fq2.student_id');
		$query->select('fq2.family_names AS parent_code_names, fq2.family_ids AS parent_code_ids');

		$famQuery3 = $db->getQuery(true)
				->select('map.parent_id, GROUP_CONCAT(CONCAT(du.forename, " ", du.surname) SEPARATOR ", ") AS family_names, GROUP_CONCAT(DISTINCT du.user_id ORDER BY du.user_id) AS family_ids')
				->from('#__dilerreg_parent_student_map AS map')
				->innerJoin('#__dilerreg_users AS du ON map.student_id = du.user_id AND map.student_id_type = 1')
				->where('map.parent_id_type = 0')
				->group('map.parent_id');
		$query->leftJoin('(' . (string) $famQuery3 . ') AS fq3 ON a.id = fq3.parent_id');
		$query->select('fq3.family_names AS student_user_names, fq3.family_ids AS student_user_ids');

		$famQuery4 = $db->getQuery(true)
				->select('map.student_id, GROUP_CONCAT(CONCAT(du.forename, " ", du.surname) SEPARATOR ", ") AS family_names, GROUP_CONCAT(DISTINCT du.user_id ORDER BY du.user_id) AS family_ids')
				->from('#__dilerreg_parent_student_map AS map')
				->innerJoin('#__dilerreg_users AS du ON map.parent_id = du.user_id AND map.parent_id_type = 1')
				->where('map.student_id_type=0')
				->group('map.student_id');
		$query->leftJoin('(' . (string) $famQuery4 . ') AS fq4 ON a.id = fq4.student_id');
		$query->select('fq4.family_names AS parent_user_names, fq4.family_ids AS parent_user_ids');
		// Filter by learning group
		$learningGroup = $this->getState('filter.learning_group');
		if ($learningGroup)
		{
			$query->where('(g1.id = ' . $learningGroup . ' OR (FIND_IN_SET(' . $learningGroup . ' , pg.parent_group_ids) > 0) OR (FIND_IN_SET(' . $learningGroup . ' , pg_user.parent_group_ids) > 0))');
		}

		$role = $this->getState('filter.role');
		if ($role)
		{
			$query->where('a.role = ' . $db->quote($role));
		}

		// Filter the items over the search string if set.
		$search = $this->getState('filter.search');
		if (!empty($search))
		{

				$search = $db->quote('%' . $db->escape($search, true) . '%');
				$query->where(
					'(' . 'code LIKE ' . $search .
						' OR ' . 'a.first_name LIKE ' . $search .
						' OR ' . 'a.last_name LIKE ' . $search .
						' OR ' . 'a.role LIKE ' . $search . ')'
				);

		}

		// Add the list ordering clause.
		$query->order($db->escape($this->getState('list.ordering', 'a.first_name')) . ' ' . $db->escape($this->getState('list.direction', 'ASC')));

		return $query;
	}

	public function getReportItems(array $ids)
	{
		$this->populateState();
		$query = $this->getListQuery();
		$query->where('a.id IN(' . implode(',', $ids) . ')');
		$this->_db->setQuery($query);
		$items = $this->_db->loadObjectList();
		$items = $this->getFamilyNames($items);
		return $items;
	}

	public function getItems()
	{
		$items = parent::getItems();
		$items = $this->getFamilyNames($items);
		return $items;
	}

	/**
	 * Adds family_names column to rows, based on whether row is parent or student.
	 *
	 * @param array $items
	 * @return array
	 */
	public function getFamilyNames($items)
	{
		foreach ($items as $item)
		{
			$item->registered_family_names = $item->unregistered_family_names = $item->family_names = '';
			if ($item->role === 'teacher') continue;
			if ($item->role === 'parent')
			{
				$delim = ($item->student_code_names && $item->student_user_names) ? ', ' : '';
				$item->family_names = $item->student_code_names . $delim . $item->student_user_names;
				$item->registered_family_names = $item->student_user_names;
				$item->unregistered_family_names = $item->student_code_names;
			}
			elseif ($item->role === 'student')
			{
				$delim = ($item->parent_code_names && $item->parent_user_names) ? ', ' : '';
				$item->family_names = $item->parent_code_names . $delim . $item->parent_user_names;
				$item->registered_family_names = $item->parent_user_names;
				$item->unregistered_family_names = $item->parent_code_names;
			}
		}
		return $items;
	}

	/**
	 *
	 * @param array $items array of stdClass objects from query
	 * @return array Assoc array: [parent key (student_code_ids . student_user_ids] => [parents => array or stdClass for parents, 'students' => array of stdClass for students]
	 */
	public function groupByFamily($items)
	{
		$parentArray = $parentSortArray = $unlistedStudentArray = $teacherArray = [];
		foreach($items as $id => $item)
		{
			if ($item->role !== 'student')
			{
				$groupKey = $item->student_code_ids ? $item->student_code_ids : $item->last_name . $item->first_name . $item->id;
				if (empty($parentSortArray[$groupKey]))
				{
					$parentSortArray[$groupKey] = $item->last_name . $item->first_name . $item->id;
					$parentArray[$groupKey] = ['parents' => [], 'students' => []];
				}
				$parentArray[$groupKey]['parents'][] = $item;
			}
			else
			{
				$unlistedStudentArray[$item->id] = $item;
			}
		}

		$parentArray[0] = ['parents' => [], 'students' => []];
		$parentSortArray[0] = '';
		$studentCheckArray = array_keys($unlistedStudentArray);
		foreach ($parentArray as $key => $valueArray)
		{
			$studentCodes = $key ? explode(',', $key) : [];
			foreach ($studentCodes as $studentCode)
			{
				// Skip if this student isn't in the list
				if (! in_array($studentCode, $studentCheckArray)) continue;

				$studentKey = $unlistedStudentArray[$studentCode]->last_name . $unlistedStudentArray[$studentCode]->first_name . $unlistedStudentArray[$studentCode]->id;
				$parentArray[$key]['students'][$studentKey] = $unlistedStudentArray[$studentCode];
				unset($unlistedStudentArray[$studentCode]);
				$studentCheckArray = array_keys($unlistedStudentArray);
			}
		}

		// Add any missing students to no-parent
		foreach ($unlistedStudentArray as $id => $studentRow)
		{
			$key = $studentRow->last_name . $studentRow->first_name . $studentRow->id;
			$parentArray[0]['students'][$key] = $studentRow;
		}

		return $parentArray;
	}
}
