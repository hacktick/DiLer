<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;
use Joomla\CMS\MVC\Model\AdminModel;

JLoader::register('DilerHelper', JPATH_ADMINISTRATOR . '/components/com_diler/helpers/diler.php');

/**
 * Dilerreg Code model.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregModelCode extends AdminModel
{
	/**
	 * @var        string    The prefix to use with controller messages.
	 * @since   1.6
	 */
	protected $text_prefix = 'COM_DILERREG';

	/**
	 * Assoc array to hold group id's for parent, student, teacher
	 * @var array: 'parent' => parent id array, 'student' => student id array, 'teacher' => teacher group id array
	 */
	public $roleGroupIds = [];

	public $fullNameArray = [];

	public $roleNames = [];

	public $familyIdCount = [];

	public $logFile = '';

	public $rejectsFile = '';

	public $state = null;

	/**
	 *
	 */

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param   object    $record    A record object.
	 *
	 * @return  boolean  True if allowed to delete the record. Defaults to the permission set in the component.
	 * @since   1.6
	 */
	protected function canDelete($record)
	{
		$user = Factory::getUser();
		return $user->authorise('core.admin', 'com_dilerreg');
	}

	/**
	 * Method to test whether a record can have its state edited.
	 *
	 * @param   object    $record    A record object.
	 *
	 * @return  boolean  True if allowed to change the state of the record. Defaults to the permission set in the component.
	 * @since   1.6
	 */
	protected function canEditState($record)
	{
		$user = Factory::getUser();

		// Check the component since there are no categories or other assets.
		return $user->authorise('core.admin', 'com_dilerreg');
	}

	/**
	 * Override parent method. Add code to get map table information for form.
	 *
	 * {@inheritDoc}
	 * @see AdminModel::getItem()
	 */
	public function getItem($pk = null)
	{
		$item = parent::getItem($pk);
		$item->students = array();
		$item->parents = array();

		$role = DiLerHelper::getRole('0', $item->id);
		if ($role == 'parent')
		{
			$item->students = DiLerHelper::getStudentsForParent($item->id, '0');
		}

		if ($role == 'student')
		{
			$item->parents = DiLerHelper::getParentsForStudent($item->id, '0');
		}

		return $item;
	}

	public function getRoleList()
	{
		$dilerOptions = ComponentHelper::getParams('com_diler');
		$teacherGroups = $dilerOptions->get('teacher_group_ids');
		$parentGroups = $dilerOptions->get('parent_group_ids');
		$studentGroups = $dilerOptions->get('student_group_ids');
		$result = ['0' => ''];
		foreach ($teacherGroups as $teacherGroup)
		{
			$result[$teacherGroup] = 'teacher';
		}
		foreach ($parentGroups as $parentGroup)
		{
			$result[$parentGroup] = 'parent';
		}
		foreach ($studentGroups as $studentGroup)
		{
			$result[$studentGroup] = 'student';
		}
		return $result;
	}

	/**
	 * Get count of published sections.
	 *
	 * @return array of section id's
	 */
	public function getSectionIds()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')
				->from('#__diler_section')
				->where('published = 1');
		return $db->setQuery($query)->loadColumn();
	}

	public function getTable($type = 'Code', $prefix = 'DilerregTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Override parent method to delete map rows
	 * @param array $pks
	 */
	public function delete(&$pks)
	{
		if (is_array($pks) && count($pks))
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true);
			$query->delete('#__dilerreg_registration_code_user_map')
					->where('code_id IN(' . implode(',', $pks) .')');
			$db->setQuery($query)->execute();
		}
		return parent::delete($pks);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   array      $data        Data for the form.
	 * @param   boolean    $loadData    True if the form is to load its own data (default case), false if not.
	 * @return  Form    A Form object on success, false on failure
	 * @since   1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_dilerreg.code', 'code', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}

		return $form;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return  mixed  The data for the form.
     * @throws Exception
     * @since   1.6
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_dilerreg.edit.code.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		$this->preprocessData('com_dilerreg.code', $data);

		return $data;
	}

	/**
	 * Override parent validate() method
	 *
	 * @see JModelForm::validate()
	 */
	public function validate($form, $data, $group = null)
	{
		if ($data = parent::validate($form, $data, $group))
		{
			$roleList = $this->getRoleList();
			if ($roleList[$data['dilerrolegroup']] === 'student' && ! $data['lg'])
			{
                throw new \Exception(Text::_('COM_DILERREG_INVALID_LEARNING_GROUP'));
			}
		}
		return $data;

	}

	/**
	 * Implement parent class prepare Table
	 *
	 * @see AdminModel::prepareTable()
	 */
	public function prepareTable($table)
	{
		$input = Factory::getApplication()->input;

		// Don't allow learning groups for non-students
		if ($table->role != 'student')
		{
			$table->lg = 0;
		}
	}

	/**
	 * Override parent data method.
	 *
	 * {@inheritDoc}
	 * @see AdminModel::save()
	 */
	public function save($data)
	{
        if($data['first_school_enrollment_date'] == '')
            unset($data['first_school_enrollment_date']);

        if($data['dob'] == '')
            unset($data['dob']);

		// Check role
		$roleList = $this->getRoleList();
		if (isset($roleList[$data['dilerrolegroup']]))
		{
			$data['role'] = $roleList[$data['dilerrolegroup']];
		}
		else
		{
			$data['role'] = '';
		}
        if($data['role']!='student') {
            unset($data['first_school_enrollment_date']);
            unset($data['dob']);
        }
		if (parent::save($data))
		{
			// Save child rows to map tables
			// Get the $id in case it is a newly inserted user
			$stateIdName = "code.id";
			$id = (isset($data['id']) && $data['id']) ? $data['id'] : $this->state->$stateIdName;

			// Update map table rows for the user, based on role
			if ($data['role'] =='parent' && $data['students'])
			{
				DilerHelper::saveParentStudentMapRows($id, 'parent', '0', $data['students']);
			}
			elseif ($data['role'] =='student' && $data['parents'])
			{
				DilerHelper::saveParentStudentMapRows($id, 'student', '0', $data['parents']);
			}
		}

		return true;
	}

}
