<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\DConst;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\MVC\Model\ListModel;

/**
 * Methods supporting a list of registration codes.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class DilerregModelUsers extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  An optional associative array of configuration settings.
	 * @see     ListModel
	 * @since   1.6
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'user_id', 'a.user_id',
				'forename', 'a.forename',
				'surname', 'a.surname',
				'nickname', 'a.nickname',
				'role', 'a.role',
				'learning_group', 'a.learning_group',
				'total_size', 'cloud.total_size',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// Load the filter state.
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$state = $this->getUserStateFromRequest($this->context . '.filter.state', 'filter_state', '', 'string');
		$this->setState('filter.state', $state);

		$learningGroup = $this->getUserStateFromRequest($this->context . '.filter.learning_group', 'filter_learning_group');
		$this->setState('filter.learning_group', $learningGroup);

		$role = $this->getUserStateFromRequest($this->context . '.filter.role', 'filter_role');
		if ($role) {
			$role = array_filter($role);
		}
		$this->setState('filter.role', $role);

		// Load the parameters.
		$params = ComponentHelper::getParams('com_dilerreg');
		$this->setState('params', $params);

		// List state information.
		parent::populateState('a.surname', 'asc');
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string    A prefix for the store id.
	 *
	 * @return  string    A store id.
	 * @since   1.6
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		return parent::getStoreId($id);
	}

	/**
	 * Gets a subquery to get the total size of private cloud files by user
	 * @return bool|\Joomla\Database\DatabaseQuery \Joomla\Database\DatabaseQuery object if successful, false if error
	 */
	protected function getCloudSubquery()
	{
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$cloudCats = MVCHelper::factory()->createModel('Cloud', 'Site')->getMediaCategories();
		$privateCats = [];
		foreach ($cloudCats as $cat)
		{
			if ($cat->mediaType == 3) $privateCats[] = $cat->id;
		}
		if (! $privateCats) return false;
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('owned_by, SUM(size) AS total_size')
				->from('#__diler_cloud')
				->group('owned_by')
				->where('catid IN(' . implode(',', $privateCats) . ')');
		return $query;
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 * @since   1.6
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$learningGroupParent = (int) ComponentHelper::getParams('com_diler')->get('learning_group_parent_id');

        $isStudentBlockedSubquery = $db->getQuery(true);
        $isStudentBlockedSubquery->select('bu.user_id');
        $isStudentBlockedSubquery->from('#__diler_user_school_history as ush');
        $isStudentBlockedSubquery->join('INNER', '#__diler_diglu_blocked_users as bu ON bu.user_id = ju.id AND a.role = ' . $db->quote(DConst::USER_ROLE_STUDENT));
        $isStudentBlockedSubquery->join('INNER', '#__diler_school as ds ON ds.id = ush.school_id AND ush.base_school = 1');
        $isStudentBlockedSubquery->join('INNER', '#__diler_school_ministry as sm ON sm.state_iso = ds.state_iso AND sm.is_avv_consent_accepted = 0');
        $isStudentBlockedSubquery->where('ush.user_id = ju.id');

		// Select the required fields from the table.
        $isDiglu = DilerHelperUser::isDiglu();
		$isDiglu ? $query->select('a.*, (' . $isStudentBlockedSubquery . ') as is_student_blocked') : $query->select('a.*');
		$query->from($db->quoteName('#__dilerreg_users') . ' AS a');
		$query->innerJoin('#__users AS ju ON ju.id = a.user_id');

		$lgSubquery = $db->getQuery(true);
		$lgSubquery->select('user_id, GROUP_CONCAT(DISTINCT m.group_id) AS group_ids, GROUP_CONCAT(DISTINCT dg.name ORDER BY dg.name SEPARATOR ", ") AS group_titles')
				->from('#__user_usergroup_map AS m')
				->innerJoin('#__usergroups AS jug ON m.group_id = jug.id AND jug.parent_id = ' . (int) $learningGroupParent)
				->leftJoin('#__diler_group AS dg ON dg.joomla_group_id = jug.id')
			->group('m.user_id');
		$query->leftJoin('(' . (string) $lgSubquery . ') AS lgs ON lgs.user_id = a.user_id');
		$query->select('lgs.group_ids, lgs.group_titles');

		$subquery = $db->getQuery(true)
			->select('m1.parent_id AS parent_id, GROUP_CONCAT(DISTINCT g2.id) AS parent_group_ids, GROUP_CONCAT(DISTINCT dg2.name ORDER BY dg2.name SEPARATOR ", ") AS parent_group_titles')
			->from('#__dilerreg_parent_student_map AS m1')
			->innerJoin('#__users AS a2 ON m1.student_id = a2.id')
			->leftJoin('#__user_usergroup_map AS m2 ON m2.user_id = m1.student_id')
			->innerJoin('#__usergroups AS g2 ON m2.group_id = g2.id AND g2.parent_id = ' . (int) $learningGroupParent)
			->innerJoin('#__diler_group AS dg2 ON dg2.joomla_group_id = g2.id')
			->where('m1.parent_id_type = 1 AND m1.student_id_type = 1')
			->group('m1.parent_id');
		$query->leftJoin('(' . (string) $subquery . ') AS pg ON a.user_id = pg.parent_id AND a.role = "parent"' );
		$query->select('(CASE WHEN a.role = "parent" THEN pg.parent_group_titles ELSE lgs.group_titles END) AS learning_group');

		$cloudSubquery = $this->getCloudSubquery();
		if ($cloudSubquery)
		{
			$query->leftJoin('(' . (string) $cloudSubquery . ') AS cloud ON cloud.owned_by = a.user_id');
			$query->select('cloud.total_size AS total_size');
		}

		$query->group('a.user_id');
		
		$query->where('a.role IN ("' . implode('","', DConst::USER_ROLES) .'")');
		
		$role = $this->getState('filter.role');
		if ($role) {
			$role = array_filter($role);
		}
		if ($role){
			$query->where('a.role IN ("'.implode('","',$role).'")');
		}

		// Filter the items over the search string if set.
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.user_id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->quote('%' . $db->escape($search, true) . '%');
				$query->where(
					'(' . $db->quoteName('a.surname') . ' LIKE ' . $search .
						' OR ' . $db->quoteName('a.forename') . ' LIKE ' . $search . ')'
				);
			}
		}

		// Filter by learning group
		$learningGroup = $this->getState('filter.learning_group');
		if ($learningGroup)
		{
			$query->where('(FIND_IN_SET(' . $learningGroup . ', lgs.group_ids) OR (FIND_IN_SET(' . $learningGroup . ' , pg.parent_group_ids) > 0))');
		}

		// Add the list ordering clause.
		$query->order($db->escape($this->getState('list.ordering', 'a.surname')) . ' ' . $db->escape($this->getState('list.direction', 'ASC')));

		$db->setQuery('SET sql_big_selects=1')->execute();
		 
		return $query;
	}

}