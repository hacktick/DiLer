<?php
/**
 * @package     Diler.Administrator
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;

FormHelper::loadFieldClass('groupedlist');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Diler.Administrator
 * @subpackage  com_diler
 * @since       5.3.9
 */
class JFormFieldDilerrolegroup extends JFormFieldGroupedList
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since   1.6
	 */
	protected $type = 'Dilerrolegroup';

	protected function checkRole($groupList)
	{
		$result = $groupList;
		if (! is_array($groupList) || ! $groupList)
		{
			$result = [0];
		}
		return $result;
	}

	/**
	 * Method to get the field options.
	 *
	 * @return  array  The field option objects.
	 * @since   1.6
	 */
	protected function getGroups()
	{
		$dilerOptions = ComponentHelper::getParams('com_diler');
		$teacherGroupsRaw = $dilerOptions->get('teacher_group_ids');
		$parentGroupsRaw = $dilerOptions->get('parent_group_ids');
		$studentGroupsRaw = $dilerOptions->get('student_group_ids');
		$teacherGroups = $this->checkRole($teacherGroupsRaw);
		$parentGroups = $this->checkRole($parentGroupsRaw);
		$studentGroups = $this->checkRole($studentGroupsRaw);
		$allGroups = array_merge($teacherGroups, $parentGroups, $studentGroups);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('title AS title, id AS id')
			->select('CASE WHEN id IN(' . implode(',', $teacherGroups) . ') THEN ' . $db->quote(DText::_('TEACHERS')) .
					'WHEN id IN(' . implode(',', $parentGroups) . ') THEN ' . $db->quote(DText::_('PARENTS')) .
					'WHEN id IN(' . implode(',', $studentGroups) . ') THEN ' . $db->quote(DText::_('STUDENTS')) .
					' ELSE "None" END AS role')
			->from('#__usergroups')
			->where('id IN(' . implode(',', $allGroups) . ')')
			->order('title');
		$rows = $db->setQuery($query)->loadObjectList();

		$groups = array();
		foreach($rows as $row)
		{
			$select = HTMLHelper::_('select.option', $row->id, $row->title, ['property' => 'data-role', 'value' => $row->role]);
			$groups[$row->role][] = $select;
		}

		$groups = array_merge(parent::getGroups(), $groups);
		reset($groups);
		return $groups;
	}
}
