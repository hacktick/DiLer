<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Form\FormHelper;

FormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class JFormFieldLearningGroup extends JFormFieldList
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since   1.6
	 */
	protected $type = 'LearningGroup';

    /**
     * Method to get the field options.
     *
     * @return  array  The field option objects.
     * @throws Exception
     * @since   1.6
     */
	protected function getOptions()
	{
		$dilerModel = MVCHelper::factory()->createModel('Diler', 'Site', array('ignore_request' => true));
		try
		{
			$groups = $dilerModel->getLearningGroups();
		}
		catch (RuntimeException $e)
		{
            throw new \Exception(Text::_('COM_DILERREG_DATABASE_ERROR'));
		}

		$options = array();
		foreach ($groups as $group)
		{
			$options[] = (object) array('value' => $group->id, 'text' => $group->title);
		}
		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);

		return $options;
	}
}
