<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
// No direct access to this file
defined('_JEXEC') or die;

use DiLer\DConst;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\HTML\HTMLHelper;

FormHelper::loadFieldClass('groupedlist');

class JFormFieldBaseSchools extends JFormFieldGroupedList
{
	protected $type = 'Baseschools';

	protected function getGroups()
	{
		$db = Factory::getDBO();
		$query = $db->getQuery(true)
			->select('s.id AS value, CONCAT(s.city, " | ", s.name, " | ", s.school_id) AS text')
			->from('#__diler_school AS s')
			->where('s.published = 1')
			->where('s.base_school = 1')
			->where('s.contract_signed_date IS NOT NULL')
			->order('s.city, s.name');

		$baseSchools = $db->setQuery($query)->loadObjectList();

		$options = array();

		foreach ($baseSchools as $baseSchool) {
			$select = HTMLHelper::_('select.option', $baseSchool->value, $baseSchool->text);
			$options[0][] = $select;
		}

		reset($options);
		return $options;
	}

	protected function getInput()
	{
		$this->options = $this->getGroups();

		$selectizeConfig = $this->getSelectizeConfig();
		HTMLHelper::_('diler.selectize', '#', $selectizeConfig);
		DText::script('STUDENTRECORD_SEARCH_FULLTEXT_ERROR_DESC');
		$document = Factory::getDocument();
		$document->addScriptOptions('useAjaxToLoadSchools', (count($this->options) == DConst::SELECTIZE_MAX_OPTIONS));
		$document->addScriptOptions('schoolHistorySelectConfig', $selectizeConfig);
		$document->addScriptOptions('baseSchoolGroups', $this->options);
		return parent::getInput() . $this->getMessageIfWeHaveSchoolMoreThanAllowedInSelectize();
	}
	

	private function getSelectizeConfig()
	{
		$options = array();
		$options['customPlugins'] = array('schools');
		$options['options'] = $this->options;
		$options['items'] = array($this->value);
		$options['plugins'] = array('schools');
		return $options;
	}
	
	private function getMessageIfWeHaveSchoolMoreThanAllowedInSelectize()
	{
		if (count($this->options) == DConst::SELECTIZE_MAX_OPTIONS)
			return '<small class="form-text text-muted selectize-search-hint">' .
		DText::sprintf('SELECTIZE_SEARCH_HINT', DConst::SELECTIZE_MAX_OPTIONS, DText::_('SCHOOL')) .
		'</small>';
		
		return "";
	}
}
 