<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Language\Text;

FormHelper::loadFieldClass('groupedlist');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 * @since       1.6
 */
class JFormFieldStudentcodes extends JFormFieldGroupedList
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since   1.6
	 */
	protected $type = 'Studentcodes';

	/**
	 * Method to get the field options.
	 *
	 * @return  array  The field option objects.
	 * @since   1.6
	 */
	protected function getGroups()
	{
		$db = Factory::getDbo();
		$registered = Text::_('COM_DILERREG_REGISTERED');
		$unregistered = Text::_('COM_DILERREG_UNREGISTERED');
		$query = $db->getQuery(true)
			->select('CONCAT("0:", id) as value, CONCAT(first_name, " ", last_name) AS text')
			->from('#__dilerreg_registration_codes')
			->where('role = "student"')
			->order('last_name, first_name');

		$unregisteredOptions = $db->setQuery($query)->loadObjectList();

		$studentGroupIds = ComponentHelper::getParams('com_diler')->get('student_group_ids');
		$registeredStudentsQuery = $db->getQuery(true)
			->select('CONCAT("1:",du.user_id) AS value, CONCAT(surname, " ", forename) AS text,du.user_id')
			->from('#__dilerreg_users AS du')
			->innerJoin('#__users as ju ON ju.id = du.user_id')
			->where('role = "student"')
			->where('block = 0')
			->innerJoin('#__user_usergroup_map AS uum ON du.user_id = uum.user_id AND uum.group_id IN(' . implode(',', $studentGroupIds) . ')')
			->order('surname, forename');
		$registeredOptions = $db->setQuery($registeredStudentsQuery)->loadObjectList();

		$groups = array();
		foreach($unregisteredOptions as $item)
		{
			$select = HTMLHelper::_('select.option', $item->value, $item->text);
			$groups[$unregistered][] = $select;
		}

		foreach($registeredOptions as $item)
		{
			$select = HTMLHelper::_('select.option', $item->value, $item->text.'&nbsp;&nbsp;&nbsp;ID:' . $item->user_id);
			$groups[$registered][] = $select;
		}

		reset($groups);
		return $groups;
	}
}
