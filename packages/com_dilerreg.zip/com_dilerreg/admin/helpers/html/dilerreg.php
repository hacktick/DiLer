<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\Lang\DText;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

/**
 * Utility class for categories
 *
 * @package     Joomla.Libraries
 * @subpackage  HTML
 * @since       1.5
 */
abstract class JHtmlDilerreg
{
	/**
	 * Cached array of the category items.
	 *
	 * @var    array
	 * @since  1.5
	 */
	protected static $items = array();

    /**
     * Returns an array of learning groups
     *
     * @param array $config
     * An array of configuration options. By default, only published and unpublished categories are returned.
     *
     * @return array
     *
     * @throws Exception
     * @since 1.5
     */
	public static function learningGroups($config = array())
	{
		$hash = md5('com_diler' . '.' . serialize($config));
		if (! isset(static::$items[$hash]))
		{
			static::$items[$hash] = array();
			BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models/');
			$dilerModel = MVCHelper::factory()->createModel('Diler', 'Administrator', array('ignore_request' => true));
			try
			{
				$items = $dilerModel->getLearningGroups();
			}
			catch (RuntimeException $e)
			{
                Factory::getApplication()->enqueueMessage(Text::_('COM_DILERREG_DATABASE_ERROR'),'WARNING');
			}
			foreach ($items as &$item)
			{
				static::$items[$hash][] = HTMLHelper::_('select.option', $item->id, $item->title);
			}
		}
		return static::$items[$hash];
	}

	/**
	 * Returns an array of standard diler roles
	 *
	 * @return array
	 *
	 * @since 3.3
	 */
	public static function roles($config = array())
	{
		// Build the active state filter options.
		$options = array();
		$options[] = HTMLHelper::_('select.option', 'teacher', Text::_('COM_DILERREG_TEACHER'));
		$options[] = HTMLHelper::_('select.option', 'parent', DText::_('PARENT'));
		$options[] = HTMLHelper::_('select.option', 'student', Text::_('COM_DILERREG_STUDENT'));
		return $options;
	}

}
