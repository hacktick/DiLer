<?php
/**
 * @package     Diler.Plugin
 * @subpackage  Authentication.diler
 *
 * @copyright   Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Registry\Registry;

/**
 * Joomla Authentication plugin
 *
 * @package     Joomla.Plugin
 * @subpackage  Authentication.diler
 * @since       1.5
 */
class PlgAuthenticationDiler extends CMSPlugin
{

	/**
	 * Checks that user params are valid. If not, fixes them prior to Joomla login.
	 * This prevents a 404 error when user params are invalid.
	 */
	protected function fixUserParams($credentials)
	{
		$username = isset($credentials['username']) ? $credentials['username'] : '';
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*')->from('#__users')->where('username = ' . $db->quote($username));
		$userRow = $db->setQuery($query)->loadObject();
		if (is_object($userRow) && isset($userRow->params))
		{
			// Check that params are valid
			try
			{
				$params = new Registry($userRow->params);
			} 
			catch (Exception $exc)
			{
				// If not valid, replace with empty params
				$params = new Registry();
				$query->clear()->update('#__users')->set('params = ' . $db->quote((string) $params))
						->where('username = ' . $db->quote($username));
				$db->setQuery($query)->execute();						
			}		
		}
	}

	/**
	 * Placeholder function required by Joomla. Return false.
	 * This delegates the actual login back to the Joomla authentication plugin.
	 */
	public function onUserAuthenticate($credentials, $options, &$response)
	{
		// Check that user params are valid. If not, fix them and then return false;
		$this->fixUserParams($credentials);
		return false;
	}

	// Redirect back to correct URL if Diler login failure
    public function onUserLoginFailure($response)
	{
		$redirect = $_SERVER['HTTP_REFERER'];
		
		// Only process Diler logins
		if (strpos($redirect, 'dilerlogin'))
		{
			$app = Factory::getApplication();
			Log::add($response['error_message'], Log::WARNING, 'jerror');
			$app->setUserState('users.login.form.data', $response);
			$app->redirect($redirect);
		}
	}
}
