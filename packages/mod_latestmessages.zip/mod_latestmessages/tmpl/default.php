<?php
/**
 * @package		DiLer.Site
 * @subpackage	mod_latestmessages
 * @filesource
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

use DiLer\DConst;
use DiLer\Lang\DText;
use DiLer\Users\OnlineStatuses\OnlineStatuses;
use DiLer\DDateTime;
use DiLer\Users\PersonalDataHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

$input = Factory::getApplication()->input;
$role = DilerHelperUser::getDilerRole();
$showTeacherFirstName = DilerHelperUser::showFirstName($role);
JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

$user = Factory::getUser();

switch ($role)
{
	case Text::_('teacher'):
		$userView = 'teacher_desk';
		$isTeacher = true;
		break;
	case Text::_('parent_desk'):
		$userView = 'parent';
		break;
	case Text::_('student_desk'):
		$userView = 'student';
		$isStudent = true;
		break;
	default:
		$userView = 'diler';
		break;
}

$date_format = Text::_('DATE_FORMAT_LC4');
$urlLang = $input->get('lang');

if ($totalMessageCount->system)
{
	$anchorClassSystem = 'unreadMessages';
	$badgeClassSystem = 'newMessage badge badge-warning';
}
else
{
	$anchorClassSystem = '';
	$badgeClassSystem = 'newMessage badge';
}
if ($totalMessageCount->manual)
{
	$anchorClassManual = 'unreadMessages';
	$badgeClassManual = 'newMessage badge badge-warning';
}
else
{
	$anchorClassManual = '';
	$badgeClassManual = 'newMessage badge';
}

?>

<h3><?php echo Text::_('MOD_LATESTMESSAGES_MODULEHEADING')." ".HTMLHelper::_('diler.helpButton','Mod_Latestmessages', 'absolute', false, 'fal fa-question-circle', false); ?></h3>
<div id="latestMessagesWrapper">
	<table id="latestMessages"
		class="table table-hover table-condensed">
		<thead>
			<tr>
				<th><?php echo Text::_('MOD_LATESTMESSAGES_DATE'); ?></th>
				<th class="text-center"><?php echo Text::_('MOD_LATESTMESSAGES_TYPE')?></th>
				<th><?php echo DText::_('SUBJECT'); ?></th>
				<th><?php echo Text::_('MOD_LATESTMESSAGES_USER'); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if($messages) : ?>
				<?php $senders = array_unique(array_column($messages, 'sender'));
				$sendersOnlineStatus = OnlineStatuses::getUsersOnlineStatus($senders);
				?>
				<?php foreach ($messages as $message) : ?>
					<?php $senderOnlineStatus = $message->sender_role == DConst::USER_ROLE_STUDENT ? '<div class="user-online-status ' . $sendersOnlineStatus[$message->sender]->status() . '"></div>' :  ""; ?>
					<tr id="latestmessages<?php echo $message->id; ?>">
						<td><?php echo DDateTime::DilerDateTimeShort($message->created_date); ?></td>
						<td class="text-center"><?php echo $message->typeObject->type; ?></td>
						<td><?php echo $message->subject_name; ?></td>
                        <td><?php echo $senderOnlineStatus . PersonalDataHelper::texterSenderName($message, $showTeacherFirstName) ?></td>
					</tr>
				<?php endforeach; ?>
			<?php  else :?>
				<tr>
					<td colspan="4">
						<?php echo Text::_('MOD_LATESTMESSAGES_NULL'); ?>
					</td>
				</tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>

