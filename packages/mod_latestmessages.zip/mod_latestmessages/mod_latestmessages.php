<?php
/**
 * @package		DiLer.Site
 * @subpackage	mod_latestmessages
 * @filesource
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;

$language = Factory::getLanguage();
$language->load('com_diler', JPATH_SITE . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_diler', null, true);

require_once __DIR__.DIRECTORY_SEPARATOR.'helper.php';
JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

$messages = modLatestmessagesHelper::getLatestMessages();
$totalMessageCount = modLatestmessagesHelper::getMessageCount();

require ModuleHelper::getLayoutPath('mod_latestmessages', $params->get('layout', 'default'));
