<?php
/**
 * @package		DiLer.Site
 * @subpackage	mod_latestmessages
 * @filesource
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;

class modLatestmessagesHelper {
	/**
	* 1. 	id 	int(11)
	* 2. 	sender 	int(11)
	* 3. 	receiver 	int(11)
	* 4. 	status 	int(11)
	* 5. 	subject_id 	int(11)
	* 6. 	compchar_id 	int(11)
	* 7. 	level_id 	int(11)
	* 8. 	date
	*/
	public static function getLatestMessages()
	{
		$db  = Factory::getDBO();
		$my_id = Factory::getUser()->id;
		Text::script('MOD_LATESTMESSAGES_NULL');
		$numMessages = Factory::getUser()->getParam('numMessages', 5);
		$dilerParams = ComponentHelper::getParams('com_diler');
		$teacherGroups = $dilerParams->get('teacher_group_ids');
		$parentGroups = $dilerParams->get('parent_group_ids');
		$studentGroups = $dilerParams->get('student_group_ids');
		$adminGroups = $dilerParams->get('admin_group_ids');

		$query = $db->getQuery(true);
		$query->select('m.*');
		$query->from('#__diler_texter AS m');

		$query->innerJoin('#__user_usergroup_map AS smap on m.sender = smap.user_id');
		$query->select('GROUP_CONCAT(smap.group_id) AS sender_groups');
		$query->innerJoin('#__dilerreg_users AS du ON du.user_id = m.sender');
		$query->select('du.salutation AS sender_salutation, du.surname AS sender_surname, du.forename AS sender_forename, du.nickname AS sender_nickname');

		$query->leftJoin('#__diler_subject AS s ON m.subject_id = s.id');
		$query->select('s.name AS subject_name');
		$query->where('m.receiver = ' . $my_id);
		$query->where('m.receiver_status = 0');
		$query->where('(m.read_date = "0000-00-00 00:00:00" OR m.read_date is null)');
		$query->order('m.created_date DESC');
		$query->group('m.id');

	    $messages = $db->setQuery($query, 0, $numMessages)->loadObjectList();
	    $msg = new Messages();

	    foreach ($messages as $message)
	    {
	    	$message->sender_role = '';
			if (array_intersect(explode(',', $message->sender_groups), $teacherGroups))
			{
				$message->sender_role = 'teacher';
			}
			elseif (array_intersect(explode(',', $message->sender_groups), $studentGroups))
			{
				$message->sender_role = 'student';
			}
			elseif (array_intersect(explode(',', $message->sender_groups), $parentGroups))
			{
				$message->sender_role = 'parent';
			}
			elseif (array_intersect(explode(',', $message->sender_groups), $adminGroups))
			{
				$message->sender_role = 'admin';
			}
			$message->typeObject = $msg->type($message);
			$message->type = $message->typeObject->type;
	    }

		return $messages;
	}

	/**
	 * Gets the total unread messages for this user for the badge counter.
	 */
	public static function getMessageCount()
	{
		$msg = new Messages();
		return $msg->countUnreadMessages(Factory::getUser()->id);
	}
}
