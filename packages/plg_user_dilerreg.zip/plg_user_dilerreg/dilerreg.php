<?php
/**
 * @package		DiLer.Site
 * @subpackage	mod_latestmessages
 * @filesource
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;
defined('JPATH_BASE') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Site\Controller\DigluLoginController;
use DiLer\Core\Repositories\RepositoryFactory;
use DiLer\DConst;
use DiLer\DGet;
use DiLer\Lang\DText;
use DiLer\Users\DUser;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Router;
use Joomla\CMS\Table\Menu;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserHelper;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\Registry\Registry;

JLoader::register('DilerLogger', JPATH_ROOT .  '/components/com_diler/helpers/logger.php');
JLoader::register('DilerParams', JPATH_ROOT .  '/components/com_diler/helpers/dilerparams.php');
Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/components/com_diler', null, true);

/**
 * An example custom profile plugin.
 *
 * @package     Joomla.Plugin
 * @subpackage  User.profile
 * @since       1.6
 */
class PlgUserDilerreg extends CMSPlugin
{
	/**
	 * Date of birth.
	 *
	 * @var    string
	 * @since  3.1
	 */
	private $_date = '';

	/**
	 * Array of valid urls to redirect to on login
	 *
	 * @var   ArrayAccess
	 * @since 4.0.0
	 */
	public $validUrls = array(
		'com_diler:cloud',
		'com_diler:parent_achieve_grid',
		'com_diler:parent_compchar',
		'com_diler:parent_contacts',
		'com_diler:parent_desk',
		'com_diler:parent_myaccount',
		'com_diler:parent_student',
		'com_diler:student_achieve_grid',
		'com_diler:student_compchar',
		'com_diler:student_desk',
		'com_diler:student_myaccount',
		'com_diler:teacher_contacts',
		'com_diler:teacher_desk',
		'com_diler:teacher_group',
		'com_diler:teacher_group_achieve_grid',
		'com_diler:teacher_maintenance',
		'com_diler:teacher_maintenance_achieve_grid',
		'com_diler:teacher_maintenance_activity',
		'com_diler:teacher_maintenance_activity_task',
		'com_diler:teacher_maintenance_compchar',
		'com_diler:teacher_maintenance_group_assign',
		'com_diler:teacher_maintenance_group_list',
		'com_diler:teacher_maintenance_group',
		'com_diler:teacher_maintenance_learning_groups',
		'com_diler:teacher_maintenance_phases',
		'com_diler:teacher_maintenance_nimbus_list',
		'com_diler:teacher_maintenance_nimbus_template',
		'com_diler:teacher_maintenance_nimbus_phrases',
		'com_diler:teacher_myaccount',
		'com_diler:teacher_student',
		'com_diler:teacher_student_achieve_grid',
		'com_diler:teacher_student_compchar',
		'com_dpcalendar:calendar',
	);

	/**
	 * Load the language file on instantiation.
	 *
	 * @var    boolean
	 * @since  3.1
	 */
	protected $autoloadLanguage = true;

	/**
	 * Constructor
	 *
	 * @param   object  $subject  The object to observe
	 * @param   array   $config   An array that holds the plugin configuration
	 *
	 * @since   1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		FormHelper::addFieldPath(__DIR__ . '/fields');

	}

    /**
     * Redirect to diler_myaccount
     *
     * @param stdClass $user
     * @param bool $isnew
     * @param bool $success
     * @param string $msg
     * @throws Exception
     */
	public function onUserAfterSave($user, $isnew ,$success, $msg)
	{
		$app = Factory::getApplication();
		JLoader::register('DilerHelperUser', JPATH_BASE. '/components/com_diler/helpers/user.php');
		$dilerRole = DilerHelperUser::getDilerRole();
		$redirect = $app->getUserState('com_diler.edit.profile.redirect');
		if ($redirect && $success && $app->isClient('site') && in_array($dilerRole, array('teacher', 'student', 'parent')))
		{
			$app->redirect(Route::_($app->getUserState('com_diler.edit.profile.redirect'), false));
		}
	}

	public function onUserBeforeDeleteGroup($data)
	{
		if ($this->isDilerGroup($data))
		{
			$url = Route::_('index.php?option=com_users&view=groups', false);
			$msg = Text::sprintf('PLG_USER_DILERREG_USERGROUP_DELETE_NOT_ALLOWED', $data['title']);
			Factory::getApplication()->redirect($url, $msg, $msgType='error');
		}
		else
		{
			return true;
		}
	}

    /**
     * Create new DiLer group and viewlevel if this is a new Diler-related Group.
     * This is determined by the parent_id matching one of: Learning Group id, Subject Group id, Extracurricular Group id.
     *
     * @param string $context
     * @param Table object  $table
     * @param boolean $isNew True if this is a new group.
     * @param array $data Data for the group being saved.
     * @return boolean
     * @throws Exception
     */
	public function onUserBeforeSaveGroup($context, $table, $isNew, $data)
	{
		if ($context == 'com_diler.group' || ! $this->isDilerGroup($data))
		{
			return true;
		}
		else
		{
			$msg = Text::_('PLG_USER_DILERREG_USERGROUP_CREATE_NOT_ALLOWED');
			Factory::getApplication()->enqueueMessage($msg, 'error');
			return false;
		}
	}

    /**
     * Prevents deleting a user if this user is a DiLer user
     *
     * @param array $data Array with the user id
     * @param string $return URL to redirect if data exists
     *
     * @return boolean  true if user is not a Diler user, false otherwise
     * @throws Exception
     */
	public function onUserBeforeDelete($data, $return='index.php?option=com_users&view=users')
	{
		if ($this->isDilerUser($data))
		{
			$url = Route::_('index.php?option=com_users&view=users', false);
			$msg = Text::sprintf('PLG_USER_DILERREG_USERHASDATA', $data['username']);
			$app = Factory::getApplication();
			$app->enqueueMessage($msg, 'error');
			$app->redirect($url);
		}
		else
		{
			return true;
		}
	}

    /**
     * This method should handle any login logic and report back to the subject
     *
     * @param array $user Holds the user data
     * @param array $options Array holding options (remember, autoregister, group)
     *
     * @return boolean True on success
     *
     * @throws Exception
     * @since 1.5
     */
	public function onUserLogin($user, $options = array())
	{
		$app = Factory::getApplication();
		$input = $app->input;
		if ($input->get('component') != 'com_diler')
		{
			if ($options['action'] == 'core.login.admin')
			{
				$this->autoPurgeTexter();
				$this->updateSSLCACertificateFile();
			}
			return;
		}
		$userObject = User::getInstance();
		$id = (int) UserHelper::getUserId($user['username']);

		if ($id)
		{
			$userObject->load($id);
            $this->processDigluAvvVvtLogin($id);
		}
        if ($userObject->block)
        {
            return true;
        }
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_dilerreg/models');
		$approve = BaseDatabaseModel::getInstance('Login', 'DilerregModel')->getApproved($userObject->id);
		$role = DilerHelperUser::getDilerRole($userObject->id);
		$ipOk = DilerHelperUser::checkSchoolIp($role);
		if ($approve == 1 && in_array($role, array('teacher', 'student', 'parent')) && ($ipOk === 1))
		{
			// If we have oauth_login allow Joomla to return to required page reading 'return` from url
			$oauthUrl = Factory::getApplication()->getUserState('com_dilerauth.redirect_to_oauth_login');
			if ($oauthUrl)
			{
				$oauthRedirect = base64_decode($oauthUrl);
				$app->redirect($oauthRedirect);
				return true;
			}
			$return_url = $userObject->getParam('return_url');
			$rawUrl = urldecode(base64_decode($return_url));

			// Convert view=diler or SEF url to correct view (e.g., teacher_desk, etc.) based in Itemid and format
			$viewUrl = '';
			if ($rawUrl) $viewUrl = $this->getViewUrl($rawUrl, $role);
			if ($return_url && ! strpos($viewUrl, '&task=')
				&& strpos($viewUrl, 'index.php') >= 0 && strpos($viewUrl, 'index.php') !== false
				&& $this->isValidUrl($viewUrl)
				&& $userObject->getParam('loginRedirect') == 2)
			{
				$cutPosition = strpos($viewUrl, 'index.php');
				$redirect = substr($viewUrl, $cutPosition);
			}
			else
			{
				$language = $input->get('lang', Factory::getApplication()->getLanguage());
				$itemId = DilerHelperUser::getDeskItemId($language);
				$redirect = 'index.php?option=com_diler&view=diler&Itemid=' . $itemId . '&lang=' . substr($language, 0,2);
			}
			// Add autoTalkie to redirect if needed
			$redirect .= '&autoTalkie=' . $userObject->getParam('autoTalkie', 2);

			// Delete the users temporary download folder (just in case they didn't log off)
			$tempFolder = Factory::getConfig()->get('tmp_path') . '/diler/' . $userObject->id;
			
			if (Folder::exists($tempFolder))
			{
				try
				{
					Folder::delete($tempFolder);

				}
				catch (Exception $ex) {
					$x = 1;
				}
			}
			$this->digluBranchGroupRemove($role);
			$this->updateStateOtherGroupUsers($userObject, $role);
			$this->updatePrincipalOtherGroup($id, $role);
			$this->log($user, $id, 'login');
			$app->redirect($redirect);
		}
		else
		{
			if (! $approve )
			{
				$app->enqueueMessage(Text::_('PLG_USER_DILERREG_NOT_REGISTERED'), 'warning');
			}
			if (! in_array($role, array('teacher','student','parent')))
			{
				$app->enqueueMessage(Text::_('PLG_USER_DILERREG_NO_ROLE'), 'warning');
			}

			if ($ipOk === 0)
			{
				$app->logout();
				$app->redirect('index.php?option=com_dilerreg&view=loggedout&ip_check=0');
				return false;
			}

			if ($ipOk === -1)
			{
				$app->logout();
				$app->redirect('index.php?option=com_dilerreg&view=loggedout&ip_check=-1');
				return false;
			}
			BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
			$this->log($user, $id, 'login.fail');
			$app->redirect(MVCHelper::factory()->createModel('Diler', 'Site')->getLoginLink());
			return false;
		}

	}

	public function onUserLogout($credentials, $options)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from('#__users')
			->where('id =' . (int) $credentials['id']);
		$user = $db->setQuery($query)->loadObject();
		if ($user)
		{
			$userArray = array('fullname' => $user->name, 'username' => $user->username);
			$this->log($userArray, $credentials['id'], 'logout');
		}
	}

	/**
	 * Checks whether a usergroup is a DiLer group (based on parent_id of the group)
	 * @param array  $data  associative array of the form data
	 * @return bool         true if this is a DiLer group, false otherwise.
	 */
	protected function isDilerGroup($data)
	{
		$params = ComponentHelper::getParams('com_diler');
		$dilerParentIds = array(
			$params->get('learning_group_parent_id'),
			$params->get('subject_group_parent_id'),
			$params->get('extracurricular_group_parent_id'),
			);
		return in_array($data['parent_id'], $dilerParentIds);
	}

	// Checks if current user is a DiLer user (has row in dilerreg_users table
    protected function isDilerUser($data)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('COUNT(*)')->from('#__dilerreg_users')->where('user_id = ' . (int) $data['id']);
		return $db->setQuery($query)->loadResult();
	}

	/**
	 * Checks that Itemid points to correct component
	 *
	 * @return bool true is item id is valid, false otherwise.
	 */
	protected function isValidItemid($itemId, $option)
	{
		Table::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_menus/tables');
		$menuTable = new Menu(Factory::getDbo());
		$menuTable->load($itemId);
		return (bool) strpos($menuTable->link, 'option=' . $option) !== false && strpos($menuTable->alias, 'bulletin') === false;
	}

	/**
	 * Checks redirect URL against a list of valid URL's. This prevents error when view names have changed after an update
	 *
	 * @param  string  $url  URL to check against the list
	 *
	 * @return  boolean  true if URL is on the list of valid URL's, false otherwise.
	 *
	 * @since 4.0.0
	 */
	protected function isValidUrl($url)
	{
		$uri = Uri::getInstance($url);
		$view = $uri->getVar('view');
		$option = $uri->getVar('option');
		$itemId = $uri->getVar('Itemid');
		return ($view && $option && in_array($option . ':' . $view, $this->validUrls) && $this->isValidItemid($itemId, $option));
	}

	protected function log($user, $userId, $action)
	{
		// Check logging options
		$role = DilerHelperUser::getDilerRole($userId);
		switch ($role)
		{
			case 'teacher' :
			case 'student' :
				$logType = $role;
				break;
			case 'parent' :
			default :
				$logType = 'misc_users';
				break;
		}

		// Log if user login to site side as core Joomla Logger do not track it.
		if ($action == 'login')
		{
			$logMessage = DText::sprintf('LOG_USER_LOGIN', $user['fullname'], $user['username']);
			$logData = array('message' => $logMessage, 'extension' => 'com_users');
			$logger = new DilerLogger('user', 'login', $logType);
			$logger->addAction($logData);
			if ($role == 'teacher')
			{
				$this->autoPurgeLog();
			}
		}

		return;
	}

	/**
	 * Automatically purges the log as needed if the option is set.
	 */
	protected function autoPurgeLog()
	{
		$days = (int) ComponentHelper::getParams('com_diler')->get('logAutoPurgeDays', 0);
		if ($days)
		{
			// Delete rows older than specified days
			$db = Factory::getDbo();
			$query = $db->getQuery(true)
				->delete('#__diler_log')
				->where('DATE(create_time) < DATE(now() - INTERVAL ' . $days . ' DAY)');
			$db->setQuery($query)->execute();
		}
	}

	/**
	 * Purge system Texter messages if DiLer option is set (default to 365 days).
	 * Also, purge trashed messages where trash date more than 30 days old.
	 */
	protected function autoPurgeTexter()
	{
		$days = (int) ComponentHelper::getParams('com_diler')->get('texterAutoPurgeDays', 365);
		if ($days && Factory::getUser()->authorise('core.admin'))
		{
			// Delete rows older than specified days
			$db = Factory::getDbo();
			$query = $db->getQuery(true)
				->delete('#__diler_texter')
				->where('(DATE(created_date) < DATE(now() - INTERVAL ' . $days . ' DAY))', 'OR')
				->where('(DATE(receiver_trash_date) < DATE(now()) - INTERVAL 30 DAY AND DATE(sender_trash_date) < DATE(now()) - INTERVAL 30 DAY AND receiver_status IN(1,2) AND sender_status IN(1,2))', 'OR');
			$db->setQuery($query)->execute();
		}
	}

	/** @param User $userObject */
	private function updateStateOtherGroupUsers($userObject, $role)
	{
		if ($role != DConst::USER_ROLE_TEACHER)
			return;
		if (!in_array(DilerParams::init()->getDigluTrainerGroupId(), $userObject->getAuthorisedGroups()))
			return;

		Table::addIncludePath(JPATH_ROOT . '/administrator/components/com_diler/tables/');
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models/');
		/** @var \Audivisa\Component\DiLer\Site\Model\StateModel $stateModel */
		$stateModel = MVCHelper::factory()->createModel('State', 'Site');
		$stateModel->rebuildAssignedUsersToStateGroups();
	}

	private function updatePrincipalOtherGroup($userId, $role)
	{
		if ($role != DConst::USER_ROLE_TEACHER || !DilerHelperUser::isDiglu())
			return;
		$school = RepositoryFactory::school()->loadByPrincipal($userId);
		if (!$school->id())
			return;
		/** @var \Audivisa\Component\DiLer\Site\Model\School_principalModel $principalModel */
		$principalModel = MVCHelper::factory()->createModel('School_principal', 'Site');
		$principalModel->rebuildAssignedUsersToSchoolGroups($school);
	}

	/**
	 * Checks whether this is a branch teacher with students having enrollment end date before today.
	 * If so, sends an email and removes the students from the teacher's "Other" group.
	 *
	 * @param string $role
	 */
	protected function digluBranchGroupRemove($role)
	{
		if ($role !== 'teacher' || ! DilerHelperUser::isDiglu()) return true;
		$branchTeacherGroup = ComponentHelper::getParams('com_diler')->get('branch_school_teacher_group_id', 0);
		$delistingDays = DilerParams::init()->getDelistingOfStudent();
		$user = Factory::getUser();
		$userGroups = $user->getAuthorisedGroups();
		if (! in_array($branchTeacherGroup, $userGroups)) return true;

		// At this point we have a Branch Teacher. We need to check students.
		$now = Factory::getDate()->toSql();
		$db = Factory::getDbo();
		$nullDate = $db->getNullDate();
		$interval = new DateInterval('P' . $delistingDays . 'D');
		$rows = $this->digluGetStudentRows($user);
		$joomlaGroupId = 0;
		foreach ($rows as $row)
		{
            $deadline = Factory::getDate($row->enroll_end)->add($interval)->toSql();
			if ($row->enroll_end === $nullDate || $row->enroll_end > $now) continue;
			if ($row->leaving_email_date !== null && $row->group_unassign_date !== null) continue;
			if ($deadline < $now && $row->group_unassign_date === null)
			{
				$joomlaGroupId = ($joomlaGroupId) ? $joomlaGroupId : $this->digluGetJoomlaGroupId($user);
				$groupRemoved = ($joomlaGroupId) ? UserHelper::removeUserFromGroup($row->user_id, $joomlaGroupId) : false;
			}
			$this->digluSchoolHistoryUpdate($row, $groupRemoved);
		}
		return true;
	}

	protected function digluGetJoomlaGroupId($user)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('joomla_group_id')
				->from('#__diler_group')
				->where('name = ' . $db->quote($user->username));
		return $db->setQuery($query)->loadResult();
	}

	// Gets information for sending email and removing the student from the teacher's other group.
    protected function digluGetStudentRows($user)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('h.*, ju.name AS student_name, s.name AS school_name, s.school_id AS school_serial_number')
				->from('#__diler_user_school_history AS h')
				->innerJoin('#__users AS ju ON h.user_id = ju.id')
				->innerJoin('#__diler_school AS s ON s.id = h.school_id')
				->where('h.branch_teacher = ' . $user->id);
		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Updates the columns in history table so we only send one email and do the group remove one time.
	 *
	 * @param stdClass $row  Row object with user_id, branch_teacher
	 * @param bool $leavingEmailSent true if we need to update the leaving_email_date
	 * @param bool $groupRemoved true if we need to update the group_unassign_date
	 * @return boolean
	 */
	protected function digluSchoolHistoryUpdate($row, $groupRemoved)
	{
		if (! $groupRemoved) return true;
		$db = Factory::getDbo();
		$nowQuoted = $db->quote(Factory::getDate()->toSql());
		$query = $db->getQuery(true)->update('#__diler_user_school_history')
				->where('id = ' . (int) $row->id);
		if ($groupRemoved)
		{
			$query->set('leaving_email_date = ' . $nowQuoted);
			$query->set('group_unassign_date = ' . $nowQuoted);
		}
		return $db->setQuery($query)->execute();
	}

	protected function getNonSefUrl($url)
	{
		// See if we need to do this. If we have a non-SEF URL just return the $url.
		if (strpos($url, 'index.php?') !== false) return $url;

		/**
		 * Because we are passing url without protocol and domain, router redirect to https
		 * To prevent it, we prepend base url to raw url.
		 * @see \Joomla\CMS\Router\SiteRouter::parse
		 */
		$fullUrl = Uri::base() . $url;

		// At this point we have a SEF URL.
		$uri = Uri::getInstance($fullUrl);
		$router = Router::getInstance('site');
		$queryArray = $router->parse($uri);
		$router->setMode(0);
		$rawUri = $router->build($queryArray);
		$rawUri->delVar('task');
		$rawUrl = (string) $rawUri;
		$result = substr($rawUrl, strpos($rawUrl, 'index.php'));
		return $result;
	}

	/**
	 * Get the right diler view based on the Itemid.
	 *
	 * @param string $rawUrl
	 * @param string $role
	 * @return string Url with view substituted.
	 */
	protected function getViewUrl($rawUrl, $role)
	{
		// Check if we need to do this.
		$viewPos = strpos($rawUrl, '&view=diler&');
		$regExp = '#.*Itemid=([0-9]*)&{0,1}#';
		$itemExists = preg_match($regExp, $rawUrl, $matches);
		$itemId = ($itemExists && isset($matches[1]) && $matches[1]) ? $matches[1] : 0;

		// If view not diler or no Itemid get the non-SEF URL
		if ($viewPos === false || ! $itemId) return $this->getNonSefUrl($rawUrl);

		// Get view from the item id
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('params')->from('#__menu')->where('id = ' . (int) $itemId);
		$paramString = $db->setQuery($query)->loadResult();
		$params = new Registry($paramString);
		$viewIndex = $params->get('view_name', 0);
		$viewName = DilerHelperUser::getViewName($role, $viewIndex);
		$result = $viewName ? str_replace('&view=diler&', '&view=' . $viewName . '&', $rawUrl) : $rawUrl;
		return $result;
	}

	private function updateSSLCACertificateFile()
	{
		$caCert = file_get_contents('https://curl.haxx.se/ca/cacert.pem');
		if (!$caCert)
		{
			Factory::getApplication()->enqueueMessage(Text::_('PLG_USER_DILERREG_CAN_NOT_UPDATE_CA_CERTIFICATE'), 'error');
			return;
		}
		file_put_contents(JPATH_ROOT . '/libraries/src/Http/Transport/cacert.pem', $caCert);
	}

    private function processDigluAvvVvtLogin(int $userId) : void
    {
        if (!\DilerHelperUser::isDiglu())
            return;
	    $dUser = DGet::user($userId);

        $digluLoginController = new DigluLoginController($userId);
        if ($digluLoginController->isUserBlocked())
        {
			$this->handleParent($dUser);
			$this->handleStudent($dUser);
        }

        if ($dUser->isParent() || $dUser->isStudent())
            return;

        $digluLoginController->logoutAndRedirectToAvvVvtAgreementIfRelatedUser();
        $digluLoginController->logoutIfBaseSchoolTeacherAndNotifyPrincipal();
    }

	private function getIsAvvConsentAcceptedForParent($userId) : bool
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('dsm.is_avv_consent_accepted');
		$query->from('#__diler_school_ministry AS dsm');
		$query->innerJoin('#__diler_school AS ds ON ds.state_iso = dsm.state_iso');
		$query->innerJoin('#__diler_user_school_history AS dush ON dush.school_id = ds.id');
		$query->innerJoin('#__dilerreg_parent_student_map AS dpsm ON dpsm.student_id = dush.user_id');
		$query->where('dpsm.parent_id = ' . $db->quote($userId));
		$query->where('dush.base_school = 1');
		$db->setQuery($query);

		return (bool) $db->loadResult();
	}

	private function getIsAvvConsentAcceptedForStudent($userId) : bool
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('dsm.is_avv_consent_accepted');
		$query->from('#__diler_school_ministry AS dsm');
		$query->innerJoin('#__diler_school AS ds ON ds.state_iso = dsm.state_iso');
		$query->innerJoin('#__diler_user_school_history AS dush ON dush.school_id = ds.id');
		$query->where('dush.user_id = ' . $db->quote($userId));
		$query->where('dush.base_school = 1');
		$db->setQuery($query);

		return (bool) $db->loadResult();
	}

	private function handleParent(DUser $dUser)
	{
		if (!$dUser->isParent())
			return;

		if ($this->getIsAvvConsentAcceptedForParent($dUser->id()))
        {
            $this->enqueueMessageForAccessDeniedToLegalBasis();
            return;
        }

		$this->enqueueMessageForAccessDeniedToWithoutLegalBasis();
	}

	private function handleStudent(DUser $dUser)
	{
		if (!$dUser->isStudent())
			return;

		if ($this->getIsAvvConsentAcceptedForStudent($dUser->id()))
        {
            $this->enqueueMessageForAccessDeniedToLegalBasis();
            return;
        }

		$this->enqueueMessageForAccessDeniedToWithoutLegalBasis();
	}

	private function enqueueMessageForAccessDeniedToLegalBasis()
	{
        Factory::getApplication()->getMessageQueue(true);
		Factory::getApplication()->enqueueMessage(Text::_('COM_DILER_ACCESS_DENIED_WITH_LEGAL_BASIS_PARENT_STUDENT_MESSAGE'), 'warning');
	}

	private function enqueueMessageForAccessDeniedToWithoutLegalBasis()
	{
        Factory::getApplication()->getMessageQueue(true);
		Factory::getApplication()->enqueueMessage(Text::_('COM_DILER_ACCESS_DENIED_WITHOUT_LEGAL_BASIS_PARENT_STUDENT_MESSAGE'), 'warning');
	}
}
