<?php

/**
 * @copyright	Copyright (C) 2021 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;

class PlgSystemDilerLinkModifier extends CMSPlugin
{
	public function onAfterRender()
	{
		$app = Factory::getApplication();
		if ($app->getName() != 'administrator' && $app->getDocument() instanceof HtmlDocument) {
			$dom = $this->getHtmlDomElement();
			$validElements = $dom->getElementsByTagName('a');
			foreach ($validElements as $element) {
				if ($this->checkExternalLink($element->getAttribute('href'))) {
					$this->setLinkAttrs($element);
				}
			}
			$app->setBody($dom->saveHTML());
		}
	}

	private function getHtmlDomElement()
	{
		$app = Factory::getApplication();
		$currentHtml = $app->getBody();
		$dom = new DOMDocument;

		if (strpos($currentHtml, '</html>') === false)
			$currentHtml = "<html>{$currentHtml}</html>";

		@$dom->loadHTML($currentHtml);
		return $dom;
	}

	private function checkExternalLink($url)
	{
		$isLinkForWebsite = (strpos($url, 'http') > -1);
		$isLinkForOtherDomain = !(strpos($url, $_SERVER['HTTP_HOST']) > -1);
		return ($isLinkForWebsite && $isLinkForOtherDomain);
	}

	private function setLinkAttrs($element)
	{
		$element->setAttribute('target', '_blank');
		$element->setAttribute('rel', 'noreferrer');
	}
}
