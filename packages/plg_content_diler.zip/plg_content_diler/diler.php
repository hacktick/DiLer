<?php
/**
 * @package     Diler.Plugin
 * @subpackage  Content.diler
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use DiLer\DUrl;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
JLoader::register('DilerLogger', JPATH_ROOT .  '/components/com_diler/helpers/logger.php');

/**
 * Example Content Plugin
 *
 * @since  1.6
 */
class PlgContentDiler extends CMSPlugin
{
	protected $contextArray = array(
		'com_diler.subject',
		'com_diler.extracurricular',
		'com_diler.phase',
		'com_diler.level',
		'com_diler.competence',
		'com_diler.compchar',
		'com_diler.gradingmethod',
		'com_diler.activitytype',
		'com_diler.reportfield',
		'com_diler.reportperiod',
		'com_diler.reporttype',
		'com_diler.languageoverrides',
		'com_diler.dataaction',
	);

	protected $extensionArray = array(
		'com_diler',
		'com_diler.extracurriculars',
		'com_diler.studentrecord',
		'com_diler.relationships',
	);

	/**
	 * Load the language file on instantiation.
	 *
	 * @var    boolean
	 * @since  3.1
	 */
	protected $autoloadLanguage = true;

	/**
	 * Log selected create and edit activities.
	 *
	 * @param   string   $context  The context of the content passed to the plugin (added in 1.6)
	 * @param   object   $table    Table object
	 * @param   boolean  $isNew    true if this row was just inserted, false if it was updated.
	 *
	 * @return  boolean  true if plugin executed successfully.
	 *
	 * @since   5.0
	 */
	public function onContentAfterSave($context, $table, $isNew)
	{
		return $this->logEvent($context, $table, 'edit', $isNew);
	}

	/**
	 * Log selected delete activities
	 *
	 * @param  string  $context  The context from where the plugin was called.
	 * @param  Table  $table    Object with the table data.
	 *
	 * @return boolean true if plugin executed successfully.
	 */
	public function onContentAfterDelete($context, $table)
	{
		$action = ($context == 'com_diler.dataaction') ? 'purge' : 'delete';

		return $this->logEvent($context, $table, $action, false);
	}

	public function onContentBeforeSave($context, $table)
	{
		if (($context != 'com_users.level') || (!isset($table->id)) || (! $table->id))
		{
			return true;
		}
		// Don't allow save from admin if this view level is associated with a DiLer group
		if ($this->isDilerViewlevel($table))
		{
			$table->setError(Text::_('PLG_CONTENT_DILER_VIEWLEVEL_EDIT_NOT_ALLOWED'));
			return false;
		}
		return true;
	}

    /**
     * For groups: Don't allow group category to be deleted if groups for this category exist.
     *
     * @param string $context Category extension.
     * @param Table object $table
     * @return boolean
     * @throws Exception
     */
	public function onContentBeforeDelete($context, $table)
	{
		// Don't allow delete from admin if this view level is associated with a DiLer group
		if ($context == 'com_users.level' && $this->isDilerViewlevel($table))
		{
			$table->setError(Text::sprintf('PLG_CONTENT_DILER_VIEWLEVEL_DELETE_NOT_ALLOWED', $table->title));
			return false;
		}

		if ($context === 'com_categories.category' && $table->extension === 'com_diler.group')
		{
			$groupCountArray = $this->groupsExist([$table->id]);
			if ($groupCountArray && $groupCountArray[$table->id]->groupCount)
			{
				$msg = Text::sprintf('PLG_CONTENT_DILER_GROUP_CATEGORY_DELETE_NOT_ALLOWED', $table->title, $groupCountArray[$table->id]->groupCount,
						$groupCountArray[$table->id]->groupNames);
                throw new \Exception($msg);
			}
		}
		return true;
	}

	/**
	 * Don't allow group category to be unpublished or trashed if groups for this category exist.
	 *
	 * @param string	$extension
	 * @param array		$pks
	 * @param int		$newValue
	 * @return bool
	 */
	public function onCategoryChangeState($extension, $pks, $newValue)
	{
		if (! in_array($extension, ['com_diler.group', 'com_diler']) || $newValue === 1) return true;
		$result = true;
		if ($extension === 'com_diler.group' && $newValue !== 1)
		{
			$result = $this->checkGroupCategoryPublish($pks, $newValue);
		}
		if ($extension === 'com_diler' && $newValue !== 1)
		{
			$result = $this->checkSubjectCategoryPublish($pks, $newValue);
		}
		return $result;
	}

	// Checks whether group categories can be unpublished or trashed. If groups exist, a category may not be unpublished or trashed.
    protected function checkGroupCategoryPublish($pks, $newValue)
	{
		$app = Factory::getApplication();
		$result = true;
		$groupCountArray = $this->groupsExist($pks);
		$badPks = [];
		foreach ($groupCountArray as $groupCount)
		{
				$msg = Text::sprintf('PLG_CONTENT_DILER_GROUP_CATEGORY_DELETE_NOT_ALLOWED', $groupCount->catTitle, $groupCount->groupCount,
						$groupCount->groupNames) . '</br></br>';
				$app->enqueueMessage($msg, 'error');
				$result = false;
				$badPks[] = $groupCount->catId;
		}
		if ($badPks)
		{
			$this->categoryPublish($badPks);
			$goodPks = count($pks) - count($badPks);
			if ($goodPks > 0)
			{
				$langTags = [-1 => 'COM_CATEGORIES_N_ITEMS_TRASHED', 0 => 'COM_CATEGORIES_N_ITEMS_UNPUBLISHED', 2 => 'COM_CATEGORIES_N_ITEMS_ARCHIVED'];
				if (isset($langTags[$newValue]))
				{
					$successMsg = Text::plural($langTags[$newValue], $goodPks);
					$app->enqueueMessage($successMsg);
				}
			}
			$app->redirect(Route::_('index.php?option=com_categories&view=categories&extension=com_diler.group', false));
		}
		return $result;
	}

	// Checks whether group categories can be unpublished or trashed. If groups exist, a category may not be unpublished or trashed.
    protected function checkSubjectCategoryPublish($pks, $newValue)
	{
		$app = Factory::getApplication();
		$result = true;
		$badPks = [];
		$userCountArray = $this->getSubjectUserCount($pks);

		foreach ($userCountArray as $userCount)
		{
				$msg = Text::sprintf('PLG_CONTENT_DILER_SUBJECT_CATEGORY_DELETE_NOT_ALLOWED', $userCount->catTitle, $userCount->userCount,
						DText::_('SUBJECTS')) . '</br></br>';
				$app->enqueueMessage($msg, 'error');
				$result = false;
				$badPks[] = $userCount->catId;
		}
		if ($badPks)
		{
			$this->categoryPublish($badPks);
			$goodPks = count($pks) - count($badPks);
			if ($goodPks > 0)
			{
				$langTags = [-1 => 'COM_CATEGORIES_N_ITEMS_TRASHED', 0 => 'COM_CATEGORIES_N_ITEMS_UNPUBLISHED', 2 => 'COM_CATEGORIES_N_ITEMS_ARCHIVED'];
				if (isset($langTags[$newValue]))
				{
					$successMsg = Text::plural($langTags[$newValue], $goodPks);
					$app->enqueueMessage($successMsg);
				}
			}
			$app->redirect(Route::_('index.php?option=com_categories&view=categories&extension=com_diler', false));
		}
		return $result;
	}

    /**
     * Gets a count of users assigned to Subjects by category.
     * @param $pks
     * @return array  Array of stdClass: user_count, category_title
     */
	protected function getSubjectUserCount($pks)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('COUNT(DISTINCT du.user_id) AS userCount, c.title AS catTitle, c.id AS catId')
				->from('#__dilerreg_users AS du')
				->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = du.user_id')
				->innerJoin('#__diler_group AS dg ON dg.joomla_group_id = uum.group_id')
				->innerJoin('#__diler_group_subject_section_map AS dgssm ON dg.id = dgssm.group_id')
				->innerJoin('#__diler_subject AS s ON s.id = dgssm.subject_id')
				->innerJoin('#__categories AS c ON s.catid = c.id')
				->where('s.catid IN(' . implode(',', $pks) . ')')
				->group('s.catid')
				->having('COUNT(DISTINCT du.user_id) > 0');
		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Checks whether groups exist for DiLer group categories
	 * @param array $pks Array of category id's to check
	 * @return array of categories where groups exist: <catId> => stdClass row object: catId, catTitle, groupCount, groupNames
	 */
	protected function groupsExist($pks)
	{
		// No action required if publishing a category or no id's
		$pks = (array) $pks;
		if (! $pks) return [];
		$pks = ArrayHelper::toInteger($pks);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('c.id AS catId, c.title AS catTitle, COUNT(dg.id) AS groupCount, GROUP_CONCAT(dg.name SEPARATOR ", ") AS groupNames')
				->from('#__diler_group AS dg')
				->innerJoin('#__categories AS c ON c.id = dg.catid')
				->where('c.id IN(' . implode(',', $pks) . ')')
				->group('c.id')
				->order('c.title, dg.name');
		$rows = $db->setQuery($query)->loadObjectList();

		$result = [];
		foreach ($rows as $row)
		{
			$row->groupNames = (strlen($row->groupNames) > 200) ? HTMLHelper::_('string.truncate', $row->groupNames, 200) : $row->groupNames;
			$result[$row->catId] = $row;
		}
		return $result;
	}

	/**
	 * Reset bad categories back to published.
	 * @param array $badPks Array of categories that cannot be unpublished
	 */
	protected function categoryPublish($badPks)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__categories')->set('published = 1')->where('id IN(' . implode(',', $badPks) . ')');
		$db->setQuery($query)->execute();
	}

    /**
     * Disables the name field for Diler users in admin user edit.
     *
     * @param Form $form The form to be altered.
     * @param mixed $data The associated data for the form.
     *
     * @return  boolean
     *
     * @throws Exception
     * @since   5.3.1
     */
	public function onContentPrepareForm($form, $data)
	{
		// Make sure we are in the right context
		$input = Factory::getApplication()->input;
		$view = $input->get('view');
		$option = $input->get('option');
		$layout = $input->get('layout');
		$component = $input->get('component');
		$formName = false;
		if ($form instanceof Form)
		{
			$formName = $form->getName();
		}

		$isUserEdit = ($formName === 'com_users.user' && $option === 'com_users' && $view === 'user' && $layout === 'edit');
		$isDiLerConfig = ($formName === 'com_config.component' && $option === 'com_config' && $component === 'com_diler');
		$isEditJoomlaGroup = ($formName === 'com_users.group' && $option === 'com_users' && $view === 'group' && $layout === 'edit');

		if ($isEditJoomlaGroup)
			$this->disableEditJoomaUserGroupAndOnlyAllowIfUserConfirmToContinue();

		if ($isUserEdit)
		{
			// Determine whether the user being edited is a DiLer user
			$role = $data->id && DilerHelperUser::getDilerRole($data->id);
			if ($role)
			{
				$form->setFieldAttribute('name', 'readonly', true);
			}
		}

		if ($isDiLerConfig && ! DilerHelperUser::extendedFeatures())
		{
			$form->removeField('deviderTalkieConf');
			$form->removeField('talkieReach');
			$form->removeField('talkieReachNamespaces');
			$form->removeField('callTrialduration');
			$form->removeField('deviderTalkieServer');
			$form->removeField('talkieServerAddress');
			$form->removeField('talkieStunAddress');
			$form->removeField('talkieTurnAddress');
			$form->removeField('talkieTurnUser');
			$form->removeField('talkieTurnPassword');

			$form->removeField('deviderBulletin');
			$form->removeField('bulletinRefresh');
			$form->removeField('bulletinBootstrapsizeLeft');
			$form->removeField('bulletinBootstrapsizeRight');
			$form->removeField('deviderBulletinTop');
			$form->removeField('bulletinTop');
			$form->removeField('bulletinTopTextalign');
			$form->removeField('bulletinTopFontsize');
			$form->removeField('bulletinTopText');
			$form->removeField('bulletinTopLogo');
			$form->removeField('deviderBulletinBottom');
			$form->removeField('bulletinWeather');
			$form->removeField('deviderBulletinDisplay');
			$form->removeField('bulletinDesk');
			$form->removeField('bulletinDeskUrlTeacher');
			$form->removeField('bulletinDeskUrlStudent');
			$form->removeField('bulletinDeskUrlParent');

			$form->removeField('nimbusStudentReports');
			$form->removeField('nimbusStudentRecords');
			$form->removeField('nimbusStudentActivities');
			$form->removeField('nimbusPhraseCut');
			$form->removeField('nimbusListDelimiter');
			$form->removeField('nimbusParentTag');

			$form->removeField('cloudParentTag');
			$form->removeField('download_id');
		}
		return true;
	}
	
	private function disableEditJoomaUserGroupAndOnlyAllowIfUserConfirmToContinue()
	{
		$this->loadDilerLanguage();
		$document = Factory::getDocument();
		$document->addScript(DUrl::mediaBaseUrl() . '/administrator/js/edit_joomla_group.js');
		DText::script('ENABLE_EDIT_JOOMLA_GROUP');
		DText::script('ENABLE_EDIT_JOOMLA_GROUP_WARNING_MESSAGE');
		
	}

	/**
	 * Logs the event based on the parameters.
	 *
	 * @param string  $context  Context for the event.
	 * @param Table  $table    Table object for the event.
	 * @param string  $action   'edit' or 'delete'
	 */
	protected function logEvent($context, $table, $action, $isNew = false)
	{
		// Check for a quick exit
		if (! $this->isDilerLoggable($context, $table))
		{
			return true;
		}

		$this->loadDilerLanguage();
		$logObject = (object) array('type' => '', 'subjectId' => 0, 'competenceId' => 0, 'levelId' => 0);
		$logObject->extraInfo = isset($table->extraInfo) ? $table->extraInfo : '';
		$logObject->newOrEdit = $isNew ? DText::_('LOG_ACTION_ADDS') : DText::_('LOG_ACTION_EDITS');

		if ($context == 'com_categories.category')
		{
			$logObject->name = $table->title;
			switch ($table->extension)
			{
				case 'com_diler' :
					$logObject->type = DText::sprintf('CATEGORY_TYPE', DText::_('SUBJECT'));
					break;

				case 'com_diler.extracurriculars' :
					$logObject->type = DText::sprintf('CATEGORY_TYPE', DText::_('EXTRACURRICULAR'));
					break;

				case 'com_diler.studentrecord' :
					$logObject->type = DText::sprintf('CATEGORY_TYPE', DText::_('STUDENTRECORD_LABEL'));
					break;

				case 'com_diler.relationships' :
					$logObject->type = DText::sprintf('CATEGORY_TYPE', Text::_('COM_DILERREG_RELATIONSHIP_LABEL'));
					break;
			}
		}
		else
		{
			$logObject->name = isset($table->name) ? $table->name : '';
			switch ($context)
			{
				case 'com_diler.subject' :
					$logObject->type = DText::_('SUBJECT');
					$logObject->subjectId = $table->id;
					break;

				case 'com_diler.extracurricular' :
					$logObject->type = DText::_('EXTRACURRICULAR');
					break;

				case 'com_diler.phase' :
					$logObject->type = DText::_('PHASE');
					$logObject->name = $table->value;
					break;

				case 'com_diler.level' :
					$logObject->type = DText::_('LEVEL');
					$logObject->name = $table->title;
					$logObject->levelId = $table->id;
					break;

				case 'com_diler.competence' :
					$logObject->type = DText::_('COMPETENCE');
					$logObject->competenceId = $table->id;
					break;

				case 'com_diler.compchar' :
					$logObject->type = DText::_('COMPCHAR');
					break;

				case 'com_diler.gradingmethod' :
					$logObject->type = DText::_('GRADING_METHOD');
					break;

				case 'com_diler.activitytype' :
					$logObject->type = DText::_('ACTIVITY_TYPE');
					break;

				case 'com_diler.reportfield' :
					$logObject->type = DText::_('REPORT_FIELD');
					break;

				case 'com_diler.reportperiod' :
					$logObject->type = DText::_('REPORT_PERIOD');
					break;

				case 'com_diler.reporttype' :
					$logObject->type = DText::_('REPORT_TYPE');
					break;

				case 'com_diler.languageoverrides' :
					$logObject->type = Text::_('JFIELD_LANGUAGE_LABEL');
					break;

				case 'com_diler.dataaction' :
					$logObject->type = DText::_('PURGEDATA_SINGULAR');
					break;

				default:
					return true;
			}
		}

		// Log based on the user, action and $logObject
		$self = Factory::getUser();
		$role = DilerHelperUser::getDilerRole();
		if ($action == 'purge')
		{
			$logMessage = DText::sprintf('LOG_ADMIN_CONTENT_PURGE', $role, $self->name, $self->username, $logObject->type, $logObject->name, $logObject->extraInfo);
		}
		elseif ($action == 'delete')
		{
			$logMessage = DText::sprintf('LOG_ADMIN_CONTENT_DELETE', $role, $self->name, $self->username, $logObject->type, $logObject->name);
		}
		else
		{
			$logMessage = DText::sprintf('LOG_ADMIN_CONTENT_EDIT', $role, $self->name, $self->username, $logObject->newOrEdit, $logObject->type, $logObject->name);
		}
		$logData = array('message' => $logMessage,'subject_id' => $logObject->subjectId,
			'competence_id' => $logObject->competenceId,'level_id' => $logObject->levelId);
		$logger = new DilerLogger('admin', $action);
		$logger->addAction($logData);
	}
	
	private function loadDilerLanguage()
	{
		$language = Factory::getLanguage();
		$language->load('com_diler', JPATH_ROOT . '/administrator/components/com_diler', null, true);
	}

	/**
	 * Checks to see whether we want to log this event, based on context and $table->extension.
	 *
	 * @param string  $context
	 * @param Table  $table
	 *
	 * @return  boolean  true if this event is loggable, false otherwise.
	 */
	protected function isDilerLoggable($context, $table)
	{
		$result = false;

		if (in_array($context, $this->contextArray))
		{
			$result = true;
		}
		elseif ($context == 'com_categories.category' && in_array($table->extension, $this->extensionArray))
		{
			$result = true;
		}
		return $result;
	}

	// Check if a view level is associated with a DiLer group.
    protected function isDilerViewlevel($table)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
				->select('id')
				->from('#__diler_group')
				->where('joomla_viewlevel_id = ' . (int) $table->id);
		return $db->setQuery($query)->loadResult();
	}
	public function onBeforeDisplay(\Joomla\CMS\MVC\View\ViewInterface $view, $extension)
	{
		$input = Factory::getApplication()->input;
		//this part is to disable batch select element for applying tags on DiLer Administrator Categories (because categories have no tags)
		$isCategoriesOnAdministrator = ($input->getString('option') === 'com_categories');
		if ($isCategoriesOnAdministrator)
		{
			$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
			$wa->addInlineStyle('#batch-tag-id{display:none;}');
			$wa->addInlineStyle('#batch-tag-lbl{display:none;}');
		}

		//this part adds custom help button on DiLer Aministrator Options
		$isAdminOptionsConfigSite = ($input->getString('option') === 'com_config' && $input->getString('component') === 'com_diler');
		if (!$isAdminOptionsConfigSite)
			return;

		$bar = \Joomla\CMS\Toolbar\Toolbar::getInstance('toolbar');
		$items = $bar->getItems();
		foreach ($items as $key => $toolbarItem)
		{
			if ($toolbarItem->getName() === 'help')
				unset($items[$key]);
		}
		$bar->setItems($items);
		$url = 'https://docs.digitale-lernumgebung.de/Backend:Optionen';
		$helpText = DText::_('HELP');
		$helpButtonHTML = '<a 
		id="toolbar-help" 
		class="dilerHelp btn btn-small" 
		href= "'. $url .'" 
		target="_blank">
		<i class="icon-question-sign"></i> ' .
                $helpText .
			'</a>';

		$bar->appendButton('Custom', $helpButtonHTML, 'Help');
	}
}
