<?php
/**
 * @copyright	Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;


class PlgSystemDilerOverideCurlTransporter extends CMSPlugin
{
	public function onAfterRoute()
	{
		$app = Factory::getApplication();
		$input = $app->input;
		if (!$app->isClient('administrator') && $input->get('option') == 'com_installer' && $input->get('view') == 'update' )
			return;
		
		JLoader::register('Joomla\CMS\Http\Transport\CurlTransport', __DIR__ . '/CurlTransport.php', true);
	}
}