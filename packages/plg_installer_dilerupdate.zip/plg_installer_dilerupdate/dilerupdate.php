<?php
/**
 * @package     Diler
 * @subpackage  com_diler
 *
 * @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

use DiLer\Lang\DText;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die;

/**
 * Installation plugin. Add download id to download URL
 *
 * @package     Diler.Plugin
 * @since       3.33
 */
class PlgInstallerDilerupdate extends CMSPlugin
{
	public function onInstallerBeforePackageDownload(&$url, $headers)
	{
		// Skip processing if not updating com_diler
		if (strpos($url, 'digitale-lernumgebung.de') > 0)
		{
			$downloadId = ComponentHelper::getParams('com_diler')->get('download_id');
			if ($downloadId)
			{
				$url .= '&dlid=' . $downloadId;
				$this->enqueueMessageIfCanNotGetUpdateFile($url, $headers);
			}
		}
	}

	/**
	 * onInstallerBeforePackageDownload is only available plugin even on update.  
	 * Since we can't check did Joomla got error response from our server, we will do it before Joomla
	 * and enqueue warning to user
	 */
	private function enqueueMessageIfCanNotGetUpdateFile($url, $headers)
	{
		try
		{
			$response = HttpFactory::getHttp()->get($url, $headers);
		}
		catch (\RuntimeException $exception)
		{
			return;
		}

		// Convert keys of headers to lowercase, to accommodate for case variations
		$headers = array_change_key_case($response->headers);

		if (302 == $response->code && !empty($headers['location']))
			return;
		
		if (200 != $response->code)
		{
			Factory::getLanguage()->load('com_diler', JPATH_ADMINISTRATOR . '/components/com_diler');
			$systemInfoUrl = Uri::base() . 'index.php?option=com_diler&view=systeminformation';
			Factory::getApplication()->enqueueMessage(DText::sprintf('UPDATE_WENT_WRONG_SEND_SYS_INFO_TO_DILER_SUPPORT', $systemInfoUrl), 'error');
		}
	}
}
