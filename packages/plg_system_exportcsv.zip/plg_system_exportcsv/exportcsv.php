<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\Folder;

class PlgSystemExportCSV extends CMSPlugin
{
	protected $app;

	public function onUserLogin($user, $options = array())
	{
		if ($this->app->isClient('administrator')) {
			$this->checkAndExportCSV();
		}
	}

	protected function checkAndExportCSV()
	{
		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->select($db->quoteName('message'))
			->from($db->quoteName('#__action_logs'))
			->where($db->quoteName('message') . ' LIKE ' . $db->quote('%"app":"PLG_ACTIONLOG_JOOMLA_APPLICATION_ADMINISTRATOR"%'))
			->order($db->quoteName('log_date') . ' DESC')
			->setLimit(1);

		$db->setQuery($query);
		$message = $db->loadResult();
		$path = JPATH_ADMINISTRATOR . ('/components/com_diler/regionalteachersearchstatistic');
		if ($message) {
			$data = json_decode($message, true);
			if (isset($data['app']) && $data['app'] === 'PLG_ACTIONLOG_JOOMLA_APPLICATION_ADMINISTRATOR') {
				// Call the function to export CSV
				$this->exportStatisticsToCSV($path);
			}
		}
	}

	protected function exportStatisticsToCSV($path)
	{
		$db = Factory::getDbo();

		$table = '#__region_teacher_search_tracking';

		$query = $db->getQuery(true)
			->select('*')
			->from($db->quoteName($table));
		$db->setQuery($query);
		$data = $db->loadAssocList();

		$logs = [];
		$totalTimes = [];
		$counts = [];

		foreach ($data as $row) {
			$logs[] = $row;

			if (!isset($totalTimes[$row['event_type']])) {
				$totalTimes[$row['event_type']] = 0;
				$counts[$row['event_type']] = 0;
			}

			if (isset($row['seconds']) && is_numeric($row['seconds'])) {
				$totalTimes[$row['event_type']] += $row['seconds'];
				$counts[$row['event_type']]++;
			}

			if (isset($row['times']) && is_numeric($row['times'])) {
				$totalTimes[$row['event_type']] += $row['times'];
				$counts[$row['event_type']]++;
			}
		}

		$averages = [];
		foreach ($totalTimes as $eventType => $totalTime) {
			$averages[] = [
				'event_type' => $eventType,
				'average' => $totalTime / $counts[$eventType]
			];
		}

		$logsFilePath = $path . '/all_logs.csv';
		$averagesFilePath = $path . '/average_results.csv';

		function writeCSV($filePath, $header, $data) {
			$file = fopen($filePath, 'w');
			fputcsv($file, $header);
			foreach ($data as $row) {
				fputcsv($file, $row);
			}
			fclose($file);
		}

		if (is_dir($path)) {
			$files = glob($path . '/*.csv');
			foreach ($files as $file) {
				if (is_file($file)) {
					unlink($file);
				}
			}
		} else {
			Folder::create($path);
		}

		$logsHeader = ['id', 'time_of_saving', 'event_type', 'seconds', 'times'];
		writeCSV($logsFilePath, $logsHeader, $logs);

		$averagesHeader = ['event_type', 'average'];
		writeCSV($averagesFilePath, $averagesHeader, $averages);

		echo "CSV files have been exported to $path";
	}
}
