<?php
/**
 * @package		DiLer.Site
 * @subpackage	mod_latestmessages
 * @filesource
 * @copyright	Copyright (C) 2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

defined('JPATH_BASE') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;

JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
JLoader::register('DilerHelper', JPATH_ROOT . '/administrator/components/com_diler/helpers/diler.php');
JLoader::register('DilerHelperPdf', JPATH_ROOT . '/administrator/components/com_diler/helpers/pdf.php');
JLoader::register('DilerLogger', JPATH_ROOT . '/components/com_diler/helpers/logger.php');
JLoader::register('DiLerParams', JPATH_ROOT . '/components/com_diler/helpers/dilerparams.php');
JLoader::register('DiLerStrings', JPATH_ROOT . '/components/com_diler/helpers/strings.php');
JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');
JLoader::registerNamespace('Audivisa\\Component\\DiLer\\Site', JPATH_ROOT . '/components/com_diler/src/', false, false, 'psr4');
JLoader::registerNamespace('Audivisa\\Component\\DiLer\\Administrator', JPATH_ROOT . '/administrator/components/com_diler/src/', false, false, 'psr4');
\Joomla\CMS\HTML\HTMLHelper::addIncludePath(JPATH_ROOT . '/components/com_diler/helpers/html/');

/**
 * An example custom profile plugin.
 *
 * @package     Joomla.Plugin
 * @subpackage  User.profile
 * @since       1.6
 */
class PlgSystemDilerssl extends CMSPlugin
{

	/**
	 * Load the language file on instantiation.
	 *
	 * @var    boolean
	 * @since  3.1
	 */
	protected $autoloadLanguage = true;

    /**
     * Executes right after Joomla! has dispatched the application to the relevant component
     * Check to see if we have a login where a Diler user is already logged in. If so, execute loggout and go to loggedout view.
     * This fixes the problem where the browser back button takes you to the login screen incorrectly.
     *
     * @return  bool
     * @throws Exception
     */
	public function onAfterDispatch()
	{
		$app = Factory::getApplication();
		$input = $app->input;
		$view = $input->get('view', '');
		$option = $input->get('option', '');
		$resetItem = $input->getUint('resetItem', 0);
		$itemId = $input->getUint('Itemid', 0);
		$lang = $input->get('lang');
		if ($view == 'login' && $option == 'com_users' && $resetItem)
		{
			JLoader::register('DilerHelperUser', JPATH_BASE . '/components/com_diler/helpers');
			$dilerRole = DilerHelperUser::getDilerRole();
			if ($dilerRole)
			{
				// User was already logged into Diler, so log them out and redirect to logged out view.
				$app->logout();
				$url = 'index.php?option=com_dilerreg&view=loggedout&Itemid=' . $itemId . '&lang=' . $lang;
				$app->redirect(Route::_($url, false));
			}
		}

		return true;
	}

	/**
	 * Remove unused fields from the Category edit form for com_diler categories.
	 *
	 * @param  Form    $form Form object.
	 * @param  array    $data array of form data.
	 * @return boolean  always true.
	 */
	public function onContentPrepareForm(Form $form, $data)
	{
		$formName = $form->getName();
		if (substr($formName, 0, 32) != 'com_categories.categorycom_diler')
		{
			return true;
		}
		$form->removeField('access');
		$form->removeField('rules');
		return true;
	}

	/**
	 * Load JS to optionally remove btn-danger class from Diler component option radio buttons.
	 */
	public function onBeforeCompileHead()
	{
		if (!Factory::getApplication()->isClient('administrator'))
			return false;

		$input = Factory::getApplication()->input;
		$option = $input->get('option');
		$view = $input->get('view');
		$component = $input->get('component');
		$extension = $input->get('extension', '');
        $dilerVersionInfo = $this->getPackageVersionInfo();
		$document = Factory::getDocument();

		// Read if statement better with this table:
		// #option  	#view
		// config   	component
		// diler    	activitytype - school- reporttype - reportfield
		// dilerreg 	*
		// categories 	category
		if (($option == 'com_config' && $view == 'component' && $component == 'com_diler')
			|| ($option == 'com_diler' && in_array($view, ['activitytype','school','reporttype','reportfield']))
			|| ($option == 'com_dilerreg')
			|| ($option == 'com_categories' && $view == 'category' && substr($extension, 0, 9) == 'com_diler'))
		{
			$document->addScript(URI::root(true) . '/media/com_diler/administrator/js/diler-isis.js');

		}
        if ($option == 'com_menus' && $view == 'item' && !DilerHelperUser::isDiglu())
			$document->addStyleDeclaration('.registration-codes { display:none!important }');

        if (!DilerHelperUser::isDiglu())
			$document->addScript(Uri::root(true) . '/media/com_diler/administrator/js/hide-diglu-features.js');

        if ($option == 'com_config' && $view == 'component' && $component == 'com_diler' && DilerHelperUser::isDiglu())
            $document->addScript(Uri::root(true) . '/media/com_diler/administrator/js/diglu-required-fields.js');

		if (($option == 'com_config' && $component == 'com_diler')
			|| ($option == 'com_diler')
			|| ($option == 'com_dilerreg')
			|| ($option == 'com_categories' && substr($extension, 0, 9) == 'com_diler'))
		{
			if($dilerVersionInfo->diler_edition != 'PE'){
				$document->addStyleSheet(URI::root(true) . '/media/com_diler/administrator/css/ce-version.css');
				$document->addScript(URI::root(true) . '/media/com_diler/administrator/js/ce-version.js');
			}
			$document->getWebAssetManager()->registerAndUseStyle("diler_administrator_css", Uri::root() . 'media/com_diler/administrator/css/diler.css');
		}

		if ($option == 'com_categories' && $extension == 'com_diler.cloud')
		{
			$document->addStyleSheet(URI::root(true) . '/media/com_diler/administrator/css/hide-category-access.css');
		}

		/** @var Joomla\CMS\Document\HtmlDocument  $document */
		$document->getWebAssetManager()->registerAndUseStyle("diler_user_atum_override", Uri::root() . 'media/com_diler/administrator/css/user.css');
		return true;
	}

    private function getPackageVersionInfo()
    {
        $xmlContent = file_get_contents(JPATH_ADMINISTRATOR . '/manifests/packages/pkg_diler.xml', true);
        $extension = new \SimpleXMLElement($xmlContent);
        $dilerInstalledVersion = (string) $extension->version[0];
        $dilerInstalledEdition = (string) $extension->version[0]['data-edition'];
        $joomlaVersion = (string) $extension->dependencies->dependency[0]['version'];

        return (object) array('diler_version' => $dilerInstalledVersion,
            'diler_edition' => $dilerInstalledEdition,
            'minimum_joomla_version' => $joomlaVersion
        );
    }

    public function onTableBeforeBind($data, $src, $ignore){
        if($data->getTableName()=='#__categories'&&($src['extension']=='com_diler.group'||$src['extension']=='com_diler.relationships'||$src['extension']=='com_diler.studentrecord'||$src['extension']=='com_diler.cloud'||$src['extension']=='com_diler')) {
            $data->setLocation(0);
        }
    }

}
