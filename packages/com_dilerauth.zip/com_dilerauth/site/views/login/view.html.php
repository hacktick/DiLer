<?php
/**
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

use Joomla\CMS\MVC\View\HtmlView;

defined('_JEXEC') or die('Restricted access');

class DilerAuthViewLogin extends HtmlView
{
	protected $form;

	public function display($tpl = null)
	{
		$this->item = $this->get('Item');
		parent::display($tpl);
	}

	public function getClientName() : string
	{
		return $this->item['name'];
	}
}
