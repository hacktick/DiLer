<?php
/**
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Form\Form;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

/** @var DilerAuthViewLogin $this */

/** @var Form $form */
$form = $this->getForm();
?>
<div class="well well-small floorBox student__main">
    <p class="lead">
		<?php echo Text::sprintf('COM_DILERAUTH_SHARE_PERSONAL_INFO_WITH', $this->getClientName()); ?>
    </p>
    <p>
		<?php echo Text::sprintf('COM_DILERAUTH_YOU_ARE_ABOUT_TO_SHARE_PERSONAL_DETAILS_WITH_CLIENT', $this->getClientName()); ?>
        <br/>
        <strong><?php echo Text::_('COM_DILERAUTH_WHAT_IS_SHARED_WITH_CLIENT'); ?></strong>
    </p>
    <form action="<?php echo Uri::root() . 'index.php?option=com_dilerauth' ?>" method="post" class="form-horizontal">
		<?php foreach ($form->getFieldset() as $field) : ?>
			<?php echo $field->renderField(); ?>
		<?php endforeach; ?>
        <input name="task" type="hidden" value="client.sendCode"/>
        <input name="option" type="hidden" value="com_dilerauth"/>
		<?php echo HTMLHelper::_('form.token') ?>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-check"></i> <?php echo Text::_('COM_DILERAUTH_ACCEPT'); ?>
            </button>
            <button class="btn cancelButton" name="task" value="client.decline">
                <i class="fal fa-times"></i> <?php echo Text::_('COM_DILERAUTH_REJECT'); ?>
            </button>
        </div>
    </form>
</div>