<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\Crypt\CipherInterface;
use Joomla\Crypt\Key;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\User\UserHelper;

class DilerAuthModelToken extends BaseDatabaseModel
{
	private CipherInterface $cipher;
	private Key $key;
	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);
		$this->cipher = $config['cipher'];
		$this->key    = isset($config['key']) ? $config['key'] : $this->getStoredKey($config);
	}

	private function getStoredKey(array $config)
	{
		/** @var DilerAuthTableAccessTokens $tokenTable */
		$tokenTable = $this->getTable('AccessTokens', 'DilerAuthTable');
		$tokenTable->load(array('hashed_code' => hash('sha512', $config['code'])));

		return new Key('sodium', hex2bin($tokenTable->private_key), hex2bin($config['code']));
	}

	public function createToken(string $clientId, int $userId) : void
	{
		$token = UserHelper::genRandomPassword(72);
		$nonce = \Sodium\randombytes_buf(\Sodium\CRYPTO_BOX_NONCEBYTES);
		$this->cipher->setNonce($nonce);

		/** @var DilerAuthTableAccessTokens $tokenTable */
		$tokenTable = $this->getTable('AccessTokens', 'DilerAuthTable');
		$tokenTable->hashed_code = hash('sha512', bin2hex($this->key->getPublic()));
		$tokenTable->private_key = bin2hex($this->key->getPrivate());
		$tokenTable->client_id = $clientId;
		$tokenTable->nonce = bin2hex($nonce);
		$tokenTable->encrypted_token = bin2hex($this->cipher->encrypt($token, $this->key));
		$tokenTable->user_id = $userId;
		$tokenTable->store();
	}

	public function getTokenDetails() : array
	{
		/** @var DilerAuthTableAccessTokens $tokenTable */
		$tokenTable = $this->getTable('AccessTokens', 'DilerAuthTable');
		$tokenTable->load(array('hashed_code' => hash('sha512', bin2hex($this->key->getPublic()))));
		$this->cipher->setNonce(hex2bin($tokenTable->nonce));

		$tokenDetails = $tokenTable->getProperties();
		$tokenDetails['token'] = $this->cipher->decrypt(hex2bin($tokenTable->encrypted_token), $this->key);
		return $tokenDetails;
	}

	public function deleteToken($id) : void
	{
		/** @var DilerAuthTableAccessTokens $tokenTable */
		$tokenTable = $this->getTable('AccessTokens', 'DilerAuthTable');
		$tokenTable->delete(array($id));
	}

    public function getUserUUID($userID)
    {
        $uuid = $this->getUuidFromDB($userID);
        if(!$uuid)
            return $this->createAndGetUserUuid($userID);

        return $uuid;
    }

    private function getUuidFromDB($userId)
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);
        $query->select('uuid');
        $query->from('#__dilerauth_user_uuid');
        $query->where($db->quoteName('user_id') . ' = ' . $db->quote($userId));
        return $db->setQuery($query)->loadResult();
    }

    private function createAndGetUserUuid($userID)
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);
        $query->insert($db->quoteName('#__dilerauth_user_uuid'));
        $query->columns($db->quoteName(array('user_id', 'uuid')));
        $query->values(':user_id, :uuid');

        $uuid = $this->generateUuid();
        $query->bind(':user_id', $userID, Joomla\Database\ParameterType::INTEGER);
        $query->bind(':uuid', $uuid);

        $db->setQuery($query);

        try {
            $db->execute();
            return $uuid;
        } catch (Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    private function generateUuid() {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // Version 4
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // Variant
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
