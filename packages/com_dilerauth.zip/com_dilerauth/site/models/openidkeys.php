<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\DiLerSettings;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use phpseclib3\Crypt\Common\PublicKey;
use phpseclib3\Crypt\RSA;

class DilerAuthModelOpenIdKeys extends BaseDatabaseModel
{
    private string $keysPath;
    const PUBLIC_KEY_FILE_NAME = 'openid_public.pem';
    const PRIVATE_KEY_FILE_NAME = 'openid_private.key';

    public function __construct($config = [], MVCFactoryInterface $factory = null)
    {
        parent::__construct($config, $factory);
        $privateDilerMediaFolder = DiLerSettings::init()->getRootFileFolder();
        $this->keysPath = $privateDilerMediaFolder . '/openid-keys';
        $this->createOpenIdKeysIfNotExist();
    }

    public function createOpenIdKeysIfNotExist(): void
    {
        if (!file_exists($this->keysPath)) {
            mkdir($this->keysPath);
        }

        if (!file_exists($this->keysPath . '/openid_private.key')) {
            $privateKey = RSA::createKey();
            $privateKeyPem = $privateKey->toString('PKCS8');
            $publicKey = $privateKey->getPublicKey();

            file_put_contents($this->keysPath . '/openid_private.key', $privateKeyPem);
            file_put_contents($this->keysPath . '/openid_public.pem', $publicKey->toString('PKCS8'));
        }
    }
    public function getOpenIdPublicKey() : PublicKey
    {
        $publicKeyPem = file_get_contents($this->keysPath . '/' . self::PUBLIC_KEY_FILE_NAME);
        return RSA::loadPublicKey($publicKeyPem);
    }

    public function getPublicKeyKId() {
        return filemtime($this->keysPath . '/' . self::PUBLIC_KEY_FILE_NAME);
    }

    public function getPrivateKeyContent()
    {
        return file_get_contents($this->keysPath . '/' . self::PRIVATE_KEY_FILE_NAME);
    }
}