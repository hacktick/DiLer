<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

class DilerAuthModelConsents extends BaseDatabaseModel
{
	private int $userId;

	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);
		$this->userId = $config['user_id'];
	}

	public function getAllConsents()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__dilerauth_user_consents as consents');
		$query->innerJoin('#__dilerauth_clients as clients ON clients.id = consents.client_id');
		$query->where('user_id = ' . $this->userId);
		return $db->setQuery($query)->loadAssocList();
	}
}