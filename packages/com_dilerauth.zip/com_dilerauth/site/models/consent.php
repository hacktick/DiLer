<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

class DilerAuthModelConsent extends BaseDatabaseModel
{
	private int $clientId;
	private int $userId;

	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);
		$this->clientId = $config['client_id'];
		$this->userId = $config['user_id'];
	}

	public function saveConsent()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->insert('#__dilerauth_user_consents');
		$query->set('user_id = ' . $this->userId);
		$query->set('client_id = ' . $this->clientId);
		$db->setQuery($query)->execute();
	}

	public function doesConsentExist()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('user_id');
		$query->from('#__dilerauth_user_consents');
		$query->where('user_id = ' . $this->userId);
		$query->where('client_id = ' . $this->clientId);

		return $db->setQuery($query)->loadResult();
	}

	public function delete()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->delete('#__dilerauth_user_consents');
		$query->where('user_id = ' . $this->userId);
		$query->where('client_id = ' . $this->clientId);
		$db->setQuery($query)->execute();
	}
}