<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\FormModel;

class DilerAuthModelLogin extends FormModel
{
	private string $clientId;
	private array $clientDetails;
	private string $redirectUri;
	private string $stateFromClient;

	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);
		$this->clientId = $config['client_id'];
		$this->redirectUri = isset($config['redirect_uri']) ? $config['redirect_uri'] : "";
		$this->stateFromClient = isset($config['state_from_client']) ? $config['state_from_client'] : "";
		$this->clientDetails = $this->getItem();
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_dilerauth.login', 'login', array('control' => '', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	protected function loadFormData()
	{
		$data = parent::loadFormData();
		$data['redirect_uri'] = $this->redirectUri;
		$data['state'] = $this->stateFromClient;
		$data['client_id'] = $this->clientDetails['id'];

		return $data;
	}

	public function isValidClientId()
	{
		return $this->clientDetails['client_id'];
	}

	public function getItem()
	{
		$table = $this->getTable();
		$table->load(array('client_id' => $this->clientId, 'published' => 1));
		$columns = $table->getProperties();
		return $columns;
	}

	public function getTable($name = 'Clients', $prefix = 'DilerauthTable', $options = array())
	{
		return parent::getTable($name, $prefix, $options);
	}
}