<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;

defined('_JEXEC') or die('Restricted access');

$deleteLink = 'index.php?option=com_dilerauth&task=consent.delete&Itemid=' . Factory::getApplication()->input->getInt('Itemid');
?>

<h2><?php echo DText::_('MY_ACCOUNT_CONSENTS_LABEL'); ?></h2>
<p><?php echo DText::_('CONSENTS_DESCRIPTION') ?></p>
<table id="dilerAuthConsents" class="table table-hover">
    <thead>
        <tr>
            <th colspan="2"><?php echo DText::_("CLIENT_APP"); ?></th>
        </tr>

        <?php foreach ($displayData as $consent) : ?>
            <tr>
                <td>
		            <a href="<?php echo $consent['client_url']?>" target="_blank">
                        <?php echo $consent['name'] ?>
                    </a>
                </td>

                <td class="text-right">
                    <a href="<?php echo Route::_($deleteLink . '&client_id=' . $consent['id'], false) ?>"
                       class="unstyled icon link">
                        <i class="fal fa-trash-alt fa-fw"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </thead>
</table>
