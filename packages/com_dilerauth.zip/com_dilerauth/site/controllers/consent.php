<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilerauth/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Router\Route;

class DilerAuthControllerConsent extends BaseController
{
	private int $clientId;
	private int $userId;
	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);
		$this->clientId = $this->input->get('client_id');
		$this->userId = isset($config['user_id']) ? $config['user_id'] : Factory::getUser()->id;
	}

	public function delete()
	{
		/** @var DilerAuthModelConsent $model */
		$model = $this->getModel('Consent', '', array('user_id' => $this->userId, 'client_id' => $this->clientId));
		$model->delete();
		$this->setRedirect(
			Route::_('index.php?option=com_diler&view=diler&Itemid=' . $this->input->getInt('Itemid'), false),
			Text::_("COM_DILERAUTH_SUCCESSFULLY_DELETED_CONSENT"), 'success'
		);
		$this->redirect();
	}
}

