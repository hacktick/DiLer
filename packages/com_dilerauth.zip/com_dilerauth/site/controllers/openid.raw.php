<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilerauth/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

ini_set('display_errors', 0);

require_once __DIR__ . '/vendor/autoload.php';

use Audivisa\Component\DiLer\Administrator\Helper\DiLerSettings;
use DiLer\DataProviders\Inputs\ThumbnailParams;
use DiLer\DGet;
use DiLer\File\Thumbnail;
use DiLer\Users\DUser;
use Firebase\JWT\JWT;
use Joomla\CMS\Crypt\Cipher\SodiumCipher;
use Joomla\Crypt\CipherInterface;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\User\UserHelper;
use Joomla\CMS\Filesystem\Folder;

class DilerAuthControllerOpenId extends BaseController
{
	private string $clientId;
	private string $clientSecret;
	private string $grantType;
	private string $code;
	private CipherInterface $cipher;
	private array $clientDetails;
	private array $tokenDetails;
	private DUser $user;
	private DilerAuthModelToken $tokenModel;

	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);
		$currentUri = Uri::getInstance();
		$redirectUri = Uri::getInstance($this->input->get('redirect_uri', '', 'raw'));

		if (!$currentUri->isSsl() || !$redirectUri->isSsl())
			throw new \Exception('Only allowed to use over https');

		$input              = $this->input;
		$this->clientId     = $input->getString('client_id', '');
		$this->clientSecret = $input->getString('client_secret', '');
		$this->grantType    = $input->getString('grant_type', '');
		$this->code         = $input->getString('code', '');

		$clientModelConfig = array('client_id' => $this->clientId);
		/** @var DilerAuthModelLogin $loginModel */
		$loginModel          = $this->getModel('login', '', $clientModelConfig);
		$this->clientDetails = $loginModel->getItem();

		$this->cipher     = new SodiumCipher();
		$tokenModelConfig = array(
			'cipher' => $this->cipher,
			'code'    => $this->code
		);
		/** @var DilerAuthModelToken $tokenModel */
		$this->tokenModel   = $this->getModel('token', '', $tokenModelConfig);
		$this->tokenDetails = $this->tokenModel->getTokenDetails();
		$this->user         = isset($config['user']) ? $config['user'] : DGet::user($this->tokenDetails['user_id']);
	}

    public function getToken()
    {
        $this->denyAccessIfNotValidClientIdAndSecret();
        $this->denyAccessIfInvalidGrandType();
        $this->denyAccessIfNotValidToken();

		$personalData = $this->user->personalData();

        /** @var DilerAuthModelOpenIdKeys $opeIdKeyModel */
        $opeIdKeyModel = $this->getModel('OpenIdKeys', 'DilerAuthModel');
        $header = array(
            'typ' => 'JWT',
            'alg' => 'RS256',
            'kid' => $opeIdKeyModel->getPublicKeyKId()
        );

        $userData = array(
            'iss' => Uri::root(),
            'name' => $personalData->fullName(),
            'email' => $personalData->email(),
            'sub' => $this->tokenModel->getUserUUID($this->user->id()),
            'schoolnumber' => DiLerSettings::init()->getSchoolSerialNumber(),
            'picture' => $this->getProfileImageUrl(),
            'roles' => array($this->user->role()),
            'aud' => $this->clientId,
            'nonce' => $this->tokenDetails->nonce,
            'iat' => time(), // Issued at
            'exp' => time() + 3600, // Expiration time (1 hour)
        );

        $privateKey = $opeIdKeyModel->getPrivateKeyContent();
        $idToken = JWT::encode($userData, $privateKey, 'RS256', null, $header);
        $data = array(
            'access_token' => $this->tokenDetails['token'],
            'token_type' => "Bearer",
            'id_token' => $idToken
        );

		echo json_encode($data);

		// Once we share token we remove it from DB as we do not allow login with same token more than one
		$this->tokenModel->deleteToken($this->tokenDetails['id']);

	}

	private function denyAccessIfNotValidClientIdAndSecret(): void
	{
		if ($this->clientDetails['secret'] !== $this->clientSecret)
			throw new \Exception('Invalid client ID or secret');
	}

	private function denyAccessIfInvalidGrandType(): void
	{
		if ($this->grantType !== 'authorization_code')
			throw new \Exception('Invalid grant type');
	}

	private function denyAccessIfNotValidToken()
	{
		if (!$this->tokenDetails['token'])
			throw new \Exception('Invalid token');
	}

	private function getProfileImageUrl() : string
	{
		$user = $this->user;
		$personalData = $user->personalData();
		$picture  = $personalData->picture();
		if (!$picture)
			return "";

		$profileImagePath = \DilerHelperUser::getRootFileFolder() . DiLer\File\File::PROFILE_PICTURES_PATH . $picture;

		if (File::exists($profileImagePath))
		{
			$profileImageName = UserHelper::genRandomPassword(128) . '.' . File::getExt($picture);
			$folderInMedia = '/media/com_dilerauth/' . $user->id();
			$profilePhotoPath = JPATH_ROOT . $folderInMedia;
			$this->createFolderForStoringPublicProfilePhoto($profilePhotoPath);
			//manipulate the image to get a square one
			$thumbnailImage = $this->getCroppedImage($profileImagePath);
			imagejpeg($thumbnailImage, $profilePhotoPath . '/' . $profileImageName);
			return Uri::root() . $folderInMedia . '/' . $profileImageName;
		}

		return "";
	}

	private function getCroppedImage($imagePath, $size = 200)
	{
		//We need to do this because the ThumbnailParams is expecting Input object
		$this->input->set('height', $size);
		$this->input->set('width', $size);
		$thumbnailParams = new ThumbnailParams($this->input, $imagePath);
		$thumbnailObject = new Thumbnail();
		return $thumbnailObject->build($thumbnailParams);
	}

	private function createFolderForStoringPublicProfilePhoto($folderPath) : void
	{
		if (Folder::exists($folderPath))
		{
			// Do not keep old photos
			Folder::delete($folderPath);
		}

		Folder::create($folderPath);
	}
}
