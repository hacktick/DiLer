<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilerauth/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Uri\Uri;

class DilerAuthControllerJwks extends BaseController
{
    public function __construct($config = array(), MVCFactoryInterface $factory = null)
    {
        parent::__construct($config, $factory);

        $currentUri = Uri::getInstance();

        if (!$currentUri->isSsl())
            throw new \Exception('Only allowed to use over https');
    }

    public function uri()
    {
        /** @var DilerAuthModelOpenIdKeys $openIdKeysModel */
        $openIdKeysModel = $this->getModel('OpenIdKeys', 'DilerAuthModel');
        $publicKey = $openIdKeysModel->getOpenIdPublicKey();

        $jwkOptions = [
            'use' => 'sig',
            'alg' => 'RS256',
            'kid' => $openIdKeysModel->getPublicKeyKId()
        ];

        $jwk = $publicKey->toString('JWK', $jwkOptions);

        $jwks = json_decode($jwk, true);

        header('Content-Type: application/json');
        echo json_encode($jwks, JSON_PRETTY_PRINT);
        $this->app->close();
    }
}