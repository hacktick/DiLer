<?php
/**
 * @copyright      Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilerauth/images/agpl-3.0.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Crypt\Cipher\SodiumCipher;
use Joomla\CMS\Document\Document;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

class DilerAuthControllerClient extends BaseController
{
	private string $redirectUri;
	private string $clientId;
	private string $stateFromClient;
	private Document $document;

	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		parent::__construct($config, $factory);
		$this->redirectUri = $this->input->get('redirect_uri', '', 'raw');
		$this->clientId = $this->input->getString('client_id', '');
		$this->stateFromClient = $this->input->get('state', '', 'raw');
		$this->document = isset($config['document']) ? $config['document'] : Factory::getDocument();

		$currentUri = Uri::getInstance();
		$redirectUri = Uri::getInstance($this->redirectUri);

		if (!$currentUri->isSsl() || !$redirectUri->isSsl())
			throw new \Exception('Only allowed to use over https');
	}

	public function login()
	{
		$this->redirectToLoginPageIfNotLoggedIn();

		$modelConfig = array(
			'client_id' => $this->clientId,
			'redirect_uri' => $this->redirectUri,
			'state_from_client' => $this->stateFromClient
		);

		/** @var  DilerAuthModelLogin $model */
		$model = $this->getModel('login', '', $modelConfig);

		$this->redirectToClientWithErrorIfInvalidClientId($model);

		$this->sendCodeToClientIfConsentAlreadyExist($model->getItem()['id']);

		$this->displayConsentPage($model);
	}

	private function sendCodeToClientIfConsentAlreadyExist($clientId) : void
	{
		/** @var DilerAuthModelConsent $consentModel */
		$consentModel = $this->getModel('Consent', '', array(
			'client_id' => $clientId,
			'user_id'   => Factory::getUser()->id
		));

		if ($consentModel->doesConsentExist())
			$this->sendCode($clientId, false);
	}

	private function displayConsentPage(DilerAuthModelLogin $model)
	{
		/** @var DilerAuthViewLogin $view */
		$view = $this->getView('login', 'html');
		$view->document = $this->document;
		$view->setModel($model, true);
		$view->display();
	}

	public function decline()
	{
		$this->checkToken();
		$this->redirectToClient(array("error" => Text::_("COM_DILERAUTH_USER_REJECTED_TO_SHARE_PERSONAL_INFO")));
	}

	public function sendCode($clientId = "", $checkToken = true)
	{
		if ($checkToken)
			$this->checkToken();

		$clientId = !$clientId ? $this->input->get('client_id') : $clientId;

		if ($this->input->getInt('consent_given', 0))
		{
			/** @var DilerAuthModelConsent $consentModel */
			$consentModel = $this->getModel('Consent','', array('client_id' => $clientId, 'user_id' => Factory::getUser()->id));
			$consentModel->saveConsent();
		}
		$cipher = new SodiumCipher();
		$key = $cipher->generateKey();

		$tokenModelConfig = array(
			'cipher' => $cipher,
			'key' => $key
		);

		/** @var DilerAuthModelToken $tokenModel */
		$tokenModel = $this->getModel('Token', '', $tokenModelConfig);
		$tokenModel->createToken($clientId, Factory::getUser()->id);

		$code = bin2hex($key->getPublic());
		$this->redirectToClient(array('state' => $this->stateFromClient, 'code' => $code));
	}

	private function redirectToLoginPageIfNotLoggedIn() : void
	{
		if (!Factory::getUser()->id)
		{
			$uri = Uri::getInstance();
			$redirectUrl = base64_encode($uri->toString());

			Factory::getApplication()->setUserState('com_dilerauth.redirect_to_oauth_login', $redirectUrl);
			$this->setRedirect(Route::_(Uri::root() . 'index.php?option=com_users&view=login&return=' . $redirectUrl), false);
			$this->redirect();
		}
	}

	private function redirectToClientWithErrorIfInvalidClientId(DilerAuthModelLogin $model) : void
	{
		if (!$model->isValidClientId())
			$this->redirectToClient(array('error' => Text::_('JGLOBAL_AUTH_ACCESS_DENIED')));
	}

	private function redirectToClient(array $params) : void
	{
		$redirectUrl = $this->redirectUri . '?' . Uri::buildQuery($params);
		$this->setRedirect($redirectUrl);
		$this->redirect();
	}

}

