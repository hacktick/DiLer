<?php
/**
 * @copyright      Copyright (C) 2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

use Joomla\CMS\MVC\Controller\BaseController;

defined('_JEXEC') or die('Restricted access');

class DilerAuthController extends BaseController 
{
	protected $default_view = 'clients';
}
