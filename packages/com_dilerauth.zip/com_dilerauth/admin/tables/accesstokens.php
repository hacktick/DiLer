<?php

use Joomla\CMS\Table\Table;

/**
 * @copyright      Copyright (C) 2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilerauth/images/agpl-3.0.txt
 */

class DilerAuthTableAccessTokens extends Table
{
	public $id = "";
	public $user_id = 0;
	public $private_key = "";
	public $nonce = "";
	public $client_id = "";
	public $hashed_code = "";
	public $encrypted_token = "";

	public function __construct($db)
	{
		parent::__construct('#__dilerauth_access_tokens', 'id', $db);
	}
}

