<?php

use Joomla\CMS\Table\Table;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\User\UserHelper;

/**
 * @package        DilerAuth.Administrator
 * @subpackage     com_dilerauth
 * @copyright      Copyright (C) 2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilerauth/images/agpl-3.0.txt
 */

class DilerAuthTableClients extends Table
{
	public $secret = "";
	public $client_id = "";

	public function __construct($db)
	{
		parent::__construct('#__dilerauth_clients', 'id', $db);
	}

	public function store($updateNulls = false)
	{
		if (!$this->id)
		{
			$this->client_id = UserHelper::genRandomPassword(40);
			$this->secret = UserHelper::genRandomPassword(40);
		}
		return parent::store($updateNulls);
	}
}

