<?php
/**
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

use Joomla\CMS\MVC\Model\ListModel;

defined('_JEXEC') or die('Restricted access');

class DilerAuthModelClients extends ListModel
{
	protected function getListQuery()
	{
		$query = $this->_db->getQuery(true);

		$query->select('*');
		$query->from('#__dilerauth_clients');

		return $query;
	}
}
