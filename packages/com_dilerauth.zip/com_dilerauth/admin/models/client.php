<?php
/**
 * @package        DilerAuth.Administrator
 * @subpackage     com_dilesamlidp
 * @copyright      Copyright (C) 2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

class DilerAuthModelClient extends AdminModel
{
	protected $text_prefix = 'COM_DILERAUTH_CLIENT';

	public $typeAlias = 'com_dilerauth.client';

	public function getTable($type = 'Clients', $prefix = 'DilerAuthTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_dilerauth.client', 'client', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	protected function loadFormData()
	{
		$app  = Factory::getApplication();
		$data = $app->getUserState('com_dilerauth.edit.client.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
			$data->authorize_url = Uri::root() . 'index.php?&option=com_dilerauth&task=client.login';
			$data->token_url = Uri::root() . 'index.php?&option=com_dilerauth&task=token.getToken&format=raw';
		}

		$this->preprocessData('com_dilerauth.client', $data);

		return $data;
	}
}
