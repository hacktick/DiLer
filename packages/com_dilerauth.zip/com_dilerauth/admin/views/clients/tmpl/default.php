<?php
/**
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

/** @var DilerAuthViewClients $this */

defined('_JEXEC') or die('Restricted access');

use \Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

$items = $this->get('Items');
?>
<form action="<?php echo JRoute::_('index.php?option=com_dilerauth&view=clients'); ?>" method="post"
      name="adminForm" id="adminForm">
    <table class="table table-striped">
        <thead>
        <tr>
            <th width="1%" class="center">
		        <?php echo JHtml::_('grid.checkall'); ?>
            </th>
            <th width="1%" class="nowrap center">
		        <?php echo Text::_('JSTATUS'); ?>
            </th>
            <th class="nowrap">
				<?php echo Text::_('COM_DILERAUTH_NAME_LABEL'); ?>
            </th>
            <th>
				<?php echo Text::_('COM_DILERAUTH_CLIENT_URL_LABEL'); ?>
            </th>
            <th>
		        <?php echo Text::_('COM_DILERAUTH_CREATED_LABEL'); ?>
            </th>
            <th width="1%" class="nowrap hidden-phone">
		        <?php echo Text::_('JGRID_HEADING_ID'); ?>
            </th>
        </tr>
        </thead>
        <tbody>
		<?php
		$n = count($items);
		foreach ($items as $i => $item) :
			?>
            <tr class="row<?php echo $i % 2; ?>">
                <td class="center">
					<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
                </td>
                <td class="center">
                    <div class="btn-group">
						<?php echo HTMLHelper::_('jgrid.published', $item->published, $i, 'clients.', true, 'cb'); ?>
                    </div>
                </td>
                <td class="has-context">
                    <a href="<?php echo Route::_('index.php?option=com_dilerauth&task=client.edit&id=' . (int) $item->id); ?>">
						<?php echo $this->escape($item->name); ?>
                    </a>
                </td>
                <td class="has-context">
                    <a href="<?php echo $item->client_url ?>" target="_blank">
			            <?php echo $item->client_url; ?>
                    </a>
                </td>
                <td class="has-context">
                    <?php echo HTMLHelper::_('date', $item->created, JText::_('DATE_FORMAT_LC4')); ?>
                </td>
                <td class="has-context">
		            <?php echo $item->id; ?>
                </td>
            </tr>
		<?php endforeach; ?>
        </tbody>
    </table>
    <input type="hidden" name="task" value=""/>
    <input type="hidden" name="boxchecked" value="0"/>
	<?php echo JHtml::_('form.token'); ?>
</form>
