<?php
/**
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

defined('_JEXEC') or die('Restricted access');

class DilerAuthViewClients extends HtmlView
{
	protected $items;

	public function display($tmpl = null)
	{
		$this->items       = $this->get('Items');
		$this->addToolBar();

		if (empty($this->items))
		{
			$this->items = array();
			Factory::getApplication()->enqueueMessage(Text::_('JGLOBAL_NO_MATCHING_RESULTS'), 'warning');
		}
		return parent::display();
	}

	private function addToolBar()
	{
		ToolbarHelper::title(Text::_('COM_DILERAUTH'), 'stack article');

		ToolbarHelper::title(JText::_('COM_DILERAUTH_CLIENTS'), 'bookmark banners');

		ToolbarHelper::addNew('client.add', 'JTOOLBAR_NEW');
		ToolbarHelper::publish('clients.publish', 'JTOOLBAR_PUBLISH', true);
		ToolbarHelper::unpublish('clients.unpublish', 'JTOOLBAR_UNPUBLISH', true);

		if (Factory::getUser()->authorise('core.edit.state',	'com_dilerauth'))
			ToolbarHelper::deleteList('JGLOBAL_CONFIRM_DELETE', 'clients.delete', 'JTOOLBAR_DELETE');
	}
}
