<?php
/**
 * @package        DilerAuth.Administrator
 * @subpackage     com_dilerauth
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Form\Form;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;

/** @var DilerAuthViewClient $this */
HTMLHelper::_('jquery.framework');
HTMLHelper::_('behavior.formvalidator');

/** @var Form $form */
$form = $this->getForm();
?>
<form action="<?php echo Route::_('index.php?option=com_dilerauth&layout=edit&id=' . $form->getValue('id')); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
    <div class="form-horizontal">
        <div class="row-fluid">
	        <?php foreach ($form->getFieldset('details') as $field) : ?>
                <?php echo $field->renderField() ?>
            <?php endforeach; ?>
        </div>
    </div>
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="option" value="com_dilerauth" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>
