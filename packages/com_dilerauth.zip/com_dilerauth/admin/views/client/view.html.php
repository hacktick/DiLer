<?php
/**
 * @package        DilerAuth.Administrator
 * @subpackage     com_dilerauth
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_dilermanager/images/agpl-3.0.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

class DilerAuthViewClient extends HtmlView
{
	protected $form;

	public function display($tmpl = null)
	{
		$this->form  = $this->get('Form');

		if ($errors = $this->get('Errors'))
			throw new Exception(implode("\n", $errors), 500);

		$this->addToolbar();

		return parent::display();
	}

	private function addToolBar()
	{
		Factory::getApplication()->input->set('hidemainmenu', true);

		$isNew = ($this->get('Item')->id == 0);

		ToolbarHelper::title($isNew ? JText::_('COM_DILERAUTH_CLIENT_NEW') : JText::_('COM_DILERAUTH_CLIENT_EDIT'), 'bookmark banners');

		ToolbarHelper::apply('client.apply');
		ToolbarHelper::save('client.save');

		ToolbarHelper::cancel('client.cancel');
	}
}
