DROP TABLE IF EXISTS `#__dilerauth_user_consents`;
DROP TABLE IF EXISTS `#__dilerauth_access_tokens`;
DROP TABLE IF EXISTS `#__dilerauth_clients`;


