CREATE TABLE IF NOT EXISTS `#__dilerauth_clients`
(
    `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`       VARCHAR(256)     NOT NULL,
    `client_id`  VARCHAR(191)     NOT NULL,
    `client_url` VARCHAR(255)     NOT NULL,
    `secret`     VARCHAR(191)     NOT NULL,
    `created`    DATETIME         NOT NULL DEFAULT NOW(),
    `published`  tinyint(3)       NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE (`client_id`, `secret`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  DEFAULT COLLATE = utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__dilerauth_access_tokens`
(
    `id`              INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`         INT(11),
    `client_id`       INT(11) UNSIGNED NOT NULL,
    `private_key`     VARCHAR(128)     NOT NULL,
    `nonce`     VARCHAR(128)     NOT NULL,
    `hashed_code`     VARCHAR(128)     NOT NULL,
    `encrypted_token` VARCHAR(786)     NOT NULL,
    constraint dilerauth_access_hash_idx
        FOREIGN KEY (`client_id`) REFERENCES `#__dilerauth_clients` (`id`)
            ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE,
    CONSTRAINT uc_user_id_sp_id UNIQUE (`hashed_code`, `private_key`, `nonce`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  DEFAULT COLLATE = utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__dilerauth_user_consents`
(
    `user_id`   INT(11),
    `client_id` INT(11) UNSIGNED NOT NULL,
    FOREIGN KEY (`client_id`) REFERENCES `#__dilerauth_clients` (`id`)
        ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE,
    UNIQUE (`user_id`, `client_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  DEFAULT COLLATE = utf8mb4_unicode_ci;
