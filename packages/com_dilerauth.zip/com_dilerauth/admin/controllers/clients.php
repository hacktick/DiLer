<?php
/**
 * @package        DilerAuth.Administrator
 * @subpackage     com_DilerAuth
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_DilerAuth/images/agpl-3.0.txt
 */

use Joomla\CMS\MVC\Controller\AdminController;

defined('_JEXEC') or die('Restricted access');

class DilerAuthControllerClients extends AdminController
{

	public function getModel($name = 'Client', $prefix = 'DilerAuthModel', $config = array())
	{
		return parent::getModel($name, $prefix, $config);
	}

}
