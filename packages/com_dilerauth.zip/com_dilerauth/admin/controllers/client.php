<?php
/**
 * @copyright      Copyright (C) 2019 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_DilerAuth/images/agpl-3.0.txt
 */

use Audivisa\Component\DiLer\Administrator\Helper\DiLerSettings;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

class DilerAuthControllerClient extends FormController
{
    protected $default_view = 'client';

    public function save($key = null, $urlVar = 'id')
    {
        $privateDilerMediaFolder = DiLerSettings::init()->getRootFileFolder();

        if (!is_writable($privateDilerMediaFolder)) {
            $this->redirectBackToEditPage($privateDilerMediaFolder);
            return false;
        }

        $isSaved = parent::save($key, $urlVar);

        if ($isSaved) {
            /** @var DilerAuthModelOpenIdKeys $openIdKeysModel */
            \Joomla\CMS\MVC\Model\BaseModel::addIncludePath(JPATH_ROOT .  '/components/com_dilerauth/models/');
            $openIdKeysModel = $this->getModel('OpenIdKeys', 'DilerAuthModel');
            $openIdKeysModel->createOpenIdKeysIfNotExist();
            $this->createOpenIdConfigurationIfNotExist();
        }

        return $isSaved;
    }

    private function redirectBackToEditPage(string $privateDilerMediaFolder)
    {
        $urlVar = 'id';
        $recordId = $this->input->getInt($urlVar);
        $data = $this->input->post->get('jform', [], 'array');
        $context = "$this->option.edit.$this->context";
        $this->app->setUserState($context . '.data', $data);
        $this->setRedirect(
            Route::_(
                'index.php?option=' . $this->option . '&view=' . $this->view_item
                . $this->getRedirectToItemAppend($recordId, $urlVar),
                false
            )
        );

        $this->setMessage(Text::sprintf('COM_DILERAUTH_INVALID_DILER_MEDIA_FOLDER', $privateDilerMediaFolder), 'error');
    }

    private function createOpenIdConfigurationIfNotExist(): void
    {
       if(!file_exists(JPATH_ROOT . '/.well-known/openid-configuration')) {
           mkdir(JPATH_ROOT . '/.well-known');
           file_put_contents(JPATH_ROOT . '/.well-known/openid-configuration', json_encode(new OpenIdConnectConfigurationDTO()));
       }
    }
}

class OpenIdConnectConfigurationDTO
{
    public string $issuer;
    public string $authorization_endpoint;
    public string $token_endpoint;
    public string $userinfo_endpoint;
    public string $jwks_uri;
    public array $scopes_supported = [];
    public array $response_types_supported = [];
    public array $token_endpoint_auth_methods_supported = [];
    public bool $claims_parameter_supported = false;
    public bool $request_parameter_supported = false;
    public bool $request_uri_parameter_supported = false;

    public function __construct()
    {
        $baseUri = Uri::root();
        $this->issuer = $baseUri;
        $this->authorization_endpoint = $this->getEndpointUrl('client.login');
        $this->token_endpoint = $this->getEndpointUrl('openid.getToken&format=raw');
        $this->jwks_uri = $this->getEndpointUrl('jwks.uri&format=raw');
        $this->scopes_supported = $this->getSupportedScopes();
        $this->response_types_supported = $this->getResponseTypeSupported();
        $this->token_endpoint_auth_methods_supported = ['client_secret_post'];
    }

    private function getEndpointUrl(string $task)
    {
        return Uri::root() . 'index.php?option=com_dilerauth&task=' . $task;
    }

    private function getSupportedScopes(): array
    {
        return [
            "openid",
            "profile",
            "email"
        ];
    }

    private function getResponseTypeSupported(): array
    {
        return [
            "code",
            "token id_token",
        ];
    }
}
