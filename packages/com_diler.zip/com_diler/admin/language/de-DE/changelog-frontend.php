<?php
/**
 *
 * @package DiLer.Site
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>

<style media="screen" type="text/css">
	.changelogWrapper{height:12em;resize: vertical;overflow-y: scroll}
	.changelogBlock{border-bottom:1px dotted #ccc}
	.changelogList{list-style: none}
	.changelogList li{padding-left: 1em; text-indent: -1em;}
	.changelogList li.add {color: green;}
	.changelogList li.add:before {content: "+";padding-right:0.3em}
	.changelogList li.remove{color: red;}
	.changelogList li.remove:before {content: "-";padding-right:0.7em}
	.changelogList li.fix{color: blue;}
	.changelogList li.fix:before {content: "#";padding-right:0.5em}
	.changelogList li.misc:before {content: "•";padding-right:0.6em}
	.changelogLegende li{float: left;margin-right: 2em}
</style>

<div class="well well-small changelogWrapper">
	<div class="changelogBlock">
		<h5>7.2.7</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Stammschulanzeige repariert</li>
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.2.6</h5>
		<ul class="unstyled changelogList">
			<li class="fix">PDF-Druck in Fachgruppen repariert</li>
			<li class="fix">Neue Typen von Erziehungsberechtigten werden wieder im Frontend angezeigt</li>
			<li class="fix">Umlaute in Talkie repariert</li>
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.7.1</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.7</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.6</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.5</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.1</h5>
		<ul class="unstyled changelogList">
    		<li class="add">Schulnoten können gerundet oder abgeschnitten werden</li>
			<li class="misc">beim Teilen einer Datei steht die Checkbox zum Nachricht senden auf JA</li>
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.0.9</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.18</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bug Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.17</h5>
		<ul class="unstyled changelogList">
			<li class="add">Spitzname/Alias kann in den Accounts angegeben werden</li>
			<li class="add">im neuen Feld "Personalien" kann bei den Schülern z.B. "Brillenträger" oder "Hortkind" angegeben werden</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.16</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bug Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.15</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bug Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.14</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schulhistorie im Schülerprofil: Einschulungsdatum in die Stammdaten verschoben, Überschrift zeigt datumsabhängig "aktuelle" oder "zuletzt besuchte Schule" an</li>
			<li class="add">Aktivitäten: Hochladende Lehrkraft in Medientabelle hinzugefügt</li>
			<li class="add">Aktivitäten: bei bewerteten Aktivitäten wird nun für jeden Schritt ein eigener Status angezeigt</li>
			<li class="add">Schultagebuch: Datumsbereicheinträge sind nur noch im Expertenmodus möglich um falsche Einträge durch unerfahrene Kollegen zu verhindern</li>
			<li class="add">Eingabe eines Alias/Spitznamen für Schüler</li>
			<li class="add">Cloud: die 4 DiLer-Gruppentypen haben eigene Dropdowns</li>
			<li class="add">DigLu: Stammschule und Bereichslehrer zur Schülerinfo hinzu gefügt</li>
			<li class="add">DigLu: Benutzerrolle der Lehrkraft für Schultagebucheinträge hinzu gefügt</li>
			<li class="fix">Offline-Aktivitäten konnten teils nicht bewertet bzw. zurück gesetzt werden werden</li>
			<li class="fix">Aktivitäten: Medientabelle wurde falsch nach Datum sortiert</li>
			<li class="fix">Aktivitäten: Mediadateien wurden für gelöste Aufgaben nicht mehr angezeigt</li>
			<li class="fix">Aktivitäten: Kompchars fehlten wenn Aufgabentypen abgeschaltet sind</li>
			<li class="fix">Nimbus: Schlagwörter fehlten</li>
			<li class="fix">Nimbus: Plugin für COM_DILER_NIMBUS_PLUGINS_SUCCEEDED_WITH_SUPPORT fehlte</li>
			<li class="fix">Reportdruck hatte das Schuljahr nicht korrekt in den Dateinamen eingefügt</li>
			<li class="fix">Schultagebuch: Buttons zum Ablegen auf dem Server waren verschwunden</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.13</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Registrierung neuer Benutzer war nicht möglich</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.12</h5>
		<ul class="unstyled changelogList">
			<li class="misc">Zugang zu Aktivitäten abgeschlossener Kompetenzen wurde wieder eingeschaltet</li>
			<li class="fix">Stundenplan wird wieder korrekt angezeigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.11</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Funktionen für PEP</li>
			<li class="fix">Avatar hat in Kora-Ansicht gefehlt</li>
			<li class="fix">Anzahl Gruppenmitglieder war falsch, da auch gesperrte Nutzer mitgezählt wurden</li>
			<li class="fix">Schwachstelle in Datenbankabfrage</li>
			<li class="fix">keine Rückmeldung der Oberfläche nach Zugangserlaubnis zu einem Test</li>
			<li class="fix">weitere kleine Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.10</h5>
		<ul class="unstyled changelogList">
			<li class="add">Online-Status: vor den Namen der Schüler oder auf ihren Profilbildern wird ein Indikator für ihren Online-Status in drei Farben angezeigt: grau = offline, orange = online, grün = online und aktiv</li>
			<li class="add">unter den Namen der Schüler wird Lerngruppe/Klasse, Klassenstufe, Zug angezeigt</li>
			<li class="add">Geburtsort ist nun Pflichtfeld</li>
			<li class="add">Persönliche Daten: Dummy-E-Mail-Adressen werden nicht mehr angezeigt, das Feld ist in dem Fall leer, damit niemand versucht an die Dummy-E-Mail-Adressen eine Nachricht zu senden</li>
			<li class="add">Persönliche Daten: bestätigte Nutzungsbedingungen können eingesehen werden</li>
			<li class="add">Persönliche Daten: Klassenstufe Ist/Soll wird immer angezeigt, da nun integraler Bestandteil der Schülerdaten</li>
			<li class="add">Cloud und Aktivitäten: Aktion bei existierender Datei kann definiert werden</li>
			<li class="add">Cloud: es kann nun auch nach "Erstellt von" gesucht werden</li>
			<li class="add">Nimbus: nur die eigenen Phrasen können auf "privat" gesetzt werden</li>
			<li class="add">Stundenplan: für jede Stunde kann einen Notiz angeglegt werden, die bei den Schülern im Stundenplan angezeigt wird</li>
			<li class="add">Lemas PEP: Teilnahme kann in den persönlichen Daten der Schüler eingestellt werden, was dann zwei weitere Reiter im Schüler anzeigt</li>
			<li class="misc">Texter: Falls eine Nachricht wegen fehlender Internetverbindung nicht gesendet werden kann erscheint ein Hinweis.</li>
			<li class="fix">Bemerkungsfelder in persönlichen Daten konnten bestimmte Zeichen nicht verarbeiten</li>
			<li class="fix">Schultagebuch: Filteroption "Schuljahr" funktionierte nicht</li>
			<li class="fix">PDF-Betrachter: Links im PDF sind nun klickbar</li>
			<li class="fix">Schülerliste: Zeit des letzten Logins war UTC, ist jetzt die im Backend eingestellte Zeitzone</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.9</h5>
		<ul class="unstyled changelogList">
			<li class="misc">Schultagebuch: Filter direkt über die Tablle gesetzt</li>
			<li class="misc">Cloud: Dateisuche um Namen des Hochladenden erweitert und Filter direkt über die Dateientablle gesetzt</li>
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.8</h5>
		<ul class="unstyled changelogList">
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.7</h5>
		<ul class="unstyled changelogList">
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.6</h5>
		<ul class="unstyled changelogList">
			<li class="add">Texter: Text kann formatiert werden</li>
			<li class="add">Schultagebuch: Hinweis zu bereits vorhandenen Einträgen im Home Schooling enthält die Namen der betreffenden Schüler:innen</li>
			<li class="fix">manche Stundplaneinträge ließen sich nicht löschen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.5</h5>
		<ul class="unstyled changelogList">
			<li class="add">die "verantwortliche Lehrkraft" wird überall beim Klassennamen mit angezeigt</li>
			<li class="add">Anzeige des Gruppenbildes neben dem Gruppennamen</li>
			<li class="add">Administration: im Kora kann direkt in der Kompetenz zwischen den Levels gewechselt werden</li>
			<li class="fix">Texter: bei manchen Installationen konnte keine Nachricht an "alle" Eltern gesendet werden</li>
			<li class="fix">Texter: manche Lehrkräfte erhielten Systemnachrichten der Parallelklassen</li>
			<li class="fix">Administration: für manche Benutzer wurde der Filter in "Gruppen" nicht zurück gesetzt</li>
			<li class="fix">Administration: manche Listen hatten eine falsche Anzeige der Reihenfolge</li>
			<li class="fix">Aufgaben: manche Schüler konnten keine Antworten hoch laden</li>
			<li class="fix">Aufgaben: einige Mediendateien wurden bei Schülern nicht angezeigt</li>
			<li class="fix">Aktivitäten: bei Aktivitäten mit Zugangskontrolle (Test, Gelingensnachweis) kam es mitunter zu einem Datenbankfehler</li>
			<li class="fix">Schulnotentabelle: manche Schulnoten waren in der Tabelle verschoben</li>
			<li class="misc">Cloud: Überschrift zeigt aktuelle Gruppe an, Gruppenauswahlfeld prominent platziert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.4</h5>
		<ul class="unstyled changelogList">
			<li class="misc">Schüler-Info-Popup: Liste der zugewiesenen Gruppen ist wieder verfügbar (unterhalb des Stundenplanes)</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Administration: Gruppen kann ein Bild zugeordnet werden (wird später für Zertifikate usw. verwendet)</li>
			<li class="add">Administration: Gruppen (außer Lerngruppen) kann Raum und Zeitfenster zugeordnet werden, woraus sich dann der Stundenplan für die SuS ergibt</li>
			<li class="add">Anzeige des Stundenplans im Infofenster der SuS</li>
			<li class="add">Administration: Eltern können den Gruppen ihrer Kinder zugeordnet werden, womit sich dann z.B. Kalender pro Klasse einrichten lassen</li>
			<li class="add">Persönliche Daten: es kann eine "Familien-E-Mail" definiert werden, damit können z.B. Kinder ohne eigene E-Mail ihr Passwort zurück setzen</li>
			<li class="add">Home Schooling wird über extra Kategorie im Schultagebuch ausgewiesen und im Notifier bei Fehltagen angezeigt</li>
			<li class="add">beim Hochladen eines Profilbildes kann dies vor dem Speichern manipuliert werden</li>
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.10.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Alle Filter haben nun einen "zurücksetzen"-Button</li>
			<li class="add">Lehrkräfte können sich als "Verantwortliche" zu Lerngruppen zuweisen, z.B. als Klassenlehrer</li>
			<li class="add">bei den persönlichen Daten jedes Schüler kann eine Lehrkraft private Notizen und Dateien hinzufügen</li>
			<li class="add">Anzahl der enthaltenen Aktivitäten wird im Kompetenzraster angezeigt</li>
			<li class="add">Mein Account: Persistente Filter können ein-/ausgeschaltet werden</li>
			<li class="misc">"Lehrkräfte sind nun automatisch immer allen Lerngruppen zugewiesen" wurde entfernt und das bisherige Verhalten wieder eingebaut, da sich diese Autozuordnung in der Praxis nicht bewährte</li>
			<li class="fix">Bedienelemente werden erst aktiv, wenn der Inhalt komplett geladen ist</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.9.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Administration/Gruppen: Gruppen werden nun immer angezeigt, nur die Aktionen sind nicht verfügbar bei fehlender Berechtigung</li>
			<li class="add">Kompetenzraster: Lehrkräfte können zu Aufgaben korrigierte Dokumente zurück hochladen</li>
			<li class="add">Kontakte: QR-Code zum Scannen der vCard</li>
			<li class="add">Schulnotenübersicht in Lerngruppenansicht mit PDF-Druck</li>
			<li class="add">Lehrkräfte sind nun automatisch immer allen Lerngruppen zugewiesen; damit können immer alle Schüler gesehen werden; Texter-Systemnachrichten werden versendet, wenn Schüler und Lehrkraft der selben Fach-/Wahlangebot-/Sonstigen Gruppe angehören, die Lerngruppe wird nicht mehr berücksichtigt</li>
			<li class="add">Mein Account: Reiter "Privatspähre" hinzugefügt (wird in Kürze weiter ausgebaut)</li>
			<li class="add">Schultagebuch: Kategoriefilter erweitert um "gewählte Kategorie ausschließen"</li>
			<li class="add">Talkie: beim Screensharing können beide Videostreams durch Tap/Klick umgeschaltet werden, was vor allem für die Empfänger hilfreich ist</li>
			<li class="add">Talkie: verbesserte Benutzerführung für Konferenzen</li>
			<li class="fix">Notifier: HTML Markup in Schulnachrichten wird nun korrekt angezeigt</li>
			<li class="fix">Notifier: es werden nun ALLE abwesenden Schüler angezeigt, sortiert nach un-/entschuldigt</li>
			<li class="fix">Schultagebuch: Filter für Suchbegriff repariert</li>
			<li class="fix">Schultagebuch: Filter für Schülereinträge hatte bei Eltern nicht funktioniert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.8.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Texter: neue Filtereinstellung "Ungelesene Nachrichten"</li>
			<li class="add">Texter: Systemnachrichten werden nun in der Sprache des Empfängers angezeigt, nicht der des Senders</li>
			<li class="add">vCard-Export für Kontakte</li>
			<li class="add">Schultagebuch: Anzahl der Einträge wird im Tabellenkopf angezeigt</li>
			<li class="misc">Anrede und Titel in ein einziges Textfeld "Anrede" vereinigt</li>
			<li class="fix">Fehler bei der PDF-Generierung behoben</li>
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.7.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Texter: kurze Sendebestätigung nach Versand einer Nachricht</li>
			<li class="add">Cloud: Gruppenname wird in der Überschrift angezeigt</li>
			<li class="add">Notifier: Benutzeravatar wird angezeigt</li>
			<li class="add">Persönliche Daten: Benutzername der Schüler und Eltern wird angezeigt</li>
			<li class="add">Mein Account: Bemerkungsfeld, das dann unter "Kontakte" angezeigt wird</li>
			<li class="add">Mein Account: Passwortfeld wird immer angezeigt, damit Benutzer sehen, dass es hier geändert werden kann</li>
			<li class="add">Talkie: Neuer Mechanismus für Funktion hinter Firewall. Die Browser versuchen erst eine direkte Verbindung aufzubauen. Wenn diese nicht zustandekommt wird automatisch über den DiLer TURN Server und damit Port 443 verbunden.</li>
			<li class="add">Administration: neben den Aufgaben selbst benutzt nun auch der Beschreibungstext der Aktivität den eingestellten WYSIWYG-Editor</li>
			<li class="fix">Administration: Dateien ließen sich nicht mehr zu Aufgaben zuordnen</li>
			<li class="fix">Systemnachrichten: Nachricht wird nun in der Sprache des Empfängers angezeigt anstatt der Sprache des Absenders</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.6.3</h5>
		<ul class="unstyled changelogList">
			<li class="fix">einige Bugs beseitigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.6.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Mein Account: Notifier: Anzeige neuer Schultagebucheinträge</li>
			<li class="add">Schultagebuch: im Gruppeneintrag können Schüler einzeln gewählt werden</li>
			<li class="misc">Schultagebuch: in der Gruppenansicht werden 3/10 Tage für alle Schüler sofort geladen, ältere nach Bedarf</li>
			<li class="fix">einige Bugs beseitigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.6.1</h5>
		<ul class="unstyled changelogList">
			<li class="fix">einige Bugs beseitigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.6.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Talkie: Screen Sharing</li>
			<li class="add">Mein Account: neue Talkie-Einstellung: Button-Untertitel anzeigen</li>
			<li class="add">Texter: Systemnachricht bei Beantwortung einer Aufgabe</li>
			<li class="add">Texter: Volltextsuche</li>
			<li class="add">Texter: Nachricht an mehrere Gruppen senden</li>
			<li class="add">PDF werden nun immer direkt in DiLer angezeigt, unabhängig von der Einstellung im Browser</li>
			<li class="add">Schulnoten: in Fachgruppen werden die Schulnoten als Matrix angezeigt</li>
			<li class="add">erzeugte PDF können optional auf dem Server abgelegt werden, diese stehen dann im Reiter "Statistik" bei den Schülern bereit</li>
			<li class="add">Notifier: Anzeige heute fehlender Schüler (sofern die Berechtigung dafür vorhanden ist)</li>
			<li class="add">Notifier: Anzeige neuer Schultagbucheinträge</li>
			<li class="add">Schülerkartei: zu jedem Notiztyp können Dateien hinterlegt werden</li>
			<li class="add">Info am Schüler, wenn Notizen oder Dateien vorhanden sind</li>
			<li class="add">Aufgaben: es können in der Aufgabenstellung und in der Lösung statt bisher nur einer Datei nun mehrere Dateien hoch geladen werden</li>
			<li class="misc">Kontakte: eingeloggter Benutzer wird als Standard angezeigt, Oberfläche überarbeitet</li>
			<li class="fix">Ladezeit in allen Ansichten verkürzt</li>
			<li class="fix">Gruppen-ID aus Gruppennamen entfernt</li>
			<li class="fix">Statistik für Schüler wird permanent angezeigt</li>
			<li class="fix">Texter: Systemnachrichten werden nur noch an die Fachgruppen des betroffenen Zuges gesendet</li>
			<li class="fix">Administration: Berechtigungen zum Bearbeiten von Gruppen korrigiert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.5.4</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Talkie: Fenster öffnen/schließen</li>
			<li class="fix">Aufgaben: Speichern und Hochladen von Antworten hat teilweise nicht funktioniert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.5.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Talkie: neue Option in Mein Account: Talkie bei Login automatisch starten</li>
			<li class="add">Fehltage: können nun für einen Datumsbereich eingegeben werden</li>
			<li class="fix">weiße Seite nach Login</li>
			<li class="fix">Schüler konnten teilweise ihre Antworten in den Übungen nicht speichern</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.5.2</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Frontend Administration: manche Benutzer ließen sich nicht sauber zuordnen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.5.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Benutzergruppen: Klassenstufe und Zug werden bei Fachgruppen angezeigt</li>
			<li class="add">Cloud: Schlagworte können mit UND oder ODER genutzt werden</li>
			<li class="add">Cloud: "Link kopieren" eingebaut</li>
			<li class="add">Cloud: Eltern erhalten eine Texter-Nachricht für Cloud-Uploads vom Typ "Schule", sofern Berechtigung erteilt</li>
			<li class="add">Anzahl der Kompetenzen im Fach kann optional in der Fächernavigation angezeigt werden</li>
			<li class="add">Reporte: im Reiter "Reporte einpflegen" werden die leeren Felder in der Feldgruppenüberschrift aufgelistet</li>
			<li class="add">Reporte: im Reiter "Reporte einpflegen" zeigt die Feldgruppenüberschrift nur dann fehlende Felder an (orange gefärbt), wenn die leeren Felder die Option "Auf fehlende Daten hinweisen" JA gesetzt haben</li>
			<li class="add">Reporte: im Reiter "Reporte einpflegen" werden Schulnotenfelder nur für Schüler mit "Schulnoten anzeigen" = Ja angezeigt</li>
			<li class="add">Texter: Eltern dürfen an mehrere Lehrkräfte gleichzeitig schreiben, sofern im Backend eingschaltet</li>
			<li class="add">Texter: Eltern als Absender enthalten die Namen ihrer Kinder</li>
			<li class="add">Aktivitäten: Maximalpunkte und Dezimalstellen können frei gewählt werden</li>
			<li class="add">Schultagebuch: gleiche Filter in Gruppenansicht wie in Schüleransicht</li>
			<li class="add">Anzeige Schülerprofilbild neben dem Schülernamen, abhängig von der Einstellung im Backend unter "Sicherheit"</li>
			<li class="add">Kompetenzraster: Beschreibungen können Bilder, Tabellen und Textformatierungen enthalten, am besten eigenet sich der kostenlose JCE-Editor (kann über das Backend installiert werden)<li>
			<li class="add">Schülerinfo enthält Zuordnungen zu allen 3 Gruppentypen</li>
			<li class="add">Mein Account: Lehrkräfte können sich neben den Lerngruppen auch allen anderen Gruppen automatisch zuordnen lassen</li>
			<li class="add">Administration: Navigation verständlicher gemacht indem die Benutzerzuordnung nun ein Untermenüpunkt von Gruppen ist</li>
			<li class="add">Texter: neuer Button "Meine Konversationen" in der Schüleransicht; zeigt ausschließlich persönliche Nachrichten an und gesendet/empfangen gleichzeitig</li>
			<li class="add">Texter: neues Icon "Konversation anzeigen" in der Schüleransicht; zeigt ausschließlich diese zusammen hängenden Nachrichten an</li>
			<li class="add">Mein Account: Land/Bundesland hinzugefügt</li>
			<li class="misc">Berechtigungen: Autozuordnungen für Gruppen sind nur möglich, wenn die Lehrkraft die Berechtigung zur Benutzerzuordnung besitzt</li>
			<li class="fix">Cloud: Notifier wurde nicht aktualisiert, wenn eine Cloud-Nachricht gelesen wurde</li>
			<li class="fix">Reporte: im Reiter "Reporte einpflegen" werden Schulnotenfelder nur dann angezeigt, wenn der Schüler "Schulnoten anzeigen" auf JA gesetzt hat</li>
			<li class="fix">Cloud: Schüler erhielten eine Texter-Nachricht für unzutreffende Cloud-Uploads</li>
			<li class="fix">2FA verfügbar für alle Benutzer</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.4.0</h5>
		<ul class="unstyled changelogList">
			<li class="misc">Gruppenzuordnungen: Lehrer und Schüler werden nun getrennt angezeigt; die Buttons sind Rollen spezifisch, um die Bedienung intuitiver zu gestalten</li>
			<li class="fix">iOS Bug: Sliders konnten nicht geöffnet werden, z.B. bei Nimbus Phrasen</li>
			<li class="fix">Gruppen und Schüler konnten unter bestimmten Bedingungen nicht gelöscht werden</li>
			<li class="fix">Schultagebuchdatum war Serverdatum statt Konfigurationsdatum</li>
			<li class="fix">alle Listen respektieren nun die Sortierung der Gruppen aus der Administration</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3.3</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Schulnotenrechner: unter bestimmten Bedingungen wurde keine Phase an die Schulnoten vergeben</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3.2</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Reporte: Kopfzeile im PDF fehlte</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schulnotenrechner: Schulnoten bleiben über das Jahr erhalten auch wenn der Schüler aus einer Lehrfachgruppe entfernt wird</li>
			<li class="add">Schulnotenrechner: Niveau hinzugefügt</li>
			<li class="add">Texter: Nachrichten werden automatisch endgültig aus DiLer gelöscht, nachdem sie 30 Tage im Papierkorb gelegen haben</li>
			<li class="fix">Schultagebuch: Zukunftseinträge wurden für Schüler und Eltern nicht angezeigt</li>
			<li class="fix">Reporte: in den Textfeldern für die Anlage hat Nimbus nur teilweise funktioniert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Zeugnisvorlagen des KM BW zum Download bereit</li>
			<li class="add">neuer Report: Unfallanzeige zum Download bereit</li>
			<li class="add">Texter: Anzeige der Zeitraum-Buttons entsprechend der Einstellung zur automatischen Löschung in den DiLer Optionen im Backend</li>
			<li class="misc">BITTE BEACHTEN: Die Schulnoten sind bis zum nächsten Update nicht bearbeitbar</li>
			<li class="misc">BITTE BEACHTEN: Die WYSIWYG-Eingabe für die Reporte funktioniert nur in Firefox korrekt.</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schultagebuch: Klassenbucheintrag</li>
			<li class="add">Bewertungsmethode wird nun immer in bewertbaren Aktivitäten angezeigt, auch wenn nur eine einzige Methode veröffentlicht ist</li>
			<li class="add">Reporte/Zeugnisse mit WYSIWYG-Eingabe</li>
			<li class="add">Gruppenansicht: "heute fehlen:" in Infobox</li>
			<li class="add">"Reporte drucken" wird bei Reiterwechsel aktualisiert, kein Neuladen der Seite zum Aktualisieren mehr notwendig</li>
			<li class="add">Texter: bei Sortierung der Tabelle Anzeige in Blöcken von zusammengehörigen Nachrichten, z.B. Absender</li>
			<li class="add">"Mein Account": neue Option für Anzeige der Texter-Nachrichten</li>
			<li class="add">"Mein Account": Adresse erweitert um Land und Bundesland</li>
			<li class="add">Gruppenansicht: für bessere Übersicht können die Angaben zu den Fächern über einen Button pro Gruppe angezeigt/versteckt werden</li>
			<li class="add">Notenrechner: erste Ausbaustufe</li>
			<li class="add">Cloud: Beschreibung und Schlagwörter zu allen Dateien gleichzeitig anzeigen</li>
			<li class="add">Klassen orientierte Fächerzuordnung möglich durch Zuordnung von mehreren Fächern pro Gruppe</li>
			<li class="fix">das zuletzt gewählte Zeugnisformular und die zugehörigen Filter werden pro Schüler bzw. Gruppe gespeichert</li>
			<li class="fix">Züge erscheinen im Frontend entsprechend der Sortierung im Backend</li>
			<li class="fix">Schultagebuchfilter werden nun auch bei Schülern und Eltern gespeichert</li>
			<li class="fix">Cloud: bei Uploads nur für Lehrer werden Texter-Nachrichten nur noch an Lehrer gesendet</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.3.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">semistatische Variante der BW LEB</li>
			<li class="fix">diverse kleine Bugs behoben</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.3.1</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Gruppenansicht: Reportdaten einpflegen: auch für statische Reporte werden nun nur die Felder des aktuell gewählten Reportes angezeigt</li>
			<li class="fix">"Meine Fächer" wird für statische Reporte nicht mehr angezeigt, da ohne Auswirkung</li>
			<li class="fix">Benutzungshinweis in Reiter "Reporte einpflegen" kann ausgeblendet werden</li>
			<li class="fix">Filter in den Reitern "Reporte einpflegen" und "Report drucken" sind synchronisiert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Statistik Schülerprofil: Fehltage nach Schuljahren, Registrationsdatum, Letzter Login</li>
			<li class="add">Cloud: Dateien sind nach Spalten sortierbar</li>
			<li class="add">Mein Account: Expertenmodus</li>
			<li class="add">Gruppen: neuer Typ steht zur Verfügung, um z.B. Exkursionen oder das Kollegium zu organisieren</li>
			<li class="add">Gruppenansicht: Filterzeitraum "Schuljahr" hinzugefügt</li>
			<li class="add">Gruppenansicht: Tabellenansicht hinzugefügt; Status, Funktion, Registrationsdatum, Letzter Login hinzugefügt</li>
			<li class="add">alle Filtereinstellungen werden permanent gespeichert</li>
			<li class="add">Registrierung für Schüler: Geburtsort hinzugefügt</li>
			<li class="misc">Schülerliste: die Liste kann direkt in die Zwischenablage kopiert werden</li>
			<li class="misc">Reporte drucken: "aktualisieren"-Button durch automatische Aktualisierung bei Klick auf Reiter ersetzt</li>
			<li class="misc">Registrierung für Schüler: Default-Einstellung für Parameter "Zensuren anzeigen" ist JA</li>
			<li class="fix">Reporte drucken nun mit neuem PDF-Drucker</li>
			<li class="fix">Gruppenzuordnung: "ich"-Button funktioniert unabhängig von der gesetzten Benutzerrolle</li>
			<li class="fix">Cloud: Eltern können nun die Gruppe ihrer Kinder auswählen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Cloud: Lehrer sehen die Berrechtigungen für den jeweiligen Reiter</li>
			<li class="add">Administration - Benutzerzuordnungen: Filtereinstellungen werden gespeichert</li>
			<li class="fix">Cloud: DragnDrop wird nur angezeigt, wenn der Benutzer die Erlaubnis hat zum Hochladen</li>
			<li class="fix">Schultagebuch: Kommentar bei neuem Fehltag lies sich nicht speichern</li>
			<li class="fix">Cloud: Datei für Schüler: Texter-Benachrichtigung wurde auch an Eltern gesendet</li>
			<li class="fix">Lehrersicht auf Schüler: weiße Seite wurde verursacht durch falsche Datumsformatierung nach Joomla-Update</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schultagebuch: PDF-Druck</li>
			<li class="add">Schultagebuch: Zukunftseinträge lassen sich ausblenden</li>
			<li class="add">Administration: Löschen von Gruppen vereinfacht - Benutzer müssen vorher nicht mehr entfernt werden</li>
			<li class="add">Administration: beim Verschieben von Schülern in die nächsten Klassenstufe lassen sich die betroffenen Fächer einzeln definieren</li>
			<li class="fix">Administration: Schüler ließen sich unter gewissen Umständen nicht über die Stapelverarbeitung einer neuen LG zuordnen</li>
			<li class="fix">Cloud: Dateien werden nun korrekt entsprechend der gewählten Gruppe geladen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">WYSIWYG-Editor für Aufgabenbeschreibungen</li>
			<li class="add">Schüler können in andere Gruppen in einem einzigen Schritt verschoben werden</li>
			<li class="add">Neue Dateneinheit "Zug" für mehrzügige Schulen: Fachgruppen können Zügen zugeordnet werden</li>
			<li class="add">Texter: Nachricht bei neuer Datei über die Cloud</li>
			<li class="add">Schülerprofil: neue Eigenschaft "Einschulungsdatum"</li>
			<li class="add">Schülerprofil: neue Eigenschaft "Geburtsort"</li>
			<li class="add">Schülerprofil: neue Eigenschaft "Soll/Ist-Klassenstufe"</li>
			<li class="add">Schülerprofil: neue Eigenschaft "Status", z.B. für Befähigungs- oder Erlaubnisstufen, Anzeige unter dem Namen des Profils</li>
			<li class="add">alle Benutzerprofile: neue  Eigenschaft "Funktion", Anzeige unter dem Namen des Profils</li>
			<li class="add">Mein Account: neue Option für "Nachricht bei neuer Cloud-Datei" für welche Cloudtypen</li>
			<li class="fix">Schultagebuch: Fehltage ließen sich doppelt eintragen</li>
			<li class="fix">Nimbus: Plugins für Status "verfügbar" und "erfolgreich mit Unterstützung" fehlten</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.0.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Mein Account: automatische Zuordnung zu neuen Lerngruppen</li>
			<li class="add">Historie der Schulbesuche im Schülerprofil</li>
			<li class="add">Beurteilungsinformation im Schülerprofil</li>
			<li class="add">Schreibtisch-Hintergrundbild global und pro Benutzer änderbar (Lehrer schalten das Feature für jeden Schüler individuel frei)</li>
			<li class="add">Cloud zum schulinternen Dateitausch</li>
			<li class="add">Gruppenverwaltung flexibilisiert, mit Stapelverarbeitung</li>
			<li class="add">Bulletin: Ansicht optional für Lehrer, Schüler, Eltern vom Schreibtisch aus zu erreichen mit optional unterschiedlicher Anzeige</li>
			<li class="add">Schülerliste in Gruppenansicht: verschiedene Formatierungen, zusätzliche Daten</li>
			<li class="fix">alle Mini-Kalender und Dropdowns überarbeitet für bessere Performance auf Touchscreens</li>
			<li class="fix">Texter Button ist abgeschaltet, wenn für den Schüler keine Eltern eingetragen sind</li>
		</ul>
	</div>
<?php /*
	<div class="changelogBlock">
		<h5>5.4.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Hilfetext zur Dateneingabe für die Baden-Württemberg-KM LEB</li>
			<li class="add">Schüleraccount: weiteres Feld "Lehrernotiz"; editierbar für alle Lehrer; sichtbar für alle Lehrer, diesen Schüler, des Schülers Eltern</li>
			<li class="fix">Schultagebuch: Schülername wird wieder angezeigt bei neuem Eintrag</li>
			<li class="fix">Phasenzuardnung funktioniert nun auch mit SEF=1</li>
			<li class="fix">Fehler in Sprachdatei für Reportdruck behoben ("2. Schulhalbjahr")</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.4.1</h5>
		<ul class="unstyled changelogList">
			<li class="add"><strong>Notifier - DiLer</strong>: Rollen spezifische Infos zu Updates usw. direkt von DiLer</li>
			<li class="add"><strong>Notifier - Schulnachrichten</strong>: Rollen spezifische Infos von der Schule</li>
			<li class="add"><strong>Texter</strong>: Systemnachricht zu bewerteter Aktivität enthält jetzt neben der erreichten Punktzahl auch die maximal erreichbaren Punkte und die daraus resultierenden Prozent sowie erreicht/verfehlt</li>
			<li class="add"><strong>Texter</strong>: Nachricht an Eltern senden im Texter der Schüler</li>
			<li class="add">Button für Klassenbucheinträge in Lerngruppenansicht</li>
			<li class="add">Datum und Lehrkraft an Aktivitäten sichtbar</li>
			<li class="add">Option in "Mein Account": Weiterleitung nach Login</li>
			<li class="add">Option "Zugang nach Abschluss" für Aktivitäten</li>
			<li class="misc">Menüpunkt "Datenpflege" heißt jetzt "Administration"</li>
			<li class="misc">Menüpunkte für Bulletin Administration in Administration verlegt</li>
			<li class="fix">Anrede in "Mein Account" wurde nicht mehr gespeichert</li>
			<li class="fix">Dropdowns für mobile Geräte überarbeitet</li>
			<li class="fix">Texter: Sonderzeichen werden nicht mehr heraus gefiltert</li>
			<li class="fix">abgeschaltete Schüler wurden in der Gruppensicht angezeigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.4.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Benachrichtigungsleiste in Vorbereitung auf den <strong>DiLer Notifier</strong></li>
			<li class="remove">Modul mit Abmeldebutton ist jetzt Teil der Benachrichtigungsleiste</li>
			<li class="fix">diverse Bugs geseitigt</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.12</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Reporte: Fachfelder wurden nicht angezeigt</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.11</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte: Filter für Fächer</li>
			<li class="add">Reporte: Filter für Kompetenzenstatus (sofern der gewählte Report Kompetenzen enthält)</li>
			<li class="fix">Kategoriewahl im Schultagebuch</li>
			<li class="fix">unterster Eintrag im Schultagebuch war nicht vollständig sichtbar</li>
			<li class="fix">falscher Link in den Breadcrumbs in Datenpflege</li>
			<li class="fix">Texter: Filter für Schüler funktionierte nicht</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.10</h5>
		<ul class="unstyled changelogList">
			<li class="misc">großes Update für den Kalender auf Version 6, bitte Einstellungen wie in den <a href="https://docs.digitale-lernumgebung.de/Backend:Kalender_Optionen" target=_blank>Manager Docs</a> beschrieben vornehmen</li>
			<li class="add">private Kalender können nach dem Freischalten des Menüpunktes "Meine privaten Einträge" von allen Benutzern angelegt werden</li>
			<li class="add">2FA: Einstellung der Zeitzone in "Mein Account" zum Abgleich mit dem zur 2FA verwendeten Gerät</li>
			<li class="fix">2FA: nur eine von möglichen mehreren eingerichteten Methoden wurde aufgelistet</li>
			<li class="fix">Kalender: fehlerhafte Darstellung auf iPad</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.9</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte: Stapelverarbeitung von Reportfeldern in Lerngruppenansicht: Eingaben können auf die ganze Lerngruppe angewendet werden</li>
			<li class="add">Reporte: entsprechend der gewählten Methode zum Speichern von Reportfeldern sitzen die Speichernbuttons nun weiterhin direkt am Feld oder unter der Feldgruppe</li>
			<li class="add">Kompetenzraster: es werden nur noch die vom DiLer Manager frei geschalteten Status angezeigt</li>
			<li class="add">Mein Account: 2FA individuell vom Benutzer selbst aktivierbar sofern durch DiLer Manager eingeschaltet</li>
			<li class="fix">Texter: auf kleinen Displays war es teilweise schwierig, den Senden Button zu erreichen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.8</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Texter Nachrichtenverteilung</li>
			<li class="fix">Passwort speichern</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.7</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Nimbus: die Kompetenzen-Plugins funktionieren wieder</li>
			<li class="fix">Nimbus: "alle Phrasen einfügen" fügt Leerzeichen zwischen den Phrasen nur ein, wenn benötigt</li>
			<li class="fix">Kompetenzraster: es werden wieder alle Kompetenzcharakteristiken angezeigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.6</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Zensurenfeld: war erst nach Speichern beschreibbar</li>
			<li class="fix">Geburtsdatum: korrekte Formatierung und erweiterte Validierung</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.5</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Geburtsdatum: falsche Validierung führte zu fehlerhaftem Speichern</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.4</h5>
		<ul class="unstyled changelogList">
			<li class="fix">404 bei fehlerhaftem Geburtsdatum</li>
			<li class="fix">fehlender Button "Speichern" in LG-Ansicht für Reportdaten</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Neuer Parameter in Persönliche Daten für Schüler: Alter/Neuer Bildungsplan</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.2</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Persönliche Daten editieren: Safari kann Standardcode nicht verarbeiten</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte: wiederholbare Feldgruppen</li>
			<li class="add">Kompetenzraster: es werden nur jene Levels angezeigt, die in der betreffenden Phase des Lehrfaches auch Kompetenzcharakteristiken enthalten</li>
			<li class="fix">Nimbus: Possesivpronomen wurde nicht mehr angezeigt</li>
			<li class="fix">JLOGIN vermutlich behoben</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Aktivitäten, Kompetenzcharakteristiken, Kompetenzen und Phasen können zur Bewertung mit verschiedenen Status versehen werden. Hilfe: <a target=_blank href="https://docs.digitale-lernumgebung.de/Frontend:Kompetenzenliste_Lehreransicht_(Kompetenzraster)">Kompetenzraster</a> und <a target=_blank href="https://docs.digitale-lernumgebung.de/Frontend:Bewertung_von_Leistungen">Bewertung von Leistungen</a></li>
			<li class="add">Kompetenzlisten für den jeweiligen Schüler lassen sich als Report drucken. Die Templates liegen auf der DiLer Website bei den PE Komponenten und können heruntergeladen und importiert werden.</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.2.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Bilder der Benutzerprofile werden beim Hochladen quadratisch zugeschnitten, um ein einheitliches Erscheinungsbild zu erreichen</li>
			<li class="add">DiLer Fontend Documentation mit weiteren kontextsensitiven Links an den Hilfebuttons</li>
			<li class="add">neues optionales Feld "Geburtstag" für Lehrer und Eltern</li>
			<li class="add">neue Option beim Hochladen von Mediendateien: konvertieren oder nur hochladen</li>
			<li class="add">neue Option für Reportfelder: Anzeige im Report wenn keine Daten vorhanden ja/nein</li>
			<li class="misc">Datenmodell der Benutzerpprofile überarbeitet, womit nun leicht neue Felder hinzugefügt werden können</li>
			<li class="misc">Ansichten aller Benutzerpprofile überarbeitet</li>
			<li class="misc">vereinfachtes Registrierungsformular, neues Feld "Nutzungsbedingungen" beachten, s. Backend</li>
			<li class="fix">DB Fehler beim Daten löschen</li>
			<li class="fix">Zusatzangebote werden nun mit dem Titel im Dropdown gelistet</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.1.4</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Joomla hat einen Bug in 3.6.0, unser Update überschreibt Core Files, die den Joomla Fix in 3.6.1 vorwegnehmen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.1.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Nimbus: Beispiele in der Pluginliste bzw. Erläuterung in der <a href="https://docs.digitale-lernumgebung.de/Frontend:Nimbus_Vorlagen_und_Phrasen_anlegen#Beispiele" target=_blank>Dokumentation</a></li>
			<li class="add">Nimbus: Fehlermeldung bei verschachtelten Plugins</li>
			<li class="add">Nimbus: Zeichenzähler für Phrasenlänge</li>
			<li class="add">Nimbus: Phrasenlimit von 500 Zeichen auf 2000 erhöht</li>
			<li class="add">Nimbus: nun auch für Bemerkungen in Aktivitäten verfügbar</li>
			<li class="add">Nimbus: Ein/Ausschalt-Button für Sortierfunktion in der Datenpflege</li>
			<li class="fix">Reporte: Seitenumbruch Deckblatt korrigiert</li>
			<li class="fix">Nimbus: Personalpronomen fehlten bei einigen Schülern</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.1.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte: die Zensuren können nun mit Kommastelle eingegeben werden (muss im Backend im Zensurenfeld eingerichtet werden)</li>
			<li class="add">Texter: Eltern sehen alle Systemnachrichten ihrer Kinder</li>
			<li class="add">Schultagebuch: Darstellung der Fehltage korrigiert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.1.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Nimbus - Textbausteine für Reporte, Schultagebuch, Bemerkungen usw.</li>
			<li class="add">DiLer Documentation: Kontextsensitivität erweitert durch Berücksichtigung des aktiven Reiters</li>
			<li class="add">in den Dropdowns der Kontakte ist nun ein Suchfeld integriert</li>
			<li class="fix">Dezimaltrenner bei Bewertungspunkten hatte die eingestellte Sprache nicht berücksichtigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.0.5</h5>
		<ul class="unstyled changelogList">
			<li class="add">Texter: Lehrer können vom Schreibtisch aus allen Benutzern schreiben, ebenso in "Kontakte" jedoch ist dort der jeweilige Kontakt bereits vorausgwählt</li>
			<li class="add">weitere Sprachen im Frontend: Arabisch, Chinesisch</li>
			<li class="fix">Registrierung: 404 behoben</li>
			<li class="fix">Texter: leere Voreinstellung fehlte in Empfängerliste</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.0.4</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schultagebuch: Filter für Schultagebuch in Gruppenansicht um 10 und 30 Tage erweitert - ACHTUNG: kann bei vielen Einträgen und großen Gruppen zu extrem langen Ladezeiten führen!</li>
			<li class="fix">Datenpflege: "Neu" Button fehlte bei leerer Aktivitätenliste</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.0.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Texter: Nachrichten an mehrere Empfänger</li>
			<li class="add">Texter: System-Nachricht senden, wenn Lehrer eine Anmerkung zu einer Aufgabe eingegeben hat</li>
			<li class="add">überlange Dateinamen werden for dem Upload automatisch gekürzt</li>
			<li class="add">weitere Sprachen im Frontend: Spanisch, Russisch, Türkisch</li>
			<li class="fix">Modales Fenster schließen über Button ist wieder möglich</li>
			<li class="fix">Fehler in französicher Sprachdatei behoben</li>
			<li class="fix">Upload im Medien Tab ist wieder möglich</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.0.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schüler: zugewiesene Phasen werden im Button des Faches angezeigt</li>
			<li class="add">Aktivitäten: die Bewertung wird neben Punkten auch in % angezeigt</li>
			<li class="add">Aktivitäten: Schüler können beim Beantworten eine Datei hochladen</li>
			<li class="add">Aktivitäten: Lehrer können zu jeder Aufgabe einer Aktivität eine Bemerkung für den Schüler hinterlassen</li>
			<li class="add">Kontaktformular auf der Login-Seite</li>
			<li class="add">Texter: Lehrer sehen in der Systemnachricht die Bemerkungen 'selbstbestätigt' und 'einzutragen in DiLer' falls zutreffend damit sie wissen, dass dort eventuell Lösungen zu prüfen sind</li>
			<li class="add">Button zu den Tutorials in der Hauptnavi</li>
			<li class="add">kontextsensitive Hilfe mit Hilfebuttons an den Modulen und in der Hauptnavi (die Hilfeseiten werden Stück für Stück gefüllt)</li>
			<li class="add">DiLer Bulletin - das Digitale Schwarze Brett</li>
			<li class="add">Datenschutzerklärung und Impressum hinzugefügt; <strong>ACHTUNG: muss noch von jeder Schule selbst individualisiert werden.</strong> Eventuell ist anwaltlicher Rat einzuholen, stellt keine Rechtsberatung dar. Dazu bitte <a target=_blank href="https://digitale-lernumgebung.de/diler-ressourcen/lernplattform-software-downloads/diler-ce-documentation-updateserver/diler-5x_stable.html">impr-dat-cookie-piwik.zip</a> herunterladen.</li>
			<li class="add">Cookie Confirmation: Um der sinnfreien EU-Cookie-Richtlinie zu entsprechen, wurde eine nervige Cookie-Meldung eingebaut</li>
			<li class="add">Talkie: Konferenzschaltung</li>
			<li class="add">frei definierbare Berechnungsmethoden: Zensuren können mittels verschiedener Methoden ermittelt und diese pro Aktivität zugewiesen werden</li>
			<li class="misc">frei definierbare Aktivitätstypen: die bisherigen drei Aktivitätstypen wurden in ein flexibles Modell überführt</li>
			<li class="misc">Datenpflege: Aktivität und zugehörige Aufgaben auf der gleichen Seite</li>
			<li class="misc">Kompetenzicons überarbeitet und erweitert</li>
			<li class="remove">Texter: alle auf den 4.x-Aktivitäten basierenden Systemnachrichten wurden gelöscht da sich die darin enthaltenen Links zu den Aktivitäten geändert haben</li>
			<li class="remove">Talkie: Button in Schüleransicht gelöscht; alle Benutzer können nun im Wartefenster erreicht werden</li>
			<li class="remove">Einzelansicht Fach entfernt, man kommt jetzt von der Fächernavigation direkt in das Kompetenzraster</li>
			<li class="remove">Schüleraccount: Pflichtfelder beschränkt auf: Vorname, Name, Geschlecht, Geburtsdatum, E-Mail</li>
			<li class="fix">Texter: Eltern sehen nun alle Nachrichten das Kind betreffend direkt auf dem Schreibtich</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte: optionale Fußzeile</li>
			<li class="fix">Reporte: letzte Leerseite entfernt</li>
			<li class="fix">Reporte: Seitenränder sind nun auf allen Seiten identisch</li>
			<li class="fix">Reporte: Seitenumbruch auf der letzten Seite entfernt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Transcoding von Mediadateien ist wieder verfügbar mit verbesserter UX</li>
			<li class="add">Texter: zusätzliches Icon an beantworteten Nachrichten</li>
			<li class="add">Mediadateienanzeige überarbeitet mit Downloadfunktion und Bildervorschau</li>
			<li class="add">Lehrerschreibtisch: Suche nach Schülern beschleunigt</li>
			<li class="add">Schultagebuch: Kategoriefilter umschaltbar alle/irgendein</li>
			<li class="add">Schultagebuch: Zukunftstermine werden gesondert angezeigt</li>
			<li class="fix">Reporte: Zeilenumbrüche wurden nicht berücksichtigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Tutorial <a href="https://www.youtube.com/watch?v=0h_JfG1AdZY" target="_blank">Schultagebuch</a></li>
			<li class="add">Schultagebuch auch in Lerngruppenliste verfügbar</li>
			<li class="add">Texter: "Nachricht senden" für den Schreibtisch der Eltern</li>
			<li class="add">unterschiedliche Symbole für Notitzen an Gelingensnachweisen: mit/ohne Inhalt</li>
			<li class="fix">unter bestimmten Umständen wurden die Kompetenzbalken nicht korrekt berechnet</li>
			<li class="fix">Kalender: Eventdetails waren nicht erreichbar</li>
			<li class="fix">Texter: löschen von mehr als 400 Einträgen war nicht möglich</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schultagebuch (ersetzt Bemerkungsfeld)</li>
			<li class="add">Bemerkungen für Tests überarbeitet (automatisches Schließen beim Speichern, anderes Icon wenn Inhalt vorhanden)</li>
			<li class="add">Info Fenster für Novizen nun auch in Lerngruppenliste</li>
			<li class="remove">altes Zeugnis gelöscht</li>
			<li class="remove">altes Bemerkungsfeld gelöscht</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.8</h5>
		<ul class="unstyled changelogList">
			<li class="add">Texter: "Nachricht schreiben" Button für Eltern auf dem Schreibtisch</li>
			<li class="fix">Texter: DiLer Translate Function war defekt nach Joomla Update 3.4.0 für Novitzen, z.B. in Aufgaben</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.7</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Texter: JS Translate Function war defekt nach Joomla Update 3.4.0</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.6</h5>
		<ul class="unstyled changelogList">
			<li class="add">Datenpflege: Kompetenzraster: angezeigte Kompetenzen können nutzerspezifisch auf die gewählten Phasen eingeschränkt werden</li>
			<li class="misc">Registrierung: nur noch die systembedingten Angaben sind Pflichtangaben (Name, Anrede, Junge/Mädchen, Geb.datum, Benutzername + Passwort, Nutzungsbedingungen)</li>
			<li class="fix">Texter: Antwort-Button u.ä. war defekt nach Joomla Update 3.4.0</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.5</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Felder für iframe und link in Aufgaben auf 2000 Zeichen erweitert, Linktext ist nun obligatorisch</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Text im Feld "Beschreibung" für Fächer und Zusatzangebote wird an verschiedenen Stellen dem Namen vorangestellt</li>
			<li class="add">Bemerkungsfelder für Gelingensnachweise: Notiz (nur für Lernbegleiter sichtbar), Kommentar (sichtbar für alle Lernbegleiter, diesen Lernpartner und seine Eltern)</li>
			<li class="add">Texter: neue Buttons in den Systemnachrichten zum sofortigen akzeptieren/ablehnen von Gelingensnachweisen und zum betrachten von Lernjobs</li>
			<li class="add">Texter: in manuellen Nachrichten werden URLs in klickbare Links verwandelt, z.B. http://www.digitale-lernumgebung.de wird zum Link "www.digitale-lernumgebung.de"</li>
			<li class="add">Texter: neue Buttons zum Speichern und Laden der persönlichen Filtereinstellungen</li>
			<li class="add">Texter: neue Option in "Mein Account": "Icons" oder "Text" auf den Buttons anzeigen</li>
			<li class="fix">die Namensfelder konnten das Apostroph nicht verarbeiten</li>
			<li class="fix">Zeugnis-App: BW LEB Einstellung der Zensuranzeige im Profil wurde nicht berücksichtigt</li>
			<li class="fix">Zeugnis-App: Apostroph (singel quote) wurde nicht korrekt verarbeitet</li>
			<li class="misc">Zeugnis-App: BW LEB Landeswappen leicht vergrößert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.2</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Zeugnis-App: BW LEB zeigt "Sozialverhalten" wieder an</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Zeugnis-App: durch Eingabe von - werden die Felder beim PDF-Druck nicht angezeigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">erste Version der Zeugnis-App</li>
			<li class="add">Formular für den verbindlichen Lernentwicklungsbericht in BW</li>
			<li class="add">neue Option für Novizen: Schulnoten anzeigen ja/nein</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.1.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Liste der verknüpften Aktivitäten für Mediadateien</li>
			<li class="add">Texter: weiterer Filter "alle Systemnachrichten"</li>
			<li class="add">Texter: Modul "Ungelesene Texter Nachrichten": Badges leiten auf entsprechend gefilterte Anzeige: "alle Systemnachrichten"/"alle manuellen Nachrichten"</li>
			<li class="add">Übungen nun auch in der Datenpflege löschbar</li>
			<li class="fix">Reihenfolge der Zusatzangebote jetzt entsprechend der Sortierung im Backend</li>
			<li class="fix">auch groß geschriebene Dateierweiterungen werden beim Upload transformiert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.1.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Bildschirmtastatur permanent wählbar</li>
			<li class="add">Datenpflege: Lerngruppenname in Tabelle Phasenzuweisung</li>
			<li class="add">neuer Upload Dialog für Mediendateien</li>
			<li class="add">neuer Reiter für Mediendateien in der Datenpflege</li>
			<li class="add">weitere Sprache: Französisch</li>
			<li class="add">Texter: Zeilenhöhe auf 4 Zeilen beschränkt</li>
			<li class="fix">Datenpflege Tests: 'Anzahl der Aufgaben' bei Offline Tests ausblenden</li>
			<li class="fix">Darstellung langer Dateinamen optimiert</li>
			<li class="misc">alle Mediendateien liegen nun außerhalb von 'document root' und sind somit vor Direktzugriff/Download gesichert</li>
		</ul>
	</div>
	*/ ?>
</div>
