<?php
/**
 *
 * @package DiLer.Site
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>

<div class="well well-small changelogWrapper">
	<div class="changelogBlock">
		<h5>7.2.6</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.9.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Joomla 5 kompatibel</li>
			<li class="add">Single-Sign-On für Edumaps</li>
			<li class="add">mehr Felder für Berechnungsmethode "stufenweise"</li>
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.7.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">DigLu: neue Felder für Datenschutzbeauftragte und Weisungsberechtigte</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.7.1</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.7</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.6</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.5</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.1.1</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.0.9</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>7.0.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Kompatibilität mit Joomla 4</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.15.6</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bugfixes</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.15.5</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schuljahreswechsel: in "Daten bearbeiten" > "Schuljahreswechsel" > "Schuljahr wechseln"</li>
			<li class="fix">Statistik der den Klassenstufen zugewiesenen SuS war inkorrekt</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.15.4</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Fehler beim Einchecken von DiLer-Inhalten behoben</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.15.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">DigLu: Parameter zum Ein-/ausschalten der Schulbesuchsdatenkollisionskontrolle in den Optionen hinzugefügt</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.15.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">DigLu: optionale E-Mail-Benachrichtung für jedes einzelne Ministerium</li>
			<li class="fix">DigLu: Enddatumsprüfung für Stammschulen heraus genommen</li>
			<li class="fix">Veröffentlichungsdatum für alle Schulfächer auf 0000-00-00 00:00:00 gesetzt</li>
			<li class="fix">Klassenstufen sortierbar gemacht</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.14.2</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Registrierungscodes lassen sich wieder löschen</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.13.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">minimale PHP-Version ist jetzt 8.1</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.12.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Templates: es gibt nur noch ein einziges Template, alle Template-Einstellungen befinden sich in den DiLer-Optionen</li>
			<li class="add">Optionen: Ansicht: Login-Seite: Button für "Passwort in Klartext" anzeigen</li>
			<li class="add">Optionen: Ansicht: Login-Seite: Button für "Virtuelle Tastatur" anzeigen</li>
		</ul>
	</div>
 -->
	<div class="changelogBlock">
		<h5>6.11.18</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bug Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.17</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Sprache uk-UA (Ukrainisch) kann aktiviert werden, siehe Tutorial: https://www.tutorialgarage.com/joomla/sprachen-installieren</li>
			<li class="add">neues Feld in Optionen > Anzeige > Felder > Personalien</li>
			<li class="add">neues Feld in Optionen > Anzeige > Global > Spitzname</li>
			<li class="add">neues Feld in Optionen > Anzeige > Global > Stundenplan</li>
			<li class="add">neues Feld in Optionen > Schultagebuch > Anzeige > Standardauswahl in 'sichtbar für' für Schultagebucheinträge</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.16</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bug Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.15</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleinere Bug Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.12</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleine Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.11</h5>
		<ul class="unstyled changelogList">
			<li class="fix">kleine Fixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.10</h5>
		<ul class="unstyled changelogList">
			<li class="add">DiLer Optionen > Anzeige > Global: Option zum Anzeigen des Online-Status</li>
			<li class="add">DiLer Optionen > Anzeige > Angabe der Wochentage zur Anzeige des Stundenplanes</li>
			<li class="misc">Registrierungscodes: PDF um Familienmitglieder und Lerngruppe ergänzt</li>
			<li class="misc">DiLer Optionen > Anzeige > Parameter "Klassenstufe anzeigen" entfernt; wird nun immer angezeigt, da nun integraler Bestandteil der Schülerdaten</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.9</h5>
		<ul class="unstyled changelogList">
			<li class="fix">HTTP/2-Fehler behoben, wird beim kommenden Update wirksam</li>
			<li class="fix">erlaubte Dateitypen sind nicht mehr Groß-Kleinschreibung sensitiv</li>
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.8</h5>
		<ul class="unstyled changelogList">
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.7</h5>
		<ul class="unstyled changelogList">
			<li class="fix">diverse Bugfixes</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.6</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Berechtigungen: "Wichtige Hinweise" und "Hinweise für Lehrkräfte" bearbeiten können getrennt vergeben werden</li>
			<li class="add">neue Berechtigungen: "Schulbesuche" bearbeiten kann getrennt vergeben werden</li>
			<li class="misc">PDF für Registrierungscodes überarbeitet</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.5</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Berechtigung "Privatspähre sehen und bearbeiten"</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.4</h5>
		<ul class="unstyled changelogList">
			<li class="add">Daten bearbeiten: als PDF abgelegte Reporttypen können als zip herunter geladen werden</li>
			<li class="add">Berechtigungen: die Schülerstatistik kann nun auch für SuS und Eltern gesetzt werden, ebenso bei abgelegten Reporttypen</li>
			<li class="add">Level: die Anzeige des zugehörigen Kompetenzbalkens kann eingestellt werden</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.11.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">unter "Daten bearbeiten" lässt sich in einer Testinstallation die Datenbank anonymisieren und damit z.B. für Schulungen einsetzen</li>
			<li class="add">DiLer Options > Schultagebuch > Anzeige > "Home Schooling"</li>
			<li class="add">Zeitfenster der Unterrichtseinheiten für Stundenpläne können eingerichtet werden</li>
			<li class="misc">"zugänglich nach Abschluss" wird nun nur noch in der Aktivität eingestellt (nicht mehr zusätzlich "global" im Aktivitätstyp)</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.10.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">das Schulsiegel kann in den DiLer Optionen (Reiter: Global) angegeben und z.B. für Zeugnisse verwendet werden</li>
			<li class="add">neue Berechtigungen: Texter sehen, Gruppen sehen</li>
			<li class="fix">Sortierspalte für Phasen (Klassenstufen) hat gefehlt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.9.0</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Benutzerimport: Beispieldaten überarbeitet, Dateiprüfung verbessert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.8.0</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Wiki kann auf "Hogfather" <a target=_blank href="https://docs.digitale-lernumgebung.de/Wiki#Aktualisieren.2FUpgraden.2FUpdaten">aktualisiert</a> werden</li>
			<li class="fix">Fehler bei der PDF-Generierung behoben</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.7.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Optionen: Zugangsdaten für den Talkie TURN-Server; die Zugangsdaten sollten bereits eingetragen sein und die Optionen müssen nur einmalig nach dem Update gespeichert werden</li>
			<li class="add">Neue Berechtigung: E-Mail-Adresse bearbeiten</li>
			<li class="add">Neue Berechtigung: Passwort bearbeiten</li>
			<li class="add">Neue Berechtigung: Kontakte pro Benutzerrolle sehen</li>
			<li class="add">Registrierungscodes können zum einfacheren Ausdrucken nach Familien sortiert werden</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.6.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Neue Berechtigung: Neue Schultagebucheinträge im Notifier sehen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.6.1</h5>
		<ul class="unstyled changelogList">
			<li class="fix">einige Bugs beseitigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.6.0</h5>
		<ul class="unstyled changelogList">
			<li class="add"></li>
			<li class="add">Cloud: neue Option zum Wählen der Voreinstellung für "Benachrichtung via Texter bei Upload" per Cloud-Kategorie</li>
			<li class="add">Optionen: im Reiter "Workflow" kann eingestellt werden, wie PDF auf dem Server abgelegt werden</li>
			<li class="add">Optionen: neuer Reiter "Benutzer-Bulletin", Spaltenbreiten sind pro Benutzerrolle definierbar</li>
			<li class="add">neue Berechtigung: Globale Abwesenheit sehen</li>
			<li class="add">neue Berechtigung: Schultagebuchausdrucke, Reportausdrucke, Schulnotenausdrucke sehen/löschen</li>
			<li class="add">neue Berechtigung: Zeilen im Schulnotenrechner löschen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.5.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Berechtigung: Private Notizen von Lehrern in Schülerprofilen sehen und bearbeiten</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.5.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Benutzerimport: Schüler werden beim Import auf "Schulnoten anzeigen = Ja" gesetzt (ebenso bei manueller Registrierung im Frontend)</li>
			<li class="add">Benutzerimport: Passwörter können mit importiert werden</li>
			<li class="add">neue Option im Reiter "Anzeige": Anzahl der Kompetenzen im Fach können optional in der Fächernavigation angezeigt werden</li>
			<li class="add">neue Option im Reiter "Texter": Eltern dürfen an mehrere Lehrkräfte gleichzeitig schreiben</li>
			<li class="add">neues Feld im Reiter "Sicherheit": DiLer API Key (wird zur Abfrage der Schülerzahlen genutzt, wird demnächst von DiLer befüllt)</li>
			<li class="misc">Registrierungscodes: Eltern und deren Kinder einer Klasse können nun gemeinsam angezeigt werden, um die Regcodes gemeinsam drucken zu können</li>
			<li class="fix">2FA für alle verfügbar</li>
			<li class="fix">Registrierungscodes: Klasse/Lerngruppe wird auch bei Eltern angezeigt, deren Kinder bereits registriert sind</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.4.0</h5>
		<ul class="unstyled changelogList">
			<li class="misc">Aufteilung von "Daten löschen" in separate Aktionen</li>
			<li class="misc">Code Base Refactoring</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3.3</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Benutzerimport: Beispielimportdateien überarbeitet</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3.2</h5>
		<ul class="unstyled changelogList">
			<li class="misc">Benutzerimport: bessere Fehlermeldung bei ungültiger Importdatei</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte können nun beim Import direkt überschrieben werden, ohne vorher löschen zu müssen</li>
			<li class="add">die Schulnotenniveaus können in Lehrfächer-Kategorien definiert werden</li>
			<li class="add">PE Feature: Benutzerimport für Registrierungscodes über Kalkulationstabelle (Excel, Calc, ...) oder CSV</li>
			<li class="add">PE Feature: Benutzerimport über Kalkulationstabelle (Excel, Calc, ...) oder CSV</li>
			<li class="add">Texter: ab jetzt werden wegen der inzwischen auflaufenden Menge an Nachrichten nicht nur System-Nachrichten sondern auch persönliche Nachrichten automatisch endgültig aus DiLer gelöscht, wenn die im Backend eingestellte Zeitspanne erreicht ist</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Optionen: Leseberechtigungen für das Schwarze Brett werden jetzt über Berechtigungen eingestellt</li>
			<li class="add">Optionen: Leseberechtigungen für Zukunftseinträge werden jetzt über Berechtigungen eingestellt</li>
			<li class="add">Reportfelder: neuer Elementtyp "Lehrkraft" als Auswahlliste aller Lehrkräfte</li>
			<li class="add">Reportfelder: Nimbus kann ein/aus geschaltet werden</li>
			<li class="add">Reportfelder können auch dann gelöscht werden, wenn Daten vorhanden sind</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Benutzergruppe ist im Registrierungscode enthalten</li>
			<li class="add">"Keine Daten"-Warnung als Option pro Reporttyp</li>
			<li class="add">detaillierte  Berechtigungen</li>
			<li class="add">Eingabeformular für Länder</li>
			<li class="add">Schulnotenrechner: Zensurenzeiträume und deren Definition im Schuljahr</li>
			<li class="add">"Daten löschen" aus "Daten bearbeiten" heraus genommen und in eigenen Menüpunkt gelegt</li>
			<li class="add">Klassen orientierte Fächerzuordnung möglich durch Mehrfachzuordnung von Fächern, definierbar in jeder Gruppenkategorie</li>
			<li class="add">Optionen: Stammdaten erweitert um "Schulträger" und "Unfallversicherer" u.a. zum Drucken des Reports "UNFALLANZEIGE"</li>
			<li class="remove">"Fächer auf neuer Seite" in Reporttyp, wird jetzt direkt im Code gesteuert</li>
			<li class="remove">Optionen: Talkie: ein/aus; wird jetzt über Berechtigungen für jede Benutzergruppe separat eingestellt</li>
			<li class="remove">Optionen: Talkie: Serverparameter: sind jetzt im Code enthalten, keine Einrichtung mehr notwendig</li>
			<li class="remove">Optionen: Workflow: Benutzerzuordnung sperren, dies wird jetzt ausschließlich über Berechtigungen gesetzt</li>
			<li class="fix">Kompetenzen: Lösch-Button fehlte</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Gruppenkategorien: neuer Typ steht zur Verfügung, um z.B. Arbeitsgemeinschaften oder das Kollegium zu organisieren</li>
			<li class="fix">Optionen: Benutzerzuordnung sperren funktioniert wieder</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Lehrfach: es kann eingestellt werden, ob ein Fach in mehreren Zügen angeboten wird</li>
			<li class="add">Benutzerprofile: für Lehrer wird eine Aufzählung aller zugewiesenen Lerngruppen angezeigt, nach 50 Zeichen wird abgeschnitten</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.1.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Gruppenkategorien: "DiLer Gruppentyp" lässt sich nur beim Erstellen der Grppe setzen, um Datenkonsistenz sicher zu stellen</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.1.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Neue Dateneinheit "Zug"</li>
			<li class="add">Neue Dateneinheit "Schuljahr", ersetzt das Schuljahr in den Optionen</li>
			<li class="add">Optionen: Auswahl des WYSIWYG-Editors für Aufgabenbeschreibungen</li>
			<li class="add">Optionen: Definition von Funktionen für alle Benutzerprofile</li>
			<li class="add">Optionen: Definition von farbcodierten Status für Schülerprofile</li>
			<li class="add">Optionen: Anzeigen der Felder zur Erfassung der Soll/Ist-Klassenstufe</li>
			<li class="remove">Optionen: Anzeige Zensuren j/n für Schüler, dies wird jetzt ausschließlich im Schülerprofil gesetzt</li>
			<li class="remove">Optionen: Schuljahr im Tab "Global"</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>6.0.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">100 neue Icons zur Einbindung in das Kompetenzraster (Nummern 200 bis 300)</li>
			<li class="fix">Gruppenzuordnungen</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>6.0.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">System Info: Cache-Ordner beschreibbar</li>
			<li class="add">Optionen: Automatische Lerngruppenzuordnung</li>
			<li class="add">Bulletin: Anzeige pro Benutzerolle</li>
			<li class="add">Cloud: übergeordnetes Schlagwort</li>
			<li class="add">Cloud: Kategorien im Dashboard</li>
			<li class="add">Berechtigungen für die Gruppenverwaltung</li>
			<li class="add">Zuschalten von Feldern für Schulen, die Kinder von beruflich reisenden Eltern unterrichten</li>
			<li class="add">Schulspezifisches Hintergrundbild</li>
			<li class="add">Fremdschlüsselprüfung und -reparaturwerkzeug für DiLer Datenbanktabellen</li>
			<li class="misc">Dashboard reorganisiert</li>
		</ul>
	</div>
<?php /*
		<h5>5.4.2</h5>
		<ul class="unstyled changelogList">
			<li class="fix">in Reportfeldern werden bei "Lehrfach" nur noch Fächer angezeigt, die in Kategorien sind, die in Reporten berücksichtigt werden sollen</li>
			<li class="fix">Kompetenzen im Papierkorb werden nicht mehr in den Filtern angezeigt</li>
			<li class="fix">Notifier: Quick Links funktionieren nun auch in "Notifier Administration"</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.4.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Optionen für DiLer Notifier</li>
			<li class="add">Option "Zugang nach Abschluss" für Aktivitäten</li>
			<li class="add">im Kompetenz-Select-Feld beim Kompetenzcharackterristik editieren wird nun auch das Fach angezeigt</li>
			<li class="add">neuer Lehreraccount "service.teacher", neuer Schüleraccount "service.student", neuer Elternaccount "service.parent" für Wartungsarbeiten durch das DiLer Team</li>
			<li class="misc">Demo-Benutzer haben ein automatisch generiertes Passwort erhalten, welches in den Benutzerhinweisen hinterlegt ist</li>
			<li class="fix">Wettermodul für das DiLer Bulletin kann wieder eingeschaltet werden</li>
			<li class="fix">diverse Bugs geseitigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.4.0</h5>
		<ul class="unstyled changelogList">
			<li class="fix">diverse Bugs geseitigt</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.11</h5>
		<ul class="unstyled changelogList">
			<li class="add">Registrierungscodes: Lerngruppenfilter filtert nun auch Eltern</li>
			<li class="add">Reporte: Seitenränder und Kopf-/Fußzeile können in den Layoutdateien gesteuert werden</li>
			<li class="add">Reporte: für die Status können Farben definiert werden, die u.a. beim Druck der Reporte verwendet werden: Optionen > Anzeige > Farben für die Kompetenzrasterstatus</li>
			<li class="add">Reporte: LEB-Version des KM-BW erfordert folgende Zeichenbegrenzungen in den Reportfeldern (ca.): Lern- und Sozialverhalten: 750 / Fächer Beurteilungstext: 700 / Profilfach Beurteilungstext: 700 / Wahlpflichtbereich Beurteilungstext: 700 / Bemerkungen: 750</li>
			<li class="add">Reporte: in der Layoutdatei kann Footer und Header manipuliert werden, s. example.php</li>
			<li class="add">Optionen: Reiter "Global" - Schuladresse: Straße, PLZ und Ort getrennt</li>
			<li class="remove">Reporttyp editieren: Einstellung "nur abgeschl. Kompetenzen" entfernt, da jetzt im Frontend verfügbar</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.10</h5>
		<ul class="unstyled changelogList">
			<li class="misc">neue Einstellungen für den Kalender nach 6er Update</li>
			<li class="misc">extra Tab für Einstellungen zu Updates</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.9</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reprotfelder: können zur Stapelverarbeitung in der Lerngruppenansicht frei geschaltet werden</li>
			<li class="add">Daten bearbeiten: Status für Kompetenzcharacteristiken, Kompetenzen und Phasen können zurück gesetzt werden</li>
			<li class="add">Optionen: verfügbare Status für Kompetenzcharacteristiken, Kompetenzen und Phasen sind nun wählbar</li>
			<li class="add">Optionen: Methoden zum Speichern von Reportfeldern wählbar</li>
			<li class="add">Optionen: 2FA pro Benutzerrolle einstellbar</li>
			<li class="add">Akeeba LoginGuard für Zwei-Schritt-Verifizierung (Two Step Verification)</li>
		</ul>
	</div>
 	<div class="changelogBlock">
		<h5>5.3.7</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte: neuer Parameter "Zensurfeld" für Reportfelder</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">neuer Parameter in Reporttyp: "Lehrfächer auf neuer Seite"</li>
			<li class="add">neuer Parameter in Reporttyp: "nur abgeschl. Kompetenzen"</li>
			<li class="add">neuer Parameter für Textfelder in Reporten: "Zeichenbegrenzung"</li>
			<li class="add">neuer Parameter für Fächer: Icons für die Kompetenzen im Kompetenzraster anzeigen ja/nein</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">Optionen: neues Feld für Stadtwappen</li>
			<li class="fix">Feld für "Name" in der Joomla Benutzerverwaltung gesperrt und mit DiLer Namensfeldern synchronisiert</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.3.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reportfelder: wiederholbare Feldgruppen lassen sich definieren über "Eintragstyp" und  "Elementtyp", Hilfe: <a target=_blank href="https://docs.digitale-lernumgebung.de/Backend:Reportfelder">Elementtyp Gruppenfeld</a></li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.2.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reportfelder: neue Option, um das Feld im Report nicht anzeigen zu lassen, wenn es keine Daten enthält</li>
			<li class="add">Optionen: neues Feld für Nutzungsbedingungen (Link zu einem Joomla-Beitrag), wird während der Registrierung angezeigt</li>
			<li class="add">neue Seite zur Eingabe von Elterntypen</li>
			<li class="add">neue Formulare für die Zuordnung von Erziehungsberechtigten zu Kindern</li>
			<li class="add">DiLer Backend Documentation mit weiteren kontextsensitiven Links an den Hilfebuttons</li>
			<li class="misc">Dashboard: Icons in Sektionen unterteilt</li>
			<li class="remove">Familien ID: Es gibt das Konzept der Familie in DiLer nicht mehr, da mit diesem Konzept nicht alle Szenarien der Zuordnung von Erziehungsberechtigten zu Kindern abgedeckt werden können.</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.1.4</h5>
		<ul class="unstyled changelogList">
			<li class="add">Optionen: erweiterte Fehlermeldungen zuschaltbar</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.1.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Optionen: Nimbus</li>
			<li class="add">Reporte: die PHP Dateien der Vorlagen lassen sich nun direkt im Backend bearbeiten</li>
			<li class="add">im LEB sind 5 Zusatzfelder verfügbar, der Titel muss "zusatz1" bis "zusatz5" heißen; Felder vom Typ "Lehrfach" werden unter der Verbalbeurteilung bzw. Zensur des Faches angezeigt, Felder vom Typ "Zeitraum"/"Schüler" oberhalb von "ort_datum"</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>5.0.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">DiLer Optionen: Landeswappen mit kleinerer Dateigröße für schnelleren LEB-Druck, z.B. kleines-wappen-400-bw.png</li>
			<li class="add">DiLer Optionen: Bulletin (PE)</li>
			<li class="add">FamilienID ist nachträglich änderbar</li>
			<li class="add">Template Style für DiLer Bulletin (PE)</li>
			<li class="add">Modul Zentools und Modul wuweather für DiLer Bulletin (PE)</li>
			<li class="add">Plugin für EU Cookie Law</li>
			<li class="add">Piwik datenschutzkonform eingebunden: Piwik ist zur anonymisierten Auswertung Ihrer DiLer-Installation eingerichtet, wenn Sie Ihre Piwik-Statistik einsehen möchten, senden wir auf E-Mail-Anfrage die Accountdaten.</li>
			<li class="add">"Bewertungsmethoden" zur Definition der "Erfolgsschwelle" zum Bestehen einer Aktivität und zur Berechnung der optionalen Zensur. Bewertungsmethoden werden einer Aktivität im Frontend zugewiesen. Ist nur eine einzige berechnende Bewertungsmethode angelegt, so wird diese für alle Aktivitäten standardmäßig genutzt und im Frontend keine Auswahl angezeigt.</li>
			<li class="add">kontextsensitive Hilfe mit Hilfebutton rechts oben (die Hilfeseiten werden Stück für Stück gefüllt, die Zugangsdaten werden demnächst an die DiLer Manager versendet)</li>
			<li class="misc">frei definierbare Aktivitätstypen: die bisherigen drei Aktivitätstypen wurden in ein flexibles Modell überführt</li>
			<li class="misc">alle Eingabemasken vereinfacht für mehr Benutzerfreundlichkeit</li>
			<li class="misc">DiLer Dashboard: neue Icons und neue Buttons im Zuge der Aktivitätenumstellung</li>
			<li class="misc">DiLer Dashboard: Benutzerverwaltung in DiLer Dashboard verschoben</li>
			<li class="misc">DiLer Dashboard: "Daten löschen" wurde zu "Daten bearbeiten"</li>
			<li class="misc">DiLer Optionen: Phasenkennzeichnung nach "Anzeige" verschoben</li>
			<li class="misc">DiLer Optionen: Zensurenanzeige nach "Anzeige" verschoben</li>
			<li class="misc">DiLer Optionen: "Erfolgsschwelle" zum Bestehen einer Aktivität ist jetzt jeweils in den neuen Bewertungsmethoden zu finden</li>
			<li class="misc">Kompetenzicons überarbeitet und erweitert, Ordner von "competenceicons" zu "icons" geändert, die neuen Icons befinden sich unter "normal" und "inverted". Die Icons sind 640 px groß, können also auch zum Drucken verwendet werden.</li>
			<li class="remove">DiLer Optionen: Reiter "Fächer" gelöscht</li>
			<li class="remove">DiLer Optionen: Reiter "Zensuren" gelöscht</li>
			<li class="remove">DiLer Dashboard: durch Umstellung auf die frei definierbaren Aktivitäten wurden gelöscht: Übungen, Inputs, GN, Aufgaben, Zensuren, Punkte (derzeit ist fest vorgegeben: max. 120 Punkte pro Aufgabe/Aktivität, Bewertungen in 0,5 Schritten)</li>
			<li class="remove">sprachgebundene Module für "Anstehende Termine" gelöscht, es gibt jetzt nur noch eines für alle Sprachen</li>
			<li class="fix">Kompetenzraster: Reihenfolge der Levels wird im Frontend berücksichtigt</li>
			<li class="fix">Registrierungscodes sind in allen Installationen wieder druckbar</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Optionen für Reporte in "Anzeige"</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.2</h5>
		<ul class="unstyled changelogList">
			<li class="add">neue Option: Vornamen der Lehrer anzeigen</li>
			<li class="add">DiLer Maturitätsstatus geändert zu "stabil"</li>
			<li class="add">Schultagebuch: Einstellungen für Zukunftstermine</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">automatisches Löschen im Ereignisprotokoll</li>
			<li class="add">Optionen für neues Schultagebuch: Kategoriesortierung</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.3.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Optionen für neues Schultagebuch</li>
			<li class="add">Berechtigungen für neues Schultagebuch</li>
			<li class="add">Option zum selektiven Einschalten von https für die DiLer-Komponente</li>
			<li class="fix">Feldstruktur der Reporte überarbeitet für Im/Export</li>
			<li class="fix">Singular - Plural Bezeichnungen</li>
			<li class="remove">altes Zeugnis gelöscht</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.8</h5>
		<ul class="unstyled changelogList">
			<li class="remove">Akeeba Auto-E-Mail-Funktion wegen Unzuverlässigkeit abgeschaltet</li>
			<li class="add">Zuordnungen für Wahlangebote löschen: nur die Zuordnungen für Schüler werden gelöscht, Lehrer bleiben erhalten</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.7</h5>
		<ul class="unstyled changelogList">
			<li class="add">Ereignisprotokoll: Autolöschfunktion</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.6</h5>
		<ul class="unstyled changelogList">
			<li class="add">Reporte/Zeugnisse/LEB: Layout-Dateien im Override Folder werden automatisch erkannt und als neuer Reporttyp angezeigt</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.5</h5>
		<ul class="unstyled changelogList">
			<li class="add">Ereignisprotokoll (die wichtigsten Ereignisse werden protokolliert, weitere Ereignisse folgen)</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.3</h5>
		<ul class="unstyled changelogList">
			<li class="add">Schullogo aus den Stammdaten wird auf der Loginseite angezeigt, es sollte ein png mit transparentem Hintergrund gewählt werden</li>
			<li class="add">Text im Feld "Beschreibung" für Fächer und Zusatzangebote wird an verschiedenen Stellen dem Namen vorangestellt; in den Optionen kann eingestellt werden, nach wie vielen Zeichen der Text abgeschnitten wird, wenn erforderlich (wie z.B. in Dropdowns)</li>
			<li class="fix">die Namensfelder konnten das Apostroph (singel quote) nicht verarbeiten</li>
			<li class="remove">Texter: Option zum Umschalten der Filter von Buttons auf Dropdowns (jetzt immer Buttons)</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.2</h5>
		<ul class="unstyled changelogList">
			<li class="fix">Fach speichern</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Zeugnis-App: BW LEB kann nun schulspezifisch angepasst werden</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.2.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Setup der Zeugnis-App</li>
			<li class="add">Schulstammdaten für die Verwendung in DiLer (Optionen)</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.1.1</h5>
		<ul class="unstyled changelogList">
			<li class="add">Option: Übung selbsbestätigt	</li>
			<li class="add">Option: Abgabetyp für Aufgaben</li>
			<li class="add">dauerhaftes Change Log im Dashboard</li>
			<li class="add">Lösch-Button für zuordnungen der Zusatzangebote</li>
		</ul>
	</div>
	<div class="changelogBlock">
		<h5>4.1.0</h5>
		<ul class="unstyled changelogList">
			<li class="add">Familien ID in 'Reg-Code Neu' Familien-Dropdown</li>
			<li class="add">Optionen: Ordnerangabe zur Speicherung der Mediendateien</li>
			<li class="add">Optionen: verschiedene Prüfungen von Uploads</li>
			<li class="add">Dashboard: neue Sturktur mit Change Log</li>
			<li class="remove">Option für Bildschirmtastatur entfällt, da permanent sichtbar</li>
		</ul>
	</div>
	*/ ?>
</div>
