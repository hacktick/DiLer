<?php
/**
 * Gradingmethod table construct, bind, load
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

use Joomla\Registry\Registry;
use Joomla\CMS\Table\Table;

// import Joomla table library
jimport('joomla.database.table');

/**
 * Gradingmethod Table class
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 5.0
 */
class DiLerTableActivitytype extends Table
{

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function __construct(&$db)
	{
		parent::__construct('#__diler_activity_type', 'id', $db);
	}

	/**
	 * Overloaded bind function
	 *
	 * @return bool
	 * @see Table:bind
	 * @since 1.5
	 */
	public function bind($array, $ignore = '')
	{

		// Set the publish date to now
		$db = $this->getDbo();
		if (isset($array['params']) && is_array($array['params']))
		{
			// Convert the params field to a string.
			$parameter = new Registry();
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}
		return parent::bind($array, $ignore);
	}

	/**
	 * Overloaded load function
	 *
	 * @param int $pk primary key
	 * @param boolean $reset reset data
	 * @return boolean
	 * @see Table:load
	 */
	public function load($pk = null, $reset = true)
	{
		if (parent::load($pk, $reset))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}