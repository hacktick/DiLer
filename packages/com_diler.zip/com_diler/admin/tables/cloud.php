<?php
/**
 * Test table construct, bind, load
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Helper\UserGroupsHelper;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Table\Table;

// Import Joomla table library
jimport('joomla.database.table');
JLoader::register('JTableObserverDilerTags', JPATH_ROOT . '/administrator/components/com_diler/tables/observer/dilertags.php');

/**
 * Nimbustemplate Table class
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 5.1
 */
class DiLerTableCloud extends Table
{

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function __construct(&$db)
	{
		parent::__construct('#__diler_cloud', 'id', $db);
		JTableObserverDilerTags::createObserver($this, array('typeAlias' => 'com_diler.cloud', 'parentTagParam' => 'cloudParentTag'));
	}

	/**
	 * Overloaded check function. Make sure path is unique in table.
	 *
	 * @return  boolean
	 *
	 * @see     Table::check
	 * @since   3.3
	 */
	public function check()
	{
		// Check that we don't have a duplicate file name.
		$checkPath = str_replace('\\', '/', $this->path);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('id')
			->from('#__diler_cloud')
			->where('path = ' . $db->quote($checkPath));

		if ($this->id)
		{
			$query->where('id !=' . $this->id);
		}

		$alreadyExists = $db->setQuery($query)->loadResult();
		if ($alreadyExists)
		{
			$this->setError(DText::_('MEDIA_DUPLICATE_NAME'));
		}
		return ! $alreadyExists;
	}
	
	public function delete($pk = null, $path = null)
	{
		$this->load($pk);
			File::delete(DilerHelperUser::getRootFileFolder() . $path);
		
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_group_cloud_map')
			->where('media_id = ' . $pk);
		
		$db->setQuery($query)->execute();
		
		return parent::delete($pk);
	}

	/**
	 * @return bool|UserGroupsHelper
	 * @since 6.5.1
	 */
	public function getGroupName()
	{
		if (!$this->id)
			return false;
		
		$query = $this->_db->getQuery(true);
		$query->select('group_id');
		$query->from('#__diler_group_cloud_map');
		$query->where('media_id = ' . $this->_db->quote($this->id));
		$groupId = $this->_db->setQuery($query)->loadResult();
		
		if (!$groupId)
			return false;

		/** @var DiLerModelGroup $groupModel */
		$groupModel = BaseDatabaseModel::getInstance('Group', 'DilerModel');
		$dilerGroup = $groupModel->getDilerGroupByJoomlaGroupId($groupId);

		return $dilerGroup->name;
	}
}
