<?php
/**
 * Test table construct, bind, load
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access
use Joomla\CMS\Table\Table;

defined('_JEXEC') or die('Restricted access');

// Import Joomla table library
jimport('joomla.database.table');

/**
 * Test Table class
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerTableActivity extends Table
{

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	public function __construct(&$db)
	{
		parent::__construct('#__diler_activity', 'id', $db);
	}

	/**
	 * Load related Compchar to currently loaded Activity
	 * @return bool
     * @since 6.4.1
	 */
	public function getCompchar()
	{
		if (!$this->id)
			return false;
		
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('compchar_id');
		$query->from('#__diler_activity_compchar_map');
		$query->where('activity_id = ' . $this->id);
		$compCharId = $db->setQuery($query)->loadResult();
		
		$compCharTable = Table::getInstance('CompChar', "DiLerTable");
		$compCharTable->load($compCharId);
		
		return $compCharTable;
	}

	/**
	 * @return bool|DiLerTableActivitytype
	 * @since 6.5.0
	 */
	public function getActivityType()
	{
		if (!$this->activity_type)
			return false;
		
		/** @var DiLerTableActivitytype $activityTypeTable */
		$activityTypeTable = Table::getInstance('Activitytype', 'DiLerTable');
		$activityTypeTable->load($this->activity_type);
		
		return $activityTypeTable;
	}
}