<?php
/**
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2019 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use Joomla\CMS\Table\Table;

// No direct access
defined('_JEXEC') or die('Restricted access');

/**
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 6.4.2
 */
class DiLerTableActivityTaskCompleted extends Table
{
	public function __construct($db)
	{
		parent::__construct('#__diler_activity_task_completed', array('task_id', 'student_id'), $db);
	}
	
	public function store($updateNulls = false)
	{
		if (!$this->hasPrimaryKey())
		{
			/** @var DiLerTableActivitytask $taskTable */
			$taskTable = Table::getInstance('Activitytask', 'DiLerTable');
			$taskTable->load($this->task_id);
			$this->task_name = $taskTable->name;
			$this->task_instruction = $taskTable->instruction;
			$this->task_max_points = $taskTable->max_points;
		}
		return parent::store($updateNulls);
	}

	/**
	 * @return bool|Table
     * @since 6.4.2
	 */
	public function getActivityTask()
	{
		if (!$this->task_id)
			return false;

		$query = $this->_db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_activity_task');
		$query->where('id = ' . (int) $this->task_id);
		$activityTaskId = $this->_db->setQuery($query)->loadResult();
		/** @var DiLerTableActivitytask $activityTable */
		$activityTaskTable = Table::getInstance('ActivityTask', 'DiLerTable');
		$activityTaskTable->load($activityTaskId);

		return $activityTaskTable;
	}
}