<?php
/**
 * This JLayout file shows the counts for the proposed status purge
 *
 * @package        DiLer.Site
 * @subpackage    com_diler
 * @filesource
 *
 * @copyright    Copyright (C) 2017 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;

extract($displayData);

?>
<?php if ($action == 'count' && $totalRows) : ?>
    <div class="alert alert-info">
        <h2 class="alert-heading"><?php echo DText::sprintf('RESET_ACHIEVEMENT_TOTAL_COUNT_MESSAGE', $totalRows); ?></h2>
        <div class="alert-message">
            <ul>
                <li><?php echo DText::sprintf('RESET_ACHIEVEMENT_COUNT_MESSAGE', $compcharCount, DText::_('COMPCHARS')); ?></li>
                <li><?php echo DText::sprintf('RESET_ACHIEVEMENT_COUNT_MESSAGE', $competenceCount, DText::_('COMPETENCES')); ?></li>
                <li><?php echo DText::sprintf('RESET_ACHIEVEMENT_COUNT_MESSAGE', $subjectCount, DText::_('SUBJECTS')); ?></li>
            </ul>
        </div>
    </div>

<?php elseif ($action == 'count') : ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <h4 class="alert-heading"><?php echo DText::_('RESET_ACHIEVEMENT_TOTAL_ZERO_COUNT_MESSAGE'); ?></h4>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
        </button>
    </div>

<?php else : ?>

    <div class="alert-success">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <h4 class="alert-heading"><?php echo DText::_('RESET_ACHIEVEMENT_SUCCESS_MESSAGE'); ?></h4>
    </div>


<?php endif; ?>