<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;

?>
<a class="btn btn-danger"
        onclick="openModal('#purge<?php echo $displayData['sectionName'] ?>ByLearningGroupModal')">
	<?php echo DText::sprintf('BUTTON_CLEAR_DILER_DELETE_BY', Text::_('COM_DILERREG_LG_PLURAL')) ?>
</a>
