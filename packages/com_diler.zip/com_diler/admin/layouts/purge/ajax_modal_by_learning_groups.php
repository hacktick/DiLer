<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;

$purgeSectionName = $displayData['sectionName'];
$headerTitle = $displayData['headerTitle'];
/** @var Form $form */
$form = $displayData['form'];

?>

<div id="purge<?php echo $purgeSectionName ?>ByLearningGroupModal" class="modal purgeDataWithAjax" tabindex="-1" role="dialog"
     data-purge-data-by-type="learningGroups">
	<form data-purge-section="<?php echo $purgeSectionName ?>">
        <div class="modal-dialog">
            <div class="modal-content">
		        <div class="modal-header">
		        	<h3>
                        <?php echo $headerTitle; ?>
		        	</h3>
		        </div>
		        <div class="modal-body modal-scrollable-body">
		        	<div class="container-fluid">
		        		<label><?php echo $form->getLabel('purgeTillDate'); ?></label>
                        <?php // We need to add "onchange" attribute here as defining in XML not working (not rendered)
		        		$form->setFieldAttribute('purgeTillDate', 'onchange', 'updateInfoData(this)');
		        		echo $form->getInput('purgeTillDate') ?>
		        		<hr>
		        		<h4><?php echo Text::_('COM_DILERREG_LG_PLURAL') ?></h4>
		        		<div class="purgeSelectorsWrapper">
		        			<div class="purgeCheckboxes"></div>
		        		</div>
		        	</div>
		        </div>
		        <div class="modal-footer">
		        	<div class="progress hide">
		        		<div class="progress-bar bar" role="progressbar"></div>
		        	</div>
		        	<div class="form-inline">
		        		<button class="btn btn-danger submitButton" disabled type="button">
		        			<?php echo DText::sprintf('BUTTON_CLEAR_DILER_DELETE_BY', Text::_('COM_DILERREG_LG_PLURAL')) ?>
		        		</button>
		        		<button type="button" onclick="closeModalById('#purge<?php echo $purgeSectionName ?>ByLearningGroupModal')" class="btn" data-dismiss="modal" aria-hidden="true"
		        		        data-close="<?php echo Text::_("JTOOLBAR_CLOSE"); ?>">
		        			<?php echo Text::_("JCANCEL"); ?>
		        		</button>
		        	</div>
		        </div>
            </div>
        </div>
	</form>
</div>
