<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
use DiLer\Lang\DText;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$section = ucfirst($displayData['section']);
defined('_JEXEC') or die('Restricted access');
?>
<div id="purge<?php echo $section ?>Modal" class="modal" tabindex="-1"
     role="dialog" aria-labelledby="purge<?php echo $section ?>Modal" aria-hidden="true">
	<form action="<?php echo Route::_('index.php'); ?>" method="post" name="purgeDiler">
        <div class="modal-dialog">
            <div class="modal-content">
		        <div class="modal-header">
		        	<h3 id="purgeStudentModalLabel">
                        <?php echo $displayData['headerTitle']; ?>
		        	</h3>
		        </div>
		        <div class="modal-body">
		        	<p class="alert warning"><?php echo DText::_('BUTTON_CLEAR_DILER_CONFIRM') ?></p>
		        </div>
		        <div class="modal-footer">
		        	<div class="form-inline">
		        		<button class="btn btn-danger submitButton" disabled>
		        			<?php echo Text::_('JACTION_DELETE'); ?>
		        		</button>
                        <button type="button" onclick="closeModalById('#purge<?php echo $section ?>Modal')" class="btn btn-small closeButton" data-bs-dismiss="modal" aria-label="<?php echo Text::_("JCANCEL"); ?>">
                            <?php echo Text::_("JCANCEL"); ?>
                        </button>

                    </div>
		        </div>
            </div>
        </div>
		<input type="hidden" name="option" value="com_diler"/>
		<input type="hidden" name="task" value="purge.delete<?php echo $section ?>"/>
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>

