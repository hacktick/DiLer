<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\Lang\DText;

$calendarTables = array('#__dpcalendar_locations','#__dpcalendar_events_location','#__dpcalendar_events');
$purgeModel = MVCHelper::factory()->createModel('Purge', 'Administrator');

$tablesGroup = $displayData['tables'];
// @TODO Change to read $calendarTables from DiLerModelPurge like rest of tables
$tables = $tablesGroup == "calendarTables" ? $calendarTables : $purgeModel->getDbTablesByGroup($tablesGroup);
sort($tables);
$tableList =  '<ol><li>' . implode('</li><li>', $tables) . '</li></ol>';
?>
<p><?php echo DText::sprintf('PURGE_AFFECTED_DATABASE_TABLES', $tableList); ?></p>
