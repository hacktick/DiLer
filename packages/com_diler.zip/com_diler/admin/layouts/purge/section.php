<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Layout\LayoutHelper;

$deleteWhat                 = $displayData['deleteWhat'];
$ajaxButtons                = isset($displayData['ajaxButtons']) ? $displayData['ajaxButtons'] : array();
$description                = isset($displayData['description']) ? $displayData['description'] : DText::sprintf('SELECTIVELY_DELETE', $displayData['deleteWhat']);
$affectedTables             = $displayData['affectedTables'];
$displayData['headerTitle'] = $deleteWhat;

$modals       = isset($displayData['modals']) ? $displayData['modals'] : array();
$customModals = isset($displayData['customModals']) ? $displayData['customModals'] : array();
?>
<div class="row-fluid">
    <div class="span12 well">
        <h4><?php echo $deleteWhat ?></h4>
        <p>
			<?php foreach ($customModals as $modal)
				echo LayoutHelper::render('purge.button', $modal);

			foreach ($ajaxButtons as $ajaxButton)
				echo LayoutHelper::render('purge.ajax_button_by_' . $ajaxButton, $displayData);
	
			foreach ($modals as $modal)
				echo LayoutHelper::render('purge.button', $modal);

			?>
        </p>
        <p><?php echo $description ?></p>
		<?php echo LayoutHelper::render('purge.affected_tables', ['tables' => $affectedTables]); ?>
    </div>
	<?php
	foreach ($customModals as $customModal)
	{
		echo $customModal['modal'];
	}

	foreach ($ajaxButtons as $ajaxButton)
		echo LayoutHelper::render('purge.ajax_modal_by_' . $ajaxButton, $displayData);

	foreach ($modals as $modal)
	{
		$modal['headerTitle'] = $deleteWhat;
		echo LayoutHelper::render('purge.modal', $modal);
	}

	?>
</div>
