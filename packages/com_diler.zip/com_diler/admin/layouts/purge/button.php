<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;

$buttonText = isset($displayData['buttonText']) ? $displayData['buttonText'] : DText::placehoder('Delete');
?>
<button class="btn btn-danger" onclick="openModal('#purge<?php echo ucfirst($displayData["section"]) ?>Modal')">
    <?php echo $buttonText ?>
</button>
