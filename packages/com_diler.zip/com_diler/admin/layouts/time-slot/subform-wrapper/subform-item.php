<?php
/**
 * @copyright Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use DiLer\Lang\DText;

defined('_JEXEC') or die;
extract($displayData);
?>
<div class="subform-repeatable-group" data-base-name="<?php echo $basegroup; ?>" data-group="<?php echo $group; ?>">
	<div class="subform-repeatable-group-inner">
		<div class="control-group">
			<div class="controls">
				<?php echo $form->getGroup('')['jform_time_slot_list__time_slot_list' . $currentIndex . '__name']->renderField(); ?>
				<div class="control-group">
					<div class="control-label">
						<?php echo DText::_('START_TIME'); ?>
					</div>
					<div class="controls">
						<div class="btn-group scheduleTimeHolder">
							<div class="hours scheduleHours start_time<?php echo $currentIndex; ?>"></div>
							<div class="doubleDot">:</div>
							<div class="minutes scheduleMinutes start_time<?php echo $currentIndex; ?>"></div>
						</div>
					</div>
				</div>
				<div class="control-group">
					<div class="control-label">
						<?php echo DText::_('END_TIME'); ?>
					</div>
					<div class="controls">
						<div class="btn-group scheduleTimeHolder">
							<div class="hours scheduleHours end_time<?php echo $currentIndex; ?>"></div>
							<div class="doubleDot">:</div>
							<div class="minutes scheduleMinutes end_time<?php echo $currentIndex; ?>"></div>
						</div>
					</div>
				</div>
				<?php echo $form->getGroup('')['jform_time_slot_list__time_slot_list' . $currentIndex . '__start_time']->renderField(); ?>
				<?php echo $form->getGroup('')['jform_time_slot_list__time_slot_list' . $currentIndex . '__end_time']->renderField(); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="controls">
				<?php if (!empty($buttons)) : ?>
					<div class="btn-group">
						<?php if (!empty($buttons['remove'])) : ?>
							<a class="group-remove btn  btn-danger">
								<i class="fal fa-times icon-cancel" aria-hidden="true"></i>
								<?php echo DText::_('REMOVE_TIME_SLOT'); ?>
							</a>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<?php if (!empty($buttons['add'])) : ?>
					<div class="btn-group">
						<a class="group-add btn btn-success">
							<i class="fal fa-plus icon-add" aria-hidden="true"></i>
							<?php echo DText::_('ADD_TIME_SLOT'); ?>
						</a>
					</div>
				<?php endif; ?>
				<?php if (!empty($buttons['move'])) : ?><a class="group-move btn  btn-info"><i class="icon-list"></i> </a><?php endif; ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label"> </div>
			<div class="controls">
				<hr>
			</div>
		</div>
	</div>
</div>
<script>
    jQuery(document).ready(function () {
        jQuery(".selectize-input>input").css("width","20px").css("position","");
    });
</script>