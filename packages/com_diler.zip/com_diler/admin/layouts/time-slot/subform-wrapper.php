<?php

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;

extract($displayData);

if ($multiple)
{
	Factory::getApplication()
		->getDocument()
		->getWebAssetManager()
		->useScript('webcomponent.field-subform');
}
$sublayout = 'subform-item';
?>
<div class="subform-repeatable-wrapper subform-layout">
    <joomla-field-subform class="subform-repeatable<?php echo $class; ?>" name="<?php echo $name; ?>"
                          button-add=".group-add" button-remove=".group-remove"
                          button-move="<?php echo empty($buttons['move']) ? '' : '.group-move' ?>"
                          repeatable-element=".subform-repeatable-group" minimum="<?php echo $min; ?>"
                          maximum="<?php echo $max; ?>">
		<?php if (!empty($buttons['add'])) : ?>
            <div class="btn-toolbar">
                <div class="btn-group">
                    <button type="button" class="group-add btn btn-sm button btn-success"
                            aria-label="<?php echo Text::_('JGLOBAL_FIELD_ADD'); ?>">
                        <span class="icon-plus icon-white" aria-hidden="true"></span>
                    </button>
                </div>
            </div>
		<?php endif; ?>
		<?php
		foreach ($forms as $key => $form) :
			echo $this->sublayout($sublayout,
				array(
					'currentIndex' => $key,
					'form'         => $form,
					'basegroup'    => $fieldname,
					'group'        => $fieldname . $key,
					'buttons'      => $buttons
				)
			);
		endforeach;
		?>
		<?php if ($multiple) : ?>
            <template class="subform-repeatable-template-section hidden"><?php
				echo trim($this->sublayout($sublayout, array(
							'form'              => $tmpl,
							'basegroup'         => $fieldname,
							'group'             => $fieldname . 'X',
							'buttons'           => $buttons,
							'unique_subform_id' => $unique_subform_id,
							'currentIndex'      => 'X'
				)));
				?></template>
		<?php endif; ?>
    </joomla-field-subform>
</div>
