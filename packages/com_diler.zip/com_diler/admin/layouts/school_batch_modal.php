<?php
/**
 *
 * @copyright   Copyright (C) 2013 - 2021 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\HTML\HTMLHelper;

/**
 * Layout variables
 * ---------------------
 *
 * @var  string   $extension The extension name
 */

extract($displayData);

?>
<label id="batch-choose-action-lbl" for="batch-choose-action"><?php echo DText::_('SCHOOL_BATCH_REGION'); ?></label>
<div id="batch-choose-action" class="control-group">
	<select class="advancedSelect" id="batch-region-id" name="batch[region-id]" onchange="enableSubmit()">
		<option value="" selected ><?php echo DText::sprintf('FILTER_SELECT_EMPTY', DText::_('REGION')); ?></option>
		<?php echo HTMLHelper::_('select.options', $regions, 'id', 'select_text'); ?>
	</select>
</div>

