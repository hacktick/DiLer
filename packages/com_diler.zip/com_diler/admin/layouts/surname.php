<?php
use DiLer\Layouts\SchoolsList\Surname;
use DiLer\DUrl;

/** @var Surname $displayData */
?>

<?php if ($displayData->isAdministrator()) : ?>
	<a href="<?php echo DUrl::editUser($displayData->userId()); ?>">
		<?php echo $displayData->surName(); ?>
	</a>
<?php else: ?>
	<?php echo $displayData->surName(); ?>
<?php endif; ?>