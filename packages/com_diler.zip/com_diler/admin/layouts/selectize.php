<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   Copyright (C) 2005 - 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('JPATH_BASE') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

/**
 * Layout variables
 * ---------------------
 *
 * @var  string   $selector       The id of the field
 * @var  array    $options        The options array
 * @var  boolean  $debug          Are we in debug mode?
 */

extract($displayData);

// Include jQuery
HTMLHelper::_('jquery.framework');
$document = Factory::getDocument();
$document->addScript(Uri::root(true) . '/media/com_diler/js/selectize.js');
$document->addStyleSheet(Uri::root(true) . '/media/com_diler/css/selectize.bootstrap2.css');
// Options array to json options string
$optionsString = json_encode($options);

$document->addScriptDeclaration(
	'
	jQuery(function ($) {
		initChosen();
		$("body").on("subform-row-add", initChosen);

		function initChosen(event, container)
		{
			container = container || document;
			$(container).find(' . json_encode($selector) . ').selectize(' . $optionsString. ');
		}
	});
	'
);
