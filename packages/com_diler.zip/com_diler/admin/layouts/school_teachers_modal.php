<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
use DiLer\DPath;
use DiLer\Lang\DText;
use DiLer\Layouts\SchoolsList\Surname;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;

defined('_JEXEC') or die('Restricted access');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');
extract($displayData);
$nullDate = Factory::getDbo()->getNullDate();
$isAdministrator = Factory::getApplication()->isClient('administrator');
?>
<div class="modal hide fade" id="schoolUsersModal" aria-hidden="true" aria-labelledby="schoolUsersModalLabel" tabindex="-1">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"><?php echo DText::sprintf('SCHOOL_ASSIGNED_TEACHERS_HEADING', $schoolInfo->name); ?></h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th></th>
                        <th><?php echo Text::_('COM_DILERREG_LAST_NAME_LABEL'); ?></th>
                        <th><?php echo Text::_('COM_DILERREG_FIRST_NAME_LABEL'); ?></th>
                        <th><?php echo DText::_('CONFIG_LEARNING_GROUPS_LABEL'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
		            <?php foreach ($rowArray as $typeArray) : ?>
			            <?php if (! count($typeArray['rows'])) : ?>
				            <?php continue; ?>
			            <?php endif; ?>
                        <tr><td colspan="4"><h4><?php echo DText::_($typeArray['tag']); ?></h4></td></tr>
			            <?php foreach ($typeArray['rows'] as $row) : ?>
                            <tr>
                                <td></td>
                                <td>
						            <?php
						            echo LayoutHelper::render(
							            'surname',
							            new Surname($row->surname, $row->user_id, $isAdministrator),
							            DPath::ADMINISTRATOR_LAYOUTS);
						            ?>
                                </td>
                                <td><?php echo $row->forename; ?></td>
                                <td><?php echo $row->lg_names; ?></td>
                            </tr>
			            <?php endforeach; ?>
		            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button class="btn btn-small closeButton" data-bs-dismiss="modal"
                        data-close="<?php echo Text::_("JTOOLBAR_CLOSE"); ?>">
					<?php echo Text::_("JCANCEL"); ?>
                </button>
            </div>
        </div>
    </div>
</div>
