<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\Display\DMediaDisplay;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

defined('_JEXEC') or die('Restricted access');

class Media
{
    public static function display($options)
    {
        if (!$options['name'])
            return "";

        if (!isset($options['groupId']))
            $options['groupId'] = 0;

        $mediaDisplay = new DMediaDisplay($options['name'], (object) $options);
        $embed['preview'] = $mediaDisplay->getPreview() . $mediaDisplay->getFileNameLabel();
        $embed['actions'] = $mediaDisplay->getShareHtml($options['groupId']) .
            $mediaDisplay->getDownloadLink() .
            $mediaDisplay->getDeskBackgroundHtml() .
            $mediaDisplay->getFileNameInfo() .
            $mediaDisplay->getCheckbox();

        return (object) $embed;
    }

    public static function displayThumbnail($options)
    {
        $fileName = $options['name'];
        $competenceId = isset($options['competenceId']) ? $options['competenceId'] : 0;
        $result = '';
        if ($fileName)
        {
            $filetype = pathinfo($fileName);
            $encFile = base64_encode($fileName);
            $token = '&competence_id=' . $competenceId . '&' . Session::getFormToken() . '=1';
            if (isset($options['mediaId']))
                $token = $token . '&media_id=' . $options['mediaId'];

            $imageEmbed = '<img style="height:72px; width:128px;" src="' . Route::_('index.php?option=com_diler&task=file.getThumbnail&fileName='
                    . $encFile . $token . '&height=72&width=128', false) . '"data-filename="' . $fileName .  '" data-file="' . $encFile . '"/>';

            $filetype['extension'] = isset($filetype['extension']) ? $filetype['extension'] : '';
            switch (strtolower($filetype['extension']))
            {
                case 'bmp':
                case 'png':
                case 'jpg':
                case 'jpeg':
                case 'gif':
                    $result = $imageEmbed;
                    break;

                default:
                    $result = '';
                    break;
            }
        }
        return $result;
    }
}