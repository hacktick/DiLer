<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\File\Thumbnail;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

class UserPicture
{
    public static function info($user, $role, $params)
    {
        $paramArray = ['student' => 'block_personal_picture_students', 'teacher' => 'block_personal_picture_teachers', 'parent' => 'block_personal_picture_parents'];
        $paramName = isset($paramArray[$role]) ? $paramArray[$role] : '';
        $blockPicture = $params->get($paramName, 1) || ! is_writable(FileRootFolder::getPath());
        $result = (object) ['status' => 0, 'src' => Uri::root().'media/com_diler/images/avatar.jpg', 'color' => 0, 'initials' => ''];
        if ($blockPicture) return $result;
        $result->status = 1;
        $result->color = 1 + ($user->user_id % 47);
        $result->initials = mb_substr($user->forename, 0, 1) . mb_substr($user->surname, 0, 1);
        // At this point, we want to try to get the picture
        if ($user->picture)
        {
            $pictureExists = MVCHelper::factory()->createModel('File', 'Site')->getPicture($user->picture, $user->user_id);
            if ($pictureExists)
            {
                $result->src = Route::_('index.php?option=com_diler&task=file.getThumbnail&fileName=' . base64_encode($user->picture) .
                    '&' . Factory::getApplication()->getSession()->getFormToken() . '=1' .
                    '&width=' . Thumbnail::PROFILE_THUMBNAIL_WIDTH .
                    '&height=' . Thumbnail::PROFILE_THUMBNAIL_HEIGHT .
                    '&media_folder=2');
            }
        }
        return $result;
    }

    public static function infoList($userList, $role, $params)
    {
        $result = [];
        foreach($userList as $user)
            $result[$user->user_id] = self::info($user, $role, $params);

        return $result;
    }
}