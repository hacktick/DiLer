<?php
/*
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\Helper;

use DiLer\DConst;
use DiLer\Reports\StoredReport;
use DilerHelperUser;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use \Exception;

defined('JPATH_BASE') or die();

class DiLerSettings {

	/**
	 * Used for radio input all over the code
	 * 2 is for NO
	 * @var int
	 * @since 6.10.1
	 */
	const CHECKED_NO = 2;
	
	/**
	 * Used for radio input all over the code
	 * 1 is for YES
	 * @var int
	 * @since 6.10.1
	 */
	const CHECKED_YES = 1;
	
	const MONDAY = "2";
	const TUESDAY = "3";
	const WEDNESDAY = "4";
	const THURSDAY = "5";
	const FRIDAY = "6";
	const DEFAULT_WEEKDAYS = array(
		self::MONDAY,
		self::TUESDAY,
		self::WEDNESDAY,
		self::THURSDAY,
		self::FRIDAY);
	/**
	 * @var DilerParams null 
	 * @since 6.4.1
	 */
	private static $instance = null;

	/**
	 * @var mixed
	 * @since 6.5.0
	 */
	private static $currentSchoolYear;

	/**
	 * @var mixed
	 * @since 6.8.0
	 */
	private $schoolCountry = null;

	/**
	 * @var mixed
	 * @since 6.8.0
	 */
	private $schoolState = null;

	private $dilerParams;
	
	public function __construct($params = null)
	{
		$this->dilerParams = $params ? $params : ComponentHelper::getParams('com_diler');
	}

	public static function init()
	{
		if (!self::$instance)
		{
			self::$instance = new DiLerSettings();
		}
		
		return self::$instance;
	}

	/**
	 * @return bool
	 * @since 6.4.1
	 */
	public function isAbsenceDaysVisible()
	{
		return  $this->dilerParams->get('studentRecordAbsencedaysDisplay', 0) &&
				$this->dilerParams->get('studentRecordExcusedAbsence', 0) &&
				$this->dilerParams->get('studentRecordUnexcusedAbsence', 0);
	}

	public function absenceCategories() : array
	{
		return array(
			$this->studentRecordExcusedAbsence(),
			$this->studentRecordUnexcusedAbsenceTagId(),
			$this->studentRecordHomeSchoolingTagId()
		);
	}

	public function studentRecordExcusedAbsence() : int
	{
		return $this->dilerParams->get('studentRecordExcusedAbsence', 0);
	}

	public function studentRecordUnexcusedAbsenceTagId() : int
	{
		return $this->dilerParams->get('studentRecordUnexcusedAbsence', 0);
	}

	public function studentRecordHomeSchoolingTagId() : int
	{
		return $this->dilerParams->get('studentRecordHomeSchooling', 0);
	}

	/**
	 * @return mixed
	 * @since 6.4.1 
	 */
	public function isNimbusEnabledStudentRecords()
	{
		return $this->dilerParams->get('nimbusStudentRecords', '0');
	}

	/**
	 * @return mixed
	 * @since 6.4.1 
	 */
	public function getSchoolName()
	{
		return $this->dilerParams->get('schoolname');
	}

	/**
	 * @return mixed
	 * @since 6.4.1
	 */
	public function getPrintFormat($default = "a4")
	{
		return $this->dilerParams->get('printFormat', $default);
	}

	/**
	 * @since 6.11.0
	 */
	public function getFirstDayOfWeek($default = 1) : int
	{
		return $this->dilerParams->get('week_first_day', $default);
	}

	
	public function getClassWeekDays($default = self::DEFAULT_WEEKDAYS) : array
	{
		return $this->dilerParams->get('class_week_days', $default);
	}
	/**
	 * Method to get param for Store Reports from extension config
	 * This is used to decide should we show button "Store Report" beside PDF button on frontend.
	 * If "optional" we show button so user can decide should we save .pdf report to 'diler-media' folder.
	 * If "always", we always save .pdf report to 'diler-media' folder
	 * And of course, if false, we never store .pdf reports on server.
	 * 
	 * @param string $storeType "studentrecords"|"studentreports"|"markstable"
	 *
	 * @return bool|string
	 * @throws Exception 
	 * @since 6.5.0 
	 */
	public function isStoreReportBtnVisible($storeType)
	{
		if (!in_array($storeType, StoredReport::ALLOWED_STORE_REPORT_TYPES))
			throw new Exception("Store report type: '$storeType' . is not allowd in " . __CLASS__ . '::' . __METHOD__);
		
		if ($storeType == StoredReport::STUDENT_RECORDS && $this->dilerParams->get('storeStudentRecordsReports', 0))
			return 'optional';
		
		if ($storeType == StoredReport::MARKS_TABLES && $this->dilerParams->get('storeStudentMarksTablesReports', 0))
			return 'optional';
		
		
		if ($storeType == StoredReport::STUDENT_REPORTS)
		{
			if ($storeStudentReports = $this->dilerParams->get('storeStudentReports', 0))
				return $storeStudentReports == 2 ? 'always' : 'optional';
		}
		
		return false;
	}


	/**
	 * Get Root file folder
	 * @return string|string[]
	 * @since 6.5.0 
	 */
	public function getRootFileFolder()
	{
		return str_replace(array('\\','//'), '/', $this->dilerParams->get('file_root_folder') . '/');
	}

	/**
	 * Gets the current schoolyear row from diler_schoolyear table.
	 * @return mixed
	 * @since 6.5.0
	 */
	public static function getCurrentSchoolyear()
	{
		if (!self::$currentSchoolYear)
		{
			$db    = Factory::getDbo();
			$query = $db->getQuery(true);
			$query->select('*');
			$query->from('#__diler_schoolyear');
			$query->where('current=1');
			$query->where('published=1');

			self::$currentSchoolYear = $db->setQuery($query)->loadObject();
		}
		
		return self::$currentSchoolYear;
	}
	
	public function getActiveUsersApiKey()
	{
		return $this->dilerParams->get('dilerManagerApiKey', null);
	}
	
	public function getLearningGroupParentId()
	{
		return $this->dilerParams->get('learning_group_parent_id');
	}
	
	public function getSchoolCountry()
	{
		if ($this->schoolCountry)
			return $this->schoolCountry;
		
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('iso2, name');
		$query->from('#__diler_country');
		$query->where('id = ' . $this->dilerParams->get('schooladdressCountryIso2', '0'));
		
		$this->schoolCountry = $db->setQuery($query)->loadObject();
		return  $this->schoolCountry;
	}
	
	public function getSchoolState()
	{
		if ($this->schoolState)
			return $this->schoolState;

		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('state_iso, name');
		$query->from('#__diler_state');
		$query->where('id = ' . $this->dilerParams->get('schooladdressCountryIso2', '0'));

		$this->schoolState = $db->setQuery($query)->loadObject();
		return  $this->schoolState;
	}
	
	public function learningGroupParentId()
	{
		return $this->dilerParams->get('learning_group_parent_id');
	}
	
	public function isNickNameVisibleForUser(string $role) : bool
	{
		return in_array($role, $this->dilerParams->get('user_roles_with_visible_nickname', array(DConst::USER_ROLE_STUDENT)));
	}
	
	public function baseSchoolUserGroupId()
	{
		return $this->dilerParams->get('base_school_teacher_group_id');
	}

    public function getSchoolSerialNumber()
    {
        return $this->dilerParams->get('schoolid');
    }
	
	public function branchSchoolTeacherUserGroupId()
	{
		return $this->dilerParams->get('branch_school_teacher_group_id');
	}

    public function ministryTeachersUserGroupId()
    {
        return $this->dilerParams->get('ministry_teacher_group_id');
    }

    public function regionTeachersUserGroup()
    {
        return $this->dilerParams->get('region_teacher_group_id');
    }

    public function digluTrainerUserGroup()
    {
        return $this->dilerParams->get('diglu_trainer_group_id');
    }

	public function digluManagerUserGroup()
    {
        return $this->dilerParams->get('diglu_manager_group_id');
    }

	public function userGroupIdsOfTeachers() : array
	{
		return $this->dilerParams->get('teacher_group_ids', array());
	}
	
	public function userGroupIdsOfStudent() : array
	{
		return $this->dilerParams->get('student_group_ids', array());
	}
	
	public function userGroupIdsOfParents() : array
	{
		return $this->dilerParams->get('parent_group_ids', array());
	}
	
	public function userGroupIdsOfAllRoles() : array
	{
		return array_merge(
			$this->userGroupIdsOfTeachers(),
			$this->userGroupIdsOfStudent(),
			$this->userGroupIdsOfParents()
		);
	}

	public function newsArticleIdForAllRoles()
	{
		return (int) $this->dilerParams->get('news_all');
	}

	public function newsArticleIdForRole($role)
	{
		return (int) $this->dilerParams->get('news_' . $role);
	}

	public function isDilerNewsForAllVisible() : bool
	{
		return $this->dilerParams->get('feeds_all', true);
	}

	public function isDilerNewsForUserRoleVisible(string $role) : bool
	{
		return $this->dilerParams->get('feeds_' . $role . 's', true);
	}

    public function getTermsAndConditionsId()
    {
        return $this->dilerParams->get('tandc_id', 0);
    }

    public function getImprintId()
    {
        return $this->dilerParams->get('imprint', 0);
    }

    public function userGroupIdsForNotificationAboutDigluRegistration() : array
    {
        if (!DilerHelperUser::isDiglu())
            return array();

        return $this->dilerParams->get('user_group_ids_for_notification_about_diglu_registration', array());
    }
}
