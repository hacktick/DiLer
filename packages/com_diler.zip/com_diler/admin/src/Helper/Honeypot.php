<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class Honeypot
{
    public static $honeypotFieldName = 'contact_by_email';

    public static function close()
    {
        $app = Factory::getApplication();
        if ($app->input->getInt(self::$honeypotFieldName, 0))
            $app->close();
    }

    public static function getInput()
    {
        return '<input type="checkbox" name="' . self::$honeypotFieldName . '" value="1" style="display:none !important" tabindex="-1" autocomplete="off">';
    }
}