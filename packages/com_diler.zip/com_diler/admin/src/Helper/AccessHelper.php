<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use DiLer\DConst;
use DiLer\Lang\DText;
use DiLer\Users\DPermission;
use Joomla\CMS\Access\Access;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Object\CMSObject;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

class AccessHelper
{
	private static $actions;
    private static array $accessibleStudentIds;

	public static function getActions($messageId = 0)
	{
		if (self::$actions)
			return self::$actions;

		// global user
		$user = Factory::getApplication()->getIdentity();
		$result = new CMSObject();
		if (empty($messageId))
			$assetName = 'com_diler';

		else
			$assetName = 'com_diler.message.' . (int) $messageId;

		$actions = Access::getActionsFromFile(JPATH_ADMINISTRATOR . '/components/' . 'com_diler' . '/access.xml');

		foreach ($actions as $action)
			$result->set($action->name, $user->authorise($action->name, $assetName));

		self::$actions = $result;

		return self::$actions;
	}

    public static function authorize($role)
    {
        $userRole = DilerRole::getRole();
        $allowedRoles = is_array($role) ? $role : array($role);
        return in_array($userRole, $allowedRoles);
    }

    public static function canView($item)
    {
        $result = true;
        $user = Factory::getUser();
        if ((strpos($item->link, 'option=com_dpcalendar') && ! $user->authorise('calendar.view', 'com_diler')) ||
            (strpos($item->link, 'doku.php') && (! DilerVersion::doesHaveExtendedFeatures() || ! $user->authorise('wiki.view', 'com_diler'))))
        {
            $result = false;
        }
        elseif (strpos($item->link, 'view=diler'))
        {
            $viewIndex = $item->getParams()->get('view_name', 0);
            switch ($viewIndex)
            {
                case 3:
                    $result = $user->authorise('group.manage', 'com_diler') || $user->authorise('group.assign', 'com_diler') ||
                        $user->authorise('activity.manage', 'com_diler') || $user->authorise('activity.manage.own', 'com_diler') ||
                        $user->authorise('nimbus.manage', 'com_diler', 'com_diler') || $user->authorise('nimbus.manage.own', 'com_diler');
                    break;

                case 4:
                    $cloudCats = CloudHelper::getCategories();
                    $result = (is_array($cloudCats) && count($cloudCats));
                    break;
            }
        }
        return $result;
    }

    public static function checkAccess($role)
    {
        if (self::authorize($role) == false)
        {
            $url = Route::_('index.php?option=com_users&view=login');
            $msg = DText::_('UNAUTHORIZE_ACCESS');
            $app = Factory::getApplication();
            $app->enqueueMessage($msg);
            $app->redirect($url);
        }
        else
            return true;
    }

    public static function checkSchoolIp($role = 'null', $isTest = false)
    {
        $result = 1;
        $params = ComponentHelper::getParams('com_diler');
        Factory::getLanguage()->load('com_dilerreg');

        $schoolIp = $params->get('school_ip');
        if ($params->get('diler_ip_restriction', 0) && $_SERVER['REMOTE_ADDR'] != $schoolIp)
            // All users must connect from school ip and no match
            $result = 0;

        elseif ($role == 'student' && $params->get('dilerstudents_ip_restriction', 0) && $_SERVER['REMOTE_ADDR'] != $schoolIp)
            // User is student and IP doesn't match
            $result = -1;

        elseif ($isTest && $role == 'student' && $params->get('dilertests_ip_restriction', 0) && $_SERVER['REMOTE_ADDR'] != $schoolIp)
            // Check for student test restriction
            $result = -2;

        return $result;
    }

    public static function isAllowedToDeleteStoredReport($reportType)
    {
        $authUser = Factory::getUser();
        $authUserRole = DilerRole::getRole($authUser->id);

        return Factory::getUser()->authorise("storereport.$reportType.delete", 'com_diler') && $authUserRole == 'teacher';
    }


    public static function canCreateStudentRecord()
    {
        $user = Factory::getUser();
        return $user->authorise('studentrecord.edit', 'com_diler') || $user->authorise('studentrecord.edit.own', 'com_diler');
    }

    public static function hasAccessToSchoolsList() : bool
    {
        $user = Factory::getUser();
        $digluHelper = new Diglu();
        $dPermission = new DPermission($user);
        $hasAccess = $dPermission->canTeacherViewAllSchools()
            || $dPermission->canTeacherViewSchoolsByState()
            || $dPermission->canTeacherViewSchoolsByPostalCodes();

        return $hasAccess && $digluHelper->isEnabled();
    }

    public static function hasAccessToStudent(int $userId, string $userRole) : bool
    {
        $isStudent = $userRole === DConst::USER_ROLE_STUDENT;
        $accessibleStudentIds = self::getAccessibleStudentIds();

        return $isStudent && in_array($userId, $accessibleStudentIds);
    }

    private static function getAccessibleStudentIds() : array
    {
        $userId = Factory::getUser()->id;

        if (isset(self::$accessibleStudentIds) && isset(self::$accessibleStudentIds[$userId]))
            return self::$accessibleStudentIds[$userId];

        $results = array();

        if (DilerRole::getRole() == DConst::USER_ROLE_PARENT)
        {
            $studentModel = MVCHelper::factory()->createModel('Student', 'Site');
            $results = $studentModel->getStudentsForParent($userId);
        }

        if (DilerRole::getRole() == DConst::USER_ROLE_TEACHER)
        {
            /** @var \DiLerModelTeacher $teacherModel */
            $teacherModel = MVCHelper::factory()->createModel('Teacher', 'Site');
            $results = $teacherModel->getMyStudents($userId);
        }

        self::$accessibleStudentIds[$userId] = array_column($results, 'user_id');
        return self::$accessibleStudentIds[$userId];
    }
}
