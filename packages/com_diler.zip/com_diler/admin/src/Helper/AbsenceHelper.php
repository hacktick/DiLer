<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DateTime;
use DateTimeZone;
use DiLer\Lang\DText;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Layout\LayoutHelper;

defined('_JEXEC') or die('Restricted access');

class AbsenceHelper
{
    public static function statisticsNotification()
    {
        $cache = Factory::getCache();
        $statsObject = $cache->get(function() {
            return self::todayAbsences();
        }, array(), 'today-absences-notification', false);

        $displayData['iconCount'] = self::iconCount($statsObject->absenceRecords);
        $displayData['modalLink'] = 'notificationAlertModal';
        $displayData['absenceStats'] = $statsObject->rows;
        $displayData['count'] = $statsObject->count;
        $displayData['studentRecordBadgeClass'] = ($displayData['iconCount']) ? 'newNotification badge badge-warning' : 'newNotification badge';
        $displayData['title'] = htmlspecialchars(DText::sprintf('NOTIFICATION_ALERT_ABSENCE_STATISTICS', $displayData['count']));
        $modalHtml = LayoutHelper::render('absence_stats', $displayData, JPATH_ROOT . '/components/com_diler/layouts/notifications');

        $alertHtml = LayoutHelper::render('student_records_alert', $displayData, JPATH_ROOT . '/components/com_diler/layouts/notifications');

        $notification = (object) [
            'modalHtml' => $modalHtml,
            'alertHtml' => $alertHtml,
        ];

        return $notification;
    }

    private static function todayAbsences()
    {
        $db = Factory::getdbo();

        $localTimezone = Factory::getUser()->getParam('timezone', Factory::getConfig()->get('offset'));
        $nowDate = new DateTime("now", new DateTimeZone($localTimezone));
        $todayDate = $nowDate->format('Y-m-d');
        $params = ComponentHelper::getParams('com_diler');
        $learningGroupParent = $params->get('learning_group_parent_id');
        $absenceCategories = array(
            'excused' => $params->get('studentRecordExcusedAbsence', 0),
            'unexcused' => $params->get('studentRecordUnexcusedAbsence', 0),
            'homeSchooling' => $params->get('studentRecordHomeSchooling', 0),
        );

        $query = $db->getQuery(true)
            ->select('sr.id, sr.student_id, sr.effective_date, sr.created, users.surname, users.forename, users.nickname, sr.created_by')
            ->select('dilerGroup.name AS learning_group_title, CASE'
                . ' WHEN tagmap.tag_id = ' . $absenceCategories['excused'] . ' THEN "excused"'
                . ' WHEN tagmap.tag_id = ' . $absenceCategories['unexcused'] . ' THEN "unexcused"'
                . ' ELSE "homeSchooling" END AS absence_type')
            ->from('#__diler_studentrecord as sr')
            ->where('sr.effective_date LIKE ' . $db->quote($todayDate . '%'))
            ->innerJoin('#__diler_studentrecord_tag_map as tagmap ON sr.id = tagmap.studentrecord_id AND tagmap.tag_id IN ('
                . implode(', ', $absenceCategories)
                . ') AND tagmap.tag_type = 3')
            ->innerJoin('#__dilerreg_users AS users ON sr.student_id = users.user_id')
            ->innerJoin('#__user_usergroup_map AS userGroupMap ON sr.student_id = userGroupMap.user_id')
            ->innerJoin('#__usergroups AS userGroup ON userGroupMap.group_id = userGroup.id AND userGroup.parent_id = ' . $learningGroupParent)
            ->innerJoin('#__diler_group AS dilerGroup ON dilerGroup.joomla_group_id = userGroup.id')
            ->order('absence_type ASC, dilerGroup.ordering, dilerGroup.name');

        $studentAbsenceRecords = $db->setQuery($query)->loadObjectList();
        $recordsWithUrl = Notifications::attachRecordUrl($studentAbsenceRecords);

        $rows = array();
        $rows["excused"] = array_filter($recordsWithUrl, function ($recordsWithUrl) {
            return $recordsWithUrl->absence_type == "excused";
        });
        $rows["unexcused"] = array_filter($recordsWithUrl, function ($recordsWithUrl) {
            return $recordsWithUrl->absence_type == "unexcused";
        });
        $rows["homeSchooling"] = array_filter($recordsWithUrl, function ($recordsWithUrl) {
            return $recordsWithUrl->absence_type == "homeSchooling";
        });
        $count = count($studentAbsenceRecords);

        return (object) array(
            'rows' => $rows,
            'count' => $count,
            'absenceRecords' => $studentAbsenceRecords,
        );
    }

    protected static function iconCount(array $absenceRecords) : int
    {
        $lastCheckDate = Notifications::lastTimeChecked('absenceStatsReadDate');
        $userId = Factory::getUser()->id;

        $newRecords = array_filter($absenceRecords, function($absenceRecord) use ($userId, $lastCheckDate) {
            return ($absenceRecord->created > $lastCheckDate && $absenceRecord->created_by !== $userId);
        });

        return count($newRecords);
    }
}