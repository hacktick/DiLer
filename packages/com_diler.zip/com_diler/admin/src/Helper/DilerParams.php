<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;
use Joomla\Registry\Registry;

defined('_JEXEC') or die('Restricted access');

class DilerParams
{
    protected static $userParams = [];

    public static function getUser($id = null)
    {
        $id = $id ? $id : Factory::getUser()->id;
        if (! isset(self::$userParams[$id]))
        {
            $db = Factory::getDbo();
            $query = $db->getQuery(true)->select('params')->from('#__dilerreg_users')->where('user_id = ' . ( int ) $id);
            $params = $db->setQuery($query)->loadResult();
            self::$userParams[$id] = new Registry($params);
        }
        return self::$userParams[$id];
    }

    public static function updateUser($params, $id = null)
    {
        $id = $id ? $id : Factory::getUser()->id;
        $db = Factory::getDbo();
        $query = $db->getQuery(true)->update('#__dilerreg_users')
            ->set('params = ' . $db->quote($params->toString()))->where('user_id = ' . $id);
        $result = $db->setQuery($query)->execute();
        if ($result) self::$userParams[$id] = $params;
        return $result;
    }
}