<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class CountriesHelper
{
    protected static $countries = null;

    public static function getCountries()
    {
        if (self::$countries !== null) return self::$countries;

        $db = Factory::getDbo();
        $query = $db->getQuery(true)->select('c.iso2 AS country_iso2, c.name AS country_name, s.state_iso AS state_iso, s.name AS state_name')
            ->from('#__diler_country AS c')
            ->innerJoin('#__diler_state AS s ON s.country_id = c.id')
            ->where('c.published = 1')
            ->order('c.ordering, s.ordering');
        $rows = $db->setQuery($query)->loadObjectList();
        $result = [];
        foreach ($rows as $row)
        {
            if (! isset($result[$row->country_iso2]))
                $result[$row->country_iso2] = (object) ['name' => $row->country_name, 'states' => []];

            $result[$row->country_iso2]->states[] = (object) ['name' => $row->state_name, 'id' => $row->state_iso];
        }
        self::$countries = $result;
        return self::$countries;
    }
}