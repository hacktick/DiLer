<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Feed\Feed;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;

defined('_JEXEC') or die('Restricted access');

class DilerVersion
{
	private static $extendedFeatures;

	public static function doesHaveExtendedFeatures()
	{
		if (!isset(self::$extendedFeatures))
		{
			self::$extendedFeatures = false;
			// Check for presence of all Talkie specific JS files
			$path = JPATH_ROOT . '/media/com_diler/js/';
			$talkieFiles = array(
				'eventemitter.min.js',
				'palava.min.js',
				'talkie.js',
				'talkie_util.js',
				'teacher-talkie.js',
				'state-machine.min.js',
				'cloud.js',
				'nimbus.js',
			);

			foreach ($talkieFiles as $file)
			{
				if (!File::exists($path . $file))
				{
					return self::$extendedFeatures;
				}
			}
			if (!Folder::exists(JPATH_ROOT . '/libraries/vendor/phpseclib') || ! Folder::exists(JPATH_ADMINISTRATOR . '/components/com_diler/vendor/phpoffice'))
			{
				return self::$extendedFeatures;
			}
			else
			{
				self::$extendedFeatures = true;
			}

		}
		return self::$extendedFeatures;
	}

    protected function handleVersion(Feed $feed, \SimpleXMLElement $el)
    {
        $feed->dilerVersion = (string) $el;
    }
}