<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;

defined('_JEXEC') or die('Restricted access');

class FileHelper
{
	public static function download($fullName, $options = [])
	{
		$tempFolder = Factory::getApplication()->getConfig()->get('tmp_path') . '/diler';
		$tempPath = $tempFolder . '/' . basename($fullName);
		if (isset($options['newExtension']))
		{
			$path_parts = pathinfo($tempPath);
			$tempPath = $tempFolder . '/' . $path_parts['filename'] . '.' . $options['newExtension'];
		}

		if (! (Folder::create($tempFolder) && File::copy($fullName, $tempPath)))
		{
			return false;
		}
		header("Set-Cookie: fileDownload=true; path=/");
		header("Content-Description: File Transfer");
		header("Content-type: application/octet-stream");
		header("Content-Disposition: attachment; filename=" . basename($tempPath));
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header("Content-Length: " . filesize($tempPath));

		readfile($tempPath);

		Factory::getApplication()->close();
	}
}