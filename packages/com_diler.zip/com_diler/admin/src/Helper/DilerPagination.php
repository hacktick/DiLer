<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\Lang\DText;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Pagination\Pagination;

defined('_JEXEC') or die('Restricted access');

class DilerPagination extends Pagination
{
    public function getLimitBoxAjax($selected = 10, $options = array())
    {
        $limits = array();
        $onChange = isset($options['onchange']) ? $options['onchange'] : '';
        $uniqueId = isset($options['uniqueId']) ? $options['uniqueId'] : '';
        $idTag = isset($options['idtag']) ? $options['idtag'] : '';
        $onChangeLimitSaveFilter = isset($options['onChangeLimitSaveFilter']) ? $options['onChangeLimitSaveFilter'] : "dilerSystem.saveFilterValue(this);";

        $limits[] = HTMLHelper::_('select.option', '10', Text::_('J10'));
        $limits[] = HTMLHelper::_('select.option', '50', Text::_('J50'));
        $limits[] = HTMLHelper::_('select.option', '100', Text::_('J100'));
        $limits[] = HTMLHelper::_('select.option', '500', Text::_('J500'));
        $limits[] = HTMLHelper::_('select.option', '1000', DText::_('1000'));
        $limits[] = HTMLHelper::_('select.option', '0', Text::_('JALL'));

        $html = HTMLHelper::_(
            'select.genericlist',
            $limits,
            'limit' . $uniqueId,
            'class="inputbox input-mini" size="1" onchange="' . $onChangeLimitSaveFilter . ';' . $onChange . '" data-limit-start="0"',
            'value',
            'text',
            $selected,
            $idTag
        );


        return $html;
    }

    public function getPaginationLinks($layoutId = 'pagination_links', $options = array())
    {
        // Allow to receive a null layout

        $layoutId = $layoutId === null ? 'pagination_links' : $layoutId;
        $limit = $this->viewall ? 0 : $this->limit;
        $limitField = $this->getLimitBoxAjax($limit, $options);

        $list = array(
            'prefix'       => $this->prefix,
            'limit'        => $limit,
            'limitstart'   => $this->limitstart,
            'total'        => $this->total,
            'limitfield'   => $limitField,
            'pagescounter' => $this->getPagesCounter(),
            'pages'        => $this->getPaginationPages(),
            'pagesTotal'   => $this->pagesTotal,
        );

        return LayoutHelper::render($layoutId, array('list' => $list, 'options' => $options), JPATH_COMPONENT . '/layouts');
    }
}