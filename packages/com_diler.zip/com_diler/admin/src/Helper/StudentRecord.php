<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

defined('_JEXEC') or die('Restricted access');

class StudentRecord
{
    public static function seenArray()
    {
        $userParams = DilerParams::getUser();
        $studentRecordSeenIds = $userParams->get('studentRecordSeenIds', '');
        $result = json_decode($studentRecordSeenIds);
        return ($result === null) ? [] : $result;
    }
}