<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;

\defined('_JEXEC') or die;

class DilerGroup
{
    protected static $v6Groups = null;

    public static function doesAnyExist()
    {
        if (self::$v6Groups === null)
        {
            $db = Factory::getDbo();
            $query = $db->getQuery(true)->select('COUNT(*)')->from('#__diler_group');
            self::$v6Groups = $db->setQuery($query)->loadResult();
        }

        if (! self::$v6Groups)
            Factory::getApplication()->enqueueMessage(DText::_('NO_GROUPS_CREATED'), 'error');
    }
}
