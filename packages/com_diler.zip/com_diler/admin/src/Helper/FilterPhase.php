<?php
/**
 * @package     Audivisa\Component\DiLer\Administrator\Helper
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

class FilterPhase
{
	public function applyPhaseFilter($query, $phase, $db) {
		if (empty($phase)) {
			return;
		}

		$query->leftJoin('#__diler_phase AS ph_filter ON ph_filter.id = scm.phase_id');

		$condition = is_numeric($phase)
			? 'scm.phase_id = ' . (int) $phase
			: 'ph_filter.value = ' . $db->quote($phase);

		$query->where($condition);
	}
}
