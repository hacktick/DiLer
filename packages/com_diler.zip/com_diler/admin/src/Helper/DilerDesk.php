<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\Lang\DText;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class DilerDesk
{
    public static function getItemId($urlLang)
    {
        $db = Factory::getDbo();
        $query = $db->getQuery(true);
        $query->select('id')
            ->from('#__menu')
            ->where('link LIKE "%option=com_diler&view=diler%"')
            ->where('params LIKE \'%view_name":"0"%\'')
            ->where('language LIKE ' . $db->quote('%' . $urlLang . '%'));
        return $db->setQuery($query)->loadResult();
    }

    public static function redirectToDesk()
    {
        $lang = Factory::getLanguage()->getTag();
        $itemid = self::getItemId($lang);
        Factory::getApplication()->enqueueMessage( DText::_('UNAUTHORIZE_ACCESS'), 'ERROR');
        Factory::getApplication()->redirect('index.php?option=com_diler&view=diler&Itemid=' . $itemid);
    }
}