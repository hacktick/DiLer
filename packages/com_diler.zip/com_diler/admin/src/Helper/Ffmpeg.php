<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Component\ComponentHelper;

defined('_JEXEC') or die('Restricted access');

class Ffmpeg
{
	public function isEnabled()
	{
        $params = ComponentHelper::getParams('com_diler');
        return (DilerVersion::doesHaveExtendedFeatures() && $params->get('ffmpeg_url') &&  $params->get('ffmpeg_username') && $params->get('ffmpeg_password'));
	}
}