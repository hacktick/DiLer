<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\Reports\StoredReport;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class StoredReports
{
    public static function getAllowedViewTypes()
    {
        $allowedTypes = array();
        $user         = Factory::getUser();

        foreach (StoredReport::ALLOWED_STORE_REPORT_TYPES as $type)
        {
            if ($user->authorise("storereport.$type.view", 'com_diler'))
                $allowedTypes[] = $type;
        }

        return $allowedTypes;
    }
}