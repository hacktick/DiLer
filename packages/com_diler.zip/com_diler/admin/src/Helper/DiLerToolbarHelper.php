<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Language\Text;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

class DiLerToolbarHelper
{
	public static function addPermissionsToolbarButton()
	{
		ToolbarHelper::link(Uri::base() . 'index.php?option=com_diler&view=permissions', Text::_('JCONFIG_PERMISSIONS_LABEL'), 'options');
	}
}