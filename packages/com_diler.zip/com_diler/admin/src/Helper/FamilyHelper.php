<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class FamilyHelper
{
    public static function parentIdsOfStudent($id)
    {
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('parent_id')
            ->from('#__dilerreg_parent_student_map AS m')
            ->innerJoin('#__dilerreg_users AS du ON du.user_id = m.parent_id')
            ->where('m.student_id = ' . (int) $id)
            ->where('m.student_id_type = 1')
            ->where('m.parent_id_type = 1')
            ->innerJoin('#__users AS u ON u.id = du.user_id')
            ->where('u.block = 0');
        return $db->setQuery($query)->loadColumn();
    }

    public static function getParentsForStudents(array $studentIds) : array
    {
        if (!$studentIds)
            return array();

        $db = Factory::getDbo();
        $query = $db->getQuery(true);
        $query->select('parent_id');
        $query->from('#__dilerreg_parent_student_map as psm');
        // In one school installation we had '#__dilerreg_parent_student_map.parent_id' that NOT
        // exist on '#__users' table. I can't figure out where we can delete user without removing those row(s)
        // For a now joining '#__users' table is the best way I can figure out
        $query->innerJoin('#__users as parent ON parent.id = psm.parent_id');
        $query->where('student_id IN (' . implode(',', $studentIds,) . ')');
        $query->where('student_id_type = 1');
        $query->where('parent_id_type = 1');
        return  $db->setQuery($query)->loadColumn();
    }
}