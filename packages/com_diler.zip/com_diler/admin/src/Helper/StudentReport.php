<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;
use Joomla\CMS\Layout\LayoutHelper;

defined('_JEXEC') or die('Restricted access');

class StudentReport
{
    public static function getValueObject($displayData, $fieldType, $fieldName)
    {
        $result = (object) ['user_id' => 0, 'forename' => '', 'surname' => '', 'salutation' => '', 'nickname' => ''];
        $userId = 0;
        $model = MVCHelper::factory()->createModel('Diler', 'Site');
        if ($fieldType === 'student' && isset($displayData->studentFields->$fieldName) && $displayData->studentFields->$fieldName->element_type == 4)
            $userId = $displayData->studentFields->$fieldName->value;

        elseif ($fieldType === 'subject' && isset($displayData->fields->$fieldName) && $displayData->fields->$fieldName->element_type == 4)
            $userId = $displayData->fields->$fieldName->value;

        elseif ($fieldType === 'period' && isset($displayData->reportInfo->$fieldName) && $displayData->reportInfo->$fieldName->element_type == 4)
            $userId = $displayData->reportInfo->$fieldName->value;

        elseif ($fieldType === 'student' && $fieldName === 'teacher_list_students')
            $userId = Factory::getUser()->id;

        if ($userId)
        {
            $teacher = $model->getInfo($userId);
            $result = (object) [
                'user_id'    => $userId,
                'forename'   => $teacher->forename,
                'surname'    => $teacher->surname,
                'salutation' => $teacher->salutation,
                'nickname'   => $teacher->nickname
            ];
        }
        return $result;
    }

    public static function getFields($displayData, $fieldType, $fieldName, $displayVariation, $cssStyles, $options = array())
    {
        $noData = (isset($displayData->reportInfo->noDataWarning) && $displayData->reportInfo->noDataWarning) ? '<span class="label label-warning">?</span>' :'';
        $result = '';
        if ($fieldType == 'student')
        {
            $subformFieldName = $fieldName . '_' . $displayData->student->user_id . '_0_';
            if (isset($displayData->studentFields->$subformFieldName) && $displayData->studentFields->$subformFieldName->element_type == 3)
                $fieldName = $subformFieldName;

            if (isset($displayData->studentFields->$fieldName) && $displayData->studentFields->$fieldName->published
                && ($displayData->studentFields->$fieldName->value || (isset($displayData->studentFields->$fieldName->displayEmpty) && $displayData->studentFields->$fieldName->displayEmpty)))
            {
                if ($displayData->studentFields->$fieldName->element_type == 3 && is_array($displayData->studentFields->$fieldName->value))
                {
                    // Process student subform field
                    $subformDisplayData = $displayData->studentFields->$fieldName;
                    $subformOptions = array('displayVariation' => $displayVariation, 'cssStyles' => $cssStyles, 'noData' => $noData);
                    $subformDisplayData->options = (object) $subformOptions;
                    $layout = isset($options['subformLayout']) ? $options['subformLayout'] : 'student_report_subform';
                    return LayoutHelper::render($layout, $subformDisplayData);
                }
                elseif ($displayData->studentFields->$fieldName->element_type != 3)
                {
                    // Process student textarea and select fields
                    if ($displayVariation == "value")
                    {
                        $cssClasses = isset($options['cssClasses']) ? ' class="'.$options['cssClasses'].'"' : '';
                        $cssStyles = $cssStyles ? ' style="'.$cssStyles.'"' : '';
                        $value = $displayData->studentFields->$fieldName->value ? nl2br($displayData->studentFields->$fieldName->value) : $noData;
                        $result = $value !== $noData ? '' : '<div class="notValid">'; // "invalid" could be passed as a css class to match bootstrap
                        $result .= $cssClasses || $cssStyles ? '<div'.$cssClasses.$cssStyles.'>':'';
                        $result .= $value;
                        $result .= $cssClasses || $cssStyles ? '</div>':'';
                        $result .= $value !== $noData ? '' : '</div>';
                    }
                    elseif ($displayVariation == "label")
                    {
                        $cssClasses = isset($options['cssClasses']) ? ' class="'.$options['cssClasses'].'"' : '';
                        $cssStyles = $cssStyles ? ' style="'.$cssStyles.'"' : '';
                        $label = $displayData->studentFields->$fieldName->label;
                        $result = $cssClasses || $cssStyles ? '<div'.$cssClasses.$cssStyles.'>':'';
                        $result .= $label;
                        $result .= $cssClasses || $cssStyles ? '</div>':'';
                    }
                }
            }
        }
        elseif ($fieldType == 'period')
        {
            if (isset($displayData->reportInfo->$fieldName) && ($displayData->reportInfo || (isset($displayData->reportInfo->$fieldName->displayEmpty)) && $displayData->reportInfo->$fieldName->displayEmpty))
                $result = '<div style="'.$cssStyles.'">'.$displayData->reportInfo->$fieldName.'</div>';

            if (isset($displayData->reportInfo->fields->$fieldName) && $displayData->reportInfo->fields->$fieldName->published
                && ($displayData->reportInfo->fields->$fieldName->value || (isset($displayData->reportInfo->$fieldName->displayEmpty)) && $displayData->reportInfo->$fieldName->displayEmpty))
            {
                if ($displayVariation == "value")
                {
                    $cssClasses = isset($options['cssClasses']) ? ' class="'.$options['cssClasses'].'"' : '';
                    $cssStyles = $cssStyles ? ' style="'.$cssStyles.'"' : '';
                    $value = $displayData->reportInfo->fields->$fieldName->value ? nl2br($displayData->reportInfo->fields->$fieldName->value) : $noData;
                    $result = $value !== $noData ? '' : '<div class="notValid">'; // "invalid" could be passed as a css class to match bootstrap
                    $result .= $cssClasses || $cssStyles ? '<div'.$cssClasses.$cssStyles.'>':'';
                    $result .= $value;
                    $result .= $cssClasses || $cssStyles ? '</div>':'';
                    $result .= $value !== $noData ? '' : '</div>';
                }
                elseif ($displayVariation == "label")
                {
                    $cssClasses = isset($options['cssClasses']) ? ' class="'.$options['cssClasses'].'"' : '';
                    $cssStyles = $cssStyles ? ' style="'.$cssStyles.'"' : '';
                    $label = $displayData->reportInfo->fields->$fieldName->label;
                    $result = $cssClasses || $cssStyles ? '<div'.$cssClasses.$cssStyles.'>':'';
                    $result .= $label;
                    $result .= $cssClasses || $cssStyles ? '</div>':'';
                }
            }
        }
        elseif ($fieldType == 'subject')
        {
            $subformFieldName = $fieldName . '_' . $displayData->student_id . '_' . $displayData->id . '_';
            if (isset($displayData->fields->$subformFieldName) && $displayData->fields->$subformFieldName->element_type == 3)
                $fieldName = $subformFieldName;

            if (isset($displayData->fields->$fieldName)  &&  $displayData->fields->$fieldName->published
                && ($displayData->fields->$fieldName->value || (isset($displayData->fields->$fieldName->displayEmpty) && $displayData->fields->$fieldName->displayEmpty)))
            {
                if ($displayData->fields->$fieldName->element_type == 3 && is_array($displayData->fields->$fieldName->value))
                {
                    // Process subject subform field
                    $subformDisplayData = $displayData->fields->$fieldName;
                    $subformOptions = array('displayVariation' => $displayVariation, 'cssStyles' => $cssStyles, 'noData' => $noData, 'subjectName' => isset($options['subjectName']) ? $options['subjectName'] : '');
                    $subformDisplayData->options = (object) $subformOptions;
                    $layout = isset($options['subformLayout']) ? $options['subformLayout'] : 'student_report_subform';
                    return LayoutHelper::render($layout, $subformDisplayData);
                }
                elseif ($displayData->fields->$fieldName->element_type != 3)
                {
                    // Process subject textarea and select fields
                    if ($displayVariation == "value")
                    {
                        $cssClasses = isset($options['cssClasses']) ? ' class="'.$options['cssClasses'].'"' : '';
                        $cssStyles = $cssStyles ? ' style="'.$cssStyles.'"' : '';
                        $value = $displayData->fields->$fieldName->value ? nl2br($displayData->fields->$fieldName->value) : $noData;
                        $result = $value !== $noData ? '' : '<div class="notValid">'; // "invalid" could be passed as a css class to match bootstrap
                        $result .= $cssClasses || $cssStyles ? '<div'.$cssClasses.$cssStyles.'>':'';
                        $result .= $value;
                        $result .= $cssClasses || $cssStyles ? '</div>':'';
                        $result .= $value !== $noData ? '' : '</div>';
                    }
                    elseif ($displayVariation == "label")
                    {
                        $subjectName = isset($options['subjectName']) ? $options['subjectName'] : '';
                        $cssClasses = isset($options['cssClasses']) ? ' class="'.$options['cssClasses'].'"' : '';
                        $cssStyles = $cssStyles ? ' style="'.$cssStyles.'"' : '';
                        $label = $displayData->fields->$fieldName->label;
                        $result = $cssClasses || $cssStyles ? '<div'.$cssClasses.$cssStyles.'>':'';
                        $result .= $label;
                        $result .= $cssClasses || $cssStyles ? '</div>':'';
                    }
                }

            }
        }

        return $result;
    }

    public static function getAchieveGrid($subjectId, $studentId, $showOnlyCompleted = false, $options = array())
    {
        $reportInfo = isset($options['reportInfo']) ? $options['reportInfo'] : [];
        $displayData = MVCHelper::factory()->createModel('Grid', 'Site')->getStudentReportGrid($subjectId, $studentId, $showOnlyCompleted, $reportInfo);
        $displayData['options'] = $options;
        $layout = isset($options['layout']) ? $options['layout'] : 'student_report_achieve_grid';
        return LayoutHelper::render($layout, $displayData);
    }
}