<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class HelpLink
{
	private DiLerAdministratorViewInterface $view;

	public function __construct(DiLerAdministratorViewInterface $view)
	{
		$this->view = $view;
	}

	public function getLink() : string
	{
		$lang = strtoupper(substr(Factory::getApplication()->getLanguage()->getTag(), 0, 2));
		$lang = in_array($lang, array('EN', 'DE')) ? $lang : 'EN';
		$temp = str_replace('_', ' ', $this->view->helpName());
		$helpPage = str_replace(' ', '_', ucwords($temp));

		$adminWiki = Factory::getApplication()->isClient('administrator') ? 'Backend:' : 'Frontend:';
		$urlNoLang = 'https://docs.digitale-lernumgebung.de/'.$adminWiki.$helpPage;
		$url = $urlNoLang . '_' . $lang;

		return $url;
	}
}