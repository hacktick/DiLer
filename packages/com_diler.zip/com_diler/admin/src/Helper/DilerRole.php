<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use DiLer\Lang\DText;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;

\defined('_JEXEC') or die;

class DilerRole
{
    protected static $lookup;
    public static $roleError = [];

    public static function getRole($userId = null)
    {
        if (! $userId)
            $userId = Factory::getUser()->id;

        if (isset(self::$lookup[$userId]))
            return self::$lookup[$userId];

        else
        {
            $groups = Factory::getUser($userId)->groups;
            $params = ComponentHelper::getParams('com_diler');
            $return = false;

            // Check for any matching group ids in priority order
            $isTeacher = count(array_intersect($groups, $params->get('teacher_group_ids', [])));
            $isStudent = count(array_intersect($groups, $params->get('student_group_ids', [])));
            $isParent = count(array_intersect($groups, $params->get('parent_group_ids', [])));
            $isAdmin = count(array_intersect($groups, $params->get('admin_group_ids', [])));
            if ($isTeacher && ! ($isStudent || $isParent || $isAdmin))
                $return = 'teacher';

            elseif ($isStudent && ! ($isTeacher || $isParent || $isAdmin))
                $return = 'student';

            elseif ($isParent && ! ($isTeacher || $isStudent || $isAdmin))
                $return = 'parent';

            elseif ($isAdmin && ! ($isTeacher || $isStudent || $isParent))
                $return = 'admin';

            else
            {
                $return = false;
                $inRoleArray = [];
                $roleArray = ['TEACHER' => $isTeacher, 'STUDENT' => $isStudent,'PARENT' => $isParent , 'ADMIN' => $isAdmin];
                foreach ($roleArray as $roleName => $inRole)
                    if ($inRole) $inRoleArray[] = DText::_($roleName);

                if (count($inRoleArray))
                    $message = DText::sprintf('ROLE_ERROR_MULITPLE_ROLES', implode(', ', $inRoleArray));

                else
                    $message = DText::_('ROLE_ERROR');

                self::$roleError[$userId] = $message;
            }
            // User must not be assigned to >1 role

            if (! $return) return false;
            // Make sure this user is approved in the #__dilerreg_users table
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('approve')
                ->from('#__dilerreg_users as du')
                ->innerJoin('#__users as U ON U.id = du.user_id')
                ->where('U.block = 0')
                ->where('du.user_id = ' . (int) $userId);
            $approved = $db->setQuery($query)->loadResult();

            if (($return && $approved) || ($return == 'admin'))
            {
                // Save for next time
                self::$lookup[$userId] = $return;
                return self::$lookup[$userId];
            }
            else
                return false;
        }
    }

    public static function isCurrentUserTeacher() : bool
    {
        return self::isUserTeacher();
    }

    public static function isUserTeacher(int $userId = null) : bool
    {
        return self::getRole($userId) === 'teacher';
    }

    public static function isExpertModeEnabled()
    {
        return Factory::getUser()->getParam('expertMode', '1') == 1;
    }

    public static function isFutureStudentRecordViewAllowed()
    {
        return Factory::getUser()->authorise('studentrecord.future.view', 'com_diler');
    }

}
