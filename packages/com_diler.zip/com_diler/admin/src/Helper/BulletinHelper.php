<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\Lang\DText;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Layout\FileLayout;
use stdClass;

defined('_JEXEC') or die('Restricted access');

class BulletinHelper
{
    public static function getContent()
    {
        if (!UserHelper::loggedIn())
            return new stdClass();

        $role = DilerRole::getRole();
        $options = ComponentHelper::getParams('com_diler');
        $userParams = DilerParams::getUser();
        $showNewsAll = $options->get('news_all');
        $showNewsRole = $options->get('news_' . $role);
        $enabled = false;
        $output = array();
        $changeDate = '0000-00-00 00:00:00';
        if ($showNewsAll || $showNewsRole)
        {
            $articles = array();
            if ($showNewsAll)
                $articles['all'] = self::getContentForRole('all');

            if ($showNewsRole)
                $articles[$role] = self::getContentForRole($role);

            foreach ($articles as $article)
            {
                if ($article->enabled)
                {
                    $enabled = true;
                    $displayData['article'] = $article;
                    $output[] = $displayData;
                    $changeDate = max(array($changeDate, $article->modified, $article->created));
                }
            }
            $unread = ($changeDate > $userParams->get('newsReadDate', '0000-00-00 00:00:00'));
            $result = (object) array('text' => $output , 'title' => DText::_('NOTIFICATION_ALERT_INTERNAL'), 'unread' => $unread, 'enabled' => $enabled);
        }
        else
            $result = (object) array('text' => '', 'title' => '', 'unread' => false, 'enabled' => $enabled);

        return $result;
    }

    protected static function getContentForRole($role)
    {
        try
        {
            $params = ComponentHelper::getParams('com_diler');
            $db = Factory::getDbo();
            $id = $params->get('news_' . $role, '0');
            if ($id)
            {
                $query = $db->getQuery(true)->select('id, introtext, title, created, modified, "1" AS enabled')
                    ->from('#__content')->where('state = 1 AND id = ' . (int) $id);
                $result = $db->setQuery($query)->loadObject();
                if (isset($result->title))
                    $result->title = htmlspecialchars($result->title);

                else
                    $result = (object) array('enabled' => false);
            }
            else
                throw new \RuntimeException(DText::sprintf('NEWS_ERROR', DText::_(strtoupper($role))), 1);

        }
        catch (\Exception $ex)
        {
            $enabled = (bool) $ex->getCode();
            $result = (object) array(
                'title' => $ex->getMessage(),
                'introtext' => '',
                'modified' => $db->getNullDate(),
                'created' => $db->getNullDate(),
                'enabled' => $enabled,
            );
        }
        return $result;
    }
}