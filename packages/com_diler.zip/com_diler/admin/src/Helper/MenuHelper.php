<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class MenuHelper
{
    public static function getMaintenanceMenuItem()
    {
        $result = false;
        $app = Factory::getApplication();
        $com = ComponentHelper::getComponent('com_diler');
        $menu = $app->getMenu();
        // Note that this automatically filters on the current language.
        $items = $menu->getItems('component_id', $com->id);
        if (is_array($items) && count($items))
        {
            foreach ($items as $item)
            {
                // Maintenance is view_name = 3
                if ($item->params->get('view_name') == 3)
                {
                    $result = $item->id;
                    break;
                }
            }
        }
        return $result;
    }
}