<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Language\Text;

defined('_JEXEC') or die('Restricted access');

class StringHelper
{
    public static function formatPoints($points, $precision = 3)
    {
        $regex = [
            '#\.000$#' => '',
            '#\.00$#' => '',
            '#\.0$#' => '',
            '#\.$#' => '',
            '#(.*\.)([1-9])00#' => '$1$2',
            '#(.*\.)([0-9][1-9])0#' => '$1$2'
        ];
        $points = str_replace(',', '.', $points);
        $pointsString = number_format((float) $points, $precision);
        $pointsFormatted = preg_replace(array_keys($regex), $regex, $pointsString);
        $pointsFormatted = str_replace('.', Text::_('DECIMALS_SEPARATOR'), $pointsFormatted);
        return $pointsFormatted;
    }
}