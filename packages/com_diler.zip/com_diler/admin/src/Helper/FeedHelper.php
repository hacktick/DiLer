<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use DiLer\Lang\DText;
use Exception;
use JLoader;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Feed\Feed;
use Joomla\CMS\Feed\FeedFactory;
use Joomla\CMS\Filesystem\Folder;
use RuntimeException;
use stdClass;

\defined('_JEXEC') or die;

class FeedHelper
{
    protected static function feedToObject(Feed $feed)
    {
        $result = new stdClass();
        $result->title = $feed->title;
        $result->description = $feed->description;
        $result->updateDate = $feed->updatedDate->toSql();
        $result->entries = array();
        $result->dilerVersion = $feed->__get('dilerVersion');
        for ($i = 0, $max = count($feed); $i < $max; $i++)
        {
            $result->entries[$i] = (object) array(
                'title' => $feed[$i]->title,
                'description' => $feed[$i]->description,
                'content' => $feed[$i]->content,
            );
        }
        return $result;
    }

    public static function getContent()
    {
        if (!UserHelper::loggedIn())
            return new stdClass();

        $lang = Factory::getLanguage();
        $lang->load('com_diler', JPATH_ROOT . '/components/com_diler', null, true);
        // See if newsfeeds are enabled for this role (DiLer options)
        $role = DilerRole::getRole();
        $options = ComponentHelper::getParams('com_diler');
        $userParams = DilerParams::getUser();
        $showFeedAll = $options->get('feeds_all');
        $showFeedRole = $options->get('feeds_' . $role . 's');
        $language = Factory::getLanguage()->getTag();
        $urlEnd = ($language == 'de-DE') ? 'de.xml' : 'en.xml';
        $output = array();
        $changeDate = '0000-00-00 00:00:00';
        $enabled = false;
        if ($showFeedAll|| $showFeedRole)
        {
            $enabled = true;
            // Get newsfeed objects
            $urlArray = array(
                'all' => 'https://www.digitale-lernumgebung.de/updateserver/diler/notifier/diler-notifier-update-feed-all-',
                'teacher' => 'https://www.digitale-lernumgebung.de/updateserver/diler/notifier/diler-notifier-update-feed-teachers-',
                'student' => 'https://www.digitale-lernumgebung.de/updateserver/diler/notifier/diler-notifier-update-feed-students-',
                'parent' => 'https://www.digitale-lernumgebung.de/updateserver/diler/notifier/diler-notifier-update-feed-parents-',
            );

            $activeArray = array();
            if ($showFeedAll)
                $activeArray['all'] = $urlArray['all'] . $urlEnd;

            if ($showFeedRole)
                $activeArray[$role] = $urlArray[$role] . $urlEnd;

            foreach ($activeArray as $role => $rssurl)
            {
                $feed = self::getContentForRole($role, $rssurl);
                $displayData['feed'] = $feed;
                $output[] = $displayData;

                // Get latest change date
                $changeDate = max(array($changeDate, $feed->updateDate));
            }

            // Return object
        }
        $unread = ($changeDate > $userParams->get('feedReadDate', '0000-00-00 00:00:00'));
        return (object) array('text' => $output, 'title' => DText::_('NOTIFICATION_ALERT_DILER_FEED'), 'unread' => $unread, 'enabled' => $enabled);
    }

    protected static function getContentForRole($role, $rssurl)
    {
        $cacheAge = 1;
        $cachedFeed = self::getCachedFeed($role);
        $date = Factory::getDate();
        $cachedDate = (isset($cachedFeed->cacheDate) ? Factory::getDate($cachedFeed->cacheDate) : Factory::getDate());
        $minutes = (strtotime($date) - strtotime($cachedDate)) / 60;
        $app = Factory::getApplication();
        if (! isset($cachedFeed->cacheDate) || $minutes > 60)
        {
            // Capture the output for the url
            try
            {
                $feedFactory   = new FeedFactory();
                JLoader::register('DilerRssParser', JPATH_ROOT . '/components/com_diler/helpers/dilerrssparser.php');
                $feedFactory->registerParser('rss', 'DilerRssParser', true);
                $feed = $feedFactory->getFeed($rssurl);
                $feedObject = self::feedToObject($feed);
                $feedObject = self::updateCache($role, $feedObject, $cachedFeed);
            }
            catch (Exception $e)
            {
                $feedObject = (object) array(
                    'title' => DText::sprintf('FEED_ERROR', DText::_(strtoupper($role))),
                    'description' => '',
                    'updateDate' => '0000-00-00 00:00:00',
                    'entries' => array(),
                );
                if ($e->getCode() === 999)
                    $feedObject->description = DText::_('NOTIFICATION_FOLDER_ERROR');

                else
                {
                    $feedObject->description = $e->getMessage();
                    $feedObject = self::updateCache($role, $feedObject, $cachedFeed);
                }
            }
            $cachedFeed = $feedObject;
        }
        return $cachedFeed;
    }

    protected static function getCachedFeed($role)
    {
        $result = new stdClass();
        $lang = (Factory::getLanguage()->getTag() == 'de-DE') ? 'de-DE' : 'en-GB';
        $path = JPATH_ROOT . '/cache/com_diler/newsfeed-' . $role . '-' . $lang . '.php';
        $contents = @file_get_contents($path);
        if ($contents)
        {
            $contents = str_ireplace("<?php die('Forbidden.'); ?>", '', $contents);
            $result = json_decode($contents);
        }
        return $result;
    }

    protected static function updateCache($role, $feedObject, $cachedFeed)
    {
        $path = JPATH_ROOT . '/cache/com_diler/';
        if (!Folder::exists($path))
        {
            if (!Folder::create($path))
                throw new RuntimeException(DText::_('NOTIFICATION_FOLDER_ERROR'), 999);
        }
        $dilerVersionInfo = MVCHelper::factory()->createModel('Dilers', 'Administrator')->getPackageVersionInfo();
        $contents = "<?php die('Forbidden.'); ?>";
        $lang = (Factory::getLanguage()->getTag() == 'de-DE') ? 'de-DE' : 'en-GB';
        $fullPath = $path . 'newsfeed-' . $role . '-' . $lang . '.php';
        if (isset($feedObject->dilerVersion) && $feedObject->dilerVersion !== $dilerVersionInfo->diler_version)
        {
            // Diler versions do not match. Use the cached feed instead of the RSS feed.
            // Check for empty cache
            $cacheArray = (array) $cachedFeed;
            if (!isset($cachedFeed->dilerVersion))
                $cachedFeed->dilerVersion = '0.0.0';
            // Check also for cache version if is higher than diler installed version.
            if (! count($cacheArray) || version_compare($cachedFeed->dilerVersion, $dilerVersionInfo->diler_version) == 1)
            {
                $feedObject = (object) [
                    'title' => DText::sprintf('FEED_ERROR', DText::_(strtoupper($role))),
                    'description' => '',
                    'updateDate' => '0000-00-00 00:00:00',
                    'entries' => [],
                ];
            }
            else
                $feedObject = $cachedFeed;
        }
        $feedObject->cacheDate = Factory::getDate()->toSql();
        $contents .= json_encode($feedObject);
        if ((! is_writable($path)) || (! @file_put_contents($fullPath, $contents)))
            throw new RuntimeException(DText::_('NOTIFICATION_FOLDER_ERROR'), 999);

        return $feedObject;
    }
}
