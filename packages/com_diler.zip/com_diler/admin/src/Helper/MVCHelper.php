<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;

defined('_JEXEC') or die('Restricted access');

class MVCHelper
{
	/**
	 * @deprecated 8.0 this is just a temp solution to replace ::getInstances
	 */
	public static function factory() : MVCFactoryInterface
	{
		return Factory::getApplication()->bootComponent('com_diler')->getMVCFactory();
	}
}