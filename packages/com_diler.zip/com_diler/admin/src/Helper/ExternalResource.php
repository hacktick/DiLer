<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\DConst;
use DOMDocument;
use Joomla\CMS\Form\Rule\UrlRule;
use SimpleXMLElement;

defined('_JEXEC') or die('Restricted access');

class ExternalResource
{
    public static function isValidTaskEmbedCode($htmlText)
    {
        $dom = new DOMDocument;
        @$dom->loadHTML($htmlText);

        $finalDom = new DOMDocument;
        //For some reason if you pass empty string to LoadHTML as source you get error with PHP 8
        //so we pass one empty space as a trick
        @$finalDom->loadHTML(" ", LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

        $tagsName = array('iframe','script');

        foreach ($tagsName as $tagName) {
            $elements = $dom->getElementsByTagName($tagName);
            // There should be 1 element
            if ($elements->length != 1)
                continue;

            $element = $elements[0];
            $elementAttributes = $element->attributes;
            $newElement = $finalDom->createElement($tagName);
            foreach ($elementAttributes as $attr) {
                $value = $attr->name == 'src' ? self::isValidUrl($element->getAttribute('src'), true) : $attr->value;
                $newElement->setAttribute($attr->name, $value);
            }
            $newElement->textContent = $element->nodeValue;
            $finalDom->appendChild($newElement);
        }

        return $finalDom->saveHTML();
    }

    public static function isValidEzAppEmbedCode($htmlContent)
    {
        $dom = new DOMDocument;
        $finalDom = new DOMDocument;

        @$dom->loadHTML($htmlContent, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        @$finalDom->loadHTML("", LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

        /**
         * @var DOMNodeList $iFrameContaners
         * @var DOMNodeList $iFrameScripts
         */
        $iFrameContaners = $dom->getElementsByTagName('div');
        $iFrameScripts = $dom->getElementsByTagName('script');

        /*** @var DOMElement $container */
        foreach ($iFrameContaners as $container)
        {
            if (($class = $container->getAttribute('class')) !== 'dilerEzEngine_app_iframe_container')
                return false;

            if (($uriBase = $container->getAttribute('data-uribase')) !== DConst::EZAPP_URI_BASE)
                return false;

            if (!$version = $container->getAttribute('data-version'))
                return false;

            if (!$config = $container->getAttribute('data-config'))
                return false;

            // Check is valid JSON passed
            json_decode($config);
            if (json_last_error() !== JSON_ERROR_NONE)
                return false;

            $div = $finalDom->createElement('div');
            $div->setAttribute('class', $class);
            $div->setAttribute('data-uribase', $uriBase);
            $div->setAttribute('data-version', $version);
            $div->setAttribute('data-config', $config);
            $finalDom->appendChild($div);
        }

        $embedJsUrl = DConst::EZAPP_URI_BASE . 'media/com_dilerezengine/js/' . $version . '/embed.min.js';

        if (!$iFrameScripts)
            return false;

        /*** @var DOMElement $script */
        foreach ($iFrameScripts as $script)
            if ($script->getAttribute('src') !== $embedJsUrl)
                return false;

        $script = $finalDom->createElement('script');
        $script->setAttribute('src', $embedJsUrl);
        $script->setAttribute('type', 'text/javascript');

        $finalDom->appendChild($script);
        return $finalDom->saveHTML();
    }

    public static function isValidUrl($url, $forceHttps = false)
    {
        $element = new SimpleXMLElement('<field/>');
        $protocol = $forceHttps ? 'https:' : 'http:';
        $url = $forceHttps ? str_ireplace('http:', 'https:', $url) : $url;
        $rule = new UrlRule();
        $result = $rule->test($element, $url);
        // Check for missing http://
        if ($result == false && stripos($url, $protocol) === false)
        {
            // Test for leading //
            if (stripos($url, '//') !== false)
                // Try adding http:
                $url = $protocol . $url;

            else
                // Try it with http:// added
                $url = $protocol . '//' . $url;

            $result = $rule->test($element, $url);
        }
        return $result ? $url : false;
    }
}