<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use Joomla\CMS\Component\ComponentHelper;

\defined('_JEXEC') or die;

class FileRootFolder
{
	protected static $rootFileFolder;

	public static function isWritable() : bool
	{
		$rootFileFolder = self::getPath();
		return $rootFileFolder && is_writable($rootFileFolder);
	}

	public static function getPath() : string
	{
		if (! isset(self::$rootFileFolder))
		{
			$result = ComponentHelper::getParams('com_diler')->get('file_root_folder') . '/';
			self::$rootFileFolder =  str_replace(array('\\','//'), '/', $result);
		}
		return self::$rootFileFolder;
	}
}
