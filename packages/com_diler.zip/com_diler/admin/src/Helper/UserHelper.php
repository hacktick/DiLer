<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class UserHelper
{
    public static function loggedIn()
    {
        return !Factory::getUser()->guest;
    }

    public static function getBackground()
    {
        $result = 'media/com_diler/images/logos/diler_sky_1280.png';
        $user = Factory::getUser();
        $dilerParams = ComponentHelper::getParams('com_diler');
        $rootPath = $dilerParams->get('file_root_folder');
        $userBackgroundPath = '';
        $userParams = DilerParams::getUser();
        $role = DilerRole::getRole($user->id);
        $allowBackground = ($role == 'student') ? $userParams->get('allow_user_background', 0) : 1;
        $userBackgroundId = $allowBackground ? $userParams->get('userBackgroundImage', 0) : 0;
        if ($userBackgroundId)
        {
	        $table = MVCHelper::factory()->createTable('Cloud');
            $table->load($userBackgroundId);
            $userBackgroundPath = $table->path;
        }
        $fullUserPath = $rootPath . '/' . $userBackgroundPath;

	    $schoolBackground = $dilerParams->get('schoolBackgroundImage','');
	    $cleanPathToSchoolBackground = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($schoolBackground);
	    $fullSchoolPath = JPATH_ROOT . '/' . $cleanPathToSchoolBackground;

        if ($userBackgroundId && is_file($fullUserPath) && file_exists($fullUserPath))
        {
            $pathParts = pathinfo($fullUserPath);
            copy($fullUserPath, JPATH_ROOT . '/tmp/user-background-image-' . $user->id . '.' . $pathParts['extension']);
            $result = 'tmp/user-background-image-' . $user->id . '.' . $pathParts['extension'];
        }
        elseif ($schoolBackground && file_exists($fullSchoolPath))
            $result = $schoolBackground;

        return $result;
    }

    public static function isBlocked($userID): bool
    {
        $user = Factory::getUser($userID);
        return (!$user || $user->block);
    }

    public static function getStateIso() : string
    {
        $userId = Factory::getUser()->id;
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('state_iso')
            ->from('#__dilerreg_users')
            ->where('user_id = ' . $userId);

        return $db->setQuery($query)->loadResult();
    }
}