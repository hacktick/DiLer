<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DiLer\Lang\DText;
use JLoader;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use LoginGuardHelperTfa;

defined('_JEXEC') or die('Restricted access');

class AuthenticationHelper
{
    public static function getTwofaMethod()
    {
        DText::sprintf('2FA_METHOD', Text::_('JNONE'));
        $user = Factory::getUser();
	    $userModel = Factory::getApplication()->bootComponent('com_users')->getMVCFactory()->createModel('User', 'Administrator');
        $joomlaTwofactorCfg = $userModel->getOtpConfig($user->id);
        $userModel->getTwofactorform($user->id);
        $loginGuardRecords = [];
        $loginGuardMethods = [];
        if (file_exists(JPATH_ROOT . '/components/com_loginguard/helpers/tfa.php'))
        {
            $loginGuardRecords = LoginGuardHelperTfa::getUserTfaRecords($user->id);
            $loginGuardMethods = LoginGuardHelperTfa::getTfaMethods();
        }
        $result = array();
        if (count($loginGuardRecords) >= 2 && isset($loginGuardRecords[1]->method))
            $result[] = DText::sprintf('2FA_METHOD', $loginGuardMethods[$loginGuardRecords[1]->method]['display']);

        elseif ($joomlaTwofactorCfg->method == 'totp')
            $result[] = DText::sprintf('2FA_METHOD', Text::_('PLG_TWOFACTORAUTH_TOTP_METHOD_TITLE'));

        elseif ($joomlaTwofactorCfg->method == 'yubikey')
            $result[] = DText::sprintf('2FA_METHOD', Text::_('PLG_TWOFACTORAUTH_YUBIKEY_METHOD_TITLE'));

        return $result;
    }
}