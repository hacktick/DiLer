<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

defined('_JEXEC') or die('Restricted access');

class PdfAssets
{
    public static function getCanvasPageScript($startPageCount, $footer, $footerStartPage, $footerPositionH, $footerPositionV, $header, $headerStartPage, $headerPositionH, $headerPositionV)
    {
        return '
				$pageNum = $PAGE_NUM +1 - ' . $startPageCount . ';
				$pageCount = $PAGE_COUNT;
				$footer = "' . $footer . '";
				$search = array("{PAGE_NUM}", "{PAGE_COUNT}");
				$replace = array($pageNum, $pageCount);
				$newFooter = str_replace($search, $replace, $footer);
				$font = $fontMetrics->getFont("Arimo", "normal");
				if ($PAGE_NUM >= ' . $footerStartPage . ')
				{
					$pdf->text("' . $footerPositionH. '", "' . $footerPositionV. '", $newFooter , $font, 7, array(0, 0, 0));
				}

				$header = "' . $header . '";
				if ($header > " " && $PAGE_NUM >= ' . $headerStartPage . ')
				{
					$newHeader = str_replace($search, $replace, $header);
					$pdf->text("' . $headerPositionH. '", "' . $headerPositionV. '", $newHeader , $font, 7, array(0, 0, 0));
				}
			';
    }

    public static function getContractCssContent(string $contractLayoutFile) : string
    {
        $layoutCssSrc = '/templates/diler3/html/com_diler/contract_layouts/' . $contractLayoutFile . '.css';
        return self::getCssContent($layoutCssSrc);
    }

    public static function getReportCssContent(string $reportLayoutName = 'reports') : string
    {
        $templateName = Factory::getApplication()->getTemplate();
        $layoutCssSrc = '/templates/' . $templateName . '/html/com_diler/report_layouts/' . $reportLayoutName . '.css';

        return self::getCssContent($layoutCssSrc);
    }

    public static function getReportCustomCss()
    {
        return self::getCssContent('/templates/diler3/html/com_diler/report_layouts/custom.css');
    }

    public static function getDilerPdfCssContent()
    {
        return self::getCssContent('/media/com_diler/css/diler-pdf.css');
    }

    private static function getCssContent(string $url, string $defaultUrl = '') : string
    {
        $cssSrc = File::exists(JPATH_ROOT . $url) ? $url : $defaultUrl;
        if ($cssSrc == '')
            return '';

        $mediaVersion = Factory::getDocument()->getMediaVersion();

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_URL, Uri::base() . $cssSrc . '?v=' . $mediaVersion);

        if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] == '127.0.0.1')
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        }

        $output = curl_exec($curl);

        return self::removeCssComments($output);
    }

    public static function getLayoutInputs($content)
    {
        $result = new Registry();
        $regex = '#<input.*id="(.*?)".*value="(.*?)"#';
        preg_match_all($regex, $content, $matches);
        if (is_array($matches) && count($matches) === 3 && count($matches[1]))
        {
            for ($i=0; $i<count($matches[1]); $i++)
                $result->set($matches[1][$i], $matches[2][$i]);
        }
        return $result;
    }

    public static function getStandardPdfCssContent(string $layout)
    {
        $layoutCssSrc = '/media/com_diler/css/' . $layout . '.css';
        return self::getCssContent($layoutCssSrc);
    }

    private static function removeCssComments($fileContent)
    {
        $regex = array(
            "`^([\t\s]+)`ism"                             => '',
            "`^\/\*(.+?)\*\/`ism"                         => "",
            "`(\A|[\n;]+)/\*[^*]*\*+(?:[^/*][^*]*\*+)*/`" => "$1",
            "`(\A|[;\s]+)//.+\R`"                         => "$1\n",
            "`(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+`ism"       => "\n"
        );

        return preg_replace(array_keys($regex),$regex,$fileContent);
    }
}