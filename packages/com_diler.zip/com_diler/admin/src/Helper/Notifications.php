<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use DateInterval;
use DiLer\DConst;
use DiLer\Lang\DText;
use DilerHelperUser;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Layout\FileLayout;
use Joomla\Utilities\ArrayHelper;

defined('_JEXEC') or die('Restricted access');

class Notifications
{
    public static function lastTimeChecked($notificationType = 'studentRecordReadDate')
    {
        $interval = new DateInterval('P1D');
        $yesterday = Factory::getDate()->sub($interval)->toSql();
        $userParams = DilerParams::getUser();
        $notificationReadDate = $userParams->get($notificationType, $yesterday);
        return $notificationReadDate;
    }

    public static function getStudentRecordNotification()
    {
        $role = DilerRole::getRole();
        $srObject = self::getLastStudentRecordForRole($role);
        $shownNotificationListCount = count($srObject->rows);
        $displayData['modalLink'] = 'studentRecordAlertModal';
        $displayData['iconCount'] = DilerHelperUser::getLastStudentRecordNotificationForRoleForCount($role);
        $displayData['studentRecordBadgeClass'] = ($displayData['iconCount']) ? 'newNotification badge badge-warning' : 'newNotification badge';
        $displayData['studentRecords'] = $srObject->rows;
        $displayData['count'] = $srObject->count;
        $displayData['rows'] = $shownNotificationListCount;
        if ($displayData['count'] > DConst::NOTIFICATION_PAGINATE_COUNT)
            $srTitle = htmlspecialchars(DText::sprintf('NOTIFICATION_ALERT_STUDENT_RECORD_PARTIAL', $shownNotificationListCount, $displayData['count']));

        else
            $srTitle = htmlspecialchars(DText::_('NOTIFICATION_ALERT_STUDENT_RECORD_0'));

        $displayData['title'] = $srTitle;
        $layout = new FileLayout('student_records', JPATH_ROOT . '/components/com_diler/layouts/notifications');
        $modalHtml = $layout->render($displayData);
        $alertLayout = new FileLayout('student_records_alert', JPATH_ROOT . '/components/com_diler/layouts/notifications');
        $alertHtml = $alertLayout->render($displayData);
        $notification = (object) [
            'modalHtml' => $modalHtml,
            'alertHtml' => $alertHtml,
            'count' => $srObject->count,
            'shown' => $shownNotificationListCount,
        ];
        return $notification;
    }

    public static function getLastStudentRecordForRole($role)
    {
        $studentRecordAllNotificationsReadDate = self::lastTimeChecked('studentRecordAllNotificationsReadDate');
        $viewUrl = '';
        $user = Factory::getUser();
        $userId = $user->id;
        $futureView = $user->authorise('studentrecord.future.view', 'com_diler');
        $db = Factory::getdbo();
        $query = $db->getQuery(true)
            ->select('sr.*')
            ->from('#__diler_studentrecord as sr')
            ->where('sr.created > "'. $studentRecordAllNotificationsReadDate. '"')
            ->where('sr.created_by != ' . $userId)
            ->order('sr.id desc');
        if (!$futureView)
            $query->where('Date(sr.effective_date) <= Date(now())');

        $studentRecordModel = MVCHelper::factory()->createModel('Studentrecord', 'Site');
        $query = $studentRecordModel->getStudentRecordTagsRawQuery($query);
        $query->group('sr.id');

        if ($role == 'student')
        {
            $query->where('(diler_access LIKE "%3%" OR diler_access LIKE "%2%")');
            $viewUrl = 'student_desk';
            $query->where('sr.student_id = '. $userId);
        }
        elseif ($role == 'parent')
        {
            $viewUrl = 'parent_student';
            $parentStudents = MVCHelper::factory()->createModel('Student', 'Site')->getStudentsForParent($userId);
            if (!$parentStudents)
                $parentStudentIds = [0];
            foreach($parentStudents AS $parentStudent){
                $parentStudentIds[] = $parentStudent->user_id;
            }
            $query->where('sr.student_id IN ('. implode(",", $parentStudentIds). ')' );
            $query->where('(diler_access LIKE "%3%" OR diler_access LIKE "%4%")');
        }
        elseif ($role == 'teacher')
        {
            $viewUrl = 'teacher_student';
            $teacherModel = MVCHelper::factory()->createModel('Teacher', 'Site',  ['ignore_request' => true]);
            $teacherStudents = $teacherModel->getMyStudents($userId);
            $teacherStudentIds = [0];
            foreach($teacherStudents AS $teacherStudent)
                $teacherStudentIds[] = $teacherStudent->user_id;

            $query->where('sr.student_id IN ('. implode(",", $teacherStudentIds). ')' );
        }
        $studentRecordsSeenArray = StudentRecord::seenArray();
        if( count($studentRecordsSeenArray) > 0 )
            $query->where('sr.id NOT IN ('. implode(",", $studentRecordsSeenArray). ')' );

        // dont show absence type student records
        $params = ComponentHelper::getParams('com_diler');
        $absenceCategories = array(
            'excused' => $params->get('studentRecordExcusedAbsence', 0),
            'unexcused' => $params->get('studentRecordUnexcusedAbsence', 0),
            'homeSchooling' => $params->get('studentRecordHomeSchooling', 0),
        );
        // Exclude absence SR entries
        $subQuery = $db->getQuery(true)->select('studentrecord_id')
            ->from('#__diler_studentrecord_tag_map')
            ->where('tag_id NOT IN(' . implode(', ', $absenceCategories) . ')')
            ->group('studentrecord_id');
        $query->innerJoin('(' . (string) $subQuery . ') AS tagmap ON tagmap.studentrecord_id = sr.id');

        $joinDilerRegUsersBy = "student_id";
        if ($role === 'student')
            $joinDilerRegUsersBy = "created_by";

        // select user first name and last name
        $query->leftJoin("#__dilerreg_users AS users ON sr.$joinDilerRegUsersBy = users.user_id");
        $query->select('users.surname, users.forename, users.nickname');
        $db->setQuery($query)->execute();
        $count = $db->getNumRows();
        $rows = $db->setQuery($query, 0, DConst::NOTIFICATION_PAGINATE_COUNT)->loadObjectList();

        if(! $count)
            self::updateAllStudentRecordReadDate();

        $studentRecordsNotification = self::attachRecordUrl($rows, $viewUrl);

        return (object) ['rows' => $studentRecordsNotification, 'count' => $count];
    }

    public static function updateAllStudentRecordReadDate()
    {
        $readType = 'notificationStudentRecordAllBadge';
        $studentRecordIdsType = 'studentRecordIdsBadge';
        $role = DilerHelperUser::getDilerRole();
        $result = false;
        $readTypeArray = [
            'notificationAlertNewsBadge' => 'newsReadDate',
            'notificationAlertFeedBadge' => 'feedReadDate',
            'notificationStudentRecordBadge' => 'studentRecordReadDate',
            'notificationStudentRecordAllBadge' => 'studentRecordAllNotificationsReadDate',
            'studentRecordIdsBadge' => 'studentRecordSeenIds',
            'notificationAbsenceStatsBadge' => 'absenceStatsReadDate',
        ];
        if (in_array($role, ['teacher', 'student', 'parent']) && in_array($readType, array_keys($readTypeArray)))
        {
            $date = Factory::getDate()->toSql();
            $db = Factory::getdbo();
            $params = DilerParams::getUser();
            $params->set($readTypeArray[$readType], $date);
            $params->set($readTypeArray[$studentRecordIdsType], json_encode([]));
            DilerParams::updateUser($params);
        }
        return $result;
    }

    public static function attachRecordUrl($notifications, $viewUrl = 'teacher_student')
    {
        $document = Factory::getDocument();
        $language = $document->language;
        $urlLang = substr($language, 0, 2);
        $dilerItemId = DilerHelperUser::getDeskItemId($language);

        $notificationsWithUrl = [];
        foreach ($notifications as $notification) {
            $url = 'index.php?option=com_diler'
                . '&view='
                . $viewUrl
                . '&user_id='
                . $notification->student_id
                . '&lang='
                . $urlLang
                . '&Itemid='
                . $dilerItemId
                . '&tab_id='
                . 'studentrecord';
            $notification->url = $url;
            $notificationsWithUrl[] = $notification;
        }

        return $notificationsWithUrl;
    }

    public static function getLastStudentRecordNotificationForRoleForCount($role)
    {
        $studentRecordReadDate = self::lastTimeChecked('studentRecordReadDate');
        $userId = Factory::getUser()->id;
        $db = Factory::getdbo();
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from('#__diler_studentrecord as sr')
            ->where('sr.created > "'. $studentRecordReadDate. '"')
            ->where('sr.created_by != ' . $userId);

        if ($role == 'student')
            $query->where('sr.student_id = '. $userId);

        elseif ($role == 'parent')
        {
            $parentStudents = MVCHelper::factory()->createModel('Student', 'Site')->getStudentsForParent($userId);
            if (!$parentStudents)
                return 0;

            $query->where('sr.student_id IN ('. implode(",", ArrayHelper::getColumn($parentStudents, 'user_id')). ')' );
        }
        elseif ($role == 'teacher')
        {
            $teacherModel = MVCHelper::factory()->createModel('Teacher', 'Site',  ['ignore_request' => true]);
            $teacherStudents = $teacherModel->getMyStudents($userId);
            if (!$teacherStudents)
                return 0;

            $query->where('sr.student_id IN ('. implode(",", ArrayHelper::getColumn($teacherStudents, 'user_id')). ')' );
        }
        // dont show absence type student records
        $params = ComponentHelper::getParams('com_diler');
        $absenceCategories = array(
            'excused' => $params->get('studentRecordExcusedAbsence', 0),
            'unexcused' => $params->get('studentRecordUnexcusedAbsence', 0),
            'homeSchooling' => $params->get('studentRecordHomeSchooling', 0),
        );
        $query->leftJoin('#__diler_studentrecord_tag_map AS tagmap ON tagmap.studentrecord_id = sr.id');
        $query->where('tagmap.tag_id NOT IN(' . implode(', ', $absenceCategories) . ')');

        return $db->setQuery($query)->loadResult();
    }
}