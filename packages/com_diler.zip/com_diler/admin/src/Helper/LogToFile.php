<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;
// No direct access to this file

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Log\Log;

defined('_JEXEC') or die('Restricted access');

class LogToFile
{
	public static function deleteLogFile($logFile)
	{
		$logPath = Factory::getApplication()->getConfig()->get('log_path');
		$fullPath = $logPath . '/' . $logFile;
		return File::delete($fullPath);
	}

	public static function addLog($logOptions)
	{
		$options ['format'] = '{DATE}\t{TIME}\t{LEVEL}\t{CODE}\t{MESSAGE}';
		$options ['text_file'] = $logOptions['logFile'];
		$categories = isset($logOptions['categories']) ? $logOptions['categories'] :  ['diler','error','warning'];
		Log::addLogger($options, Log::ALL, $categories);
		Log::add($logOptions['message'], $logOptions['status'], $logOptions['type']);
	}
}