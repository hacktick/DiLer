<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use Joomla\CMS\Access\Rules;
use Joomla\CMS\Factory;

\defined('_JEXEC') or die;

class CloudHelper
{
    protected static $cloudCategories;

    public static function getCategories()
    {
        $user = Factory::getUser();
        if (is_array(self::$cloudCategories) && isset(self::$cloudCategories[$user->id])) return self::$cloudCategories[$user->id];
        $isSuperAdmin = $user->authorise('core.admin');
        $userGroups = $user->getAuthorisedGroups();
        // Get assets for cloud categories
        $db = Factory::getDbo();
        $query = $db->getQuery(true)->select('c.*, a.id AS assetId, a.rules AS rules_string')
            ->from('#__categories AS c')
            ->innerJoin('#__assets AS a ON c.asset_id = a.id')
            ->where('extension="com_diler.cloud"')
            ->order('c.lft');
        $assetRows = $db->setQuery($query)->loadObjectList();
        $categories = [];
        foreach ($assetRows as $assetRow)
        {
            $rules = new Rules($assetRow->rules_string);
            $view = $rules->allow('cloud.view', $userGroups);
            $manage = $rules->allow('cloud.manage', $userGroups);
            $manageOwn = $rules->allow('cloud.manage.own', $userGroups);
            if ($isSuperAdmin || $view || $manage || $manageOwn)
            {
                $assetRow->viewAllowed = $view;
                $assetRow->manageAllowed = $manage;
                $assetRow->manageOwnAllowed = $manageOwn;
                $assetRow->rules = $rules;
                $categories[] = $assetRow;
            }
        }
        self::$cloudCategories[$user->id] = $categories;
        return $categories;
    }

}
