<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

class DDateTimeHelper
{
    public static function isValidTimestamp($timestamp)
    {
        $result = false;
        $nullDate = Factory::getDbo()->getNullDate();
        if ($timestamp != $nullDate && strlen($timestamp) >= 18)
        {
            $interval = min(array(10, Factory::getConfig()->get('lifetime', 10)));
            $currentTime = strtotime((string) Factory::getDate());
            $expireTime = strtotime($timestamp . ' + ' . $interval . ' minutes');
            $result = ($currentTime < $expireTime);
        }
        return $result;
    }

    public static function convertPhpToJs($phpFormat)
    {
        $phpCodes = array('Y',   'y', 'M',  'm', 'n','F',   'd', 'j','l',   'H', 'g','h', 'i');
        $jsCodes =  array('YYYY','YY','MMM','MM','M','MMMM','DD','D','dddd','HH','h','hh','mm');
        return str_replace($phpCodes, $jsCodes, $phpFormat);
    }

    public static function dateFromString($dateString, $formatString = 'DATE_FORMAT_CALENDAR_DATE')
    {
        $result = false;
        $format = str_replace('%', '', Text::_($formatString));
        $array = date_parse_from_format($format, $dateString);
        if ($array['year'] && $array['month'] && $array['day'])
            $result = $array['year'] . '-' . sprintf("%02d", $array['month']) . '-' . sprintf("%02d", $array['day']);

        return $result;
    }

    public static function formatDateFromString($date, $formatString = 'DATE_FORMAT_CALENDAR_DATE')
    {
        // Remove , and . and truncate any time values
        $date = self::dateFromString($date, $formatString);

        // See if $date can be converted into valid date.
        $validDate = strtotime($date);
        return $validDate ? date("Y-m-d", $validDate) : '';
    }
}
