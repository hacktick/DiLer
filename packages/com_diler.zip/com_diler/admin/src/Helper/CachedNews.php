<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Helper;

\defined('_JEXEC') or die;

class CachedNews
{
	public static function isWritable() : bool
	{
		$path = JPATH_ROOT . '/cache/com_diler/';
		$result = true;
		if (!file_exists($path))
			$result = mkdir($path);

		return $result && is_writable($path);
	}
}
