<?php
/**
 * @copyright      Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\MVC\Model\ListModelInterface;

defined('_JEXEC') or die('Restricted access');

class ClassschedulesModel extends ListModel implements ListModelInterface
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'name',
				'a.name',
				'ordering',
				'a.ordering',
				'published',
				'a.published'
			);
		}

		parent::__construct($config);
	}

	protected function getListQuery()
	{
		$db    = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from($db->quoteName('#__diler_class_schedule') . ' AS a');

		$search = $this->state->get('filter.search');
		if (!empty($search))
		{
			$search = $db->Quote('%' . $db->escape($search, true) . '%');
			$query->where('a.name LIKE ' . $search);
		}

		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		$orderCol  = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		return $query;
	}

	public function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.id', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');

		return parent::getStoreId($id);
	}

	public function setDefaultSchedule($classScheduleId)
	{
		$this->assignClassScheduleToAllStudents($classScheduleId);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_class_schedule');
		$query->set('standard_class_schedule = CASE WHEN id = ' . $classScheduleId . ' THEN 1 ELSE 0 END');
		return $db->setQuery($query)->execute();
	}

	public function assignClassScheduleToAllStudents($classScheduleId): void
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__dilerreg_users');
		$query->where('role = "student"');
		$query->set('standard_class_schedule = ' . $db->quote($classScheduleId));

		$db->setQuery($query)->execute();

	}
}
