<?php
/**
 * @copyright      Copyright (C) 2013-2025 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Site\Helper\DigluUsers;
use Joomla\CMS\MVC\Model\ListModel;

class DigluInvalidUsersModel extends ListModel
{
    protected function getListQuery()
    {
        $db = $this->getDatabase();

        $query = $db->getQuery(true);
        $query->select('du.*, ju.username');
        $query->from($db->quoteName('#__dilerreg_users') . 'AS du');
        $query->join('LEFT', $db->quoteName('#__users') . 'AS ju ON ju.id = du.user_id');

        return $query;
    }

    public function getItems()
    {
        $allUsers = parent::getItems();
        if(!$allUsers)
            return array();
        $digluUsers = new DigluUsers($this->getDatabase());
        $digluValidUsers = $digluUsers->getIdsOfAllDigLuUsers();
        $invalidUsers = array_filter($allUsers, function ($user) use ($digluValidUsers) {
            return !in_array($user->user_id, $digluValidUsers);
        });
        return $invalidUsers;
    }
}


