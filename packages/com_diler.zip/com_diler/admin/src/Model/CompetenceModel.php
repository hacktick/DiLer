<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;

class CompetenceModel extends AdminModel
{

	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.competence', 'competence', array(
			'control'   => 'jform',
			'load_data' => $loadData
		));
		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	public function save($data)
	{
		$result = parent::save($data);
		if ($result)
		{
			$state      = $this->getState();
			$data['id'] = ($data['id']) ?: $this->getState()->get('competence.id');
			$result     = $this->saveSubjects($data);
		}

		return $result;
	}

	protected function saveSubjects($data)
	{
		// Delete all old rows in mapping table
		$db     = Factory::getDbo();
		$query  = $db->getQuery(true)
			->delete('#__diler_subject_competence_map')
			->where('competence_id = ' . (int) $data['id']);
		$result = $db->setQuery($query)->execute();

		// Add new rows if applicable
		if ($result && is_array($data['subject_list']) && count($data['subject_list']))
		{
			$query = $db->getQuery(true)
				->insert('#__diler_subject_competence_map')
				->columns(array(
					$db->quoteName('subject_id'),
					$db->quoteName('competence_id'),
					$db->quoteName('phase_id')
				));

			foreach ($data['subject_list'] as $subject)
			{
				$query->values((int) $subject . ',' . (int) $data['id'] . ',' . (int) $data['phase_id']);
			}
			$result = $db->setQuery($query)->execute();
		}

		return $result;
	}

	public function delete(&$pks)
	{
		$pks = $this->checkChangeStatus($pks);
		// Delete the mapped subjects from map table
		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->delete('#__diler_subject_competence_map')
			->where('competence_id IN (' . implode(',', $pks) . ')');

		$result = $db->setQuery($query)->execute();

		if ($result)
		{
			$result = parent::delete($pks);
		}

		return $result;
	}

	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no compchar rows for these competences
		$db     = Factory::getDbo();
		$query  = $db->getQuery(true)
			->select('competence_id')
			->from('#__diler_competence_compchar_map')
			->where('competence_id IN(' . implode(',', $pks) . ')')
			->group('competence_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && count($badPks))
		{
			// We need to give a message and also remove these from the $pks array
			Factory::getApplication()->enqueueMessage(DText::plural('N_COMPETENCES_CANNOT_CHANGE_STATUS', count($badPks)), 'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new \Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}

		return $pks;
	}

	public function publish(&$pks, $value = 1)
	{
		if ($value == -2)
		{
			$pks = $this->checkChangeStatus($pks);
		}

		return parent::publish($pks, $value);
	}

	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.competence.data', array());
		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		$data = parent::getItem($pk);
		if ($data->id)
		{
			$db    = Factory::getDbo();
			$query = $db->getQuery(true)
				->select('GROUP_CONCAT(subject_id) AS subject_list, phase_id')
				->from('#__diler_subject_competence_map')
				->where('competence_id = ' . (int) $data->id)
				->group('competence_id');
			$row   = $db->setQuery($query)->loadObject();
			if ($subjectList = $row->subject_list)
			{
				$data->subject_list = explode(',', $subjectList);
				$data->phase_id     = $row->phase_id;
			}
			else
			{
				$data->subject_list = '';
				$data->phase_id     = '';
			}

		}

		return $data;
	}
}