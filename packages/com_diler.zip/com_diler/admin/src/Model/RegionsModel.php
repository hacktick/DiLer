<?php
/**
 * @copyright      Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\MVC\Model\ListModelInterface;

defined('_JEXEC') or die('Restricted access');

class RegionsModel extends ListModel implements ListModelInterface
{
	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'a.country_iso2',
				'country_iso2',
				'postal_code',
				'a.postal_code',
				'a.city', 'city', 'a.community', 'community','a.state_iso','state_iso',
				'ordering',
				'a.ordering',
				'published',
				'a.published',
				'sch.school_count',
				'region_teacher'
			);
		}

		parent::__construct($config, $factory);
	}

	protected function getListQuery()
	{
		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('a.*');
		$query->from($db->quoteName('#__diler_region') . ' AS a');
		$subquery = $db->getQuery(true)->select('country_iso2, postal_code, COUNT(*) AS school_count')
				->from('#__diler_school')
				->group('country_iso2, postal_code');
		$query->leftJoin('(' . (string) $subquery . ') AS sch ON a.country_iso2 = sch.country_iso2 AND a.postal_code = sch.postal_code');
		$query->select('sch.school_count');
		$query->group('a.id');
		$query = $this->getRegionTeachersQuery($query);

		$search = $this->state->get('filter.search');
		if (!empty($search))
		{
			$search = $db->Quote('%' . $db->escape($search, true) . '%');
			$query->where('(a.postal_code LIKE ' . $search . ' OR a.city LIKE ' . $search . ' OR a.community LIKE ' . $search . ')');
		}

		$published = $this->getState('filter.published');
		if (is_numeric($published))
			$query->where('a.published = ' . (int) $published);

		elseif ($published === '')
			$query->where('(a.published = 0 OR a.published = 1)');


		$regionTeacher = $this->getState('filter.region_teacher');
		if (!empty($regionTeacher)) {
			$regionTeacher = (array) $regionTeacher;

			$subQuery = $db->getQuery(true)
				->select('rum.user_id, GROUP_CONCAT(du.forename) AS forename, GROUP_CONCAT(du.surname) AS surname')
				->select('GROUP_CONCAT(du.user_id) AS region_teacher_id')
				->from('#__diler_region_user_map AS rum')
				->innerJoin('#__dilerreg_users AS du ON rum.user_id = du.user_id')
				->where('rum.region_id = a.id')
				->where('rum.user_id IN (' . implode(',', array_map([$db, 'quote'], $regionTeacher)) . ')')
				->group('rum.user_id');

			$query->where('EXISTS (' . $subQuery . ')');
		}

		$orderCol  = $this->state->get('list.ordering', 'a.country_iso2,a.state_iso,a.postal_code');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		return $query;
	}

	private function getRegionTeachersQuery($query)
	{
		$db = $this->getDbo();
		$subQuery = $db->getQuery(true);
		$subQuery->select('GROUP_CONCAT(CONCAT(du.forename, " ", du.surname) SEPARATOR ", ")');
		$subQuery->from('#__diler_region_user_map AS rum');
		$subQuery->where('rum.region_id = a.id');
		$subQuery->innerJoin('#__dilerreg_users as du ON du.user_id = rum.user_id');
		$subQuery->innerJoin('#__users AS u ON u.id = du.user_id');
		$subQuery->where('u.block = 0');

		$query->select('(' . $subQuery . ') AS region_teachers');
		return $query;
	}

	public function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.id', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');

		return parent::getStoreId($id);
	}

	public function getRegionForTeacher($userId)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->select('DISTINCT r.community')
				->from('#__diler_region_user_map AS rm')
				->innerJoin('#__diler_region AS r ON r.id = rm.region_id')
				->where('rm.user_id = '. (int) $userId)
				->where('r.published = 1');
		return $db->setQuery($query)->loadColumn();

	}
}
