<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Site\Model\GroupModel;
use Audivisa\Component\DiLer\Site\Model\StateModel;
use DiLerHelper;
use DilerHelperUser;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

class MinistryModel extends AdminModel
{
	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.ministry', 'ministry',
			array(
				'control'   => 'jform',
				'load_data' => $loadData
			));
		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_diler.edit.ministry.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		$item = parent::getItem($pk);
		$item->diglu_trainers = $item->id ? DiLerHelper::getDigluTrainersForMinistry($item->id) : array();

		return $item;
	}

	public function save($data)
    {
        $save = parent::save($data);
        if ($save && DilerHelperUser::isDiglu())
        {
            BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');

            $id = $this->getState($this->getName() . '.id');
            $mvcHelper = MVCHelper::factory();
            DilerHelper::saveMinistryDigluTrainerMapRows($id, $data['diglu_trainers']);
            /** @var StateModel $stateModel */
            $stateModel = $mvcHelper->createModel('State', 'Site');
            $state      = $this->getStateForMinistry($data['state_iso']);

            /** @var GroupModel $groupModel */
            $groupModel = $mvcHelper->createModel('Group', 'Site');
            $stateModel->refreshAssignedUsersToStateGroup($state, $groupModel);
        }

        return $save;
    }

    private function getStateForMinistry($ministryStateIso)
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__diler_state');
        $query->where('state_iso = ' . $db->quote($ministryStateIso));

        return $db->setQuery($query)->loadObject();

    }
}