<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use DiLer\Models\School;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SchoolModel extends AdminModel
{
	use School;

	public function batch($commands, $pks, $contexts)
	{
		if (empty($commands['region-id']) || empty($pks))
		{
			$this->setError(DText::_('SCHOOL_BATCH_REGION_EMPTY'));
			return false;
		}
		$db = $this->getDbo();
		$query = $db->getQuery(true)->update('#__diler_school')
				->set('region_id = ' . (int) $commands['region-id'])
				->where('id IN(' . implode(',', $pks) . ')');
		return $db->setQuery($query)->execute();
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.school', 'school',
		array('control' => 'jform','load_data' => $loadData));

        if (empty($form))
            return false;

		return $form;
	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_diler.edit.school.data', array());

		if (empty($data))
            $data = $this->getItem();

        return $data;
	}
    public function save($data)
    {
        if($data['principal_user_id'] == '')
            unset($data['principal_user_id']);

        if($data['contract_signed_by'] == '')
            unset($data['contract_signed_by']);

        return parent::save($data);
    }

    public function getItem($pk = null)
    {
        $item = parent::getItem($pk);

        if ($item && isset($item->id))
        {
            $db    = Factory::getDbo();
            $query = $db->getQuery(true);
            $query->select($db->quoteName('contract_file_name'));
            $query->from($db->quoteName('#__diler_diglu_school_avv_vvt_agreement'));
            $query->where($db->quoteName('base_school_id') . ' = ' . (int) $item->id);
            $contractFileName = $db->setQuery($query)->loadResult();

            $item->contract_file_name = $contractFileName ?: $item->contract_file_name;
        }

        return $item;
    }
}