<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Access\Rules;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\FormModel;
use Joomla\CMS\Table\Table;

class PermissionsModel extends FormModel
{
    public function getForm($data = array(), $loadData = false)
	{
        $form = $this->loadForm('com_diler.permissions', 'permissions',
            array(
                'control' => 'jform',
                'load_data' => $loadData
            ));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}


    public function save($data)
    {
        $dataForSave = array_filter($data['dilerrules']);
        $optionName = 'com_diler';
        // Save the rules.
        if ($dataForSave) {
            if (!$this->getCurrentUser()->authorise('core.admin', $optionName)) {
                throw new \RuntimeException(Text::_('JLIB_APPLICATION_ERROR_SAVE_NOT_PERMITTED'));
            }

            $rules = new Rules($dataForSave);
            $asset = Table::getInstance('asset');

            if (!$asset->loadByName('com_diler')) {
                $root = Table::getInstance('asset');
                $root->loadByName('root.1');
                $asset->name  = $optionName;
                $asset->title = $optionName;
                $asset->setLocation($root->id, 'last-child');
            }

            $asset->rules = (string) $rules;

            if (!$asset->check() || !$asset->store()) {
                throw new \RuntimeException($asset->getError());
            }
        }
    }
}