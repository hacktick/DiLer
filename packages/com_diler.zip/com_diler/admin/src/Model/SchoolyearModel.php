<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Language\Text;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SchoolyearModel extends AdminModel
{
	public function addMarksPeriodsToForm($form, $marksPeriods)
	{
		foreach ($marksPeriods as $periodType => $periodData)
		{
			foreach ($periodData['rows'] as $row)
			{
				$startFieldName = 'start_date_marks_period-' .  $row->period_id;
				$endFieldName = 'end_date_marks_period-' .  $row->period_id;
				$this->addFieldToForm($form, $startFieldName, $row->start_date);
				$this->addFieldToForm($form, $endFieldName, $row->end_date);
			}
		}
	}

	protected function addFieldToForm($form, $fieldName, $value)
	{
		$label = (substr($fieldName, 0, 5) === 'start') ? 'COM_DILER_PERIOD_START_DATE_LABEL' : 'COM_DILER_PERIOD_END_DATE_LABEL';
		$desc = (substr($fieldName, 0, 5) === 'start') ? 'COM_DILER_MARKS_PERIOD_START_DATE_DESC' : 'COM_DILER_MARKS_PERIOD_END_DATE_DESC';
		$xml = '<field name="' . $fieldName . '" type="calendar" required="true" label="' . $label . '"
						description="' . $desc . '" size="22" translateformat="true" filter="none" />';
		$element = new \SimpleXMLElement($xml);
		$test = $form->setField($element, null, true, 'marksPeriodsDates');
		$form->setValue($fieldName, null, $value);
	}

	public function getMarksPeriods($item)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->select('dmp.name AS period_name, dmp.id AS period_id, dmpt.name AS period_calendar, dmpt.id AS period_calendar_id')
				->from('#__diler_marks_period AS dmp')
				->innerJoin('#__diler_marks_period_calendar AS dmpt ON dmp.marks_period_calendar_id = dmpt.id')
				->where('dmpt.published = 1')
				->order('dmpt.name, dmp.ordering');
		$periodRows = $db->setQuery($query)->loadObjectList();

		$query->clear()->select('*')
				->from('#__diler_schoolyear_marks_period_map')
				->where('schoolyear_id = ' . (int) $item->id);
		$schoolyearRows = $db->setQuery($query)->loadObjectList();
		$periodIdArray = [];
		foreach ($schoolyearRows as $schoolyearRow)
		{
			$periodIdArray[$schoolyearRow->marks_period_id] = $schoolyearRow;
		}

		$periodsByType = [];
		foreach ($periodRows as $periodRow)
		{
			if (! isset($periodsByType[$periodRow->period_calendar_id]))
				$periodsByType[$periodRow->period_calendar_id] = ['period_calendar' => $periodRow->period_calendar, 'period_calendar_id' => $periodRow->period_calendar_id, 'rows' => []];

			$periodRow->start_date = $db->getNullDate();
			$periodRow->end_date = $db->getNullDate();
			if (isset($periodIdArray[$periodRow->period_id]))
			{
				$periodRow->start_date = $periodIdArray[$periodRow->period_id]->start_date;
				$periodRow->end_date = $periodIdArray[$periodRow->period_id]->end_date;
			}
			$periodsByType[$periodRow->period_calendar_id]['rows'][] = $periodRow;
		}
		return $periodsByType;
	}

	protected function insertUpdateMapTable($valueArray, $data)
	{
		$db = $this->getDbo();
		$result = true;
		$query = $db->getQuery(true)->select('CONCAT(schoolyear_id, ":", marks_period_id)')
				->from('#__diler_schoolyear_marks_period_map')
				->where('schoolyear_id = ' . (int) $data['id']);
		$existingArray = $db->setQuery($query)->loadColumn();
		foreach ($valueArray as $periodId => $dateArray)
		{
			$validStart = \DilerHelperUser::filterDate($dateArray['start_date'], "%Y-%m-%d");
			$validEnd = \DilerHelperUser::filterDate($dateArray['end_date'], "%Y-%m-%d");
			$query->clear()->set('start_date = ' . $db->quote($validStart))
						->set('end_date = ' . $db->quote($validEnd));
			if (in_array($data['id'] . ':' . $periodId, $existingArray))
			{
				$query->update('#__diler_schoolyear_marks_period_map')
						->where('schoolyear_id = ' . (int) $data['id'])
						->where('marks_period_id = ' . (int) $periodId);
			}
			else
			{
				$query->insert('#__diler_schoolyear_marks_period_map')
						->set('schoolyear_id = ' . (int) $data['id'])
						->set('marks_period_id = ' . (int) $periodId);
			}
			$result = $result && $db->setQuery($query)->execute();
		}
		return $result;
	}

	public function publish(&$pks, $value = 1)
	{
		foreach ($pks as $pk)
		{
			$table = $this->getTable();
			$table->load($pk);
			if ($table->current && $value !== 1)
			{
				Factory::getApplication()->enqueueMessage( DText::_('SCHOOLYEAR_UNPUBLISH_ERROR'), 'error');
				Factory::getApplication()->redirect('index.php?option=com_diler&view=schoolyears');
			}
		}
		return parent::publish($pks, $value);
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.schoolyear', 'schoolyear', array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
			return false;

		return $form;
	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_diler.edit.schoolyear.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

	public function save($data)
	{

		$startDate = Factory::getDate($data['start_date']);
		$endDate = Factory::getDate($data['end_date']);
        $data['start_date'] = $startDate->format("Y-m-d");
        $data['end_date'] = $endDate->format("Y-m-d");

		if ($endDate->toUnix() <= $startDate->toUnix())
		{
			$this->setError(DText::_('SCHOOLYEAR_BAD_DATE'));
			return false;
		}
		$data['publish_up'] = $this->_db->getNullDate();
		$data['publish_down'] = $this->_db->getNullDate();
		$result = parent::save($data);
		$data['id'] = $data['id'] ? $data['id'] : $this->getState($this->getName() . '.id');
		if ($result && $data['current'])
			$result = $this->setDefault([$data['id']], $data['current']);

		$formData = Factory::getApplication()->input->get('jform', [], 'array');
		$formResult = $this->saveMarksPeriodDates($formData, $data);
		if (! $formResult)
		{
			$this->setError(DText::_('SCHOOLYEAR_BAD_MARKS_PERIOD_DATE'));
			return false;
		}
		return $result;
	}

	protected function saveMarksPeriodDates($formData, $data)
	{
		$valueArray = [];
		$db = $this->getDbo();
		foreach ($formData as $field => $value)
		{
			if (strpos($field, 'marks_period') === false) continue;
			$nameArray = explode('-', $field);
			if (count($nameArray) !== 2) continue;
			if (! isset($valueArray[$nameArray[1]]))
				$valueArray[$nameArray[1]] = ['start_date' => $db->getNullDate(), 'end_date' => $db->getNullDate()];
            
            $dateValue = Factory::getDate($value);
            $value = $dateValue->format("Y-m-d");
            
			if (strpos($field, 'start') !== false)
				$valueArray[$nameArray[1]]['start_date'] = $value;

            else
				$valueArray[$nameArray[1]]['end_date'] = $value;
		}
		$result = $this->insertUpdateMapTable($valueArray, $data);
		return $result;
	}

	public function setDefault($idArray, $current)
	{
		$db = $this->getDbo();
		if (! $current) return $this->unsetDefault($idArray);

		$query = $db->getQuery(true)->update('#__diler_schoolyear');
		$query->set('current = CASE WHEN id = ' . (int) $idArray[0] . ' THEN 1 ELSE 0 END');
		return $db->setQuery($query)->execute();
	}

	public function unsetDefault($idArray)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->update('#__diler_schoolyear')->set('current = 0')->where('id IN(' . implode(',', $idArray) . ')');
		return $db->setQuery($query)->execute();
	}
}