<?php
/**
 * @copyright  Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;

use DiLer\Lang\DText;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

defined('_JEXEC') or die('Restricted access');

class TexterModel extends BaseDatabaseModel
{
	public function getTexterTypes()
	{
		return array(
			0  => DText::_('TEXTER_MANUAL_MESSAGES'),
			-2 => DText::sprintf('PURGE_TEXTER_MESSAGE_ALL_EXCEPT',
								DText::_('TEXTER_MESSAGES_DISPLAY_TYPE_ALL_SYSTEM'),
								DText::_('TEXTER_MESSAGES_DISPLAY_TYPE_CLOUD_MESSAGES')
			),
			9  => DText::_('TEXTER_MESSAGES_DISPLAY_TYPE_CLOUD_MESSAGES')
		);
	}

	public function isValidTexterTypes(int $typeId)
	{
		if (!array_key_exists($typeId, $this->getTexterTypes()))
			throw new \Exception("Invalid texter type: $typeId. Please contact DiLer support.");

		return true;
	}
}