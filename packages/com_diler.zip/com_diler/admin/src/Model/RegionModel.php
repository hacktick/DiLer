<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die('Restricted access');

class RegionModel extends AdminModel
{
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);

		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('DISTINCT sch.postal_code')
			->from('#__diler_school AS sch')
			->where('sch.postal_code IN(SELECT postal_code FROM #__diler_region WHERE id IN(' . implode(',', $pks) . '))');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && count($badPks))
		{
			if (count($badPks) == 1)
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('REGION'), DText::_('SCHOOLS'));

            else
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($badPks), DText::_('REGIONS'), DText::_('SCHOOLS'));

            Factory::getApplication()->enqueueMessage($msg,'WARNING');
			$pks = array_diff($pks, $badPks);

            if (empty($pks))
				throw new \Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
		}
		return $pks;
	}

	public function delete(&$pks)
	{
		try
		{
			$pks = $this->checkChangeStatus($pks);
		}
		catch (\Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage());
			return false;
		}

		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_region_user_map')
			->where('region_id IN (' . implode(',', $pks) . ')');
		$result = $db->setQuery($query)->execute();

		if ($result)
			$result = parent::delete($pks);

		return $result;
	}

	public function getItem($pk = null)
	{
		$data = parent::getItem($pk);
		if ($data->id)
		{
			$db = $this->getDbo();
			$query = $db->getQuery(true)
				->select('user_id AS region_teacher_list')
				->from('#__diler_region_user_map')
				->where('region_id = ' . (int) $data->id);
			$data->teacher_list = $db->setQuery($query)->loadColumn();
		}
		return $data;
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm(
			'com_diler.region',
			'region',
			array(
				'control'   => 'jform',
				'load_data' => $loadData
			)
		);

		if (empty($form))
			return false;

		return $form;
	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_diler.edit.region.data', array());

		if (empty($data))
			$data = $this->getItem();

		return $data;
	}

	protected function regionExists($data)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->select('id')
				->from('#__diler_region')
				->where('postal_code = ' . $db->quote($data['postal_code']))
				->where('country_iso2 = ' . $db->quote($data['country_iso2']))
				->where('city = ' . $db->quote($data['city']))
				->where('id != ' . $data['id']);
		return (bool) $db->setQuery($query)->loadResult();
	}

	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
			$pks = $this->checkChangeStatus($pks);

		return parent::publish($pks, $value);
	}

	public function save($data)
	{
		if ($this->regionExists($data))
		{
			$this->setError(DText::sprintf('CLASS_SCHEDULE_ALREADY_EXISTS', DText::_('REGION')));
			return false;
		}

		$result = parent::save($data);
		if ($result)
		{
			$data['id'] = ($data['id']) ? $data['id'] : $this->getState()->get('region.id');
			$result = $this->saveRegionTeachers($data);
		}
		return $result;
	}

	protected function saveRegionTeachers($data)
	{
		$db = $this->getDbo();

		$query = $db->getQuery(true)
			->delete('#__diler_region_user_map')
			->where('region_id = ' . (int) $data['id']);
		$result = $db->setQuery($query)->execute();

		if ($result && isset($data['teacher_list']) && is_array($data['teacher_list']) && $data['teacher_list'])
		{
			$query = $db->getQuery(true)
				->insert('#__diler_region_user_map')
				->columns([$db->quoteName('region_id'),$db->quoteName('user_id')]);

			foreach ($data['teacher_list'] as $userId)
			{
				$query->values((int) $data['id'] . ',' . (int) $userId);
			}
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}

}
