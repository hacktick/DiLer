<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\ListModel;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class ReportfieldsModel extends ListModel
{
	public function __construct($config = array(), MVCFactoryInterface $factory = null)
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array('a.name','name','a.published','published','a.id', 'id','a.ordering', 'ordering','a.description',
				'a.label','a.type','type','a.element_type','element_type');
		}

		parent::__construct($config, $factory);
	}

	protected function getListQuery()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('a.*');
		$query->from('#__diler_report_field_definition AS a');
		$query->leftJoin('#__diler_report_field_subject_map AS m ON m.field_id = a.id');
		$query->group('a.id');
		$query->select('COUNT(m.field_id) AS subject_map_count');
		$subquery = $db->getQuery(true)
			->from('#__diler_report_field_history')
			->select('field_id, COUNT(*) AS history_count')
			->group('field_id');
		$query->leftJoin('(' . $subquery . ') AS hist ON hist.field_id = a.id');
		$query->select('hist.history_count');

		$filter_search = $this->getState('filter.search');
		if ($filter_search)
			$query->where('a.name LIKE ' . $db->quote('%' . $filter_search . '%'));

		$published = $this->getState('filter.published');
		if (is_numeric($published))
			$query->where("a.published = " . (int) $published);

        elseif ($published === '')
			$query->where('(a.published = 0 OR a.published = 1)');

		$fieldType = $this->getState('filter.field_type');
		if (is_numeric($fieldType))
			$query->where('a.type = ' . (int) $fieldType);

		$elementType = $this->getState('filter.element_type');
		if (is_numeric($elementType))
			$query->where('a.element_type = ' . (int) $elementType);

		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		return $query;
	}

	protected function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$category = $this->getUserStateFromRequest($this->context . '.filter.category_id', 'filter_category_id', '');
		$this->setState('filter.category', $category);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);

		$fieldType = $this->getUserStateFromRequest($this->context . '.filter.field_type', 'filter_field_type', '');
		$this->setState('filter.field_type', $fieldType);

		$elementType = $this->getUserStateFromRequest($this->context . '.filter.element_type', 'filter_element_type', '');
		$this->setState('filter.element_type', $elementType);

		parent::populateState('name', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}
}