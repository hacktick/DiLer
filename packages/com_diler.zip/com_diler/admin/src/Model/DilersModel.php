<?php
/**
 * DiLer default model
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Model\BaseDatabaseModel;


class DiLersModel extends BaseDatabaseModel
{

	public function getPackageVersionInfo()
	{
		$xmlContent = file_get_contents(JPATH_ADMINISTRATOR . '/manifests/packages/pkg_diler.xml', true);
		$extension = new \SimpleXMLElement($xmlContent);
		$dilerInstalledVersion = (string) $extension->version[0];
		$dilerInstalledEdition = (string) $extension->version[0]['data-edition'];
		$joomlaVersion = (string) $extension->dependencies->dependency[0]['version'];

		return (object) array('diler_version' => $dilerInstalledVersion,
			'diler_edition' => $dilerInstalledEdition,
			'minimum_joomla_version' => $joomlaVersion
		);
	}

	public function dilerUpdateVersion()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('version')
			->from('#__updates')
			->where('element = "pkg_diler"');
		$db->setQuery($query);
		return $db->loadResult();
	}
}