<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Exception;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;

class CompcharModel extends AdminModel
{
	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.compchar', 'compchar', array(
			'control'   => 'jform',
			'load_data' => $loadData
		));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	public function publish(&$pks, $value = 1)
	{
		if ($value == -2)
		{
			$pks = $this->checkChangeStatus($pks);
		}

		return parent::publish($pks, $value);
	}

	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no answers for these tasks
		$db = $this->getDbo();

		$query = $db->getQuery(true)
			->select('m.compchar_id')
			->from('#__diler_activity_compchar_map AS m')
			->innerJoin('#__diler_activity AS a ON m.activity_id = a.id')
			->where('m.compchar_id IN(' . implode(',', $pks) . ')')
			->group('m.compchar_id');

		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && count($badPks))
		{
			// We need to give a message and also remove these from the $pks array
			Factory::getApplication()->enqueueMessage(DText::plural('N_COMPCHARS_CANNOT_CHANGE_STATUS', count($badPks)), 'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new \Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}

		return $pks;
	}

	public function save($data)
	{
		$compLevelArray        = explode('-', $data['competence_level']);
		$data['competence_id'] = $compLevelArray[0];
		$data['level_id']      = $compLevelArray[1];
		if ($data['competence_id'] && $data['level_id'])
		{
			$result = parent::save($data);
			if (!$data['id'])
			{
				$data['id'] = $this->getState($this->getName() . '.id');
			}
			// Check if already in map table
			$db    = Factory::getDbo();
			$query = $db->getQuery(true)->from('#__diler_competence_compchar_map')
				->select('COUNT(*)')
				->where('competence_id = ' . (int) $data['competence_id'])
				->where('level_id = ' . (int) $data['level_id'])
				->where('compchar_id = ' . (int) $data['id']);
			$count = $db->setQuery($query)->loadResult();
			if (!$count)
			{
				// Delete old row
				$query->clear()
					->delete('#__diler_competence_compchar_map')
					->where('compchar_id = ' . (int) $data['id']);
				$db->setQuery($query)->execute();

				// Insert new row
				$query->clear()
					->insert('#__diler_competence_compchar_map')
					->set('competence_id = ' . (int) $data['competence_id'])
					->set('level_id = ' . (int) $data['level_id'])
					->set('compchar_id = ' . (int) $data['id']);
				$db->setQuery($query)->execute();
			}
		}
		else
		{
			$this->setError(DText::_('FIELD_COMPETENCELEVEL_REQUIRED'));
			$result = false;
		}

		return $result;
	}

	public function delete(&$pks)
	{
		try
		{
			$pks = $this->checkChangeStatus($pks);
		}
		catch (Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage());

			return false;
		}

		// Delete compchar_map rows before deleting the compchar row
		if (!is_array($pks) || !count($pks))
			return true;

		$db    = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->delete()->from('#__diler_competence_compchar_map');
		$query->where('compchar_id IN(' . implode(',', $pks) . ')');

		if ($db->setQuery($query)->execute())
			return parent::delete($pks);
	}

	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.compchar.data', array());
		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		$item                   = parent::getItem($pk);
		$db                     = $this->getDbo();
		$item->competence_level = '';
		$item->level_id         = '';
		$item->competence_id    = '';
		if ($item->id)
		{
			$query = $db->getQuery(true)->select('*')
				->from('#__diler_competence_compchar_map AS ccm')
				->where('ccm.compchar_id = ' . (int) $item->id);

			$row                    = $db->setQuery($query)->loadObject();
			$item->competence_level = $row->competence_id . '-' . $row->level_id;
			$item->level_id         = $row->level_id;
			$item->competence_id    = $row->competence_id;
		}

		return $item;
	}

}