<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\Model;

use Audivisa\Component\DiLer\Administrator\Helper\FilterPhase;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\MVC\Model\ListModelInterface;

class CompcharsModel extends ListModel implements ListModelInterface
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'competence',
				'subject',
				'published',
				'ccpublished',
				'id',
				'ccid',
				'language',
				'cclanguage',
				'cname',
				'level',
				'lname',
				'level_id',
				'sname',
				'subject_id',
                'phase'
			);
		}
		parent::__construct($config);
	}

	protected function getListQuery()
	{
		$input = Factory::getApplication()->input;
		$db = Factory::getDBO();
		$query = $db->getQuery(true);

		$query->select('cc.id as ccid,'.
			'cc.name as ccname,'.
			'cc.description as ccdesc,'.
			'cc.published as ccpublished,'.
			'cc.language as cclanguage,'.
			'cc.publish_up as ccpublish_up,'.
			'cc.publish_down as ccpublish_down,'.
			'cc.checked_out as ccchecked_out,'.
			'cc.checked_out_time as ccchecked_out_time,'.
			'cc.created_by as cccreated_by'
		);

		$query->from($db->quoteName('#__diler_compchar') . ' AS cc');

		// Join over the competence
		$query->select('co.id as cid, co.name as cname, co.description as cdesc, co.icon as cico');
		$query->innerJoin('#__diler_competence_compchar_map AS ccm ON ccm.compchar_id = cc.id');
		$query->innerJoin('#__diler_competence AS co ON co.id = ccm.competence_id');

		$query->select('ph.value as phase');
		$query->leftJoin('#__diler_subject_competence_map AS scm ON ccm.competence_id = scm.competence_id');
		$query->innerJoin('#__diler_phase AS ph ON ph.id = scm.phase_id');

		// Join over the level.
		$query->select(
			'le.id as lid,' .
			'le.name as lname,' .
			'le.description as ldesc'
		);
		$query->innerJoin('#__diler_level AS le ON le.id = ccm.level_id');

		//if get filter BY Keyword Search
		// Filter by search in name,description
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('cc.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->quote('%' . $db->escape($search, true) . '%');
				//search data from competence characteristic name
				$query->where('(cc.name LIKE ' . $search . ' OR cc.description LIKE ' . $search . ')');
			}
		}

		//if get filter BY competence id
		$competence = $this->getState('filter.competence');
		if ($competence)
		{
			$query->where('ccm.competence_id = ' . (int) $competence);
		}

		$level = $this->getState('filter.level');
		if (is_numeric($level))
		{
			$query->where(" ccm.level_id = " . (int) $level);
		}

		// if get filter BY phase id
		$phaseId = $this->getState('filter.phase');
		$filterPhase = new FilterPhase();
		$filterPhase->applyPhaseFilter($query, $phaseId, $db);
		$phase = $this->getState('filter.phase');

		// Join over the subject
		$subQuery = $db->getQuery(true)
			->select('scm.competence_id, GROUP_CONCAT(s.name) as sname, GROUP_CONCAT(s.description) as sdesc')
			->select('GROUP_CONCAT(s.id) AS subject_id_list')
			->from('#__diler_subject_competence_map AS scm')
			->innerJoin('#__diler_subject AS s ON scm.subject_id = s.id')
			->group('scm.competence_id');

		//if get filter BY subject id
		if ($input->getUint('filter_subject') > 0)
		{
			$filter_subject = $input->getUint('filter_subject');
			$subQuery->where('scm.subject_id = ' . $db->quote((int) $filter_subject));
		}
		// Subject filter.
		$subject = $this->getState('filter.subject');
		if (is_numeric($subject))
		{
			$subQuery->where('scm.subject_id = ' . $db->quote((int) $subject));
		}

		$query->select('sname, sdesc');
		$query->innerJOIN('(' . trim((string) $subQuery) . ') AS sub ON sub.competence_id = ccm.competence_id');

		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('cc.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(cc.published = 0 OR cc.published = 1)');
		}

		//order by [field] [direction]
		$orderCol  = $this->state->get('list.ordering', 'cc.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		return $query;
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');

		return parent::getStoreId($id);
	}

	function getLevelList()
	{
		$result = array();
		$db     = Factory::getDBO();

		$query = " SELECT id,name FROM #__diler_level where published = 1 order by name asc ";
		$db->setQuery($query);
		$rows = $db->loadObjectList();

		foreach ($rows as $row)
		{
			$result[] = HTMLHelper::_('select.option', $row->id, Text::_($row->name));
		}

		return $result;
	}
}