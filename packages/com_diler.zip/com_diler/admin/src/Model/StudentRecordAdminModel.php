<?php
/**
 * Point default model, update, load form, load script
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright	Copyright (C) 2013-15 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;

use Joomla\CMS\MVC\Model\AdminModel;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Point model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class StudentRecordAdminModel extends AdminModel
{
	public function getForm($data = array(), $loadData = true)
	{
		return false;
	}

	protected function getReorderConditions($table)
	{
		$condition = array();
		$condition[] = 'student_id = ' . (int) $table->student_id;
		$condition[] = 'DATE(effective_date) = ' . substr($table->effective_date, 0, 10);

		return $condition;
	}
}