<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\MVC\Model\ListModel;

// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted access' );

class DatamanagementModel extends ListModel
{
    public function getStatusForm()
    {
        Form::addFormPath(JPATH_COMPONENT . '/models/forms');
        Form::addFieldPath(JPATH_COMPONENT . '/models/fields');
        return Form::getInstance('statusReset', 'status_reset');
    }

    protected function buildDeleteQueryString($query)
	{
		$queryString = 'DELETE status ' . $query->from;
        if($query->join) {
            for ($i = 0; $i < count($query->join); $i++) {
                $queryString .= $query->join[$i];
            }
        }

		$queryString .= $query->where;
		return $queryString;
	}

	public function getBulletinMenuItems()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->select('COUNT(*)')
				->from('#__menu')
				->where('link LIKE "%com_diler%"')
				->where('title LIKE "%bulletin%"')
				->where('menutype LIKE "%hidden%"');
		return $db->setQuery($query)->loadResult();
	}

	public function getBulletinTemplateStyles()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->select('COUNT(*)')
				->from('#__template_styles')
				->where('title LIKE "%diler3%bulletin%"');
		return $db->setQuery($query)->loadResult();
	}

	public function getGroupsExist()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->select('COUNT(*)')->from('#__diler_group');
		return (bool) $db->setQuery($query)->loadResult();
	}

	protected function getListQuery()
	{
		$db = $this->getDbo();

		$query = $db->getQuery ( true );

		$query->select ( 'id,name,description' );

		$query->from ( '#__diler_subject' );
		return $query;
	}

	public function getResetAchievementCounts($statusCodes, $phases, $subjects, $date)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('COUNT(*)')
			->from('#__diler_student_compchar_status AS status')
			->innerJoin('#__diler_compchar AS cc ON status.compchar_id = cc.id')
			->innerJoin('#__diler_competence_compchar_map AS ccm ON ccm.compchar_id = cc.id')
			->innerJoin('#__diler_competence AS c ON ccm.competence_id = c.id')
			->innerJoin('#__diler_subject_competence_map AS map ON c.id = map.competence_id')
			->innerJoin('#__diler_phase AS p ON map.phase_id = p.id');

		if (is_array($statusCodes) && count($statusCodes) && ! in_array(-1, $statusCodes))
			$query->where('status.status IN(' . implode(',', $statusCodes) . ')');

		if (is_array($phases) && count($phases) && ! in_array(-1, $phases))
			$query->where('p.id IN(' . implode(',', $phases) . ')');

		if (is_array($subjects) && count($subjects) && ! in_array(-1, $subjects))
			$query->where('map.subject_id IN(' . implode(',', $subjects) . ')');

		$query->where('status.modified <= ' . $db->quote($date));
		$compcharCount = $db->setQuery($query)->loadResult();

		$query->clear()
			->select('COUNT(*)')
			->from('#__diler_student_competence_status AS status')
			->innerJoin('#__diler_competence AS c ON status.competence_id = c.id')
			->innerJoin('#__diler_subject_competence_map AS map ON c.id = map.competence_id')
			->innerJoin('#__diler_phase AS p ON map.phase_id = p.id');

		if (is_array($statusCodes) &&count($statusCodes) &&!in_array(-1, $statusCodes))
			$query->where('status.status IN(' .implode(',', $statusCodes) .')');

		if (is_array($phases) &&count($phases) &&!in_array(-1, $phases))
			$query->where('p.id IN(' .implode(',', $phases) .')');

		if (is_array($subjects) &&count($subjects) &&!in_array(-1, $subjects))
			$query->where('map.subject_id IN(' .implode(',', $subjects) .')');

		$query->where('status.modified <= ' . $db->quote($date));
		$competenceCount = $db->setQuery($query)->loadResult();

		$query->clear()
			->select('COUNT(*)')
			->from('#__diler_student_subject_phase_status AS status');

		if (is_array($statusCodes) &&count($statusCodes) &&!in_array(-1, $statusCodes))
			$query->where('status.status IN(' .implode(',', $statusCodes) .')');

		if (is_array($phases) &&count($phases) &&!in_array(-1, $phases))
			$query->where('status.phase_id IN(' .implode(',', $phases) .')');

		if (is_array($subjects) &&count($subjects) &&!in_array(-1, $subjects))
			$query->where('status.subject_id IN(' .implode(',', $subjects) .')');

		$query->where('status.modified <= ' . $db->quote($date));
		$subjectCount = $db->setQuery($query)->loadResult();
		$totalRows = ($compcharCount + $competenceCount + $subjectCount);
		$displayData = array('compcharCount' => $compcharCount, 'competenceCount' => $competenceCount, 'subjectCount' => $subjectCount,
				'totalRows' => $totalRows, 'action' => 'count');
		$markup = LayoutHelper::render('reset_status_counts', $displayData);
		return array('counts' => $displayData, 'markup' => $markup);
	}

	public function resetAchievements($statusCodes, $phases, $subjects, $date)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->from('#__diler_student_compchar_status AS status')
			->innerJoin('#__diler_compchar AS cc ON status.compchar_id = cc.id')
			->innerJoin('#__diler_competence_compchar_map AS ccm ON ccm.compchar_id = cc.id')
			->innerJoin('#__diler_competence AS c ON ccm.competence_id = c.id')
			->innerJoin('#__diler_subject_competence_map AS map ON c.id = map.competence_id')
			->innerJoin('#__diler_phase AS p ON map.phase_id = p.id');

		if(is_array($statusCodes) && count($statusCodes) && !in_array(-1, $statusCodes))
			$query->where('status.status IN(' .implode(',', $statusCodes) .')');

		if(is_array($phases) && count($phases) && !in_array(-1, $phases))
			$query->where('p.id IN(' .implode(',', $phases) .')');

		if(is_array($subjects) && count($subjects) && !in_array(-1, $subjects))
			$query->where('map.subject_id IN(' .implode(',', $subjects) .')');

		$query->where('status.modified <= ' .$db->quote($date));
		$queryString = $this->buildDeleteQueryString($query);

		$db->setQuery($queryString)->execute();

		$query->clear('from')->clear('join')
			->from('#__diler_student_competence_status AS status')
			->innerJoin('#__diler_competence AS c ON status.competence_id = c.id')
			->innerJoin('#__diler_subject_competence_map AS map ON c.id = map.competence_id')
			->innerJoin('#__diler_phase AS p ON map.phase_id = p.id');

		$queryString = $this->buildDeleteQueryString($query);
		$db->setQuery($queryString)->execute();

		$query->clear()->from('#__diler_student_subject_phase_status AS status');

		if (is_array($statusCodes) &&count($statusCodes) &&!in_array(-1, $statusCodes))
			$query->where('status.status IN(' .implode(',', $statusCodes) .')');

		if (is_array($phases) &&count($phases) &&!in_array(-1, $phases))
			$query->where('status.phase_id IN(' .implode(',', $phases) .')');

		if (is_array($subjects) &&count($subjects) &&!in_array(-1, $subjects))
			$query->where('status.subject_id IN(' .implode(',', $subjects) .')');

		$query->where('status.modified <= ' . $db->quote($date));
		$queryString = $this->buildDeleteQueryString($query);
		$db->setQuery($queryString)->execute();

		$displayData = array('action' => 'purge');
		$markup = LayoutHelper::render('reset_status_counts', $displayData);
		return array('counts' => $displayData, 'markup' => $markup);
	}

	public function getLastSchoolYearSwitch()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('switch_date');
		$query->from('#__diler_switch_school_year_history');
		$query->order('switch_id DESC');

		return $db->setQuery($query)->loadResult();
	}

	public function isHighestPhaseSet()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select("*");
		$query->from('#__diler_phase');
		$query->where('is_highest_phase = 1');
		$query->where('published = 1');

		return $db->setQuery($query)->loadResult();
	}


	public function updateStudentActualAndTargetPhases()
	{
		$phases = $this->getPhases();
		$students = $this->getStudents();
		foreach ($students as $student)
		{
			$studentId = $student['user_id'];
			$currentActualPhase = $student['student_phase_actual'];
			$nextActualPhase = $this->getNextActualPhase($currentActualPhase, $phases);

			if ($currentActualPhase && !$nextActualPhase)
			{
				$this->blockStudent($studentId);
				continue;
			}

			$newTargetPhase = $this->getNextTargetPhase($student['student_phase_target'], $phases);
			$this->updateStudentPhases($nextActualPhase, $newTargetPhase, $studentId);
		}

		$this->saveDateWhenSwitchedSchoolYear();
	}

	private function getPhases()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__diler_phase');
		$query->where('published = 1');
		$query->order('ordering ASC, id ASC');

		return $db->setQuery($query)->loadAssocList();
	}

	private function getStudents()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('du.user_id');
		$query->select('du.student_phase_actual');
		$query->select('du.student_phase_target');
		$query->from('#__dilerreg_users as du');
		$query->innerJoin('#__users as ju ON ju.id = du.user_id');
		$query->where('ju.block = 0');
		$query->where('role = ' . $db->quote('student'));

		return $db->setQuery($query)->loadAssocList();
	}

	private function getNextActualPhase($current, $phases)
	{
		if (!$current)
			return 0;

		$phaseKey = array_search($current, array_column($phases, 'id'));
		if ($phases[$phaseKey]['is_highest_phase'])
			return 0;

		$nextPhase = $phases[$phaseKey + 1];
		if ($nextPhase)
			return $nextPhase['id'];

		return 0;
	}

	private function getNextTargetPhase($current, $phases)
	{
		if (!$current)
			return 0;

		$phaseKey = array_search($current, array_column($phases, 'id'));
		if ($phases[$phaseKey]['is_highest_phase'])
			return $current;

		$nextPhase = $phases[$phaseKey + 1];
		if ($nextPhase)
			return $nextPhase['id'];

		return $current;
	}

	private function updateStudentPhases($actualPhase, $targetPhase, $studentId)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->update('#__dilerreg_users');
		$query->set('student_phase_actual = ' . (int) $actualPhase);
		$query->set('student_phase_target = ' . (int) $targetPhase);
		$query->where('user_id = ' . (int) $studentId);

		$db->setQuery($query)->execute();
	}

	private function blockStudent($userId)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->update('#__users');
		$query->set('block = 1');
		$query->where('id = ' . (int) $userId);

		$db->setQuery($query)->execute();
	}

	private function saveDateWhenSwitchedSchoolYear()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->insert('#__diler_switch_school_year_history');
		$query->set('switch_date = ' . $db->quote(Factory::getDate()->toSql()));
		$db->setQuery($query)->execute();
	}

}