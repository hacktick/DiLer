<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\MVC\Model\ListModel;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class ReporttypesModel extends ListModel
{
	public $contract = 0;

	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array('a.name','a.published', 'published','a.id','a.ordering', 'a.state');

			$app = Factory::getApplication();
		}
		$this->contract = Factory::getApplication()->input->getUint('contract', 0);

		parent::__construct($config);
	}

	protected function addLayoutFiles()
	{
		$layoutFolder = $this->contract ? 'contract_layouts' : 'report_layouts';
		$folders = Folder::folders(JPATH_ROOT . '/templates', $layoutFolder, 4, true);
		if ($folders)
		{
			foreach ($folders as $folder)
			{
				$files = Folder::files($folder, '.php', false, false);
				if ($files)
				{
					foreach ($files as $file)
					{
						$fileName = File::stripExt($file);
						$table = Factory::getApplication()->bootComponent('com_diler')->getMVCFactory()->createTable('Reporttype');

						if (!$table->load(array('layout_file_name' => $fileName)))
						{
							$description = $this->contract ? DText::sprintf('CONTRACT_TYPE_DEFAULT_DESCRIPTION', $fileName) : DText::sprintf('REPORT_TYPE_DEFAULT_DESCRIPTION', $fileName);
							$data = array(
								'name' => $fileName,
								'published' => 1,
								'report_or_contract' => $this->contract,
								'description' => $description,
								'layout_file_name' => $fileName,
							);
							$table->save($data);
						}
					}
				}
			}
		}
	}

	public function getContract()
	{
		return $this->contract;
	}

	public function getItems()
	{
		$layoutFolder = $this->contract ? 'contract_layouts' : 'report_layouts';
		$items = parent::getItems();
		foreach ($items as $row)
		{
			$path = JPATH_ROOT . '/templates/diler3/html/com_diler/' . $layoutFolder . '/' . $row->layout_file_name . '.php';
			$row->layout_exists = (file_exists($path));
		}
		return $items;
	}

	protected function getListQuery()
	{
		$this->addLayoutFiles();

		// Create a new query object.
		$db = $this->getDbo();
		$input = Factory::getApplication()->input;
		$query = $db->getQuery(true);
		$query->select('a.*');
		$query->from('#__diler_report_type AS a');
		$query->where('report_or_contract = ' . (int) $this->contract);
		$filter_search = $this->getState('filter.search');
		if ($filter_search)
		{
			$query->where('a.name LIKE ' . $db->quote('%' . $filter_search . '%'));
		}

        $published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where("a.published = " . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		return $query;
	}

	protected function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState();
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}
}