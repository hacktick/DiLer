<?php
/*
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\Lang\DText;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Table\Usergroup;
use Joomla\CMS\Table\ViewLevel;
use Joomla\Component\Categories\Administrator\Model\CategoryModel;
use Joomla\Component\Menus\Administrator\Model\MenuModel;
use Joomla\Component\Menus\Administrator\Table\MenuTable;
use Joomla\Component\Tags\Administrator\Table\TagTable;
use Joomla\Component\Templates\Administrator\Model\StyleModel;
use Joomla\Component\Users\Administrator\Model\GroupModel;
use Joomla\Registry\Registry;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;
use \Exception;
use \RuntimeException;
use \JLoader;

\JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

/**
 * DiLer model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DilerModel extends AdminModel
{

	protected $calendarTables = array('#__dpcalendar_locations','#__dpcalendar_events_location','#__dpcalendar_events');

	protected $allDilerTables = array(
		'#__diler_activity_compchar_map',
		'#__diler_activity_task_map',
		'#__diler_subject_competence_map',
		'#__diler_report_field_subject_map',
		'#__diler_user_extra_curricular_map',
		'#__diler_user_phase_map',
		'#__diler_competence_compchar_map',
		'#__diler_group_cloud_map',
		'#__diler_group_subject_section_map',
		'#__diler_report_field_history',
		'#__diler_activity_completed',
		'#__diler_activity_task_completed',
		'#__diler_activity',
		'#__diler_activity_grading_method',
		'#__diler_activity_task',
		'#__diler_activity_type',
		'#__diler_student_compchar_status',
		'#__diler_student_competence_status',
		'#__diler_student_subject_phase_status',
		'#__diler_compchar',
		'#__diler_competence',
		'#__diler_extra_curricular',
		'#__diler_group_marks_period_calendar_map',
		'#__diler_group_marks_period_map',
		'#__diler_marks_history',
		'#__diler_group',
		'#__diler_level',
		'#__diler_log',
		'#__diler_phase',
		'#__diler_report_definition_xref',
		'#__diler_report_field_definition',
		'#__diler_report_period',
		'#__diler_report_type',
		'#__diler_subject',
		'#__diler_texter',
		'#__diler_nimbus_phrase',
		'#__diler_nimbus_template',
		'#__diler_section',
		'#__diler_schoolyear_marks_period_map',
		'#__diler_schoolyear',
		'#__diler_marks_period',
		'#__diler_marks_period_calendar',
		'#__diler_cloud',
	);

	/**
	 * Array of compchars in format compcharId => competenceId.
	 */
	protected $competenceArray = array();

	protected $warnings = 0;
	protected $errors = 0;
	protected $superUserGroupids = array();

	protected $subjectUsergroupParentId = 0;
	protected $extracurricularUsergroupParentId = 0;
	protected $nextViewAccessLevelOrdering = 0;

	/**
	 * Quickly adds a list of Joomla users to usergroups.
	 * Much faster than using UserHelper::addUserToGroup function.
	 *
	 * @param array $usergroupInsertArray : {Joomla group id} => {array of user id's}
	 */
	public function addUsersToUsergroup($usergroupInsertArray)
	{
		return MVCHelper::factory()->createModel('Usergroup', 'Site')->addUsersToUsergroup($usergroupInsertArray);
	}

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.message.' . ((int) isset($data[$key]) ? $data[$key] : 0)) or parent::allowEdit($data, $key);
	}

	/**
	 * Assigns all teachers to all LG's.
	 *
	 * @param array $lgUsergroups  Array of row objects for all learning groups
	 */
	protected function assignTeachersToLearningGroups($lgUsergroups)
	{
		$this->logDataConversion('Adding all teachers to all Learning Groups ...');
		$rowCount = 0;
		$errors = 0;
		// get teachers
		$usergroupModel = MVCHelper::factory()->createModel('Usergroup', 'Site');
		$teachers = $usergroupModel->getTeachers();
		$teacherIdArray = ArrayHelper::getColumn($teachers, 'user_id');
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->insert('#__user_usergroup_map')->columns('user_id, group_id');

		// For each lg, insert rows in user_usergroup table for all teachers
		foreach ($lgUsergroups as $group)
		{
			// Get a users already assigned to this group so we can skip them
			$assignedQuery = $db->getQuery(true)->select('user_id')->from('#__user_usergroup_map')
					->where('user_id IN(' . implode(',', $teacherIdArray) . ')')
					->where('group_id = ' . $group->id);
			$assignedIdArray = $db->setQuery($assignedQuery)->loadColumn();
			$unassignedIdArray = array_diff($teacherIdArray, $assignedIdArray);

			// Insert unassigned teachers to map table
			$query->clear('values');
			foreach ($unassignedIdArray as $teacherId)
			{
				$query->values($teacherId . ',' . $group->id);
			}
			if ($unassignedIdArray)
			{
				$insert = $db->setQuery($query)->execute();
				if ($insert)
				{
					$rowCount += count($unassignedIdArray);
				}
				else
				{
					$errors += count($unassignedIdArray);
				}
			}
		}
		if ($rowCount && ! $errors)
		{
			$this->logDataConversion('Success! ' . $rowCount . ' teacher / Learning Group rows mapped. ' . count($lgUsergroups) . ' groups and ' . count($teacherIdArray) . ' teachers.');
		}
		else
		{
			$this->logDataConversion('Warning: ' . $errors . ' rows not added to user group mapping table. ' . $rowCount . ' rows were added. ' . count($lgUsergroups) . ' groups and ' . count($teacherIdArray) . ' teachers.');
		}
	}

	protected function batchInsert($query, $values, $batchSize = 100)
	{
		$chunkArray = array_chunk($values, $batchSize);
		$db = Factory::getDbo();
		$result = false;
		foreach ($chunkArray as $valueArray)
		{
			$valueArray = array_map(array($db, 'quote'), $valueArray);
			$query->clear('values');
			foreach ($valueArray as $values)
			{
				$query->values(implode(',', $values));
			}
			try
			{
				$result = $db->setQuery($query)->execute();
			}
			catch (Exception $exc)
			{
				$this->logDataConversion('Error: Insert query failed. Query = ' . (string) $query);
				throw new Exception($exc);
			}

			if (! $result)
			{
				return $result;
			}
			}
		return $result;
	}

	// Checks that the foreign key references are correct in the current db
    public function checkDbSchema()
	{
		// These are the fk references that should exist
		$fkeyArray = array(
			"#__diler_activity_compchar_map.activity_id" => "#__diler_activity.id",
			"#__diler_activity_compchar_map.compchar_id" => "#__diler_compchar.id",
			"#__diler_activity_completed.activity_id" => "#__diler_activity.id",
			"#__diler_activity_completed.student_id" => "#__dilerreg_users.user_id",
			"#__diler_activity_task_completed.student_id" => "#__dilerreg_users.user_id",
			"#__diler_activity_task_completed.task_id" => "#__diler_activity_task.id",
			"#__diler_activity_task_grid_media_map.activity_task_id" => "#__diler_activity_task.id",
			"#__diler_activity_task_grid_media_map.grid_media_id" => "#__diler_grid_media.id",
			"#__diler_activity_task_map.activity_id" => "#__diler_activity.id",
			"#__diler_activity_task_map.task_id" => "#__diler_activity_task.id",
			"#__diler_activity.activity_type" => "#__diler_activity_type.id",
			"#__diler_activity.grading_method" => "#__diler_activity_grading_method.id",
			"#__diler_class_schedule_time_slot.class_schedule_id" => "#__diler_class_schedule.id",
			"#__diler_competence_compchar_map.compchar_id" => "#__diler_compchar.id",
			"#__diler_competence_compchar_map.competence_id" => "#__diler_competence.id",
			"#__diler_competence_compchar_map.level_id" => "#__diler_level.id",
			"#__diler_group_cloud_map.group_id" => "#__usergroups.id",
			"#__diler_group_cloud_map.media_id" => "#__diler_cloud.id",
			"#__diler_group_marks_period_calendar_map.group_id" => "#__diler_group.id",
			"#__diler_group_marks_period_calendar_map.marks_period_calendar_id" => "#__diler_marks_period_calendar.id",
			"#__diler_group_marks_period_map.group_id" => "#__diler_group.id",
			"#__diler_group_marks_period_map.marks_period_id" => "#__diler_marks_period.id",
			"#__diler_group_responsible_teacher.group_id" => "#__usergroups.id",
			"#__diler_group_responsible_teacher.teacher_id" => "#__users.id",
			"#__diler_group_schedule.class_schedule_id" => "#__diler_class_schedule.id",
			"#__diler_group_schedule.class_schedule_slot_id" => "#__diler_class_schedule_time_slot.id",
			"#__diler_group_schedule.group_id" => "#__diler_group.id",
			"#__diler_group_subject_section_map.group_id" => "#__diler_group.id",
			"#__diler_group_subject_section_map.phase_id" => "#__diler_phase.id",
			"#__diler_group_subject_section_map.section_id" => "#__diler_section.id",
			"#__diler_group_subject_section_map.subject_id" => "#__diler_subject.id",
			"#__diler_group.joomla_group_id" => "#__usergroups.id",
			"#__diler_group.joomla_viewlevel_id" => "#__viewlevels.id",
			"#__diler_marks_history.group_id" => "#__diler_group.id",
			"#__diler_marks_history.marks_period_id" => "#__diler_marks_period.id",
			"#__diler_marks_history.schoolyear_id" => "#__diler_schoolyear.id",
			"#__diler_marks_history.subject_id" => "#__diler_subject.id",
			"#__diler_marks_period.marks_period_calendar_id" => "#__diler_marks_period_calendar.id",
			"#__diler_nimbus_phrase.template_id" => "#__diler_nimbus_template.id",
			"#__diler_pep_assessments.student_id" => "#__users.id",
			"#__diler_pep_assessments.subject_group_id" => "#__diler_group.id",
			"#__diler_pep_development.student_id" => "#__users.id",
			"#__diler_pep.create_by" => "#__users.id",
			"#__diler_pep.school_year_id" => "#__diler_schoolyear.id",
			"#__diler_region_user_map.region_id" => "#__diler_region.id",
			"#__diler_region_user_map.user_id" => "#__dilerreg_users.user_id",
			"#__diler_report_definition_xref.field_id" => "#__diler_report_field_definition.id",
			"#__diler_report_definition_xref.subform_field_id" => "#__diler_report_field_definition.id",
			"#__diler_report_field_history.field_id" => "#__diler_report_field_definition.id",
			"#__diler_report_field_history.period_id" => "#__diler_report_period.id",
			"#__diler_report_field_subject_map.field_id" => "#__diler_report_field_definition.id",
			"#__diler_report_field_subject_map.subject_id" => "#__diler_subject.id",
			"#__diler_schoolyear_marks_period_map.marks_period_id" => "#__diler_marks_period.id",
			"#__diler_schoolyear_marks_period_map.schoolyear_id" => "#__diler_schoolyear.id",
			"#__diler_state.country_id" => "#__diler_country.id",
			"#__diler_stored_report.learning_group_id" => "#__usergroups.id",
			"#__diler_stored_report.schoolyear_id" => "#__diler_schoolyear.id",
			"#__diler_stored_report.student_id" => "#__users.id",
			"#__diler_student_compchar_status.compchar_id" => "#__diler_compchar.id",
			"#__diler_student_compchar_status.student_id" => "#__dilerreg_users.user_id",
			"#__diler_student_competence_status.competence_id" => "#__diler_competence.id",
			"#__diler_student_competence_status.student_id" => "#__dilerreg_users.user_id",
			"#__diler_student_subject_phase_status.phase_id" => "#__diler_phase.id",
			"#__diler_student_subject_phase_status.student_id" => "#__dilerreg_users.user_id",
			"#__diler_student_subject_phase_status.subject_id" => "#__diler_subject.id",
			"#__diler_studentrecord_group_map.studentrecord_id" => "#__diler_studentrecord.id",
			"#__diler_studentrecord_history.studentrecord_id" => "#__diler_studentrecord.id",
			"#__diler_studentrecord_tag_map.studentrecord_id" => "#__diler_studentrecord.id",
			"#__diler_subject_competence_map.competence_id" => "#__diler_competence.id",
			"#__diler_subject_competence_map.phase_id" => "#__diler_phase.id",
			"#__diler_subject_competence_map.subject_id" => "#__diler_subject.id",
			"#__diler_teacher_mynotes.student_id" => "#__users.id",
			"#__diler_teacher_mynotes.teacher_id" => "#__users.id",
			"#__diler_user_extra_curricular_map.extra_curricular_id" => "#__diler_extra_curricular.id",
			"#__diler_user_grid_media_map.grid_media_id" => "#__diler_grid_media.id",
			"#__diler_user_grid_media_map.user_id" => "#__users.id",
			"#__diler_user_phase_map.phase_id" => "#__diler_phase.id",
			"#__diler_user_phase_map.subject_id" => "#__diler_subject.id",
			"#__diler_user_phase_map.user_id" => "#__dilerreg_users.user_id",
			"#__diler_user_school_history.school_id" => "#__diler_school.id",
			"#__diler_user_school_history.user_id" => "#__dilerreg_users.user_id",
			"#__dilerreg_registration_code_user_map.code_id" => "#__dilerreg_registration_codes.id",
			"#__dilerreg_registration_code_user_map.user_id" => "#__dilerreg_users.user_id",
            "#__diler_group_school_map.joomla_group_id" => "#__usergroups.id",
            "#__diler_group_school_map.school_id" => "#__diler_school.id",
            "#__diler_group_state_map.joomla_group_id" => "#__usergroups.id",
            "#__diler_group_state_map.state_id" => "#__diler_state.id",
            "#__diler_school_ministry.assigned_user_id" => "#__users.id",
            "#__diler_student_region_teacher_at_time_of_enrollment.student_id" => "#__users.id",
            "#__diler_student_region_teacher_at_time_of_enrollment.teacher_id" => "#__users.id",
            "#__diler_pep_assessments.development_area_id" => "#__diler_pep_development_area.id",
            "#__diler_pep.pep_assessment_id" => "#__diler_pep_assessments.id",
            "#__diler_pep.goal_id" => "#__diler_pep_goal.id"
		);

		// Get the actual fk constraints from the db
		$config = Factory::getConfig();
		$prefix = $config->get('dbprefix');
		$db = Factory::getDbo();
		$app = Factory::getApplication();
		$query = $db->getQuery(true)
				->select("concat(table_name, '.', column_name) as 'foreign_key'")
				->select("concat(referenced_table_name, '.', referenced_column_name) as 'references'")
				->from('information_schema.key_column_usage')
				->where('referenced_table_name is not null')
				->where('CONSTRAINT_SCHEMA = ' . $db->quote($config->get('db')))
				->order('table_name, column_name');
		$rows = $db->setQuery($query)->loadObjectList();
		$rowArray = array();
		foreach ($rows as $row)
		{
			$rowArray[$row->foreign_key] = $row->references;
		}

		// Make sure all of the ones that should exist are found in the current db
		$errors = array();
		foreach ($fkeyArray as $child => $parent)
		{
			// Use current db prefix
			$child = str_replace('#__', $prefix, $child);
			$parent = str_replace('#__', $prefix, $parent);
			if (! isset($rowArray[$child]) || $rowArray[$child] != $parent)
			{
				$errors[$child] = $parent;
			}
		}
		if ($errors)
		{
			$messageArray = array();
			$errorMessageArray = array();
			foreach ($errors as $errorChild => $errorParent)
			{
				$fixResult = $this->checkDbSchemaFix($errorChild, $errorParent);
				if ($fixResult->status == 1)
				{
					$message = DText::sprintf('CHECK_DATABASE_SCHEMA_FIX_DETAIL', $errorChild, $errorParent, $fixResult->rowsDeleted);
					$messageArray[] = $message;
					$this->logDataConversion($message, 'info');
				}
				else
				{
					$message = DText::sprintf('CHECK_DATABASE_SCHEMA_ERROR_DETAIL', $errorChild, $errorParent, $fixResult->message);
					$errorMessageArray[] = $message;
					$this->logDataConversion($message, 'error');
				}
			}
			if ($errorMessageArray)
			{
				array_unshift($errorMessageArray, DText::sprintf('CHECK_DATABASE_SCHEMA_ERROR', count($errors)));
				throw new RuntimeException(implode("</br>", $errorMessageArray));
			}
			else
			{
				array_unshift($messageArray, DText::sprintf('CHECK_DATABASE_SCHEMA_ERROR', count($errors)));
				foreach ($messageArray as $msg)
				{
					$app->enqueueMessage($msg);
				}
			}
		}
		$deletedGroups = $this->checkDbSchemaFixGroupSubjectMap();
		if (is_array($deletedGroups) && $deletedGroups)
		{
			$app->enqueueMessage(DText::sprintf('CHECK_DATABASE_GROUPS_DELETED', count($deletedGroups)));
		}
	}

	// Adds missing FK constraint. First it removes any invalid rows that would prevent the FK constraing.
    protected function checkDbSchemaFix($errorChild, $errorParent)
	{
		$db = Factory::getDbo();
		// Split the child and parent table/col pairs
		$childArray = explode('.', $errorChild);
		$parentArray = explode('.', $errorParent);
		$existsObject = $this->checkDbSchemaExists($childArray, $parentArray);
		if (! $existsObject->status)
		{
			return (object) array('status' => 0, 'message' => $existsObject->message);
		}

		// Delete any invalid rows in child table
		$subQuery = $db->getQuery(true)
				->select($db->quoteName($parentArray[1]))
				->from($db->quoteName($parentArray[0]));
		$query = $db->getQuery(true);
		$query->delete($db->quoteName($childArray[0]))
				->where($db->quoteName($childArray[1]) . ' NOT IN (' . (string) $subQuery . ')');
		$result = $db->setQuery($query)->execute();
		$rowsDeleted = $db->getAffectedRows();
		$constraintName = 'FK_' .  $childArray[0] . '_' . $childArray[1];
		if (strlen($constraintName) > 64)
		{
			$constraintName = substr($constraintName, 0,63);
		}
		$alter = "ALTER TABLE " . $db->quoteName($childArray[0]) . ' ADD CONSTRAINT ' . $db->quoteName($constraintName) . ' FOREIGN KEY (' .
				$db->quoteName($childArray[1]) . ') REFERENCES ' . $db->quoteName($parentArray[0]) .
				' (' . $db->quoteName($parentArray[1]) . ")";
		$fkResult = $db->setQuery($alter)->execute();
		if ($fkResult)
		{
			return (object) array('status' => 1, 'rowsDeleted' => (int) $rowsDeleted);
		}
		else
		{
			return array('status' => 0, 'message' => $db->getErrorMsg());
		}
	}

	/**
	 * Check that a table or column exists
	 * @param array $childArray
	 * @param array $parentArray
	 */
	protected function checkDbSchemaExists($childArray, $parentArray)
	{
		$resultArray = array();
		$resultArray[] = $this->checkDbTableColumn($childArray);
		$resultArray[] = $this->checkDbTableColumn($parentArray);
		$messageArray = array();
		foreach ($resultArray as $resultItem)
		{
			if (! $resultItem->status)
			{
				$messageArray[] = $resultItem->message;
			}
		}
		$result = (object) array('status' => 1);
		$resultMessages = array();
		if ($messageArray)
		{
			// We had some errors
			$result->status = 0;
			$resultMessages = implode('</br>', $messageArray);
		}
		$result->message = $resultMessages;
		return $result;
	}

	// Checks for Subject Groups that are not mapped to subjects and removes them plus any mapped users and related view levels.
	protected function checkDbSchemaFixGroupSubjectMap()
	{
		// Find if there are any unmapped subject groups
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('g.id')
				->from('#__diler_group AS g')
				->innerJoin('#__categories AS c on g.catid = c.id')
				->leftJoin('#__diler_group_subject_section_map AS gsm ON gsm.group_id = g.id')
				->where('c.params LIKE ' . $db->quote('%"group_type":"2"%'))
				->where('gsm.group_id IS NULL')
				->group('g.id');
		$badGroups = $db->setQuery($query)->loadColumn();
		if (is_array($badGroups) && $badGroups)
		{
			$language = Factory::getLanguage();
			$language->load('com_diler', JPATH_SITE . '/components/com_diler', null, true);
			$groupModel = MVCHelper::factory()->createModel('Group', 'Site');
			foreach ($badGroups as $badGroup)
			{
				$result = $groupModel->deleteGroup($badGroup);
			}
		}
		return $badGroups;
	}

	protected function checkDbTableColumn($tableColumn)
	{
		$result = (object) array('status' => 0, 'message' => DText::sprintf('CHECK_DATABASE_SCHEMA_FIX_TABLE_NOT_FOUND', implode('.', $tableColumn)));
		if ((! is_array($tableColumn)) || count($tableColumn) != 2)
		{
			return $result;
		}
		// Check table
		$config = Factory::getConfig();
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('count(*)')
				->from('information_schema.TABLES')
				->where('TABLE_NAME = ' . $db->quote($tableColumn[0]))
				->where('TABLE_SCHEMA = ' . $db->quote($config->get('db')));
		$tableExists = $db->setQuery($query)->loadResult();
		if (! $tableExists)
		{
			return $result;
 		}
		$query->clear()->select('count(*)')
				->from('information_schema.COLUMNS')
				->where('TABLE_NAME = ' . $db->quote($tableColumn[0]))
				->where('TABLE_SCHEMA = ' . $db->quote($config->get('db')))
				->where('COLUMN_NAME = ' . $db->quote($tableColumn[1]));
		$columnExists = $db->setQuery($query)->loadResult();
		if (! $columnExists)
		{
			return (object) array('status' => 0, 'message' => DText::sprintf('CHECK_DATABASE_SCHEMA_FIX_COLUMN_NOT_FOUND', $tableColumn[1]));
		}
		else
		{
			return (object) array('status' => 1);
		}
	}

    /**
     * Converts studentrecord_tag_map rows with tag_type=2. Change tag_id to point to diler_group table (ec group) instead of old extra_curricular table.
     *
     * @param array $dilerGroupIdArray $dilerGroupIdArray[$hash] = $groupRow->id
     * @param array $extracurricularIdArray $extracurricularIdArray[$row->id] = $hash
     *
     * @return int  count of map rows changed
     * @throws Exception
     */
	protected function convertStudentrecordTagMap($dilerGroupIdArray, $extracurricularIdArray)
	{
		$this->logDataConversion('Starting convertStudentrecordMap.');
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('m.*')->from('#__diler_studentrecord_tag_map AS m');
		$query->innerJoin('#__diler_extra_curricular AS ec ON m.tag_id = ec.id AND m.tag_type = 2 AND ec.published = 1');
		$mapRows = $db->setQuery($query)->loadObjectList();

		if ((!is_array($mapRows)) || !$mapRows)
		{
			return 0;
		}

		// Delete the old map rows
		$query->clear()->delete('#__diler_studentrecord_tag_map')->where('tag_type = 2');
		$deleted = $db->setQuery($query)->execute();
		if (! $deleted)
		{
			$this->logDataConversion('Error: Unable to delete diler_studentrecord_tag_map rows', LOG::error);
			$this->errors++;
			return 0;
		}
		else
		{
			$this->logDataConversion('Old diler_studentrecord_tag_map rows successfully deleted.');
		}

		$query->clear();
		$query->insert('#__diler_studentrecord_tag_map')->columns('studentrecord_id, tag_id, tag_type');
		$values = array();
		foreach ($mapRows AS $mapRow)
		{
			if (! isset($extracurricularIdArray[$mapRow->tag_id]))
			{
				$this->logDataConversion('Error: $extracurricularIdArray[$mapRow->tag_id] not set for $mapRow->tag_id = ' . $mapRow->tag_id . '.');
				$this->errors++;
			}
			elseif (! isset($dilerGroupIdArray[$extracurricularIdArray[$mapRow->tag_id]]))
			{
				$this->logDataConversion('Error: $dilerGroupIdArray[$extracurricularIdArray[$mapRow->tag_id]] not set for $extracurricularIdArray[$mapRow->tag_id] = ' . $extracurricularIdArray[$mapRow->tag_id] . '.');
				$this->errors++;
			}
			else
			{
				$dilerGroupId = $dilerGroupIdArray[$extracurricularIdArray[$mapRow->tag_id]];
				if (isset($values[$mapRow->studentrecord_id . '-' . $dilerGroupId]))
				{
					$this->logDataConversion('Warning! Duplicate row. $values[$mapRow->studentrecord_id-$dilerGroupId] already set for ' . $mapRow->studentrecord_id . '-' . $dilerGroupId);
				}
				$values[$mapRow->studentrecord_id . '-' . $dilerGroupId] = array($mapRow->studentrecord_id, $dilerGroupId, 2);
			}
		}

		$this->logDataConversion('Starting insert queries to insert ' . count($values) . ' new diler_studentrecord_tag_map rows.');
		$inserted = $this->batchInsert($query, $values);
		if (!$inserted)
		{
			$this->logDataConversion('Error: Unable to insert new diler_studentrecord_tag_map rows.');
			$this->errors++;
			return 0;
		}
		$this->logDataConversion('Success! ' . count($mapRows) . ' diler_studentrecord_tag_map rows inserted into diler_studentrecord_tag_map table.');
		return count($mapRows);
	}

	/**
	 * Sets the diler options to the newly created menu items.
	 *
	 * @param array $menuItemData
	 * @result bool true on success.
	 */
	protected function createBulletinDilerOptions($menuItemData)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('extension_id, params')->from('#__extensions')->where('type = "component"')->where('element = "com_diler"');
		$row = $db->setQuery($query)->loadObject();
		$params = new Registry($row->params);
		foreach ($menuItemData as $menuItem)
		{
			$params->set($menuItem['param'],$menuItem['menuItemId']);
		}
		$query->clear()->update('#__extensions')->set('params = ' . $db->quote((string) $params))->where('extension_id = ' . $row->extension_id);
		$result = $db->setQuery($query)->execute();
		return $result;
	}

	/**
	 * Create bulletin menu, menu items, and set related DiLer options.
	 * Only if the site has a diler3 - Bulletin template style.
	 */
	public function createBulletinMenuItems()
	{
		$this->logDataConversion('Starting Create Bulletin Menu Items.');
		$menuItemDataArray = array(
				array('access' => 'DiLer Student', 'title' => 'Bulletin Desk Students', 'param' => 'bulletinDeskUrlStudent', 'style' => 'Bulletin Desk Students'),
				array('access' => 'DiLer Teacher', 'title' => 'Bulletin Desk Teachers', 'param' => 'bulletinDeskUrlTeacher', 'style' => 'Bulletin Desk Teachers'),
				array('access' => 'DiLer Parent', 'title' => 'Bulletin Desk Parents', 'param' => 'bulletinDeskUrlParent', 'style' => 'Bulletin Desk Parents'),
			);
		// Get id of diler_bulletin template style (else return)
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')
				->from('#__template_styles')
				->where('template = "diler3"')
				->where('title LIKE "%diler3 - Bulletin%"');
		$styleRow = $db->setQuery($query)->loadObject();
		if (! (is_object($styleRow) && $styleRow->id))
		{
			$this->logDataConversion('Notice. No bulletin template style found. No bulletin menu or menu items were created.');
			return true;
		}
		// Create new template styles for each role
		/** @var StyleModel $templateModel */
		$templateModel = Factory::getApplication()->bootComponent('com_templates')->getMVCFactory()->createModel('Style', 'Administrator');
		foreach ($menuItemDataArray as $index => $menuItem)
		{
			$menuItemDataArray[$index]['styleId'] = $this->createBulletinTemplateStyle($styleRow, $menuItem['style'], $templateModel);
		}

		// create or find hidden menu -- get id
		$query->clear()->select('id')->from('#__menu_types')->where('menutype ="hidden-menu"');
		$menuTypeId = $db->setQuery($query)->loadResult();
		if (! $menuTypeId)
		{
			$data = array('id' => 0, 'menutype' => 'hidden-menu', 'title' => 'Hidden Menu');
			/** @var MenuModel $menuModel */
			$menuModel = Factory::getApplication()->bootComponent('com_menus')->getMVCFactory()->createModel('Menu', 'Administrator');
			$result = $menuModel->save($data);
			if (! $result)
			{
				$this->logDataConversion('Error. Could not create Hidden Menu.');
				return false;
			}
		}

		// Get com_diler component id
		$query->clear()->select('extension_id')->from('#__extensions')->where('type = "component"')->where('element = "com_diler"');
		$dilerComponentId = $db->setQuery($query)->loadResult();
		if (! $dilerComponentId)
		{
			$this->logDataConversion('Error. Could not find DiLer component id.');
			return false;
		}

		// create menu items for teacher, student, parents
		foreach ($menuItemDataArray as $index => $menuItemData)
		{
			$newId = $this->createBulletinMenuRow($menuItemData, $dilerComponentId);
			if (! $newId)
			{
				$this->logDataConversion('Error. Could not create menu item for ' . $menuItemData['title'] . '.');
				return false;
			}
			$menuItemDataArray[$index]['menuItemId'] = $newId;
		}

		// set diler options for bulletinDeskUrlTeacher, etc.
		if (! $this->createBulletinDilerOptions($menuItemDataArray))
		{
			$this->logDataConversion('Error. Could not assign menu item ids to bulletinDeskUrlStudent, bulletinDeskUrlStudent, bulletinDeskUrlParent options.');
			return false;
		}
		$this->logDataConversion('Success! Bulletin menu and menu items created.');
		return true;
	}

    /**
     * Creates new bulletin menu item for this role.
     * @param array $menuItemData
     * @param int $dilerComponentId
     * @return int  New menu item id on success, 0 on fail.
     * @throws Exception
     */
	protected function createBulletinMenuRow($menuItemData, $dilerComponentId)
	{
		/** @var \Joomla\Component\Menus\Administrator\Model\ItemModel $model */
		$model = Factory::getApplication()->bootComponent('com_menus')->getMVCFactory()->createModel('Item', 'Administrator');

		$dilerAccess = $this->getDilerUserAccess($menuItemData['access']);
		$params = new Registry();
		$params->set('pageclass_sfx', 'BulletinDesk');
		$path = strtolower(str_replace(' ', '-', $menuItemData['title']));
		$data = array(
			'id' => 0,
			'menuordering' => '-2',
			'menutype' => 'hidden-menu',
			'title' => $menuItemData['title'],
			'alias' => $path,
			'path' => $path,
			'link' => 'index.php?option=com_diler&view=diler',
			'type' => 'component',
			'published' => '1',
			'parent_id' => '1',
			'level' => '1',
			'component_id' => $dilerComponentId,
			'access' => $dilerAccess,
			'template_style_id' => $menuItemData['styleId'],
			'params' => (string) $params,
			'language' => '*',
			'client_id' => '0',
		);
		$result = $model->save($data);
		$newMenuItemId = 0;
		if ($result)
		{
			$newMenuItemId = $model->getState($model->getName() . '.id');
		}
		return $newMenuItemId;
	}

	/**
	 * Creates a template style that is a copy of the diler3 - Bulletin template style.
	 *
	 * @param string $title  The name of the new style.
	 * @return int   The id of the template style created.
	 */
	protected function createBulletinTemplateStyle($row, $title, $model)
	{
		$result = 0;
		$data = array('id' => 0, 'template' => $row->template, 'client_id' => $row->client_id, 'home' => $row->home, 'title' => $row->template . ' - ' . $title,
			'params' => $row->params);
		if ($model->save($data))
		{
			$result = $model->getState($model->getName() . '.id');
		}
		return $result;
	}

    /**
     * Creates a new category row
     *
     * @param array $data associative array of category row column => value
     * @return mixed  New catid if successful, false if not.
     * @throws Exception
     */
	protected function createCategory($data)
	{
		/** @var CategoryModel $categoryModel */
		$categoryModel = Factory::getApplication()->bootComponent('com_categories')->getMVCFactory()->createModel('Category', 'Administrator');
		$catid = false;
		if ($categoryModel->save($data))
		{
			$catid = $categoryModel->getState($categoryModel->getName() . '.id');
		}
		else
		{
			$this->logDataConversion('Error! ' . $categoryModel->getError());
			$this->errors++;
		}
		return $catid;
	}

	/**
	 * Inserts a new row in the #__usergroups table.
	 *
	 * We insert rows instead of using the usergroups model save() function because it is much faster when
	 * inserting a large number of rows to insert and then rebuild the table once.
	 * IMPORTANT: The usergroups table must be rebuilt to fix up the lft and rgt values in the table. This
	 * can be done once, after all of the inserts are done.
	 */
	protected function createNewJoomlaUserGroup($data)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->insert('#__usergroups');
		foreach ($data as $column => $value)
		{
			$query->set($db->quoteName($column) . '=' . $db->quote($value));
		}
		$db->setQuery($query)->execute();
		return $db->insertid();
	}

	/**
	 * Create new view access level that corresponds to a usergroup. Uses the usergroup id to make it unique.
	 *
	 * @param  array $groupData               Associative array of id, name for associated Joomla usergroup.
	 *                                   Give this usergroup permission to view this level.
	 *
	 * @param  bool  $includeSuperusers  If true, include any superuser groups in the rules column.
	 *
	 * @return mixed  on success, int id of newly created level. on failure, false.
	 */
	protected function createViewAccessLevel($groupData, $includeSuperusers = true)
	{
		$viewlevelTable = new ViewLevel(Factory::getDbo());

		// Get the next ordering from the table only once (otherwise use the saved value)
		$this->nextViewAccessLevelOrdering = ($this->nextViewAccessLevelOrdering) ? $this->nextViewAccessLevelOrdering + 1 : $viewlevelTable->getNextOrder();

		$rulesArray = array($groupData['id']);
		if ($includeSuperusers)
		{
			$superUserGroupIds = $this->getSuperusergroupIds();
			$rulesArray = array_merge($rulesArray, $superUserGroupIds);
		}
		$rulesArray = array_map('intval', $rulesArray);

		$viewlevelData = array('title' => $groupData['title'], 'id' => 0, 'rules' => json_encode($rulesArray), 'ordering' => $this->nextViewAccessLevelOrdering);
		if (! $viewlevelTable->bind($viewlevelData))
		{
			$this->logDataConversion('Error! Unable to create view access level for group named "' . $groupData['title'] . '". Table bind method failed.');
			$this->errors++;
			return false;
		}
		// Check to see if the name is unique. Add sequence if needed (up to 5 tries).
		$tries = 1;
		while (! $viewlevelTable->check() && $tries < 5)
		{
			$viewlevelTable->title = $groupData['title'] . ' - ' . $tries;
			$tries++;
		}
		if ($tries == 5)
		{
			$this->logDataConversion('Error! Unable to create view access level for group named "' . $groupData['title'] . '". Unable to create unique title.');
			$this->errors++;
			return false;
		}

		if (! $viewlevelTable->store())
		{
			$this->logDataConversion('Error! Unable to create view access level for group named "' . $groupData['title'] . '". Table store method failed.');
			$this->errors++;
			return false;
		}
		return $viewlevelTable->id;
	}

	protected function rebuildJoomlaUsergroupTable()
	{
		$table = new Usergroup(Factory::getDbo());
		return $table->rebuild();
	}

	/**
	 * Sets two new diler options for v600.
	 */
	protected function setSubjectExtracurricularParentDilerOptions()
	{
		$params = ComponentHelper::getParams('com_diler');
		$params->set('subject_group_parent_id', $this->subjectUsergroupParentId);
		$params->set('extracurricular_group_parent_id', $this->extracurricularUsergroupParentId);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__extensions')
				->set('params = ' . $db->quote($params->toString()))
				->where('element = "com_diler"')
				->where('type = "component"');
		return $db->setQuery($query)->execute();
	}

	/**
	 * Creates a new menu item for the cloud view
	 */
	protected function createCloudMenuItem()
	{
		JLoader::register('MenusModelItem', JPATH_ADMINISTRATOR . '/components/com_menus/models/item.php');
		JLoader::register('MenusTableMenu', JPATH_ADMINISTRATOR . '/components/com_menus/tables/menu.php');
		AdminModel::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_menus/models/');

		/** @var MVCFactoryInterface $menuFactory */
		$menuFactory = Factory::getApplication()->bootComponent('com_menus')->getMVCFactory();
		/** @var \Joomla\Component\Menus\Administrator\Model\ItemModel $model */
		$model = $menuFactory->createModel('Item', 'Administrator');

		/** @var MenuTable $adminTable */
		$adminTable = $menuFactory->createTable('Menu', 'Administrator');
		$adminTable->load(array('alias' => 'administration'));
		$dilerAccess = $this->getDilerUserAccess();
		$params = new Registry($adminTable->params);
		$params->set('view_name', '4');
		$params->set('menu-anchor_css', 'cloud');
		$data = array(
			'menutype' => 'diler-mainmenu',
			'title' => DText::_('CLOUD'),
			'path' => 'cloud',
			'link' => 'index.php?option=com_diler&view=diler',
			'type' => 'component',
			'published' => '1',
			'parent_id' => '1',
			'level' => '1',
			'component_id' => $adminTable->component_id,
			'access' => $dilerAccess,
			'template_style_id' => $adminTable->template_style_id,
			'params' => (string) $params,
			'language' => '*',
			'client_id' => '0',
		);
		$result = $model->save($data);
		$cloudItemId = $model->getState($model->getName() . '.id');
		$cloudTable = $menuFactory->createTable('Menu', 'Administrator');
		$cloudTable->load($cloudItemId);
		$cloudTable->setLocation($adminTable->id, 'before');
		$cloudTable->store();
		return $result;
	}

	/**
	 * Creates three categories for the cloud view, with pre-set permissions.
	 */
	protected function createCloudCategories()
	{
		$rules = $this->getMediaCategoryRules();
		$access = $this->getDilerUserAccess();
		$teacherAccess = $this->getDilerUserAccess('Diler Teacher');
		$studentAccess = $this->getDilerUserAccess('Diler Student');
		$parentAccess = $this->getDilerUserAccess('Diler Parent');
		$uniqueData = array(
			'title' => array(DText::_('CLOUD_TYPE_PUBLIC'), DText::_('TEACHERS'), DText::_('CLOUD_TYPE_GROUP'), DText::_('CLOUD_TYPE_PRIVATE'),
				DText::_('CLOUD_TYPE_PARENT_INFORMATION'), DText::_('CLOUD_TYPE_FORMS')),
			'alias' => array('public', 'teachers', 'group', 'private', 'parents', 'forms'),
			'path' =>  array('public', 'teachers', 'group', 'private', 'parents', 'forms'),
			'params' => array('{"cloud_type":"2"}', '{"cloud_type":"1"}', '{"cloud_type":"1"}', '{"cloud_type":"3"}', '{"cloud_type":"2"}', '{"cloud_type":"2"}'),
			'rules' => array($rules->public, $rules->teacher, $rules->group, $rules->private, $rules->parent, $rules->public),
			'access' => array($access, $teacherAccess, $access, $access, $access, $access),
		);

		$commonData = array(
			'parent_id' => '1',
			'level' => '1',
			'extension' => 'com_diler.cloud',
			'published' => '1',
			'language' => '*',
		);

		$created = array();
		for ($i = 0; $i < 6; $i++)
		{
			$thisData = array();
			foreach ($uniqueData as $column => $values)
			{
				$thisData[$column] = $values[$i];
			}
			$data = array_merge($thisData, $commonData);
			$created[] = $this->createCategory($data);
		}

		$result = ($created[0] && $created[1] && $created[2] && $created[3] && $created[4] && $created[5]);
		return $result;

	}

	/**
	 * Inserts a row in Joomla tags table for the Cloud tags parent tag. Then sets this id as the cloudParentTag
	 * in the DiLer options.
	 * @return boolean
	 */
	protected function createCloudTagOption()
	{
		$storeOK = false;
		/** @var TagTable $tagTable */
		$tagTable = Factory::getApplication()->bootComponent('com_tags')->getMVCFactory()->createModel('Tag', 'Administrator');

		$tagTable->id = 0;
		$tagTable->title = 'Cloud';
		$tagTable->published = 1;
		$tagTable->language = '*';
		$tagTable->access = $this->getDilerUserAccess();
		$tagTable->setLocation(1, 'last-child');

		// Try to store tag
		if ($tagTable->check())
		{
			// Assign the alias as path (autogenerated tags have always level 1)
			$tagTable->path = $tagTable->alias;
			$storeOK = $tagTable->store();
		}
		if (! $storeOK)
		{
			return false;
		}
		$params = ComponentHelper::getParams('com_diler');
		$params->set('cloudParentTag', $tagTable->id);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__extensions')
				->set('params = ' . $db->quote($params->toString()))
				->where('element = "com_diler"')
				->where('type = "component"');
		return $db->setQuery($query)->execute();
	}

	protected function getMediaCategoryRules()
	{
		// Get group id's for Diler User, Teacher
		$params = ComponentHelper::getParams('com_diler');
		$teacherGroupIds = $params->get('teacher_group_ids');
		if (! (isset($teacherGroupIds[0]) && $teacherGroupIds[0]))
		{
			return '';
		}
		$parentGroupIds = $params->get('parent_group_ids', array());
		$studentGroupIds = $params->get('student_group_ids', array());
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('parent_id')
				->from('#__usergroups')
				->where('id = ' . (int) $teacherGroupIds[0]);
		$dilerGroupId = $db->setQuery($query)->loadResult();
		$allGroups = array($dilerGroupId => 1);
		$teacherOnlyArray = array();
		$teacherStudentOnly = array();
		$teacherParentOnly = array();
		foreach ($teacherGroupIds as $id)
		{
			$teacherOnlyArray[$id] = 1;
			$teacherStudentOnly[$id] = 1;
			$teacherParentOnly[$id] = 1;
		}
		foreach ($studentGroupIds as $studentGroupId)
		{
			$teacherStudentOnly[$studentGroupId] = 1;
		}
		foreach ($parentGroupIds as $parentGroupId)
		{
			$teacherParentOnly[$parentGroupId] = 1;
		}
		$schoolRules = array(
			'core.create' => $teacherOnlyArray,
			'core.delete' => $teacherOnlyArray,
			'core.edit' => $teacherOnlyArray,
			'core.edit.own' => $teacherOnlyArray,
			);

		$teacherRules = array(
			'core.create' => $teacherOnlyArray,
			'core.delete' => $teacherOnlyArray,
			'core.edit' => $teacherOnlyArray,
			'core.edit.own' => $teacherOnlyArray,
			);

		$groupRules = array(
			'core.create' => $teacherOnlyArray,
			'core.delete' => $teacherOnlyArray,
			'core.edit' => $teacherOnlyArray,
			'core.edit.own' => $teacherOnlyArray,
			);

		$parentInformationRules = array(
			'core.create' => $teacherOnlyArray,
			'core.delete' => $teacherOnlyArray,
			'core.edit' => $teacherOnlyArray,
			'core.edit.own' => $teacherOnlyArray,
			);

		$privateRules = array(
			'core.create' => $allGroups,
			'core.delete' => $allGroups,
			'core.edit' => array(),
			'core.edit.own' => $allGroups,
			);

		return (object) array('public' => $schoolRules, 'teacher' => $teacherRules, 'group' => $groupRules,
			'parent' => $parentInformationRules, 'private' => $privateRules);
	}

	protected function createExtracurricularGroups($usergroupParentId)
	{
		// Create Extracurricular Parent Group
		$this->logDataConversion('Creating parent Joomla usergroup for extracurricular activities.');
		$data = array('id' => 0, 'title' => DText::_('EXTRACURRICULARS'), 'parent_id' => $usergroupParentId);
		$this->extracurricularUsergroupParentId = $this->createNewJoomlaUserGroup($data);
		$extracurricularIdArray = array();
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		// Check and fix any duplicate extracurricular names. Duplicate names not allowed for Joomla usergroups or DiLer groups (within the same type).
		$this->v600FixDuplicateExtracurricularNames();
		// Create extracurricular groups from existing extracurriculars. Need to create Joomla usergroup and assign users to it.
		$query->select('*')->from('#__diler_extra_curricular')->where('published = 1');
		$rows = $db->setQuery($query)->loadObjectList();
		if (is_array($rows) && $rows)
		{
			$this->logDataConversion('Creating DiLer and Joomla groups for extracurricular activities.');
			$query->clear()->insert('#__diler_group')->columns('name, description, joomla_group_id, joomla_viewlevel_id, catid, published, created, created_by, modified, modified_by, ordering');
			foreach ($rows as $row)
			{
				// Create Joomla usergroup
				$data = array('id' => 0, 'title' => $row->name, 'parent_id' => $this->extracurricularUsergroupParentId);
				$joomlaUsergroupId = $this->createNewJoomlaUserGroup($data);
				if (! $joomlaUsergroupId)
				{
					$this->errors++;
					$this->logDataConversion('Error! Unable to create extracurricular Joomla usergroup for ' . $row->name . '.');
				}
				$viewlevelData = array('id' => $joomlaUsergroupId, 'title' => $row->name);
				$joomlaViewlevelId = $this->createViewAccessLevel($viewlevelData);
				if (! $joomlaViewlevelId)
				{
					$this->errors++;
					$this->logDataConversion('Error! Unable to create extracurricular Joomla view level for ' . $row->name . '.');
				}
				if ($joomlaUsergroupId && $joomlaViewlevelId)
				{
					$values = array($db->quote($row->name), $db->quote($row->description), $db->quote($joomlaUsergroupId), $db->quote($joomlaViewlevelId),
						$db->quote($row->catid), $db->quote($row->published), $db->quote($row->created), $db->quote($row->created_by), $db->quote($row->modified),
						$db->quote($row->modified_by), $db->quote($row->ordering));
					$query->values(implode(',', $values));
					$hash = base64_encode($row->name . $row->catid . $row->created . $row->created_by . $row->ordering);
					$extracurricularIdArray[$row->id] = $hash;
				}
			}
			$result = $db->setQuery($query)->execute();

			if (! $result)
			{
				$this->errors++;
				$this->logDataConversion('Error! Unable to create new DiLer groups for extracurricular activities. Data conversion for extracurricular activites aborted.');
				return false;
			}

			$this->logDataConversion('Success! ' . count($extracurricularIdArray) . ' extracurricular groups created.');
			// Add users to joomla user groups
			// Get the newly created Diler Group id's in an array (need to associate new Diler Group id with old extracurricular id)
			$query->clear()
					->select('g.*')
					->from('#__diler_group AS g')
					->innerJoin('#__categories AS c ON c.id = g.catid')
					->where('c.params LIKE "%group\_type_:_3%"');
			$groupRows = $db->setQuery($query)->loadObjectList();
			$dilerGroupIdArray = array();
			$dilerGroupToJoomla = array();
			if (is_array($groupRows) && $groupRows)
			{
				foreach ($groupRows as $groupRow)
				{
					$hash = base64_encode($groupRow->name . $groupRow->catid . $groupRow->created . $groupRow->created_by . $groupRow->ordering);
					$dilerGroupIdArray[$hash] = $groupRow->id;
					$dilerGroupToJoomla[$groupRow->id] = $groupRow->joomla_group_id;
				}
			}

			// Add Joomla users to the joomla usergroup.
			$query->clear()->select('GROUP_CONCAT(map.user_id) AS user_id_list, map.extra_curricular_id')
					->from('#__diler_user_extra_curricular_map AS map')
					->innerJoin('#__diler_extra_curricular AS e ON e.id = map.extra_curricular_id AND e.published = 1')
					->group('extra_curricular_id');
			$mapRows = $db->setQuery($query)->loadObjectList();
			if (is_array($mapRows) && $mapRows)
			{
				$groupIdUserIdArray = array();
				foreach ($mapRows as $mapRow)
				{
					if (! isset($extracurricularIdArray[$mapRow->extra_curricular_id]))
					{
						$this->logDataConversion('Error: $extracurricularIdArray[] value not set for $mapRow->extra_curricular_id = ' . $mapRow->extra_curricular_id . '.');
						$this->errors++;
					}
					elseif (! isset($dilerGroupIdArray[$extracurricularIdArray[$mapRow->extra_curricular_id]]))
					{
						$this->logDataConversion('Error: $dilerGroupIdArray[] value not set for $extracurricularIdArray[$mapRow->extra_curricular_id]=' . $extracurricularIdArray[$mapRow->extra_curricular_id] . '.');
						$this->errors++;
					}
					else
					{
						$dilerGroupId = $dilerGroupIdArray[$extracurricularIdArray[$mapRow->extra_curricular_id]];
						$joomlaGroup = $dilerGroupToJoomla[$dilerGroupId];
						$groupIdUserIdArray[$joomlaGroup] = explode(',', $mapRow->user_id_list);
					}
				}
				if ($this->addUsersToUsergroup($groupIdUserIdArray))
				{
					$this->logDataConversion('Success! Users mapped to ' . count($mapRows) . ' extracurricular groups.');
				}
				else
				{
					$this->logDataConversion('Error! Unable to map users to extracurricular groups.');
				}

			}

			// Convert diler_studentrecord_tag_map tag.id for tag_type = 2
			// Currently tag.id = extracurricular id, need to change to group id
			$totalStudentRecordTagCount = $this->convertStudentrecordTagMap($dilerGroupIdArray, $extracurricularIdArray);
		}
		return count($extracurricularIdArray);
	}

	protected function createLGGroups($dilerGroupParentId)
	{
		// Create DiLer group category for LG's
		$access = $this->getDilerUserAccess();
		$data = array (
				'id' => 0,
				'title' => DText::_('CONFIG_LEARNING_GROUPS_LABEL'),
				'parent_id' => 1,
				'level' => '1',
				'extension' => 'com_diler.group',
				'published' => 1,
				'access' => $access,
				'language' => '*',
				'associations' => array (),
				'params' => array('group_type' => '1'),
		);
		$catid = $this->createCategory($data);
		$createdCount = 0;
		if (! $catid)
		{
			$this->logDataConversion('Error! Unable to create Group Category for Learning Groups. Aborting LG data conversion.');
			$this->errors++;
			throw new RuntimeException('Error! Unable to create Group Category for Learning Groups. Aborting LG data conversion.');
		}

		$this->logDataConversion('DiLer group category with id=' . $catid . ' and title="' . DText::_('CONFIG_LEARNING_GROUPS_LABEL') . '" created.');

		// Create DiLer group for each LG (users are alread mapped)
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')->from('#__usergroups')->where('parent_id = ' . (int) $dilerGroupParentId)->order('title');
		$lgUsergroups = $db->setQuery($query)->loadObjectList();
		$user = Factory::getUser();
		$date = Factory::getDate()->toSql();
		if (is_array($lgUsergroups) && $lgUsergroups)
		{
			$query->clear()->insert('#__diler_group')->columns('name, joomla_group_id, joomla_viewlevel_id, catid, published, created, created_by, ordering');
			$ordering = 0;
			foreach ($lgUsergroups as $lgUsergroup)
			{
				$data = array('id' => $lgUsergroup->id, 'title' => $lgUsergroup->title);
				$viewlevelId = $this->createViewAccessLevel($data);
				if (! $viewlevelId)
				{
					$this->logDataConversion('Error! Unable to create view level for Learning Group. Aborting Learning Group data conversion.');
					$this->errors++;
					throw new RuntimeException('Error! Unable to create view level for Learning Group. Aborting Learning Group data conversion.');
				}
				$ordering++;
				$values = array($db->quote($lgUsergroup->title), $db->quote($lgUsergroup->id), $db->quote($viewlevelId), $db->quote($catid), 1, $db->quote($date), $db->quote($user->id), $db->quote($ordering));
				$query->values(implode(',', $values));
			}
			$result = $db->setQuery($query)->execute();
			if (! $result)
			{
				$this->logDataConversion('Error! Unable to create DiLer Groups for Learning Groups. Aborting Learning Group data conversion.');
				$this->errors++;
				throw new RuntimeException('Error! Unable to create DiLer Groups for Learning Groups. Aborting Learning Group data conversion.');
			}

			$createdCount = count($lgUsergroups);
			$this->logDataConversion('Success! ' . $createdCount . ' LG Diler groups and view levels created.');
		}

		// Assign all teachers to all LG's
		if (is_array($lgUsergroups) && $lgUsergroups)
		{
			$teachersAssigned = $this->assignTeachersToLearningGroups($lgUsergroups);
		}
		return $createdCount;
	}

	protected function createSubjectPhaseGroups($parentGroupId)
	{
		// Create Subject-Phase Parent Group
		$joomlaGroupData = array('id' => 0, 'title' => DText::_('SUBJECTS'), 'parent_id' => $parentGroupId);
		$this->subjectUsergroupParentId = $this->createNewJoomlaUserGroup($joomlaGroupData);
		$user = Factory::getUser();
		$date = Factory::getDate()->toSql();
		$joomlaUsergroupsAdded = 0;
		$dilerGroupsAdded = 0;
		$viewlevelsAdded = 0;

		// Create Group Category
		$access = $this->getDilerUserAccess();
		$data = array (
				'id' => 0,
				'title' => DText::_('SUBJECTS'),
				'parent_id' => 1,
				'level' => '1',
				'extension' => 'com_diler.group',
				'published' => 1,
				'access' => $access,
				'language' => '*',
				'associations' => array (),
				'params' => array('group_type' => '2'),
		);
		$catid = $this->createCategory($data);

		// Get a list of users, phases and subjects
		if (! $catid)
		{
			$this->logDataConversion('Error! Unable to create Group Category for Subject / Phase Groups. Aborting Subject / Phase data conversion.');
			$this->errors++;
			throw new RuntimeException('Error! Unable to create Group Category for Subject / Phase Groups. Aborting Subject / Phase data conversion.');
		}
		$this->logDataConversion('Category created for subject phase groups with id=' . $catid . ' and title="' . DText::_('SUBJECTS') . '".');
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('GROUP_CONCAT(m.user_id) AS users, m.phase_id, m.subject_id, p.value AS phase_value, s.name AS subject_name')
			->from('#__diler_user_phase_map AS m')
			->innerJoin('#__diler_phase AS p ON p.id = m.phase_id')
			->innerJoin('#__diler_subject AS s ON s.id = m.subject_id')
			->innerJoin('#__categories AS c on s.catid = c.id')
			->order('c.lft ASC, s.ordering ASC, p.value * 1 ASC, p.value ASC')
			->where('s.published = 1')
			->where('p.published = 1')
			->group('m.phase_id, m.subject_id');
		$mapRows = $db->setQuery($query)->loadObjectList();
		// Get schoolyear id
		$query->clear()->select('id')->from('#__diler_schoolyear')->where('published = 1');
		$schoolyearId = $db->setQuery($query)->loadResult();
		$schoolyearId = $schoolyearId ? $schoolyearId : 1;
		if (is_array($mapRows) && $mapRows)
		{
			$this->logDataConversion('Creating ' . count($mapRows) . ' new DiLer Groups, Joomla groups, and view levels for Subject / Phase combinations.');
			$ordering = 0;
			$usergroupInsertArray = array();
			foreach ($mapRows as $mapRow)
			{
				// Create new joomla usergroup
				$name = DText::sprintf('CONVERSION_SUBJECT_GROUP_NAME', $mapRow->phase_value, $mapRow->subject_name);
				$data = array('id' => 0, 'title' => $name, 'parent_id' => $this->subjectUsergroupParentId);
				try
				{
					$groupId = $this->createNewJoomlaUserGroup($data);
				}
				catch (Exception $ex)
				{
					$this->logDataConversion($ex->getMessage());
					$this->errors++;
					throw new RuntimeException($ex->getMessage());
				}

				$ordering++;
				if (! $groupId)
				{
					$message = 'Error! Unable to create new Joomla usergroup with  name = "' . $name . '".';
					$this->logDataConversion($message);
					$this->errors++;
					throw new RuntimeException($message);
				}
				$joomlaUsergroupsAdded++;
				$viewlevelData = array('id' => $groupId, 'title' => $name);
				try
				{
					$viewlevelId = $this->createViewAccessLevel($viewlevelData);
				}
				catch (Exception $ex)
				{
					$this->logDataConversion($ex->getMessage());
					$this->errors++;
					throw new RuntimeException($ex->getMessage());
				}
				if (! $viewlevelId)
				{
					$message = 'Error! Unable to create new Joomla view level with  name = "' . $name . '".';
					$this->logDataConversion($message);
					$this->errors++;
					throw new \RuntimeException($message);
				}
				$viewlevelsAdded++;
				// Add joomla users to joomla usergroup
				$usergroupInsertArray[$groupId] = explode(',', $mapRow->users);

				// Create new DiLer group
				$query->clear()->insert('#__diler_group')
					->set('name = ' . $db->quote($name))
					->set('joomla_group_id = ' . (int) $groupId)
					->set('catid = ' . (int) $catid)
					->set('published = 1')
					->set('created = ' . $db->quote($date))
					->set('created_by = ' . (int) $user->id)
					->set('ordering = ' . (int) $ordering)
					->set('joomla_viewlevel_id = ' . $viewlevelId);
				try
				{
					$result = $db->setQuery($query)->execute();
				}
				catch (\Exception $ex)
				{
					$this->logDataConversion($ex->getMessage());
					$this->errors++;
					throw new \RuntimeException($ex->getMessage());
				}

				$newGroupId = $db->insertid();

				if ((! $result) || (! $newGroupId))
				{
					$message = 'Unable to create new Diler Group for Subject / Phase with name = "' . $name . '".';
					$this->logDataConversion($message, Log::ERROR, 'Error');
					$this->errors++;
					throw new RuntimeException($message);
				}
				$dilerGroupsAdded++;
				// Insert row into group_subject_map
				$query->clear()->insert('#__diler_group_subject_section_map')
					->set('group_id = ' . $newGroupId)
					->set('subject_id = ' . (int) $mapRow->subject_id)
					->set('phase_id = ' . (int) $mapRow->phase_id)
					->set('section_id = 1');
				$result = $db->setQuery($query)->execute();
			}
			$this->logDataConversion('Success! ' . count($mapRows) . ' DiLer and Joomla groups created.');
			$this->logDataConversion('Adding Subject / Phase users to new Joomla usergroups ...');
			if ($this->addUsersToUsergroup($usergroupInsertArray))
			{
				$this->logDataConversion('Success! ' . count($usergroupInsertArray) . ' usergroups updated.');
			}
			else
			{
				$this->logDataConversion('Error: Unable to add users to Joomla Subject / Phase usergroups!');
				$this->errors++;
			}
		}
		$this->logDataConversion('Subject Phase groups completed. ' . $joomlaUsergroupsAdded . ' Joomla usergroups added. ' . $dilerGroupsAdded . ' DiLer groups added. ' . $viewlevelsAdded . ' Joomla view levels added.');
		return $dilerGroupsAdded;
	}

	/**
	 * Create groups and categories for V600 data conversion. This is only run when #__diler_group table is empty!
	 * This also does other required V6 work. It creates the Cloud menu item, the Cloud category rows, the Cloud tag parent option,
	 * and the hidden bulletin menu and menu items.
	 *
	 * @throws RuntimeException
	 */
	public function createV600Groups()
	{
		// Make sure no rows exist in #__diler_group
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('COUNT(*)')->from('#__diler_group');
		if ($db->setQuery($query)->loadResult())
		{
			throw new \RuntimeException('DiLer Groups already exist. Nothing was updated.');
		}
		// Get DiLer options
		$this->logDataConversion('----------Starting Version 600 data conversion to create DiLer groups.----------');
		$options = ComponentHelper::getParams('com_diler');
		// Use the parent id of the LG group for the parent id for other DiLer user groups
		$dilerGroupParentId = $options->get('learning_group_parent_id');

		/** @var GroupModel $usergroupModel */
		$usergroupModel = Factory::getApplication()->bootComponent('com_users')->getMVCFactory()->createModel('Group', 'Administrator');
		$lgGroup = $usergroupModel->getItem($dilerGroupParentId);

		// Create LG's from existing
		$lgCount = $this->createLGGroups($dilerGroupParentId);

		// Create class group for each subject / phase combination
		$subjectPhaseCount = $this->createSubjectPhaseGroups($lgGroup->parent_id);

		// Create groups for extracurricular activities
		$extracurricularCount = $this->createExtracurricularGroups($lgGroup->parent_id);
		$this->logDataConversion('Rebuilding Joomla usergroups table after inserts ...');
		if ($this->rebuildJoomlaUsergroupTable())
		{
			$this->logDataConversion('Success! Joomla usergroups table rebuilt.');
		}
		else
		{
			$this->logDataConversion('Error. Unable to rebuild Joomla usergroups table.');
			throw new \RuntimeException('Error. Unable to rebuild Joomla usergroups table.');
		}

		if ($this->createV6GroupPermissionsForTeachers())
		{
			$this->logDataConversion('Success! Permissions set for Teachers for Manage DiLer Groups and Manage Own DiLer Groups.');
		}
		else
		{
			$this->warnings++;
			$this->logDataConversion('Warning! Permissions not set for Teachers for Manage DiLer Groups and Manage Own DiLer Groups.');
		}

		if ($this->setSubjectExtracurricularParentDilerOptions())
		{
			$this->logDataConversion('Success! New options set for Subject Group and Extracurricular Group parent id.');
		}
		else
		{
			$this->warnings++;
			$this->logDataConversion('Warning! New options NOT set for Subject Group and Extracurricular Group parent id.');
		}

		if ($this->createCloudMenuItem())
		{
			$this->logDataConversion('Success! New menu item created for cloud view.');
		}
		else
		{
			$this->warnings++;
			$this->logDataConversion('Warning! Unable to create new menu item for cloud view.');
		}
		if ($this->createCloudCategories())
		{
			$this->logDataConversion('Success! New cloud categories created.');
		}
		else
		{
			$this->warnings++;
			$this->logDataConversion('Warning! Unable to create new cloud categories.');
		}

		if ($this->createCloudTagOption())
		{
			$this->logDataConversion('Success! New cloud tag and option created.');
		}
		else
		{
			$this->warnings++;
			$this->logDataConversion('Warning! Unable to create new cloud tag and option.');
		}

//      Done processing. Report any warnings and errors.
		if ($this->warnings)
		{
			$this->logDataConversion($this->warnings . ' warnings were detected during group data conversion.', Log::INFO);
		}
		if ($this->errors)
		{
			$this->logDataConversion($this->errors . ' errors were detected during group data conversion.', Log::ERROR);
		}
		$this->logDataConversion('----------Version 600 data conversion to create DiLer groups is done.----------');
		return $extracurricularCount + $lgCount + $subjectPhaseCount;
	}

	/**
	 * Sets Manage DiLer Groups and Manage Own DiLer Groups to Allowed for teachers.
	 * @return bool true on success
	 */
	protected function createV6GroupPermissionsForTeachers()
	{
		$asset  = Table::getInstance('asset');
		$result = $asset->loadByName('com_diler');
		if ($result === false) return false;
		$temp = json_decode($asset->rules, true);
		$actions = array('group.manage', 'group.manage.own');
		$teacherGroups = ComponentHelper::getParams('com_diler')->get('teacher_group_ids');
		foreach ($actions as $action)
		{
			foreach ($teacherGroups as $group)
			{
				// Check if we already have an action entry.
				if (!isset($temp[$action]))
				{
					$temp[$action] = array();
				}
				// Check if we already have a rule entry.
				if (!isset($temp[$action][$group]))
				{
					$temp[$action][$group] = array();
				}
				// Set the new permission.
				$temp[$action][$group] = 1;
			}
		}
		$asset->rules = json_encode($temp, JSON_FORCE_OBJECT);
		if (!$asset->check() || !$asset->store())
		{
			$app->enqueueMessage(Text::_('JLIB_UNKNOWN'), 'error');
			return false;
		}
		return true;
	}

	protected function v600FixDuplicateExtracurricularNames()
	{
		$this->logDataConversion('Checking for duplicate names of extracurricular activities.');
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
				->select('name, GROUP_CONCAT(id) as id_list')
				->from('#__diler_extra_curricular')
				->where('published = 1')
				->group('name')
				->having('count(id) > 1');
		$duplicates = $db->setQuery($query)->loadObjectList();
		if ((! is_array($duplicates)) || ! $duplicates)
		{
			$this->logDataConversion('No duplicate extracurricular names found.');
			return;
		}
		$queryValueArray = array();
		foreach ($duplicates as $row)
		{
			$idArray = explode(',', $row->id_list);
			$count = count($idArray);
			for ($i = 0; $i < $count; $i++)
			{
				$seq = $i + 1;
				$queryValueArray[] = (object) array('id' => $idArray[$i], 'name' => $row->name . '-' . $seq);
			}
		}
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		foreach ($queryValueArray as $queryValue)
		{
			$query->clear()
				->update('#__diler_extra_curricular')
				->set('name = ' . $db->quote($queryValue->name))
				->where('id = ' . $queryValue->id);
			if ($db->setQuery($query)->execute())
			{
				$this->logDataConversion('Warning: Name changed to "' . $queryValue->name . '" for extracurricular with id = ' . $queryValue->id . '.');
				$this->warnings++;
			}
			else
			{
				$this->logDataConversion('Error: Unable to update name to "' . $queryValue->name . '" for extracurricular with id = ' . $queryValue->id . '.');
				$this->errors++;
			}
		}

	}

	/**
	 * Gets the competence id from the compchar ID
	 *
	 * @return int competence ID for this compchar
	 */
	public function getCompetenceId($compcharId)
	{
		if (! isset($this->competenceArray[$compcharId]))
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true)
				->select('competence_id')
				->from('#__diler_compchar')
				->where('id = ' . (int) $compcharId);
			$result = $db->setQuery($query)->loadResult();
			$this->competenceArray[$compcharId] = $result;
		}
		return $this->competenceArray[$compcharId];
	}

	public function getDilerTables()
	{
		return $this->allDilerTables;
	}

	/**
	 * Tries to get the id of the Diler User view level. Returns the id if found, otherwise returns 1 (for public)
	 *
	 * @return int Id of Diler User viewlevel, if found. Otherwise, 1 for Public.
	 */
	public function getDilerUserAccess($title = 'Diler User')
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')->from('#__viewlevels')->where('title = ' . $db->quote($title));
		$id = $db->setQuery($query)->loadResult();
		return $id ? $id : 1;
	}

	protected function deleteTables($tableArray)
	{
		$db = Factory::getDbo();
		try
		{
			foreach ($tableArray as $table)
			{
				$query = $db->getQuery(true)->delete($db->quoteName($table));
				$db->setQuery($query)->execute();
			}
		}
		catch (\Exception $e)
		{
			$this->setError($e);
			return false;
		}
		return true;
	}

	protected function deleteFilesAndFolder($path)
	{
		if (is_dir($path) === true)
		{
			try
			{
				\JLoader::register('Joomla\CMS\Filesystem\Folder', JPATH_ROOT . '/libraries/joomla/filesystem/folder.php');
				Folder::delete($path);
			}
			catch (\Exception $e)
			{
				$this->setError($e);
				return false;
			}
			return true;
		}

		else
		{
			return true;
		}
	}

	/**
	 * Deletes all DiLer categories rows.
	 *
	 * @return bool  true on success.
	 * @throws \RuntimeException
	 */
	protected function deleteDilerCategories()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__categories')
			->where('extension LIKE "com_diler%"');
		return $db->setQuery($query)->execute();
	}

	/**
	 * Deletes all rows from all Diler tables (from $this->allDilerTables)
	 *
	 * @return boolean  true on success, false on failure.
	 */
	public function deleteDilerDB()
	{
		$result = $this->deleteTables($this->allDilerTables);
		$this->deleteDilerCategories();
		$this->deleteDilerMedia();
		$this->logDataAction(DText::_('BUTTON_CLEAR_DILER_DATABASE_COMPRASTER'));
		return $result;
	}

	/**
	 * Deletes all media folders except profilepictures. (These are deleted when users deleted.)
	 * @return boolean true
	 */
	protected function deleteDilerMedia()
	{
		$result = true;
		$mediaFolderArray = ['media', 'studentmedia', 'cloud-groups', 'cloud-institution', 'cloud-private'];
		$basePath = \DilerHelperUser::getRootFileFolder();
		foreach ($mediaFolderArray as $folder)
		{
		$result = $result && Folder::delete($basePath . '/' . $folder);
		}
		return $result;
	}

	/**
	 * Deletes rows from student reports history for the specified period ids.
	 *
	 * @param array  $periodArray  array of period ids
	 */
	public function deleteStudentReportHistory($periodArray)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_report_field_history')
			->where('period_id IN(' . implode(',', $periodArray) . ')');
		$result = $db->setQuery($query)->execute();

		$query = $db->getQuery(true)
			->delete('#__diler_report_period')
			->where('id IN(' . implode(',', $periodArray) . ')');
		$result2 = $db->setQuery($query)->execute();
		$this->logDataAction(DText::sprintf('BUTTON_CLEAR_DILER_STUDENTREPORTS', DText::_('STUDENT')));
		return $result && $result2;
	}

	public function deleteCalendarEvents()
	{
		$result = $this->deleteTables($this->calendarTables);
		$this->logDataAction(DText::_('BUTTON_CLEAR_DILER_CALENDAR_EVENTS'));
		return $result;
	}

	public function getCalendarTables()
	{
		return $this->calendarTables;
	}

	public function getTable($type = 'DiLer', $prefix = 'Administrator', $config = array())
	{
		return parent::getTable($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.diler', 'diler', array('control' => 'jform','load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	protected function getSuperusergroupIds()
	{
		if (! $this->superUserGroupids)
		{
			$this->superUserGroupids = ComponentHelper::getParams('com_diler')->get('admin_group_ids');
		}
		return $this->superUserGroupids;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.diler.data', array());
		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

	public function logDataAction($name, $extraInfo = '')
	{
		$table = (object) array('name' => $name, 'extraInfo' => $extraInfo);
		PluginHelper::importPlugin($this->events_map['save']);
		Factory::getApplication()->triggerEvent('onContentAfterDelete', array('com_diler.dataaction', $table, false));
	}

	public function logDataConversion($message, $status = Log::INFO, $type = 'Update')
	{
		$options ['format'] = '{DATE}\t{TIME}\t{LEVEL}\t{CODE}\t{MESSAGE}';
		$options ['text_file'] = 'diler-log.php';
		Log::addLogger($options, Log::INFO, array (
				'Update',
				'diler',
				'jerror'
		));
		Log::add($message, $status, $type);
	}

	/**
	 * Unpublishes any online activities that don't have tasks. These are not valid until tasks are added.
	 * For v5, we do not allow an online activity to be published unless it has tasks created.
	 */
	public function unpublishActivitiesNoTasks()
	{
		$result = 0;
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('DISTINCT a.id')
			->from('#__diler_activity AS a')
			->leftJoin('#__diler_activity_task_map AS m ON m.activity_id = a.id')
			->leftJoin('#__diler_activity_task AS t ON m.task_id = t.id AND t.published = 1')
			->where('a.published = 1')
			->where('a.offline = 0')
			->where('t.id IS NULL');
		$idArray = $db->setQuery($query)->loadColumn();

		if ($idArray)
		{
			$query = $db->getQuery(true)
				->update('#__diler_activity')
				->set('published = 0')
				->where('id IN (' . implode(',', $idArray) . ')');
			$db->setQuery($query)->execute();
			$result = count($idArray);
		}
		return $result;
	}

}
