<?php
/**
 * @copyright   Copyright (C) 2013 - 2022 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use Joomla\CMS\Factory;
use DiLer\Lang\DText;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;

defined('_JEXEC') or die();

class ReportperiodModel extends AdminModel
{
	public $typeAlias = 'com_diler.reportperiods';

	protected function canDelete($record)
	{
		if (! empty($record->id)) {
			if ($record->published != - 2)
				return;

			return parent::canDelete($record);
		}
	}

	protected function canEditState($record)
	{
		$user = Factory::getApplication()->getIdentity();

		if (! empty($record->catid))
			return $user->authorise('core.edit.state', 'com_diler.category.' . (int) $record->catid);

		return parent::canEditState($record);
	}

	public function delete(&$pks)
	{
		$pks = $this->checkChangeStatus($pks);

		if (is_array($pks) && $pks)
			return parent::delete($pks);

		return false;
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.reportperiod', 'reportperiod', array(
			'control' => 'jform',
			'load_data' => $loadData
		));

		if (empty($form))
			return false;

		return $form;
	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_diler.edit.reportperiod.data', array());

		if (empty($data))
			$data = $this->getItem();

		$this->preprocessData('com_diler.reportperiod', $data);

		return $data;
	}

	protected function prepareTable($table)
	{
		$table->name = htmlspecialchars_decode($table->name, ENT_QUOTES);
	}

	public function publish(&$pks, $value = 1)
	{
		if ($value == -2)
			$pks = $this->checkChangeStatus($pks);

        if (is_array($pks) && $pks)
			return parent::publish($pks, $value);
	}

	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);

		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('h.period_id')
			->from('#__diler_report_field_history AS h')
			->innerJoin('#__diler_report_field_definition AS f ON f.id = h.field_id AND f.type = 1')
			->where('h.period_id IN(' . implode(',', $pks) . ')')
			->where('h.field_value > ""')
			->group('h.period_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
            Factory::getApplication()->enqueueMessage(DText::plural('N_REPORTPERIODS_CANNOT_CHANGE_STATUS', count($badPks)),'WARNING');
			$pks = array_diff($pks, $badPks);
		}
		return $pks;
	}

	public function getPeriodReportFields($periodId = null)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->from('#__diler_report_field_definition AS f')
			->select('f.*')
			->where('f.type = 1')
			->where('f.published = 1')
			->order('f.ordering ASC');
		if ($periodId)
		{
			$query->leftJoin('#__diler_report_field_history AS fh ON f.id = fh.field_id AND fh.period_id = ' . (int) $periodId);
			$query->select('CASE WHEN ISNULL(fh.field_id) THEN "" ELSE fh.field_value END AS value');
		}
		else
			$query->select('"" AS value');

		$reportFields = $db->setQuery($query)->loadObjectList();

		foreach ($reportFields as $reportField)
		{
			$reportField->value = htmlspecialchars($reportField->value, ENT_QUOTES);
		}
		return $reportFields;
	}

	public function save($data)
	{
		$result = parent::save($data);
		if ($result)
		{
			$id =  isset($id) ? $id : (int) $this->getState($this->getName().'.id');

			$app = Factory::getApplication();
			$fieldArray = $app->input->get('reportFields', array(), 'array');
			$result = $this->saveReportField($id, $fieldArray);
		}
		return $result;
	}

	protected function saveReportField($period, $fieldArray)
	{
		$db = $this->getDbo();
		$fieldIds = array_keys($fieldArray);

		$query = $db->getQuery(true)
			->delete('#__diler_report_field_history')
			->where('period_id = ' . (int) $period)
			->where('field_id IN(' . implode(',', $fieldIds) . ')');
		$db->setQuery($query)->execute();

		$query = $db->getQuery(true)
			->insert('#__diler_report_field_history')
			->columns('field_id, period_id, student_id, subject_id, field_value, created, created_by, modified, modified_by');
		$userId = Factory::getApplication()->getIdentity()->id;
		$date = Factory::getDate()->toSql();

		foreach ($fieldArray as $id => $value)
		{
			if ($value != '')
				$query->values($id . ',' . $period . ',' . '0,0,' . $db->quote($value) . ',' . $db->quote($date) . ',' . $userId . ',' . $db->quote($date) . ',' . $userId);
		}
		$result = true;
		if ((string) $query->values)
			$result = $db->setQuery($query)->execute();

		return $result;
	}
}
