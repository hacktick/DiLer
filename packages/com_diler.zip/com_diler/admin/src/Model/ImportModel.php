<?php
/**
 * @package     Diler.Administrator
 * @subpackage  com_diler
 *
 * @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
defined('_JEXEC') or die;
require JPATH_ADMINISTRATOR . '/components/com_diler/vendor/autoload.php';

use Audivisa\Component\DiLer\Administrator\Helper\Diglu;
use Audivisa\Component\DiLer\Administrator\Helper\LogToFile;
use DiLer\DPath;
use DiLer\ImportLog\ImportLogCollectionFromFile;
use DiLer\Lang\DText;
use DiLer\Layouts\FileViewModal;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Log\Log;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Language\Text;


/**
 * Diler Code model.
 *
 * @package     Diler.Administrator
 * @subpackage  com_diler
 * @since       1.6
 */
class ImportModel extends BaseDatabaseModel
{
	/**
	 * @var        string    The prefix to use with controller messages.
	 * @since   1.6
	 */
	protected $text_prefix = 'COM_DILERREG';

	/**
	 * Assoc array to hold group id's for parent, student, teacher
	 * @var array: 'parent' => parent id array, 'student' => student id array, 'teacher' => teacher group id array
	 */

	public $logFile = '';

	public $rejectsFile = '';
	private $rejectsFilePhp = '';

	public $requiredRegionColumns = [
		'country_code' => 'country_iso2',
		'zipcode' => 'postal_code',
		'city' => 'city',
		'state_code' => 'state_iso',
		'community' => 'community',
	];

	public $optionalRegionColumns = [
		'community_code' => 'community_code',
		'province' => 'province',
		'province_code' => 'province_code',
		'latitude' => 'latitude',
		'longitude' => 'longitude',
	];

	public $ignoreRegionColumns = ['state', 'region_teachers'];

	public $specialRegionColumns = ['longitude' => 'checkRegionLocation', 'latitude' => 'checkRegionLocation'];

	/**
	 * Array of required import columns that must be present in all import files. Note that the order is not important.
	 * @var array
	 */
	public $requiredSchoolColumns = [
		'school id' => 'school_id',
		'school name' => 'name',
		'address' => 'address',
		'postal code' => 'postal_code',
		'city' => 'city',
		'state' => 'state_iso',
		'email' => 'email',
		];

	public $optionalSchoolColumns = [
		'phone' => 'phone',
		'base school' => 'base_school',
		'contact email' => 'contact_email',
		'contact phone' => 'contact_phone',
		'contact postal code' => 'contact_postal_code',
		'contact state' => 'contact_state_iso',
		'contact city' => 'contact_city',
		'contact address' => 'contact_address',
		'contact department' => 'contact_department',
		'contact name' => 'contact_name',
		'region teachers email' => '',
		];

	public $ignoreSchoolColumns = ['country','contact country','ministry','funding', 'school funding', 'type', 'school type', 'region teachers', 'region', 'region teachers email'];

	/**
	 * Array of optional columns that require special function to validate.
	 * @var array: {import column heading} => {validate function name}
	 */
	public $specialSchoolColumns = ['contact email' => 'checkContactEmail', 'contact state' => 'checkContactState', 'base school' => 'checkBaseSchool'];

	/**
	 * File lines read from Excel/CSV file. Updated to show string value of dates.
	 * @var array
	 */
	public $fileLinesArray = [];

	protected function checkBaseSchool($rawData, $result, $columnName)
	{
		$dataName = $this->optionalSchoolColumns[$columnName];
		$result->value[$dataName] = $rawData ? 1 : 0;
	}

	protected function checkContactEmail($rawData, $result, $columnName)
	{
		$this->checkEmail($rawData, $result, $columnName, $this->optionalSchoolColumns[$columnName], true);
	}

	protected function checkContactState($rawData, $result, $columnName)
	{
		$this->checkState($rawData, $result, $columnName, $this->optionalSchoolColumns[$columnName], 'contact_country_iso2', true);
	}

	protected function checkRegionFileRows()
	{
		$errorLog = $successLog = $warningLog = $warningRows = $validData = [];
		$this->fileLinesArray[0] = $this->toLowerCase($this->fileLinesArray[0]);
		$rowCheck = $this->checkRegionFileHeader($this->fileLinesArray[0]);
		if ($rowCheck->error)
		{
			return (object) ['error' => $rowCheck->error, 'successRows' => $successLog, 'warning' => $warningLog, 'warningRows' => $warningRows, 'validData' => $validData];
		}
		$start = 1;
		$columnCount = count($rowCheck->columns);
		$count = count($this->fileLinesArray);
		for ($i = $start; $i < $count; $i++)
		{
			$rowCheck = $this->checkRegionRow($i, $columnCount);
			// Status: 1=success, 0=error, -1=warning
			if ($rowCheck->status === 0)
			{
				$errorLog[$i] = $rowCheck->error;
				if ($rowCheck->warning) $warningLog[$i] = $rowCheck->warning;
			}
			elseif ($rowCheck->status === 1)
			{
				$successLog[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
			elseif ($rowCheck->status === -1)
			{
				$warningLog[$i] = $rowCheck->warning;
				$warningRows[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
		}
		$result = (object) ['error' => $errorLog, 'successRows' => $successLog, 'warning' => $warningLog, 'warningRows' => $warningRows, 'validData' => $validData];
		return $result;
	}

	protected function checkRegionFileHeader($columnArray)
	{
		$result = (object) ['error' => [], 'warning' => [], 'value' => [], 'columns' => $columnArray];
		$missingColumns = [];
		$requiredRegionHeaders = array_keys($this->requiredRegionColumns);
		foreach ($requiredRegionHeaders as $column)
		{
			if (! in_array($column, $columnArray)) $missingColumns[] = $column;
		}
		$unmatchedColumns = [];
		$this->allRegionColumns = array_merge($requiredRegionHeaders, array_keys($this->optionalRegionColumns));
		foreach ($columnArray as $i => $fileColumn)
		{
			if (! in_array($fileColumn, $this->allRegionColumns) && ! in_array($fileColumn, $this->ignoreRegionColumns)) $unmatchedColumns[] = $fileColumn;
			if (in_array($fileColumn, $this->ignoreRegionColumns)) unset($result->columns[$i]);
		}
		$errors = [];
		if ($missingColumns) $errors[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_MISSING_COLUMNS', implode(', ', $missingColumns));
		if ($unmatchedColumns) $errors[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_UNKNOWN_COLUMNS', implode(', ', $unmatchedColumns));
		if ($errors)
		{
			$errors[] = Text::_('COM_DILERREG_IMPORT_ERROR_HEADER');
			$result->error[0] = array_reverse($errors);
		}
		else
		{
			$this->regionHeaderColumns = $columnArray;
			$this->optionalColumnArray = array_diff($this->regionHeaderColumns, $this->requiredRegionColumns);
		}
		return $result;
	}

	protected function checkRegionRequired($dataArray, $result, $columnName, $columnLanguageTag)
	{
		$dataName = $this->requiredRegionColumns[$columnName];
		if (! $dataArray[$columnName])
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_REQUIRED_FIELD', Text::_($columnLanguageTag));
			$result->value[$columnName] = false;
		}
		else
		{
			$result->value[$dataName] = str_replace('"', '', $dataArray[$columnName]);
		}
	}


	protected function checkRegionRow($i, $columnCount)
	{
		$columnArray = $this->fileLinesArray[$i];
		$result = (object) ['error' => [], 'warning' => [], 'value' => []];
		$regionDataArray = $this->createRegionDataArray($columnArray);
		if (count($regionDataArray) !== $columnCount)
		{
			$msg = Text::sprintf('COM_DILERREG_IMPORT_ERROR_BAD_COLUMN_COUNT', $i+1, $columnCount, count($columnArray));
			return (object) ['status' => 0, 'error' => [$msg]];
		}
		$this->checkRegionCity($regionDataArray, $result, 'city');
		$this->checkRegionRequired($regionDataArray, $result, 'zipcode', 'LISTHEADING_POSTAL_CODE');
		$this->checkRegionRequired($regionDataArray, $result, 'community', 'COM_DILER_COMMUNITY_LABEL');
		$this->checkRegionRequired($regionDataArray, $result, 'city', 'COM_DILER_COMMUNITY_LABEL');
		$this->checkRegionState($result, $regionDataArray);

		// Process optional columns, if any
		$this->checkregionOptionalColumns($regionDataArray, $result, $i);
		$result->status = 1;
		if ($result->error)
		{
			$result->status = 0;
		} elseif ($result->warning)
		{
			$result->status = -1;
		}
		return $result;
	}

	protected function checkRegionLocation($rawValue, $result, $columnName)
	{
		$max = ($columnName === 'latitude') ? 90 : 180;
		$min = - $max;
		$filteredValue = ($rawValue > $max || $rawValue < $min) ? 0 : $rawValue;
		$result->value[$columnName] = $filteredValue;
	}

	protected function checkRegionOptionalColumns($dataArray, $result, $i)
	{
		foreach ($this->optionalRegionColumns as $columnName => $dataName)
		{
			if (in_array($columnName, $this->ignoreRegionColumns)) continue;
			if (key_exists($columnName, $this->specialRegionColumns) && in_array($columnName, $this->fileLinesArray[0]))
			{
				$functionName = $this->specialRegionColumns[$columnName];
				$this->$functionName($dataArray[$columnName], $result, $columnName);
				}
			elseif (in_array($columnName, $this->fileLinesArray[0]))
			{
				$this->checkTextField($dataArray, $columnName, $result, $dataName);
			}
		}
	}

	/**
	 * Check that this zip code doesn't exist in the db table or the import file
	 *
	 * @param array $rawValue
	 * @param object $result
	 * @param string $columnName
	 */
	protected function checkRegionCity($rawValue, $result, $columnName)
	{
		$id = '';
		$count = 0;
		$dataName = $this->requiredRegionColumns[$columnName];
		$isPostalCodeFiveOrLessDigits = strlen($rawValue['zipcode']) == 5 ;
		if (!$isPostalCodeFiveOrLessDigits)
		{
			$result->error[] = DText::sprintf('IMPORT_INVALID_POSTAL_CODE', $rawValue['zipcode']);
			$result->value[$dataName] = false;
		}
		if ($rawValue['city'])
		{
			$id = $this->getPostalCodeAndCity($rawValue);
			$count = $this->zipcodeCount[$rawValue['zipcode']];
		}
		if (! $id && $count === 1)
			$result->value[$dataName] = (string) $rawValue['city'];
		if ($id)
            $result->value[$dataName] = (string) $rawValue['city'];
		if ($count > 1)
		{
			$result->error[] = DText::sprintf('IMPORT_DUPLICATE_VALUE', $count, $rawValue['city'], $rawValue['zipcode']);
			$result->value[$dataName] = false;
		}
		return $result;
	}

    /**
     *
     * @param object $result
     * @param $regionDataArray
     */
	protected function checkRegionState($result, $regionDataArray)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('s.*')
				->from('#__diler_state AS s')
				->where('s.country_iso2 = ' . $db->quote($regionDataArray['country_code']))
				->where('s.state_iso = ' . $db->quote($regionDataArray['state_code']));
		$row = $db->setQuery($query)->loadObject();

		if (is_object($row) && $row->id)
		{
			$result->value['state_iso'] = $row->state_iso;
			$result->value['country_iso2'] = $row->country_iso2;
		}
		else
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('STATE'), $regionDataArray['country_code'] . '-' . $regionDataArray['state_code']);
			$result->value['state_code'] = false;
		}

	}

	protected function checkSchoolFileRows()
	{
		$count = count($this->fileLinesArray);
		$start = 1;
		$errorLog = [];
		$successLog = [];
		$warningLog = [];
		$warningRows = [];
		$validData = [];
		$this->fileLinesArray[0] = $this->toLowerCase($this->fileLinesArray[0]);
		$rowCheck = $this->checkSchoolFileHeader($this->fileLinesArray[0]);
		if ($rowCheck->error)
		{
			return (object) ['error' => $rowCheck->error, 'successRows' => $successLog, 'warning' => $warningLog, 'warningRows' => $warningRows, 'validData' => $validData];
		}

		$columnCount = count($rowCheck->columns);
		for ($i = $start; $i < $count; $i++)
		{
			$rowCheck = $this->checkSchoolRow($i, $columnCount);
			// Status: 1=success, 0=error, -1=warning
			if ($rowCheck->status === 0)
			{
				$errorLog[$i] = $rowCheck->error;
				if ($rowCheck->warning) $warningLog[$i] = $rowCheck->warning;
			}
			elseif ($rowCheck->status === 1)
			{
				$successLog[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
			elseif ($rowCheck->status === -1)
			{
				$warningLog[$i] = $rowCheck->warning;
				$warningRows[$i] = $this->fileLinesArray[$i];
				$validData[$i] = $rowCheck->value;
			}
		}
		$result = (object) ['error' => $errorLog, 'successRows' => $successLog, 'warning' => $warningLog, 'warningRows' => $warningRows, 'validData' => $validData];
		return $result;
	}

	protected function checkSchoolFileHeader($columnArray)
	{
		$result = (object) ['error' => [], 'warning' => [], 'value' => [], 'columns' => $columnArray];
		$missingColumns = [];
		$requiredSchoolHeaders = array_keys($this->requiredSchoolColumns);
		foreach ($requiredSchoolHeaders as $column)
		{
			if (! in_array($column, $columnArray)) $missingColumns[] = $column;
		}
		$unmatchedColumns = [];
		$this->allSchoolColumns = array_merge($requiredSchoolHeaders, array_keys($this->optionalSchoolColumns));
		foreach ($columnArray as $i => $fileColumn)
		{
			if (! in_array($fileColumn, $this->allSchoolColumns) && ! in_array($fileColumn, $this->ignoreSchoolColumns)) $unmatchedColumns[] = $fileColumn;
			if (in_array($fileColumn, $this->ignoreSchoolColumns)) unset($result->columns[$i]);
		}
		$errors = [];
		if ($missingColumns) $errors[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_MISSING_COLUMNS', implode(', ', $missingColumns));
		if ($unmatchedColumns) $errors[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_UNKNOWN_COLUMNS', implode(', ', $unmatchedColumns));
		if ($errors)
		{
			$errors[] = Text::_('COM_DILERREG_IMPORT_ERROR_HEADER');
			$result->error[0] = array_reverse($errors);
		}
		else
		{
			$this->schoolHeaderColumns = $columnArray;
			$this->optionalColumnArray = array_diff($this->schoolHeaderColumns, $this->requiredSchoolColumns);
		}
		return $result;
	}

	protected function checkEmail($rawData, $result, $columnName, $dataName = false, $warnOnly = false)
	{
		$dataName = $dataName ? $dataName : $this->requiredSchoolColumns[$columnName];
		$regex1 = '/.+\@.+\..+/'; // basic email form
		$regex2 = '/[\',\s,\"]/'; // no spaces or quotes (note that we don't want a match)
		$match1 = preg_match($regex1, $rawData);
		$match2 = preg_match($regex2, $rawData);
		$valid = $match1 && ! $match2;
		if ($valid || ($warnOnly && ! $rawData))
		{
			$result->value[$dataName] = $rawData;
		}
		elseif (! $valid && ! $warnOnly)
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_FIELD', $columnName, $rawData);
			$result->value[$dataName] = false;
	}
		else
		{
			$result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_INVALID_FIELD', $columnName, $rawData);
			$result->value[$dataName] = '';
		}
	}

	protected function checkSchoolPostalCode($schoolDataArray, $result)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('COUNT(id)')
				->from('#__diler_region')
				->where('postal_code = ' . $db->quote($schoolDataArray['postal code']))
				->where('published = 1');
		$count = $db->setQuery($query)->loadResult();
		if ($count)
		{
			$result->value['postal_code'] = $schoolDataArray['postal code'];
		}
		else
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('CONFIG_SCHOOLADDRESS_ZIPCODE_LABEL'), $schoolDataArray['postal code']);
			$result->value['postal_code'] = false;
		}
	}

	protected function checkSchoolRow($i, $columnCount)
	{
		$columnArray = $this->fileLinesArray[$i];
		$result = (object) ['error' => [], 'warning' => [], 'value' => []];
		$schoolDataArray = $this->createSchoolDataArray($columnArray);
		if (count($schoolDataArray) !== $columnCount)
		{
			$msg = Text::sprintf('COM_DILERREG_IMPORT_ERROR_BAD_COLUMN_COUNT', $i+1, $columnCount, count($columnArray));
			return (object) ['status' => 0, 'error' => [$msg]];
		}

		$this->checkSchoolId($schoolDataArray['school id'], $result, 'school id');
		$this->checkRequired($schoolDataArray, $result, 'school name', 'COM_DILER_CONFIG_SCHOOLOPERATOR_NAME_LABEL');
		$this->checkRequired($schoolDataArray, $result, 'address', 'COM_DILER_CONFIG_SCHOOLOPERATOR_ADDRESS_LABEL');
		$digluHelper = new Diglu();
		if ($digluHelper->isEnabled())
		{
			$this->checkSchoolPostalCode($schoolDataArray, $result);
		}
		else
		{
			$this->checkRequired($schoolDataArray, $result, 'postal code', 'COM_DILER_CONFIG_SCHOOLADDRESS_ZIPCODE_LABEL');
		}

		$this->checkRequired($schoolDataArray, $result, 'city', 'COM_DILER_CONFIG_SCHOOLOPERATOR_ADDRESS_CITY_LABEL');
		$stateDataName = $this->requiredSchoolColumns['state'];
		$this->checkState($schoolDataArray['state'], $result, 'state', $stateDataName, 'country_iso2');
		$this->checkEmail($schoolDataArray['email'], $result, 'email');

		// Process optional columns, if any
		$this->checkschoolOptionalColumns($schoolDataArray, $result, $i);


		$result->status = 1;
		if ($result->error)
		{
			$result->status = 0;
		} elseif ($result->warning)
		{
			$result->status = -1;
		}
		return $result;
	}

	protected function checkSchoolOptionalColumns($schoolDataArray, $result, $i)
	{
		foreach ($this->optionalSchoolColumns as $columnName => $dataName)
		{
			if (in_array($columnName, $this->ignoreSchoolColumns)) continue;
			if (key_exists($columnName, $this->specialSchoolColumns) && in_array($columnName, $this->fileLinesArray[0]))
			{
				$functionName = $this->specialSchoolColumns[$columnName];
				$this->$functionName($schoolDataArray[$columnName], $result, $columnName);
				}
			elseif (in_array($columnName, $this->fileLinesArray[0]))
			{
				$this->checkTextField($schoolDataArray, $columnName, $result, $dataName);
			}
		}
	}

	/**
	 * Checks a text field.
	 * @param array $schoolDataArray
	 * @param string $columnName
	 * @param array $result
	 */
	protected function checkTextField($schoolDataArray, $columnName, $result, $dataName = false)
	{
		$dataName = ($dataName) ? $dataName : $this->requiredSchoolColumns[$columnName];
		$result->value[$dataName] = ($schoolDataArray[$columnName]) ? $schoolDataArray[$columnName] : '';
	}

	/**
	 *
	 * @param string $rawValue
	 * @param array $result
	 * @param string $stateColumnName
	 * @param string $stateDataName
	 * @param string $countryDataName
	 * @param bool $warnOnly : if true, issue warning instead of error.
	 */
	protected function checkState($rawValue, $result, $stateColumnName, $stateDataName, $countryDataName, $warnOnly = false)
	{
		$row = null;
		if (strlen($rawValue) === 5)
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true);
			$query->select('s.*')
					->from('#__diler_state AS s')
					->where('s.country_iso2 = ' . $db->quote(substr($rawValue, 0, 2)))
					->where('s.state_iso = ' . $db->quote(substr($rawValue, -2)));
			$row = $db->setQuery($query)->loadObject();
		}
		if (is_object($row) && $row->id)
		{
			$result->value[$stateDataName] = $row->state_iso;
			$result->value[$countryDataName] = $row->country_iso2;
		}
		elseif (! $warnOnly)
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', DText::_('STATE'), $rawValue);
			$result->value[$stateDataName] = false;
		}
		else
		{
			if ($rawValue) $result->warning[] = Text::sprintf('COM_DILERREG_IMPORT_INVALID_LOOKUP', $stateColumnName, $rawValue);
			$result->value[$stateDataName] = '';
			$result->value[$countryDataName] = '';
		}
	}

	protected function checkRequired($schoolDataArray, $result, $columnName, $columnLanguageTag)
	{
		$dataName = $this->requiredSchoolColumns[$columnName];
		if (! $schoolDataArray[$columnName])
		{
			$result->error[] = Text::sprintf('COM_DILERREG_IMPORT_ERROR_REQUIRED_FIELD', Text::_($columnLanguageTag));
			$result->value[$columnName] = false;
		}
		else
		{
			$result->value[$dataName] = str_replace('"', '', $schoolDataArray[$columnName]);
		}
	}

	// Check that this id is not in the table or in the import file
    protected function checkSchoolId($rawValue, $result, $columnName)
	{
		$id = '';
		$count = 0;
		$dataName = $this->requiredSchoolColumns[$columnName];
		if ($rawValue)
		{
			$options = ['table' => '#__diler_school', 'searchColumn' => 'school_id', 'searchValue' => $rawValue, 'importColumn' => 'id'];
			$id = $this->getTableId($options);
			$count = $this->schoolIdCount[$rawValue];
		}
		if (! $id && $count === 1)
		{
			$result->value[$dataName] = $rawValue;
		}
		if ($id)
            $result->value[$dataName] = $rawValue;

		if ($count > 1)
		{
			$result->error[] = DText::sprintf('IMPORT_DUPLICATE_VALUE', DText::_('SCHOOL_ID_LABEL'), $count, $rawValue);
			$result->value[$dataName] = false;
		}
		return $result;
	}

	protected function createSchoolDataArray($columnArray)
	{
		$result = [];
		foreach ($this->schoolHeaderColumns as $i => $colName)
		{
			if (in_array($colName, $this->ignoreSchoolColumns)) continue;
			$result[$colName] = $columnArray[$i];
		}
		return $result;
	}

	protected function getFirstValidSheet($spreadsheet)
	{
		$sheetCount = $spreadsheet->getSheetCount();
		for ($i = 0; $i < $sheetCount; $i++)
		{
			$testSheet = $spreadsheet->getSheet($i);
			$range = $testSheet->calculateWorksheetDataDimension();
			$fileArray = $testSheet->rangeToArray($range);
			$testResult = $this->checkSchoolFileHeader($fileArray[0]);
			if (! $testResult->error) break;
		}
		return $testSheet;
	}

	protected function getImportFile($options)
	{
		$fileName = $options['fileInfo']['tmp_name'];
		$fileArray = [];
		$fileInfo = new \finfo(FILEINFO_MIME);
		$mimeType = $fileInfo->buffer(file_get_contents($fileName));
		$okTypes = ['application/vnd.ms-excel; charset=binary', 'application/vnd.oasis.opendocument.spreadsheet; charset=binary', 'application/octet-stream; charset=binary', 'text/plain; charset=utf-8'];
		if (! in_array($mimeType, $okTypes))
		{
			throw new \Exception(Text::sprintf('COM_DILERREG_IMPORT_BAD_FORMAT', $options['fileInfo']['name'], $mimeType));
		}
		if (true || strpos($mimeType, 'charset=binary'))
		{
			// Should be Excel file
			$reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($fileName);
			$reader->setReadDataOnly(true);
			$spreadsheet = $reader->load($fileName);
			$activeSheet = $this->getFirstValidSheet($spreadsheet);
			$range = $activeSheet->calculateWorksheetDataDimension();
			$fileArray = $activeSheet->rangeToArray($range);
			if (is_array($fileArray) && count($fileArray) === 1 && is_array($fileArray[0]) && count($fileArray[0]) === 1 &&
					$fileArray[0][0] === null)
			{
				throw new \Exception(Text::_('COM_DILERREG_IMPORT_ERROR_NO_DATA'));
			}
		}
		else
		{
			$fileArray = file($fileName);
		}

		if ((! is_array($fileArray)) || ! $fileArray)
		{
			throw new Exception(DText::sprintf('NOT_FOUND', Text::_('COM_DILERREG_IMPORT_FILE')));
		}
		return $fileArray;
	}

    /**
     * Converts Excel numeric date to string formatted date.
     * @param mixed $dateValue
     * @throws Exception
     */
	protected function convertExcelDate($dateValue)
	{
		if (gettype($dateValue) !== 'string')
		{
			$phpDate = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($dateValue);
			$dateValue = $phpDate->format('Y-m-d');
		}
		return $dateValue;
	}

	public function displayFile($options)
	{
		$language = Factory::getApplication()->getLanguage();
		$language->load('com_diler', JPATH_SITE . '/components/com_diler', null, true);

		$logFileName     = $this->getLogFileName($options['type'], $options['view']) . '.php';
		$fullLogFilePath = Factory::getApplication()->getConfig()->get('log_path') . '/' . $logFileName;

		$importedLogRows = new ImportLogCollectionFromFile($fullLogFilePath);
		$fileViewModal   = new FileViewModal($options['type'], $importedLogRows, $options['view'], $this->option);

		$displayData     = array(
			'html'    => $fileViewModal->render(new FileLayout('file_view_modal', DPath::LAYOUTS)),
			'status'  => $importedLogRows->loadStatus(),
			'modalId' => $fileViewModal->modalId()
		);

		return (object) $displayData;
	}

	public function getLogFileName($type, $view)
	{
		$baseName = 'diler-import-' . $view . '-';
		$fileName = $baseName . $type . '-' . Factory::getUser()->id;
		if ($type === 'sample')
			$fileName = JPATH_ROOT . '/media/com_diler/administrator/images/sample-school-import-profiles.zip';
		if ($type == 'sample' && $view == 'regions')
			$fileName = DPath::ADMINISTRATOR_MEDIA_IMAGES . 'sample-region-import.zip';
		return $fileName;
	}

	/**
	 * Gets a search value from a table. Used to check if row exists in table.
	 * @param array $options searchColumn => <name of column to search>, table => <table name>, searchValue => <value to search for>
	 *		importColumn => <column to store in the imported table>
	 * @return mixed : int column value if found, otherwise null
	 */
	protected function getTableId($options)
	{
		extract($options);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select($db->quoteName($importColumn))
				->from($db->quoteName($table))
				->where($db->quoteName($searchColumn) . ' = ' . $db->quote($searchValue));
		return $db->setQuery($query)->loadResult();
	}

	private function getPostalCodeAndCity($options)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('postal_code, city');
		$query->from('#__diler_region');
		$query->where('postal_code = ' . $db->quote($options['zipcode']));
		$query->where('city = ' . $db->quote($options['city']));
		$query->where('country_iso2 = ' . $db->quote($options['country_code']));
		$query->where('state_iso = ' . $db->quote($options['state_code']));
		return $db->setQuery($query)->loadResult();
	}

    /**
     * Import file
     * @param array $options : view, skipFirstLine, allowDuplicates, subtask (check vs. import), fileInfo (array for viewing logs)
     * @throws Exception
     */
	public function import($options)
	{
		$this->logPrepare($options);
		$this->fileLinesArray = $this->getImportFile($options);
		$this->initializeFields($options);
		$rowResults = [];
		if ($options['view'] === 'schools')
		{
			$rowResults = $this->checkSchoolFileRows();
		}

		if ($options['subtask'] === 'import' && $options['view'] === 'schools')
		{
			$rowResults->insertedCount = $this->insertRows($rowResults, '#__diler_school');
		}
		if ($rowResults->error && $options['subtask'] === 'import')
		{
			$this->createRejectsFiles($options, $rowResults);
		}
		$this->logResults($options, $rowResults);
		$this->showMessages($options, $rowResults);
	}

	public function importRegions($options)
	{
		$this->logPrepare($options);
		$this->fileLinesArray = $this->getImportFile($options);
		$this->initializeRegionFields();
		$rowResults = $this->checkRegionFileRows();

		if ($options['subtask'] === 'import')
		{
			$rowResults->insertedCount = $this->insertRows($rowResults, '#__diler_region');
			$rowResults->teacherAssignedCount = $this->regionTeachersAssign($rowResults);
		}

		if ($rowResults->error && $options['subtask'] === 'import')
		{
			$this->createRejectsFiles($options, $rowResults);
		}
		$this->logResults($options, $rowResults);
		$this->showMessages($options, $rowResults);
	}

	protected function createRegionDataArray($columnArray)
	{
		$result = [];
		foreach ($this->regionHeaderColumns as $i => $colName)
		{
			if (in_array($colName, $this->ignoreRegionColumns)) continue;
			$result[$colName] = $columnArray[$i];
		}
		return $result;
	}


	protected function createRejectsFiles($options, $rowResults)
	{
		$rejectsArray = [];
		if ($options['view'] !== 'codes' || $options['skipFirstLine'] != '2')
		{
			$rejectsArray[] = '"' . implode('","', $this->fileLinesArray[0]) . '"' . "\n";
		}
		$badRows = array_keys($rowResults->error);
		foreach ($badRows as $i => $rowIndex)
		{
			$formattedRow = '"' . implode('","', $this->fileLinesArray[$rowIndex]) . '"' . "\n";
			$rejectsArray[] = $formattedRow;
		}
		$logPath = Factory::getConfig()->get('log_path');
		$write = File::write($logPath . '/' . $this->rejectsFile, implode('', $rejectsArray), true);
	}

	private function getRegionIdsFromRegionUserMap()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('region_id');
		$query->from('#__diler_region_user_map');

		return $db->setQuery($query)->loadAssocList();
	}

	private function getRegionIdsByPostalCode($postalCodes, $regionIds): array
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id, postal_code');
		$query->from('#__diler_region');
		$postalCode = array_column($postalCodes, 'postal_code');
		$ignoredRegionIds = array_column($regionIds, 'region_id');
		$query->where('postal_code IN (' . implode(',', array_map([$db, 'quote'], $postalCode)) . ')');
		$query->where('id NOT IN (' . implode(',', array_map([$db, 'quote'], $ignoredRegionIds)) . ')');
		$rows = $db->setQuery($query)->loadAssocList();

		foreach ($rows as $row)
			$result[] = ['region_id' => $row['id'], 'postal_code' => $row['postal_code']];

		return $result;
	}

	private function getRegionTeacherUsersFromUserMap($validData, $regionIds): array
	{
		$postalCode = array_column($validData, 'postal_code');
		$stateIso = array_column($validData, 'state_iso');
		$countryIso = array_column($validData, 'country_iso2');
		$db         = Factory::getDbo();
		$query      = $db->getQuery(true);
		$query->select('rum.user_id, dr.postal_code');
		$query->from('#__diler_region_user_map AS rum');
		$query->innerJoin('#__diler_region AS dr on dr.id = rum.region_id');
		$query->where('postal_code IN (' . implode(',', array_map([$db, 'quote'], $postalCode)) . ')');
		$query->where('state_iso IN (' . implode(',', array_map([$db, 'quote'], $stateIso)) . ')');
		$query->where('country_iso2 IN (' . implode(',', array_map([$db, 'quote'], $countryIso)) . ')');

		$regionTeacherIds = $db->setQuery($query)->loadAssocList();
		$regionPostalMap = [];
		foreach ($regionIds as $region)
			$regionPostalMap[$region['region_id']] = $region['postal_code'];

		$uniqueResults = [];
		foreach ($regionTeacherIds as $regionTeacherId)
		{
			$postalCode = $regionTeacherId['postal_code'];
			foreach ($regionPostalMap as $regionId => $regionPostal)
			{
				if ($postalCode === $regionPostal)
				{
					$uniqueKey = $regionTeacherId['user_id'] . '-' . $postalCode . '-' . $regionId;
					if (!isset($uniqueResults[$uniqueKey]))
					{
						$uniqueResults[$uniqueKey] = [
							'user_id'     => $regionTeacherId['user_id'],
							'postal_code' => $postalCode,
							'region_id'   => $regionId
						];
					}
				}
			}
		}

		return array_values($uniqueResults);
	}

	private function assignRegionTeachersWithExistingPostalCodes($regionIds): array
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->insert('#__diler_region_user_map');
		$query->columns('region_id, user_id');

		$uniqueCombinations = [];
		foreach ($regionIds as $row)
		{
			$combination = $row['region_id'] . '-' . $row['user_id'];
			if (!in_array($combination, $uniqueCombinations))
			{
				$uniqueCombinations[] = $combination;
				$values = array($row['region_id'], $row['user_id']);
				$query->values(implode(',', array_map([$db, 'quote'], $values)));
			}
		}

		try
		{
			$result = $db->setQuery($query)->execute();
		}

		catch (\Exception $e)
		{
			return ['result' => false, 'error' => $e->getMessage()];
		}
		$countInsertedUserIds = count($uniqueCombinations);

		return ['result' => $result, 'count' => $countInsertedUserIds];
	}

	protected function regionTeachersAssign($rowResults): array|int
	{
		if (! $rowResults->validData) return 0;
		$regionIdsRegionUserMap = $this->getRegionIdsFromRegionUserMap();
		$regionIds = $this->getRegionIdsByPostalCode($rowResults->validData, $regionIdsRegionUserMap);
		$regionTeachers = $this->getRegionTeacherUsersFromUserMap($rowResults->validData, $regionIds);
		return $this->assignRegionTeachersWithExistingPostalCodes($regionTeachers);
	}

	protected function showMessages($options, $rowResults)
	{
		$errorCount = count($rowResults->error);
		$successCount = count($rowResults->successRows);
		$warningCount = count($rowResults->warningRows);
		$insertedCount = ($options['subtask'] === 'import') ? $rowResults->insertedCount['inserted'] : 0;
		$updatedCount = ($options['subtask'] === 'import') ? $rowResults->insertedCount['updated'] : 0;
		$messageType = $options['view'] === 'schools' ? DText::_('SCHOOLS') : DText::_('REGIONS');
		$app = Factory::getApplication();
		if ($options['view'] === 'schools' && isset($rowResults->error[0]) && $rowResults->error[0])
		{
			$app->enqueueMessage(Text::_('COM_DILERREG_IMPORT_ERROR_HEADER'), 'error');
		}
		elseif ($errorCount)
		{
			$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_ERRORS', $messageType, $errorCount), 'error');
		}
		if ($warningCount && $options['subtask'] === 'check')
		{
			$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_WARNING', $messageType, $warningCount), 'warning');
		}
		if ($successCount && $options['subtask'] === 'check')
		{
			$app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_CHECK_SUCCESS', $messageType, $successCount), 'success');
		}

        if ($insertedCount)
            $app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_SUCCESS', $messageType, $insertedCount, DText::_('IMPORTED')), 'success');

        if ($updatedCount)
            $app->enqueueMessage(Text::sprintf('COM_DILERREG_IMPORT_SUCCESS', $messageType, $updatedCount, DText::_('UPDATED')), 'success');

		if ($options['view'] === 'regions' && $options['subtask'] === 'import' && $rowResults->teacherAssignedCount['result'])
		{
			$app->enqueueMessage(DText::sprintf('REGION_IMPORT_TEACHERS_ASSIGNED', $rowResults->teacherAssignedCount['count']), 'success');
		}
		if ($options['view'] === 'regions' && $options['subtask'] === 'import' && is_array($rowResults->regionTeacherWarnings) && $rowResults->regionTeacherWarnings)
		{
			$app->enqueueMessage(DText::sprintf('REGION_IMPORT_TEACHER_WARNING', count($rowResults->regionTeacherWarnings)), 'warning');
		}
	}

    private function insertRows($rowResults, $tableName)
	{
		$inserted = 0;
        $updated = 0;
		$db = Factory::getDbo();
        foreach ($rowResults->validData as $data)
		{
                if ($this->rowExists($db, $tableName, $data))
                {
                    $this->updateRow($db, $tableName, $data);
                    $updated++;
                }
                else
                {
                    $this->insertRow($db, $tableName, $data);
                    $inserted++;
                }
		}
        return ['inserted' => $inserted, 'updated' => $updated];
	}

    private function rowExists($db, $tableName, $data)
    {
        $query = $db->getQuery(true);
        $query->select('COUNT(*)');
        $query->from($db->quoteName($tableName));

        $this->addConditionsBasedOnTable($tableName, $query, $db, $data);

        return (int) $db->setQuery($query)->loadResult() > 0;
    }

    private function updateRow($db, $tableName, $data)
    {
        $fields = [];
        $regionOrSchoolKeys = $tableName === '#__diler_region' ? ['postal_code', 'city'] : ['school_id'];

        foreach ($data as $key => $value)
        {
            if (!in_array($key, $regionOrSchoolKeys))
                $fields[] = $db->quoteName($key) . ' = ' . $db->quote($value);
        }
        $query = $db->getQuery(true);
        $fields[] = $db->quoteName('published') . ' = 1';
        $query->update($db->quoteName($tableName));
        $query->set($fields);
        $this->addConditionsBasedOnTable($tableName, $query, $db, $data);

        $db->setQuery($query)->execute();
    }

    private function insertRow($db, $tableName, $data)
    {
        $columns = array_keys($data);
        $columns[] = 'published';

        $values = array_map([$db, 'quote'], array_values($data));
        $values[] = 1;

        $quotedColumns = array_map([$db, 'quoteName'], $columns);

        $query = $db->getQuery(true);
        $query->insert($db->quoteName($tableName));
        $query->columns($quotedColumns);
        $query->values(implode(',', $values));

        $db->setQuery($query)->execute();
    }

    private function addConditionsBasedOnTable($tableName, $query, $db, $data)
    {
        $postalCode = $data['postal_code'] ?? null;
        $city = $data['city'] ?? null;
        $schoolId = $data['school_id'] ?? null;
        if ($tableName === '#__diler_region')
        {
            $query->where($db->quoteName('postal_code') . ' = ' . $db->quote($postalCode));
            $query->where($db->quoteName('city') . ' = ' . $db->quote($city));
        }
        else
            $query->where($db->quoteName('school_id') . ' = ' . $db->quote($schoolId));
    }

	protected function initializeFields($options)
	{
		// Build count array of school ids
		$header = $this->fileLinesArray[0];
		$pos = array_search('school_id', $header);
		$count = count($this->fileLinesArray);
		$this->schoolIdCount = [];
		for ($i = 1; $i < $count; $i++)
		{
			if (! isset($this->schoolIdCount[$this->fileLinesArray[$i][$pos]])) $this->schoolIdCount[$this->fileLinesArray[$i][$pos]] = 0;
			$this->schoolIdCount[$this->fileLinesArray[$i][$pos]]++;
		}
		return true;
	}

	protected function initializeRegionFields()
	{
		// Build count array of school ids
		$header = $this->fileLinesArray[0];
		$pos = array_search('city', $header);
		$count = count($this->fileLinesArray);
		$this->zipcodeCount = [];
		for ($i = 1; $i < $count; $i++)
		{
			if (! isset($this->zipcodeCount[$this->fileLinesArray[$i][$pos]])) $this->zipcodeCount[$this->fileLinesArray[$i][$pos]] = 0;
			$this->zipcodeCount[$this->fileLinesArray[$i][$pos]]++;
		}
		return true;
	}

	protected function logPrepare($options)
	{
		$this->logFile = $this->getLogFileName(($options['subtask']) . '-log', $options['view']) . '.php';
		$this->rejectsFile = $this->getLogFileName('rejects', $options['view']) . '.csv';
		$this->rejectsFilePhp = $this->getLogFileName('rejects', $options['view']) . '.php';

		// Clear out old files.
		LogToFile::deleteLogFile($this->logFile);
		LogToFile::deleteLogFile($this->rejectsFile);
		LogToFile::deleteLogFile($this->rejectsFilePhp);

		$logOptions = ['message' => '', 'status' => Log::INFO, 'type' => 'FILE', 'logFile' => $this->logFile, 'categories' => ['FILE', 'ROW', 'COLUMN']];
		$messageType = ($options['view'] === 'schools') ? DText::_('SCHOOLS') : '';
		$logOptions['message'] = Text::sprintf('COM_DILERREG_CODES_LOG_CHECK_START', $messageType, $options['fileInfo']['name']);
		LogToFile::addLog($logOptions);
		$action = $options['subtask'] === 'check' ? 'COM_DILERREG_IMPORT_ACTION_CHECK' : 'COM_DILERREG_IMPORT_ACTION_IMPORT';
		$msg = '';
		$msg .= DText::_('TASK') . '=' . Text::_($action) . '. ';
		$logOptions['message'] = $msg;
		LogToFile::addLog($logOptions);
	}

	protected function logResults($options, $rowResults)
	{
		$logOptions = ['message' => '', 'status' => Log::INFO, 'type' => 'FILE', 'logFile' => $this->logFile, 'categories' => ['FILE', 'ROW', 'COLUMN']];
		$logOptions['message'] = Text::_('COM_DILERREG_IMPORT_COMPLETE');
		LogToFile::addLog($logOptions);
		if ($rowResults->error)
		{
			$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ERROR_HEADING', count($rowResults->error));
			LogToFile::addLog($logOptions);

			$logRejectOptions = array(
				'message' => Text::sprintf('COM_DILERREG_IMPORT_VIEW_REJECTED_ROWS', count($rowResults->error)),
				'status' => Log::ERROR,
				'type' => 'REJECT',
				'logFile' => $this->rejectsFilePhp,
				'categories' => ['REJECT']
			);
			LogToFile::addLog($logRejectOptions);
		}
		$logOptions['status'] = Log::ERROR;
		foreach ($rowResults->error as $count => $msgArray)
		{
			foreach ($msgArray as $msg)
			{
				$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ROW_ERRORS', $count, $msg);
				LogToFile::addLog($logOptions);

				$logRejectOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ROW_ERRORS', $count, $msg);
				LogToFile::addLog($logRejectOptions);
			}
			$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_DUMP', $count, '"' . implode('","', $this->fileLinesArray[$count]) . '"');
			LogToFile::addLog($logOptions);
		}
		$logOptions['status'] = Log::WARNING;
		if ($rowResults->warning && $options['subtask'] === 'check')
		{
			$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_WARNING_HEADING', count($rowResults->warning));
			LogToFile::addLog($logOptions);

			foreach ($rowResults->warning as $i => $msgArray)
			{
				$count = ($options['view'] === 'codes' && $options['skipFirstLine'] == 1) ? $i : $i + 1 ;
				foreach ($msgArray as $msg)
				{
					$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_ROW_WARNINGS', $count, $msg);
					LogToFile::addLog($logOptions);
				}
				$logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_LOG_DUMP', $count, '"' . implode('","', $this->fileLinesArray[$i]) . '"');
				LogToFile::addLog($logOptions);
			}
		}
		if ($options['view'] === 'regions' && $options['subtask'] === 'import' && is_array($rowResults->regionTeacherWarnings) && count($rowResults->regionTeacherWarnings))
		{
			$logOptions['message'] = DText::sprintf('REGION_IMPORT_TEACHER_WARNING', count($rowResults->regionTeacherWarnings));
			LogToFile::addLog($logOptions);
			foreach ($rowResults->regionTeacherWarnings as $badEmail)
			{
				$logOptions['message'] = $badEmail;
				LogToFile::addLog($logOptions);
			}
		}
		if ($options['subtask'] === 'import' && $rowResults->insertedCount)
		{
			$type = ($options['view'] === 'schools') ? 'COM_DILER_SCHOOLS' : 'COM_DILER_REGIONS';
            $insertedCount = $rowResults->insertedCount['inserted'];
            $updatedCount = $rowResults->insertedCount['updated'];

            if ($insertedCount)
                $logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_SUCCESS', Text::_($type), $insertedCount, DText::_('IMPORTED'));

            if ($updatedCount)
                $logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORT_SUCCESS', Text::_($type), $updatedCount, DText::_('UPDATED'));

            if ($updatedCount && $insertedCount)
                $logOptions['message'] = Text::sprintf('COM_DILERREG_IMPORTED_AND_UPDATED_SUCCESS',
                    Text::_($type),
                    $updatedCount,
                    DText::_('UPDATED'),
                    $insertedCount,
                    DText::_('IMPORTED'));

            $logOptions['status'] = Log::INFO;
			LogToFile::addLog($logOptions);
		}
		elseif ($options['subtask'] === 'import')
		{
			$logOptions['message'] = Text::_('COM_DILERREG_IMPORT_ERROR');
			$logOptions['status'] = Log::ERROR;
			LogToFile::addLog($logOptions);
		}
		if ($options['view'] === 'regions' && $options['subtask'] === 'import' && $rowResults->teacherAssignedCount['result'])
		{
			$logOptions['message'] = DText::sprintf('REGION_IMPORT_TEACHERS_ASSIGNED', $rowResults->teacherAssignedCount['count']);
			$logOptions['status'] = Log::INFO;
			LogToFile::addLog($logOptions);
		}
	}

	protected function toLowerCase($array)
	{
		$result = [];
		foreach ($array as $value)
		{
			$result[] = strtolower($value);
		}
		return $result;
	}
}
