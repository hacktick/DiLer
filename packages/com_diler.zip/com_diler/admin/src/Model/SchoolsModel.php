<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use DiLer\Users\DPermission;
use Joomla\CMS\User\User;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\Session\Session;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SchoolsModel extends ListModel
{
	private User $user;
	private DPermission $dPermission;

	public function __construct($config = array()) {
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'published', 'a.published',
				'a.level', 'level', 'start_date', 'end_date','a.school_id', 'a.postal_code','a.city','a.base_school',
				'CASE WHEN ISNULL(a.contract_signed_date) THEN 0 ELSE 1 END','student_count'
			);
		}

		$this->user = Factory::getApplication()->getIdentity();
		$this->dPermission = new DPermission($this->user);
		parent::__construct($config);
	}

	public function getItems()
	{
		$itemsRaw = parent::getItems();
		$items = $this->getTeacherCount($itemsRaw);

		$token = '&' . Session::getFormToken() . '=1';
		foreach ($items as $item)
		{
			$item->downloadLink = '';
			if ($item->contract_signed_date > $this->getDbo()->getNullDate())
			{
				$item->downloadLink = 'index.php?option=com_diler&task=school.download&file=' . base64_encode($item->contract_file_name) . $token;
			}
		}
		return $items;
	}

	protected function getListQuery() {

		$db = $this->getDbo();
		$query = $db->getQuery(true);

        $query->select('a.*, GROUP_CONCAT(DISTINCT h.user_id) AS student_id_list');
        $query->select('COUNT(DISTINCT CASE WHEN h.base_school = 1 THEN h.user_id ELSE NULL END) AS student_count');
        $query->select('GROUP_CONCAT(CONCAT(h.base_school, ":", h.branch_teacher)) AS teacher_list');
        $query->from($db->quoteName('#__diler_school') . ' AS a');
        $query->leftJoin('#__diler_user_school_history AS h ON h.school_id = a.id');
        $query->group('a.id');

        $search = $this->state->get('filter.search');

		if ($this->canRestrict())
			$query = $this->restrictByStateAndPostalCodes($query);

		$query = $this->setSearchQuery($query, $search);

		$published = $this->getState('filter.published');
		if (is_numeric($published))
			$query->where('a.published = ' . (int) $published);

        elseif ($published === '')
			$query->where('(a.published = 0 OR a.published = 1)');

		$baseSchool = $this->getState('filter.base_school', '');
		if ($baseSchool !== '')
			$query->where('a.base_school = ' . (int) $baseSchool);

		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn) . ',a.name ASC');
		return $query;
	}

	private function canRestrict() : bool
	{
		$isAdministrator = Factory::getApplication()->isClient('administrator');
		return !$this->dPermission->canTeacherViewAllSchools() && !$isAdministrator;
	}

	private function restrictByStateAndPostalCodes($query)
	{
		$isRestrictedByState = $this->dPermission->canTeacherViewSchoolsByState();
		$isRestrictedByPostalCodes = $this->dPermission->canTeacherViewSchoolsByPostalCodes();

		if (!$isRestrictedByState && !$isRestrictedByPostalCodes)
			return $query;

		if ($isRestrictedByState && $isRestrictedByPostalCodes)
			return $query->where(
				'((' .
					$this->getRestrictedByStateCondition() . ') or (' .
					$this->getRestrictedByPostalCodesCondition() .
				'))'
			);

		if ($isRestrictedByState)
			return $query->where($this->getRestrictedByStateCondition());

		return $query->where($this->getRestrictedByPostalCodesCondition());
	}

	private function getRestrictedByStateCondition() : string
	{
		$state = \DilerHelperUser::getUserStateIso();
		$db = $this->getDbo();

		return 'a.state_iso = ' . $db->quote($state);
	}

	private function getRestrictedByPostalCodesCondition() : string
	{
		$db = $this->getDbo();
		$assignedPostalCodes = $db->getQuery(true)
			->select('postal_code')
			->from('#__diler_region AS r')
			->innerJoin('#__diler_region_user_map as rum ON rum.region_id = r.id')
			->where('rum.user_id = ' . $this->user->id);

		return 'a.postal_code IN (' . $assignedPostalCodes . ')';
	}

	private function setSearchQuery($query, $search)
	{
		if (empty($search))
			return $query;

		if (stripos($search, 'id:') !== false)
			return $query->where('a.id = ' . (int) substr($search, 3));

		$db = $this->getDbo();
		$search = $db->Quote('%' . $db->escape($search, true) . '%');
		return $query->where('(a.name LIKE ' . $search .
			'OR a.email LIKE ' . $search . 'OR a.postal_code LIKE ' . $search .
			'OR a.school_id LIKE ' . $search . 'OR a.city LIKE ' . $search . ')');
	}

	public function getTeacherCount(array $items)
	{
		foreach ($items as $item)
		{
			$item->base_teacher_array = $item->branch_teacher_array = [];
			$teacherArray = $item->teacher_list ? explode(',', $item->teacher_list) : [];
			foreach ($teacherArray as $teacherString)
			{
				$workArray = explode(':', $teacherString);
				if (is_array($workArray) && count($workArray) === 2 && $workArray[1] && $workArray[0])
                    $item->base_teacher_array[] = $workArray[1];

				elseif (is_array($workArray) && count($workArray) === 2 && $workArray[1])
                    $item->branch_teacher_array[] = $workArray[1];
			}
			$item->base_teacher_array = array_unique($item->base_teacher_array);
			$item->branch_teacher_array = array_unique($item->branch_teacher_array);
			$item->base_principal_array = ($item->contract_signed_by) ? [$item->contract_signed_by] : [];
			$item->teacher_count = count($item->base_teacher_array) + count($item->branch_teacher_array) + count($item->base_principal_array);
		}
		return $items;
	}

	public function populateState($ordering = null, $direction = null) {
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.name', 'asc');
	}

	public function getRegions()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)->select('*, CONCAT(postal_code, " | ", place, " | ", community, " | ", state_iso) AS select_text')
				->from('#__diler_region')
				->where('published = 1')
				->order('ordering, country_iso2, state_iso, postal_code');
		return $db->setQuery($query)->loadObjectList();
	}

	protected function getStoreId($id = '') {
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}
}