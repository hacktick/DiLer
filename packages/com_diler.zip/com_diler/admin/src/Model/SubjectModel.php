<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SubjectModel extends AdminModel
{
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('m.subject_id')
			->from('#__diler_group_subject_section_map AS m')
			->where('m.subject_id IN(' . implode(',', $pks) . ')')
			->group('m.subject_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && count($badPks))
		{
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('SUBJECT'), DText::_('SUBJECT'));
			}
			else
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS', count($badPks), DText::_('SUBJECTS'), DText::_('SUBJECT'));
			}

			Factory::getApplication()->enqueueMessage($msg, 'warning');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new \Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}
		return $pks;
	}

	private function deleteMappedRecords($tableNames, $pks) : void
	{
		$db = $this->getDbo();
		foreach ($tableNames as $tableName)
		{
			$query = $db->getQuery(true)
				->delete($tableName)
				->where('subject_id IN (' . implode(',', $pks) . ')');
			$db->setQuery($query)->execute();
		}
	}

	public function delete(&$pks)
	{
		try
		{
			$db = $this->getDbo();
			$db->transactionStart();
			$pks = $this->checkChangeStatus($pks);
			$pks = ArrayHelper::toInteger($pks);
			$relatedTables = array(
				'#__diler_subject_competence_map',
				'#__diler_user_phase_map',
				'#__diler_student_subject_phase_status',
				'#__diler_marks_history',
				'#__diler_report_field_subject_map'
			);
			$this->deleteMappedRecords($relatedTables, $pks);
		}

		catch (\Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage(), 'error');
			$db->transactionRollback();
			return false;
		}

		$result = parent::delete($pks);
		if ($result)
		{
			$db->transactionCommit();
		}
		else
		{
			$db->transactionRollback();
		}
		return $result;

	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.subject', 'subject', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;

	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_diler.edit.subject.data', array());

		if (empty($data))
			$data = $this->getItem();

		return $data;
	}

	protected function prepareTable($table)
	{
		$table->name = trim(preg_replace('/(\s{2,})/', ' ', $table->name));
	}

	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		return parent::publish($pks, $value);
	}

}