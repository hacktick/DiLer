<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;

class CountryModel extends AdminModel
{
	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.country', 'country',

			array(
				'control'   => 'jform',
				'load_data' => $loadData
			));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	public function publish(&$pks, $value = 1)
	{
		if ($value == -2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		parent::publish($pks, $value);
	}

	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no answers for these tasks
		$db     = Factory::getDbo();
		$query  = $db->getQuery(true)
			->select('s.country_id')
			->from('#__diler_state AS s')
			->where('s.country_id IN(' . implode(',', $pks) . ')')
			->group('s.country_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && count($badPks))
		{
			// We need to give a message and also remove these from the $pks array
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('COUNTRY'), DText::_('STATES'));
                throw new \Exception($msg);
			}
			else
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($badPks), DText::_('COUNTRIES'), DText::_('STATES'));
                throw new \Exception($msg);
			}

			Factory::getApplication()->enqueueMessage($msg, 'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new \Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}

		return $pks;
	}

	public function save($data)
	{
		$result = parent::save($data);
		if ($result)
		{
			$data['id'] = isset($data['id']) && $data['id'] ? $data['id'] : (int) $this->getState($this->getName() . '.id');
			$this->saveStateRows($data);
		}

		return $result;
	}

	protected function saveStateRows($data)
	{
		$currentIds = $this->getCurrentRowIds($data['id']);
		if (isset($data['state_list']) && is_array($data['state_list']) && count($data['state_list']))
		{
			$i      = 0;
			$newIds = [];
			foreach ($data['state_list'] as $key => $nameArray)
			{
				if ($this->isDuplicateStateName($data, $nameArray))
				{
					Factory::getApplication()->enqueueMessage(DText::sprintf('COUNTRY_ALREADY_EXISTS', DText::_('STATE')), 'error');
					continue;
				}
				if ($nameArray['id'])
				{
					$this->updateStateRow($data, $nameArray, $i);
					$newIds[] = $nameArray['id'];
				}
				else
				{
					$this->insertStateRow($data, $nameArray, $i);
				}
				$i++;
			}
		}

		// Check for deletes of current rows
		$deleteIds = [];
        if(isset($newIds)) {
		    foreach ($currentIds as $currentId)
		    {
                if (!in_array($currentId, $newIds))
                    $deleteIds[] = $currentId;
		    }
        }else {
            $deleteIds = $currentIds;
        }
		if (count($deleteIds))
			$this->deleteStateRows($deleteIds);

		return true;
	}

	protected function getCurrentRowIds($stateId)
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')
			->from('#__diler_state')
			->where('country_id = ' . (int) $stateId);

		return $db->setQuery($query)->loadColumn();
	}

	protected function isDuplicateStateName($data, $nameArray)
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')
			->from('#__diler_state')
			->where('country_id = ' . $data['id'])
			->where('(name = ' . $db->quote($nameArray['name']) . ' OR ' . 'state_iso = ' . $db->quote($nameArray['state_iso']) . ')');

		if ($nameArray['id'])
		{
			$query->where('id != ' . (int) $nameArray['id']);
		}

		return $db->setQuery($query)->loadResult();
	}

	protected function updateStateRow($data, $nameArray, $i)
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_state')
			->set('name = ' . $db->quote($nameArray['name']))
			->set('state_iso = ' . $db->quote($nameArray['state_iso']))
			->set('country_iso2 = ' . $db->quote($data['iso2']))
			->set('is_avv_consent_accepted = ' . $db->quote($nameArray['is_avv_consent_accepted']))
			->set('ordering = ' . (int) $i)
			->where('id = ' . (int) $nameArray['id']);

		return $db->setQuery($query)->execute();
	}

	protected function insertStateRow($data, $nameArray, $i)
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true)->insert('#__diler_state')
			->set('state_iso = ' . $db->quote($nameArray['state_iso']))
			->set('country_iso2 = ' . $db->quote($data['iso2']))
			->set('name = ' . $db->quote($nameArray['name']))
			->set('is_avv_consent_accepted = ' . $db->quote($nameArray['is_avv_consent_accepted']))
			->set('ordering = ' . (int) $i)
			->set('country_id = ' . (int) $data['id']);

		return $db->setQuery($query)->execute();

	}

	protected function deleteStateRows($deleteIds)
	{
		$result   = false;
		$db       = Factory::getDbo();
		$validIds = ArrayHelper::toInteger((array) $deleteIds);
		if (!count($validIds)) return false;
		// See if there are history rows for these periods
		$query  = $db->getQuery(true)->select('st.id')
			->from('#__dilerreg_users AS du')
			->innerJoin('#__diler_state AS st ON du.state_iso = st.state_iso')
			->where('st.id IN(' . implode(',', $validIds) . ')')
			->group('st.id');
		$badPks = $db->setQuery($query)->loadColumn();
		if (is_array($badPks) && count($badPks))
		{
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('STATE'), DText::_('DASHBOARD_HEADING_USER_MANAGEMENT'));
			}
			else
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($badPks), DText::_('STATES'), DText::_('DASHBOARD_HEADING_USER_MANAGEMENT'));
			}
			Factory::getApplication()->enqueueMessage($msg, 'warning');
		}
		$validIds = array_diff($validIds, $badPks);
		if (is_array($validIds) && count($validIds))
		{
			try
			{
				$db->transactionStart();
				// Delete schoolyear map rows
				$query  = $db->getQuery(true)->delete('#__diler_state')
					->where('id IN(' . implode(',', $validIds) . ')');
				$result = $db->setQuery($query)->execute();
			}
			catch (\Exception $ex)
			{
				$db->transactionRollback();
			}
			$db->transactionCommit();
		}

		return $result;
	}

	public function delete(&$pks)
	{
		// Don't delete if mapped
		try
		{
			$pks = $this->checkChangeStatus($pks);
		}
		catch (\Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage());

			return false;
		}

		return parent::delete($pks);
	}

	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.country.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	public function getItem($pk = null)
	{
		$item             = parent::getItem($pk);
		$item->state_list = [];
		$db               = Factory::getDbo();

		$query = $db->getQuery(true)->select('*')
			->from('#__diler_state')
			->where('country_id = ' . (int) $item->id)
			->order('ordering');

		$detailRows = $db->setQuery($query)->loadObjectList();
		$count      = count($detailRows);

		for ($i = 0; $i < $count; $i++)
		{
			$item->state_list['state_list' . $i] = [
				'ordering'     => $i,
				'name'         => $detailRows[$i]->name,
				'id'           => $detailRows[$i]->id,
				'state_iso'    => $detailRows[$i]->state_iso,
				'country_iso2' => $detailRows[$i]->country_iso2
			];
		}

		return $item;
	}
}