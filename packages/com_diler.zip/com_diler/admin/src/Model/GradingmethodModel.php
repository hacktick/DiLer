<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\Model;
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;

class GradingmethodModel extends AdminModel
{
	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.gradingmethod', 'gradingmethod',
			array(
				'control'   => 'jform',
				'load_data' => $loadData
			));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	public function save($data)
	{
		// Convert language decimal separator to '.' for saving in the db.
		$data = $this->localiseDecimal($data, 'toDb');

		return parent::save($data);
	}

	protected function localiseDecimal($data, $action)
	{
		if (Text::_('DECIMALS_SEPARATOR') != '.')
		{
			$data['lowest_pass'] = $this->localiseDecimalForField($data['lowest_pass'], $action);
			foreach ($data['params'] as $key => $value)
			{
				$data['params'][$key] = $this->localiseDecimalForField($value, $action);
			}
		}

		return $data;
	}

	protected function localiseDecimalForField($value, $action)
	{
		$localDecimal = Text::_('DECIMALS_SEPARATOR');
		$result       = $value;
		if ($action == 'toDb')
		{
			$result = str_replace($localDecimal, '.', $value);
		}
		elseif ($action == 'toLocal')
		{
			$result = str_replace('.', $localDecimal, $value);
		}

		return $result;
	}

	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.gradingmethod.data', array());

		if (empty($data))
		{
			$data = ArrayHelper::fromObject($this->getItem());
		}
		$this->preprocessData('com_diler.gradingmethod', $data);

		return $data;
	}

	protected function preprocessData($context, &$data, $group = 'content')
	{
		// Convert '.' to local decimal value (if different)
		$data = $this->localiseDecimal($data, 'toLocal');
		parent::preprocessData($context, $data, $group);
	}
}