<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SectionModel extends AdminModel
{
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('m.section_id')
			->from('#__diler_group_subject_section_map AS m')
			->where('m.section_id IN(' . implode(',', $pks) . ')')
			->group('m.section_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			if (count($badPks) == 1)
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('SECTION'), DText::_('SUBJECT'));
			else
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS', count($badPks), DText::_('SECTIONS'), DText::_('SUBJECT'));

            Factory::getApplication()->enqueueMessage($msg,'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
				throw new \Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
		}
		return $pks;
	}
	public function delete(&$pks)
	{
		try
		{
			$pks = $this->checkChangeStatus($pks);
		}
		catch (\Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage());
			return false;
		}
		return parent::delete($pks);
	}

	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm('com_diler.section', 'section',

		array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
			return false;

        return $form;
	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_diler.edit.section.data', array());

		if (empty($data))
			$data = $this->getItem();

        return $data;
	}

	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
			$pks = $this->checkChangeStatus($pks);

		$db = $this->getDbo();
		$db->transactionStart();
		$result = parent::publish($pks, $value);

		$query = $db->getQuery(true)->select('COUNT(*)')->from('#__diler_section')->where('published = 1');
		$count = $db->setQuery($query)->loadResult();
		if (! $count)
		{
			$db->transactionRollback();
			$result = false;
			throw new \Exception(DText::sprintf('SECTIONS_CANNOT_UNPUBLISH', DText::_('SECTION')));
		}
		else
			$db->transactionCommit();
	}
}