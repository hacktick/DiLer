<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SubjectsModel extends ListModel
{

	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array('a.name',
				'a.published','published','a.id','language','ordering','a.ordering',
				'user_count','competence_count', 'a.category_id','category_id');
		}

		parent::__construct($config);
	}

	protected function getListQuery()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('a.*, c.title AS category_title');
		$query->from('#__diler_subject AS a');
		$query->leftJoin('#__categories AS c ON a.catid = c.id');
		$subQuery = $db->getQuery(true)
			->select('gsm.subject_id, COUNT(DISTINCT uum.user_id) AS user_count')
			->from('#__diler_group_subject_section_map AS gsm')
			->innerJoin('#__diler_group AS g ON gsm.group_id = g.id')
			->innerJoin('#__user_usergroup_map AS uum ON uum.group_id = g.joomla_group_id')
			->group('subject_id');
		$query->leftJoin('(' . $subQuery . ') AS uc ON uc.subject_id = a.id');
		$query->select('CASE WHEN uc.subject_id IS NULL THEN 0 ELSE uc.user_count END as user_count');

		$subQuery2 = $db->getQuery(true)
			->select('subject_id, COUNT(competence_id) AS competence_count')
			->from('#__diler_subject_competence_map')
			->group('subject_id');
		$query->leftJoin('(' . $subQuery2 . ') AS cc ON cc.subject_id = a.id');
		$query->select('CASE WHEN cc.subject_id IS NULL THEN 0 ELSE cc.competence_count END as competence_count');

		$search = $this->state->get('filter.search');
		if (! empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('(a.name LIKE ' . $search . ' OR a.description LIKE ' . $search . ')');
			}
		}
		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		$categoryIds = $this->getState('filter.category_id');
		$categoryIdArray = ArrayHelper::toInteger($categoryIds);
		if (is_array($categoryIdArray) && count($categoryIdArray))
		{
			$query->where('a.catid IN(' . implode(',', $categoryIdArray) . ')');
		}

		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		return $query;
	}

	protected function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$categoryId = $this->getUserStateFromRequest($this->context . '.filter.category_id', 'filter_category_id', '');
		$this->setState('filter.category_id', $categoryId);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.ordering', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}

	function getSubjectList()
	{
		$result = array();
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('id, name')
			->from('#__diler_subject')
			->where('published = 1')
			->order('ordering ASC');
		$rows = $db->setQuery($query)->loadObjectList();

		foreach($rows as $row)
		{
			$result[] = HTMLHelper::_('select.option', $row->id, Text::_($row->name));
		}
		return $result;
	}

}