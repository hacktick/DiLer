<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

class PhasesModel extends ListModel
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'published',
				'a.published',
				'a.level',
				'level',
				'user_count',
				'a.value * 1',
				'value * 1',
				'a.ordering'
			);
		}

		parent::__construct($config);
	}

	public function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.value * 1', 'asc');
	}

	protected function getListQuery()
	{
		$db    = Factory::getDBO();
		$query = $db->getQuery(true);

		$query->select('*');
		$query->from($db->quoteName('#__diler_phase') . ' AS a');

		$subQuery = $db->getQuery(true)
			->select('gsm.phase_id, COUNT(DISTINCT uum.user_id) AS user_count')
			->from('#__user_usergroup_map AS uum')
			->innerJoin('#__diler_group AS dg ON dg.joomla_group_id = uum.group_id')
			->innerJoin('#__diler_group_subject_section_map AS gsm ON dg.id = gsm.group_id')
			->group('gsm.phase_id');
		$query->leftJoin('(' . $subQuery . ') AS uc ON uc.phase_id = a.id');
		$query->select('CASE WHEN uc.phase_id IS NULL THEN 0 ELSE uc.user_count END as user_count');

		$search = $this->state->get('filter.search');
		if (!empty($search))
		{
			$search = $db->Quote('%' . $db->escape($search, true) . '%');
			$query->where('(a.value LIKE ' . $search . 'OR a.description LIKE ' . $search . ')');
		}

		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		$orderCol  = $this->state->get('list.ordering', 'a.value * 1');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		return $query;
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');

		return parent::getStoreId($id);
	}
}