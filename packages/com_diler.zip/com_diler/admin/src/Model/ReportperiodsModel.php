<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Model;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

defined('_JEXEC') or die('Restricted access');

class ReportperiodsModel extends ListModel
{

	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'a.name',
				'published',
				'a.published',
				'a.id',
				'a.edit_start_date',
				'a.edit_end_date',
				'edit_end_date',
				'edit_start_date',
				'id',
				'name'
			);
		}

		parent::__construct($config);
	}

	protected function getListQuery()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('a.*');
		$query->from('#__diler_report_period AS a');

		$filter_search = $this->getState('filter.search');
		if ($filter_search)
			$query->where('a.name LIKE ' . $db->quote('%' . $filter_search . '%'));

		$published = $this->getState('filter.published');
		if (is_numeric($published))
			$query->where("a.published = " . (int) $published);

		elseif ($published === '')
			$query->where('(a.published = 0 OR a.published = 1)');

		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		return $query;
	}

	protected function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('name', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}
}