<?php
/**
 * @copyright   Copyright (C) 2013 - 2022 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use Joomla\CMS\MVC\Controller\AdminController;

defined('_JEXEC') or die;

class ReportperiodsController extends AdminController
{
	protected $text_prefix = 'COM_DILER';

	public function getModel($name = 'Reportperiod', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}
}
