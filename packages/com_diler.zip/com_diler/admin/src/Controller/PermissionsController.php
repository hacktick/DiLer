<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

use Audivisa\Component\DiLer\Administrator\Model\PermissionsModel;
use DiLer\Lang\DText;
use Joomla\CMS\Access\Rules;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

class PermissionsController extends FormController
{
    public function __construct($config = [], MVCFactoryInterface $factory = null, $app = null, $input = null)
    {
        parent::__construct($config, $factory, $app, $input);

        $this->registerTask('apply', 'save');
    }

    public function save($key = null, $urlVar = null)
    {
        // Check for request forgeries.
        $this->checkToken();

        $data    = $this->input->get('jform', [], 'ARRAY');
        $option  = $this->input->get('component');
        $user    = $this->app->getIdentity();
        $context = "$this->option.edit.$this->context.$option";

        /** @var PermissionsModel $model */
        $model = $this->getModel();
        $form  = $model->getForm();

        // Make sure com_joomlaupdate and com_privacy can only be accessed by SuperUser
        if (\in_array(strtolower($option), ['com_joomlaupdate', 'com_privacy'], true) && !$user->authorise('core.admin')) {
            $this->setRedirect(Route::_('index.php', false), Text::_('JERROR_ALERTNOAUTHOR'), 'error');
        }

        // Check if the user is authorised to do this.
        if (!$user->authorise('core.admin', $option) && !$user->authorise('core.options', $option)) {
            $this->setRedirect(Route::_('index.php', false), Text::_('JERROR_ALERTNOAUTHOR'), 'error');
        }

        // Remove the permissions rules data if user isn't allowed to edit them.
        if (!$user->authorise('core.admin', $option) && isset($data['params']) && isset($data['params']['rules'])) {
            unset($data['params']['rules']);
        }

        $asset = Table::getInstance('asset');

		// create new row for permissions in #__assets table if not exist
        if (!$asset->loadByName('com_diler')) {
            $root = Table::getInstance('asset');
            $root->loadByName('root.1');
            $asset->name  = 'com_diler';
            $asset->title = 'com_diler';
            $asset->setLocation($root->id, 'last-child');
        }
        else
        {
			// if row for permissions already exist
            $savedRulesToRawArray = array();
            $savedRules = new Rules($asset->rules);

			// convert first to standard assoc array
            foreach ($savedRules->getData() as $key => $oldRule)
                $savedRulesToRawArray[$key] = $oldRule->getData();

            foreach ($data['dilerrules'] as $permissionName => $newRules)
            {
                foreach ($newRules as $groupId => $ruleValue)
                {
					// if rule is changed (access permission is set to Inherited) we need to remove it from already saved
	                // permissions
                    if ($ruleValue === "")
                    {
                        unset($savedRulesToRawArray[$permissionName][$groupId]);
                    }
                }
            }


			// merge already saved and new data posted
	        // we need to do this because we are using pagination to display permissions
	        // so if we store something what's on page 45, we need to be sure all other pages keeps saved
            $data['dilerrules'] = ArrayHelper::mergeRecursive($data['dilerrules'], $savedRulesToRawArray);
        }

        // Validate the posted data.
        $return = $model->validate($form, $data);

        $limitStart = '&limitstart=' . $this->input->get('limitstart', 0);
        $redirect = Route::_('index.php?option=com_diler&view=permissions' . $limitStart, false);
	    $redirectDashboard = Route::_('index.php?option=com_diler&view=dilers', false);
        // Check for validation errors.
        if ($return === false) {
            // Save the data in the session.
            $this->app->setUserState($context . '.data', $data);

            // Redirect back to the edit screen.
            $this->setRedirect(
                Route::_($redirect, false),
                $model->getError(),
                'error'
            );

            return false;
        }

        // Attempt to save the configuration.
        try {
            $model->save($return);
        } catch (\RuntimeException $e) {
            // Save the data in the session.
            $this->app->setUserState($context . '.data', $data);

            // Save failed, go back to the screen and display a notice.
            $this->setRedirect(
                Route::_($redirect, false),
                Text::_('JERROR_SAVE_FAILED', $e->getMessage()),
                'error'
            );

            return false;
        }

        // Clear session data.
        $this->app->setUserState($context . '.data', null);

        // Set the redirect based on the task.
        switch ($this->input->get('task')) {
            case 'apply':
                $this->setRedirect(
                    Route::_($redirect, false),
                    DText::_('PERMISSIONS_SUCCESSFULLY_SAVED'),
                    'message'
                );

                break;

            case 'save':
                $this->setMessage(DText::_('PERMISSIONS_SUCCESSFULLY_SAVE'), 'message');

                // No break

            default:
				$this->setRedirect(Route::_($redirectDashboard, false));
        }

        return true;
    }

    public function cancel($key = null)
    {

        $redirect = 'index.php?option=com_diler&view=dilers';

        $this->setRedirect(Route::_($redirect, false));

        return true;
    }

    public function getModel($name = 'Permissions', $prefix = 'Administrator', $config = ['ignore_request' => true])
    {
        return parent::getModel($name, $prefix, $config);
    }

}
