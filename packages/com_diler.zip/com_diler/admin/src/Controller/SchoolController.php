<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use DiLer\Lang\DText;
use DiLerHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Language\Text;

// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted access' );

class SchoolController extends FormController
{
	public function batch($model = null)
	{
		$model = $this->getModel('School', 'Administrator');
		$this->setRedirect(Route::_('index.php?option=com_diler&view=schools' . $this->getRedirectToListAppend(), false));
		return parent::batch($model);
	}

	public function download()
	{
		Session::checkToken('get') or jexit(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		$input = $app->input;
		$decryptedFile = base64_decode($input->get('file', '', 'BASE64'));
		$basePath = ComponentHelper::getParams('com_diler')->get('file_root_folder');
		$fullName = $basePath . '/contracts/' . $decryptedFile;
		if (file_exists($fullName))
		{
			DiLerHelper::downloadFile($fullName);
		}
		else
		{
			$app->enqueueMessage(DText::sprintf('NOT_FOUND', DText::_('SCHOOL_CONTRACT')), 'error');
			$app->redirect('index.php?option=com_diler&view=schools');
		}
	}

	/**
	 * Function to do standard controller tasks. Saves duplicate code in each controller function.
	 *
	 * @param string $function Name of model function to call.
	 * @param array $options Associative array of options to pass to model. Depends on model.
	 * @throws \Exception
	 */
	public function processModel($function, $options, $checkToken = true)
	{
		$checkToken && (Session::checkToken() or jexit(Text::_('JINVALID_TOKEN')));
		$app = Factory::getApplication();
		try
		{
			$result = $this->getModel()->$function($options);
		}
		catch (\Exception $e)
		{
			header('HTTP/1.0 500 Internal Server Error');
			$response = $e->getMessage();
			echo json_encode($response, JSON_UNESCAPED_UNICODE);
			$app->close();
		}
		echo json_encode($result);
		$app->close();
	}

	public function getUsersForSchool()
	{
		$app = Factory::getApplication();
		$options = ['id' => $app->input->getUint('id', 0), 'type' => $app->input->get('type')];
		if ($options['type'] === 'teacher')
		{
			$options['branchTeachers'] = $app->input->getString('branchTeachers');
			$options['baseTeachers'] = $app->input->getString('baseTeachers');
			$options['regionTeachers'] = $app->input->getString('regionTeachers');
			$options['basePrincipals'] = $app->input->getString('basePrincipals');
		}
		$this->processModel('getUsersForSchool', $options);
	}
}
