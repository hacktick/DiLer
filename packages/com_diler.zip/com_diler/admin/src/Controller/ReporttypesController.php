<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use Audivisa\Component\DiLer\Administrator\Model\ReporttypeModel;
use DiLer\Lang\DText;
use Joomla\Archive\Archive;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Filesystem\Path;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\MVC\Controller\AdminController;

defined('_JEXEC') or die();

\JLoader::register('DilerLogger', JPATH_ROOT . '/components/com_diler/helpers/logger.php');
class ReporttypesController extends AdminController
{
	protected $text_prefix = 'COM_DILER';

	public function copy()
	{
		Session::checkToken() or die(Text::_('JINVALID_TOKEN'));
		$input = Factory::getApplication()->input;
		$formId = $input->get('cid', array(), 'array')[0];
		$newName = $input->getString('new_report_type_name');

		try
		{
			$model = $this->getModel();
			$model->copy($formId, $newName);
		}
		catch (\Exception $e)
		{
			$this->setMessage($e->getMessage(), 'error');
			$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));
			return;
		}

		$this->setMessage(DText::sprintf('REPORT_TYPE_COPY_SUCCESS', $newName));
		$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));
	}

	public function export()
	{
		Session::checkToken() or die(Text::_('JINVALID_TOKEN'));

		$app = Factory::getApplication();
		$cid = $app->input->get('cid', array(), 'array');

		if (! is_array($cid) || count($cid) != 1)
		{
			$this->setMessage(DText::_('REPORT_TYPE_EXPORT_SELECT_ONE'), 'error');
			$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));
			return;
		}

		/** @var ReporttypeModel $model */
		$model = $this->getModel();
		$logger = new \DilerLogger('report', 'export');
		try
		{
			$result = $model->export($cid[0]);
		}
		catch (\Exception $e)
		{
			$error = $e->getMessage();
			$logger->logError($error);
			$this->setMessage($error, 'error');
			$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));
			return;
		}

		$logMessage = DText::sprintf('REPORT_TYPE_EXPORT_LOG', Factory::getUser()->username, $result);
		$logger->addAction(array('message' => $logMessage));
		$this->setMessage(DText::_('REPORT_TYPE_EXPORT_SUCCESS'));
		$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));

		$app->close();
	}

	public function getModel($name = 'Reporttype', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}

	/**
	 * @TODO Find and fix bug: There is something causing this task to run twice.
	 *       For some reason after form is processed it calls this method again with empty data.
	 *       From my understanding on success it's redirect to:
	 *       /administrator/index.php?option=com_diler&task=reporttypes.import
	 *       But when I ECHO redirection url, it seems to be fine.
	 *       It seems that there is something wrong with list veiw. If I add die() right before redirecting
	 *       back after success, I see method is run twice by checking logger data
	 *       (you can see one is success, other is error: not selected file).
	 *       If I try to resubmit form, it seem to all be fine.
	 *       In general there is no issue for end user as user don't see this error, only we can see wrong data in logger.
	 */
	public function import()
	{
		Session::checkToken() or die(Text::_('JINVALID_TOKEN'));
		$input = Factory::getApplication()->input;
		$userfile = $input->files->get('install_package', null, 'raw');

		if (!$userfile['name'])
		{
			return $this->redirectOnError(DText::_('REPORT_TYPE_IMPORT_NO_FILE'));
		}

		// @TODO Use specific message if any of following error appears
		$errorFailUpload = false;

		if (!ini_get('file_uploads') || !extension_loaded('zlib'))
			$errorFailUpload = true;

		if ($userfile['error'] && ($userfile['error'] == UPLOAD_ERR_NO_TMP_DIR || $userfile['error'] == UPLOAD_ERR_INI_SIZE))
			$errorFailUpload = true;

		if ($userfile['error'] || $userfile['size'] < 1)
			$errorFailUpload = true;

		if ($errorFailUpload)
			return $this->redirectOnError(DText::_('REPORT_TYPE_IMPORT_UPLOAD_ERROR'));

		$config		= Factory::getConfig();
		$destFolder = basename($userfile['name'], '.zip');
		$tmpDest	= $config->get('tmp_path') . '/diler/report-import/' . $destFolder;
		$tmpSrc	= $userfile['tmp_name'];

		if (Folder::exists($tmpDest))
			Folder::delete($tmpDest);

		Folder::create($tmpDest);
		$tmpFile = $tmpDest . '/' . $userfile['name'];
		$result = File::upload($tmpSrc, $tmpFile, false, true);
		if (! $result)
            return $this->redirectOnError(DText::_('REPORT_TYPE_IMPORT_UPLOAD_ERROR'));

		$extractdir = Path::clean($tmpDest . '/install');
		Folder::create($extractdir);
		$archivename = Path::clean($tmpFile);

		try
		{
            $archive = new Archive();
            $archive->extract($archivename, $extractdir);
		}
		catch (\Exception $e)
		{
			Folder::delete($tmpDest);
			return $this->redirectOnError(DText::sprintf('REPORT_TYPE_IMPORT_FAIL', $e->getMessage()));
		}

		$model = $this->getModel();
		try
		{
			$message = $model->import($extractdir);
		}
		catch (\Exception $e)
		{
			Folder::delete($tmpDest);
			return $this->redirectOnError(DText::sprintf('REPORT_TYPE_IMPORT_FAIL', $e->getMessage()));
		}

		// @TODO Remove following addIncludePath if NOT needed
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');
		$logMessage = DText::sprintf('REPORT_TYPE_IMPORT_LOG', Factory::getUser()->username, basename($archivename));
		$logger = new \DilerLogger('report', 'import');
		$logger->addAction(array('message' => $logMessage));

		Folder::delete($tmpDest);
		$this->setMessage($message);
		$this->redirectToListView();
	}

	private function redirectToListView()
	{
		$contract = Factory::getApplication()->input->get('contract', '0');
		$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list . '&contract=' . $contract, false));
		$this->redirect();
	}

	protected function postDeleteHook($model, $cid = null)
	{
		$app = Factory::getApplication();
		$contract = $app->input->get('contract', '0');
		Factory::getApplication()->redirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list . '&contract=' . $contract, false));
	}

	public function publish()
	{
		$this->checkToken();

		$cid = $this->input->get('cid', array(), 'array');
		$data = array('publish' => 1, 'unpublish' => 0, 'archive' => 2, 'trash' => -2, 'report' => -3);
		$task = $this->getTask();
		$value = ArrayHelper::getValue($data, $task, 0, 'int');

		if (empty($cid))
			Log::add(Text::_($this->text_prefix . '_NO_ITEM_SELECTED'), Log::WARNING, 'jerror');

		else
		{
			$model = $this->getModel();

			$cid = ArrayHelper::toInteger($cid);

			try
			{
				$model->publish($cid, $value);
				$errors = $model->getErrors();
				$ntext = null;

				if ($value === 1)
				{
					if ($errors)
						Factory::getApplication()->enqueueMessage(Text::plural($this->text_prefix . '_N_ITEMS_FAILED_PUBLISHING', count($cid)), 'error');

					else
                        $ntext = $this->text_prefix . '_N_ITEMS_PUBLISHED';
				}
				elseif ($value === 0)
					$ntext = $this->text_prefix . '_N_ITEMS_UNPUBLISHED';

				elseif ($value === 2)
                    $ntext = $this->text_prefix . '_N_ITEMS_ARCHIVED';

				else
					$ntext = $this->text_prefix . '_N_ITEMS_TRASHED';

				if ($ntext !== null)
                    $this->setMessage(Text::plural($ntext, count($cid)));
			}
			catch (\Exception $e)
			{
				$this->setMessage($e->getMessage(), 'error');
			}
		}

		$contract = Factory::getApplication()->input->get('contract', '0');
		$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list . '&contract=' . $contract, false));
	}

	private function redirectOnError($error, $route = null)
	{
		$app = Factory::getApplication();
		$app->enqueueMessage($error, 'error');

		$logger = new \DilerLogger('report', 'error');
		$logger->logError($error);

		if (!$route)
            $this->redirectToListView();

		$this->setRedirect(Route::_($route));
		$this->redirect();
	}
}