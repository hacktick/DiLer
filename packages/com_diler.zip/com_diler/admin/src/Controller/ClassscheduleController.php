<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
use Joomla\Utilities\ArrayHelper;

defined('_JEXEC') or die('Restricted access');

class ClassscheduleController extends FormController
{
	public function assignClassScheduleToAllStudents()
	{
		$recordId = $this->input->getInt('id');
		$this->getModel()->assignClassScheduleToAllStudents($recordId);
		$this->getModel()->setDefaultSchedule($recordId);
		$this->setMessage('Success');
		$this->setRedirect(Route::_(
			'index.php?option=' . $this->option . '&view=' . $this->view_item
			. $this->getRedirectToItemAppend($recordId), false
		));
	}
}
