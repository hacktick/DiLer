<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Session\Session;

class ActivityController extends BaseController
{
	/**
	 * Tests the grading method to show user the results for various percent grades.
	 */
	public function testGradingMethod()
	{
		$app = Factory::getApplication();
		if (! Session::checkToken('request'))
		{
			echo '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>'
				. '<h1>' . Text::_('JINVALID_TOKEN') . '</h1></div><div class="modal-body"></div>';
			$app->close();
		}
		$gradingMethodId = $app->input->getUint('id');
		$activityModel = $this->getModel('Activity', 'Site');
		$result = $activityModel->testGradingMethod($gradingMethodId);
		echo $result;
		$app->close();
	}
}
