<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use Joomla\CMS\MVC\Controller\AdminController;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');


class SubjectsController extends AdminController
{
	public function getModel($name = 'Subject', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}

}