<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted access' );

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;

class SectionController extends FormController
{
	public function save($key = null, $urlVar = null)
	{
		// #__diler_section value is check database yes or no
		$input = Factory::getApplication()->input;
		$id = $input->get ( 'id' );
		$data = $input->post->get ( 'jform', array (), 'array' );
		$value = $data ['value'];
		$user = Factory::getUser ();
		$user_id = $user->get ( 'id' );
		$db = Factory::getDBO ();
		$query = "SELECT value FROM #__diler_section
				  WHERE id = '$id'";
		$db->setQuery ( $query );
		$row = $db->loadResult ();
		$query_duplicate_check = $db->getQuery ( true );
		if (isset ( $id ) && $id > 0)
		{
			$query_duplicate_check = "SELECT * FROM " . $db->quoteName ( "#__diler_section" ) . " WHERE value=" . $db->quote ( $value ) . " and id!=" . $id;
		}
		else
		{
			$query_duplicate_check = "SELECT * FROM " . $db->quoteName ( "#__diler_section" ) . " WHERE  value=" . $db->quote ( $value ) . " ";
		}
		
		$db->setQuery ( $query_duplicate_check );
		$lists = $db->loadObjectList ();
		if (count ( $lists ) > 0)
		{
			$query_duplicate_check_msg = DText::_('SECTION_ALREADY_EXISTS');
			$url = 'index.php?option=com_diler&view=section&layout=edit';
			if (isset ( $id ) && $id > 0)
			{
				$url .= '&id=' . $id;
			}
            Factory::getApplication()->enqueueMessage( $query_duplicate_check_msg, 'error');
			Factory::getApplication()->redirect ( $url );
			return false;
		}
		
		return parent::save ( $key, $urlVar );
	}
}