<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */


namespace Audivisa\Component\DiLer\Administrator\Controller;
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Router\Route;
use Joomla\Input\Input;

class CompetencesController extends AdminController
{
	public function __construct($config = array(), MVCFactoryInterface $factory = null, ?CMSApplication $app = null, ?Input $input = null)
	{
		parent::__construct($config, $factory, $app, $input);
		$this->registerTask('trash', 'trash');
	}

	public function getModel($name = 'Competence', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}

	public function delete()
	{
		try
		{
			parent::delete();
		}
		catch (\Exception $e)
		{
			$this->setMessage($e->getMessage(), 'error');
		}
		$this->setRedirect(Route::_('index.php?option=com_diler&view=competences', false));
	}

}