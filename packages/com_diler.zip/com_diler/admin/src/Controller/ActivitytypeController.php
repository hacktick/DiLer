<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Controller\FormController;

class ActivitytypeController extends FormController
{
	public function save($key = null, $urlVar = null)
	{
		$data = $this->input->post->get('jform', array(), 'array');
		if ($data['controlled_access'] == 1)
		{
			$data['default_self_confirmed'] = 2;
		}
		else
		{
			$data['max_points'] = 0;
			$data['offline_access_check'] = 2;
		}
		if ($data['track_completed'] == 0)
		{
			$data['show_in_statistics'] = 0;

		}
		$this->input->post->set('jform', $data);
		return parent::save($key, $urlVar);
	}
}