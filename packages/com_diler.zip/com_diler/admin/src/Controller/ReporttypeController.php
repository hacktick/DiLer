<?php
/**
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;

defined('_JEXEC') or die;

class ReporttypeController extends FormController
{
	protected function getRedirectToItemAppend($recordId = null, $urlVar = 'id')
	{
		$result = parent::getRedirectToItemAppend($recordId, $urlVar);
		$contract = Factory::getApplication()->input->get('contract', '0');
		return $result . '&contract=' . $contract;
	}

	protected function getRedirectToListAppend()
	{
		$result = parent::getRedirectToListAppend();
		$contract = Factory::getApplication()->input->get('contract', '0');
		return $result . '&contract=' . $contract;
	}
}
