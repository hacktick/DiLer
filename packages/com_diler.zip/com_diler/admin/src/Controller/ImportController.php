<?php
/**
 * @package     Diler.Administrator
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\Controller;

defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Administrator\Helper\DilerVersion;
use Audivisa\Component\DiLer\Administrator\Helper\FileHelper;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Language\Text;

class ImportController extends FormController
{
	protected $view_list = 'codes';

	public function check()
	{
		$this->input->set('subtask', 'check');
		$_FILES['import_file'] = $_FILES['import_check_file'];

		$this->import();
	}

	public function importSchools()
	{
		$this->input->set('subtask', 'import');
		$this->import();
	}

	public function importRegions()
	{
		$this->input->set('subtask', 'import');
		$this->import();
	}

	public function import()
	{
		Session::checkToken() or die(Text::_('JINVALID_TOKEN'));
		if (! DilerVersion::doesHaveExtendedFeatures())
		{
			throw new \RuntimeException(strip_tags(DText::_('EXTENDED_FEATURES_NOT_AVAILABLE')));
		}
		$app = Factory::getApplication();
		$options['subtask'] = $app->input->get('subtask');
		$options['view'] = $app->input->get('view');
		$this->view_list = $options['view'];
		if ($options['view'] === 'teachers')
		{
			$options['regionTeachers'] = $app->input->getUint('region_teachers', 2);
		}
		$options['fileInfo'] = $this->input->files->get('import_file');
		try
		{

			if ($options['view'] === 'regions')
			{
				$this->getModel()->importRegions($options);
			}
			else
			{
				$this->getModel()->import($options);
			}
		}
		catch (\Exception $ex)
		{
			$this->setMessage(DText::sprintf('REPORT_TYPE_IMPORT_FAIL', $ex->getMessage()), 'error');
			$this->setRedirect(Route::_('index.php?option=com_diler&view=' . $this->view_list, false));
			return false;
		}
		$this->setRedirect(Route::_('index.php?option=com_diler&view=' . $this->view_list, false));
		return true;
	}

	public function downloadFile()
	{
		$app = Factory::getApplication();
		$type = $app->input->get('fileType');
		$view = $app->input->get('view');
		$logPath = Factory::getApplication()->getConfig()->get('log_path');
		$baseName = $this->getModel()->getLogFileName($type, $view);
		$ext = ($type === 'rejects' ? '.csv' : '.php');
		$fullName = $logPath . '/' . $baseName . $ext;
		if ($type === 'sample')
		{
			$fullName = $baseName;
			$options['newExtension'] = 'zip';
		}
		else
		{
			$options['newExtension'] = 'csv';
		}

		if (file_exists($fullName))
		{
			FileHelper::download($fullName, $options);
		}
		else
		{
			$app->enqueueMessage(DText::sprintf('NOT_FOUND', Text::_('COM_DILERREG_IMPORT_FILE')), 'error');
			$app->redirect('index.php?option=com_diler&view=schools');
		}
	}

	public function displayFile()
	{
		$input = Factory::getApplication()->input;
		$options['type'] = $input->get('type');
		$options['view'] = $input->get('view');
		echo $this->getModel()->displayFile($options)->html;
	}


}
