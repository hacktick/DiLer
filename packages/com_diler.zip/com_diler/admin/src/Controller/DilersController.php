<?php
/**
 * DiLers default controller
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Controller\AdminController;
 
// import Joomla controlleradmin library

 
/**
 * DiLers Controller class
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @since 2.5
 */
class DilersController extends AdminController
{
        public function getModel($name = 'Diler', $prefix = 'Administrator', $config = [])
        {
                return parent::getModel($name, $prefix, $config);
        }
		
		
}