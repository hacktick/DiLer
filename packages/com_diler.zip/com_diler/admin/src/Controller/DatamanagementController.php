<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use DiLer\Lang\DText;
use DiLer\Reports\ArchiveReports;
use DiLer\Reports\StoredReportsList;
use DiLer\Wrappers\DUri;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\MVC\Controller\AdminController;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class DatamanagementController extends AdminController
{
	public function getModel($name = 'Datamanagement', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}

	public function getView($name = '', $type = '', $prefix = '', $config = array())
	{
		$view = parent::getView($name, $type, $prefix, $config);
		$view->setModel($this->getModel('Diler'));
		$view->setModel($this->getModel('Sampledata'));
		return $view;
	}


	public function resetAchievements()
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		$input = $app->input;
		$statusCodes = $input->get('statusCodes', array(), 'array');
		$phases= $input->get('phases', array(), 'array');
		$subjects= $input->get('subjects', array(), 'array');
		$date = $input->get('date');
		$action = $input->get('action', 'count');

		ArrayHelper::toInteger($statusCodes);
		ArrayHelper::toInteger($phases);
		ArrayHelper::toInteger($subjects);

		try
		{
			if ($action == 'purge')
				$result = $this->getModel()->resetAchievements($statusCodes, $phases, $subjects, $date);

			else
				$result = $this->getModel()->getResetAchievementCounts($statusCodes, $phases, $subjects, $date);

		}
		catch (\Exception $e)
		{
			header('HTTP/1.0 500 Internal Server Error');
			$response = $e->getMessage();
			echo $response;
			$app->close();
		}
		echo json_encode($result);
		$app->close();
	}

	public function downloadStoredPdf()
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$input = $this->input;
		$learningGroupIds = $input->get('learningGroupIds', array());
		$schoolYearIds = $input->get('schoolYearIds', array());
		$action = $input->get('action', 'count');

		$storedReportsModel = $this->getModel('Storedreports', 'Site');
		$storedPdfReports = $storedReportsModel->getStoredReports($learningGroupIds, $schoolYearIds);
		if ($action == 'count')
			$this->renderCountOfStoredReports($storedPdfReports);
		
		if ($action == 'list')
			$this->renderDownloadFileAddressOfZippedStoredReports($storedPdfReports);

		Factory::getApplication()->close();
	}
	
	private function renderCountOfStoredReports(StoredReportsList $reports) : void
	{
		echo json_encode(array('count' => count($reports)));
	}
	
	private function renderDownloadFileAddressOfZippedStoredReports(StoredReportsList $storedPdfReports) : void
	{
		$zip = new ArchiveReports($storedPdfReports, Factory::getDate());
		$pdfAddress['downloadFileAddress'] = $zip->getDownloadUrl(new DUri);
		echo json_encode($pdfAddress);
	}

	/**
	 * Checks that the foreign key references are correct in the current db
	 */
	public function checkDbSchema()
	{
		Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		try
		{
			$checkDbSchema = $this->getModel('Diler')->checkDbSchema();
		}
		catch (\Exception $ex)
		{
            $app->enqueueMessage( $ex->getMessage(), 'error');
			$app->redirect('index.php?option=com_diler&view=datamanagement');
		}
		$this->app->enqueueMessage(DText::_('CHECK_DATABASE_SCHEMA_SUCCESS'), $this->app::MSG_INFO);
		$app->redirect('index.php?option=com_diler&view=datamanagement', 200);
	}

	/**
	 * Checks that the foreign key references are correct in the current db
	 */
	public function createSampleDb()
	{
		Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
        $options['password'] = $this->app->input->getString('sample_password');
		try
		{
			$this->getModel('Sampledata')->createSampleDb($options);
		}
		catch (\Exception $ex)
		{
            $this->app->enqueueMessage($ex->getMessage(), 'error');
            $this->app->redirect('index.php?option=com_diler&view=datamanagement');
        }
		$message = DText::_('BUTTON_SAMPLE_DATA_SUCCESS');
		if ($options['password'])
		{
			$message .= '</br>' . DText::sprintf('SAMPLE_DATA_PASSWORD', $options['password']);
		}
        $this->app->enqueueMessage($message, 'success');
        $this->app->redirect('index.php?option=com_diler&task=datamanagement.display');

    }

	public function moveDatesForward()
	{
		Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));
		try
		{
			$this->getModel('Sampledata')->moveDatesForward();
		}
		catch (\Exception $ex)
		{
            $this->app->enqueueMessage($ex->getMessage(), 'error');
            $this->app->redirect('index.php?option=com_diler&view=datamanagement');
        }
        $this->app->enqueueMessage(DText::_('BUTTON_DATE_FORWARD_SUCCESS'), 'success');
        $this->app->redirect('index.php?option=com_diler&view=datamanagement');
    }

	/**
	 * Create hidden menu and menu items for the DiLer Bulletin
	 */
	public function createBulletinMenuItems()
	{
		$app = Factory::getApplication();
		try
		{
			$this->getModel('Diler')->createBulletinMenuItems();
		}
		catch (\Exception $ex)
		{
			$this->getModel('Diler')->logDataConversion($ex->getMessage());
            $app->enqueueMessage($ex->getMessage(), 'error');
			$app->redirect('index.php?option=com_diler&view=datamanagement');
		}
		$app->redirect('index.php?option=com_diler&view=datamanagement', DText::_('BUTTON_CREATE_BULLETIN_MENU_SUCCESS'), 'success');
	}

	public function createV600Groups()
	{
		$app = Factory::getApplication();
		try
		{
			$createdcount = $this->getModel('Diler')->createV600Groups();
		}
		catch (\Exception $ex)
		{
			$this->getModel('Diler')->logDataConversion($ex->getMessage());
            $app->enqueueMessage($ex->getMessage(), 'error');
			$app->redirect('index.php?option=com_diler&view=datamanagement');
		}
		$app->redirect('index.php?option=com_diler&view=datamanagement', DText::sprintf('GROUPS_CREATED', $createdcount), 'success');
	}
}
