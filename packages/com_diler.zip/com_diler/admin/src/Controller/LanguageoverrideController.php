<?php
/**
 * @copyright      Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Language\Text;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class LanguageoverrideController extends FormController
{
	public function cancel($key = null)
	{
		$this->setRedirect(
			Route::_(
				'index.php?option=' . $this->option . '&view=' . $this->view_list
				. $this->getRedirectToListAppend(), false
			)
		);

		return true;
	}

	public function checkTags()
	{
		$this->getModel()->checkTags();
		$this->app->enqueueMessage('Language tags were checked and results were logged in the following files: 
		language-check-missing-admin.php, 
		language-check-missing-site.php, 
		language-check-unused-admin.php, 
		language-check-unused-site.php');
		$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));
		$this->redirect();
	}

	public function save($key = null, $urlVar = null)
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$data = $this->input->post->get('jform', array(), 'array');
		$task = $this->getTask();

		$model = $this->getModel();
		$id    = $this->input->getUint('id');
		try
		{
			$model->saveLanguageOverride($id, $data);
		}
		catch (\Exception $e)
		{
            Factory::getApplication()->enqueueMessage( $e->getMessage(), 'error');
			Factory::getApplication()->redirect(Route::_('index.php?option=com_diler&view=languageoverrides', false));
		}
		$this->setMessage(DText::_('LANGUAGEOVERRIDES_SAVE_SUCCESS'));
		if ($task == 'save' || $task == 'cancel')
		{
			$this->setRedirect(Route::_('index.php?option=com_diler&view=languageoverrides' . $this->getRedirectToListAppend(), false));
		}
		else
		{
			$this->setRedirect(Route::_('index.php?option=com_diler&view=languageoverride&layout=edit&id=' . $id . $this->getRedirectToListAppend(), false));
		}
	}
}