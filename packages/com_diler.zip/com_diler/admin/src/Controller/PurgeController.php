<?php
/**
 * @copyright      Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Administrator\Model\DilerModel;
use Audivisa\Component\DiLer\Administrator\Model\PurgeModel;
use Audivisa\Component\DiLer\Administrator\Model\TexterModel;
use DiLer\Constants\ResponseCode;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Response\JsonResponse;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class PurgeController extends FormController
{
	public function getModel($name = 'Purge', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}

	public function deleteCalendarData()
	{
		$this->checkPermission('post');
		$model = $this->getDilerModel();
		if (!$model->deleteCalendarEvents())
			$this->redirectToPurgeView($model->getError(), 'error');

		$this->redirectToPurgeView('COM_DILER_CLEAR_DILER_CALENDAR_EVENTS');
	}

	public function purgeEventLog()
	{
		$this->checkPermission('post');
		$tillDate = $this->getTillDate();
		$model = $this->getModel();
		try
		{
			$model->purgeEventLog($tillDate);
			Factory::getApplication()->enqueueMessage(DText::sprintf('PURGE_EVENT_LOG_SUCCESS', $tillDate));
		}
		catch (\Exception $e)
		{
			$this->redirectToPurgeView($e->getError(), 'error');
		}

		$this->redirectToPurgeView();

	}

	public function deleteGridTables()
	{
		$this->checkPermission('post');
		$model = $this->getModel();
		if (!$model->deleteGridTables())
			$this->redirectToPurgeView($model->getError(), 'error');

		$this->redirectToPurgeView('COM_DILER_PURGE_GRID_TABLES');
	}

	public function deleteTexterDataDB()
	{
		/** @var TexterModel $texterModel */
		/** @var PurgeModel $model */
		$this->checkPermission('post');
		$app = Factory::getApplication();
		$texterTypes = $this->input->get('texter_type');
		$tillDate    = $this->getTillDate();
		
		if (!$texterTypes)
			return $this->redirectToPurgeView('JGLOBAL_NO_ITEM_SELECTED', 'warning');

		$texterModel = $this->getModel('Texter');
		foreach ($texterTypes as $type)
		{
			try
			{
				$texterModel->isValidTexterTypes($type);
			}
			catch (\Exception $exception)
			{
				return $this->redirectToPurgeView($exception->getMessage(), 'error');
			}
		}

		if ($texterTypes)
		{
			try {
				$model  = $this->getModel();
				$model->deleteTexterData($texterTypes, $tillDate);
				$app->enqueueMessage(DText::_('CLEAR_DILER_TEXTER_SUCCESS'));
				$dilerModel = $this->getDilerModel();
				$dilerModel->logDataAction(DText::_('BUTTON_CLEAR_DILER_TEXTER'));
			}
			catch (\Exception $exception)
			{
				$app->enqueueMessage($exception->getMessage(), 'error');
			}
		}

		return $this->redirectToPurgeView();
	}

	public function cleanCloudData()
	{
		/*** @var $model PurgeModel */
		$this->checkPermission('post');
		$model    = $this->getModel();
		$taskType = $this->input->get('taskType');
		$app = Factory::getApplication();
		try
		{
			if ($taskType == 'cleanFilesMissingDb')
			{
				$deletedFiles = $model->deleteCloudFilesMissingDbRecords();
				$app->enqueueMessage(DText::sprintf('PURGE_SUCCESSFULLY_CLEANED_CLOUD_FILES_WITHOUT_DATABASE', $deletedFiles));
			}

			if ($taskType == 'cleanDbMissingFiles')
			{
				$deletedDBRows = $model->deleteCloudDBEntriesMissingRealFile();
				$app->enqueueMessage(DText::sprintf('PURGE_SUCCESSFULLY_CLEANED_CLOUD_DATABASE_WITHOUT_FILES', $deletedDBRows));
			}
		}
		catch (\Exception $exception)
		{
			$app->enqueueMessage($exception->getMessage());
		}
		
		return $this->redirectToPurgeView();
	}

	public function deleteStudentReports()
	{
		/** @var  $model DilerModel */
		$this->checkPermission('post');
		$periodArray = $this->input->get('periodIds');
		$model = $this->getModel('Diler');
		$result = true;
		
		if ($periodArray)
			$result = $model->deleteStudentReportHistory($periodArray);
		
		if (!$result)
			$this->redirectToPurgeView($model->getError(), 'error');
			
		$this->redirectToPurgeView('COM_DILER_CLEAR_DILER_STUDENTREPORTS_SUCCESS');
	}

	public function deleteCloudData()
	{
		/*** @var $model PurgeModel */
		$this->checkPermission('post');

		$model            = $this->getModel();
		$deleteKey       = $this->input->get('deleteKeys')[0];
		$filterId         = $this->input->get('filter_id');
		$type             = $this->input->get('type');
		$getDataMethod    = 'getCloudPer' . ucfirst($type);
		$deletePerRequest = $this->input->getInt('deletePerRequest');
		$tillDate         = $this->getTillDate(true);

		$deleted = array(
			'deletedKeys'  => array(),
			'totalDeleted' => 0,
			'filterId'     => $filterId
		);

		try
		{
			$forDelete = $model->$getDataMethod($deleteKey, $tillDate, $deletePerRequest);
			foreach ($forDelete as $doDelete)
			{
				$model->deleteCloudData($doDelete['id'], $doDelete['path']);
				$deleted['totalDeleted'] += 1;
			}

			if(!$forDelete)
				$deleted['deletedKeys'][] = $deleteKey;
			
			Factory::getApplication()->enqueueMessage(
				DText::sprintf('PURGE_SUCCESS_DELETED_CLOUD_DATA', DText::_('CLOUD'))
			);

			echo new JsonResponse($deleted);

		}
		catch (\Exception $exception)
		{
			echo new JsonResponse($exception);
		}
		Factory::getApplication()->close();
	}

	public function deleteStudentRecordsGarbage()
	{
		$this->checkPermission('post');
		$app = Factory::getApplication();
		try {
			$deletedEntries = $this->getModel()->cleanStudentRecordsGarbage();
			$app->enqueueMessage(DText::sprintf('N_ITEMS_DELETED', $deletedEntries));
		} 
		catch (\Exception $exception)
		{
			$app->enqueueMessage($exception->getMessage(), 'error');
		}

		$this->redirectToPurgeView();
	}
	
	public function deleteDataWithAjax()
	{
		/*** @var $model PurgeModel */
		$this->checkPermission('post');

		$app = Factory::getApplication();
		$model            = $this->getModel();
		$deleteKeys       = $this->input->get('deleteKeys');
		$filterId         = $this->input->get('filter_id');
		$section          = $this->input->get('section');
		$type             = $this->input->get('type');
		$modelMethodName  = 'delete' . ucfirst($section) . 'By' . ucfirst($type);
		$deletePerRequest = $this->input->getInt('deletePerRequest');
		$tillDate         = $this->getTillDate(true);
		$forDelete        = array_slice($deleteKeys, 0, $deletePerRequest);

		$deleted = array(
			'deletedKeys'  => array(),
			'totalDeleted' => 0,
			'filterId'     => $filterId
		);

		try
		{
			foreach ($forDelete as $doDelete)
			{
				$totalDeleted = $model->$modelMethodName($doDelete, $tillDate);

				$deleted['totalDeleted']  += $totalDeleted;
				$deleted['deletedKeys'][] = $doDelete;
			}
			echo new JsonResponse($deleted);

		}
		catch (\Exception $exception)
		{
			echo new JsonResponse($exception);
		}

		$app->close();
	}

	public function loadFormDataForPurgeWithAjax()
	{
		/*** @var $model PurgeModel */
		$this->checkPermission('post');
		$app = Factory::getApplication();
		$model    = $this->getModel();
		$type     = $this->input->get('type');
		$section  = $this->input->get('section');
		$tillDate = $this->getTillDate(true);

		try
		{
			$modelMethodName = 'get' . ucfirst($type) . 'Per' . ucfirst($section);
			$results          = $model->$modelMethodName($tillDate);
			$preparedData = array();

			foreach ($results as $key => $result)
				$preparedData["_$key"] = $result;

			if (!$preparedData)
				$app->enqueueMessage(DText::sprintf('PURGE_NOTHING_TO_DELETE', DText::_('TRY_CHANGING_DATE_SELECTOR')), 'warning');

			echo new JsonResponse($preparedData);
		}
		catch (\Exception $exception)
		{
			echo new JsonResponse($exception);
		}
		$app->close();
	}

	private function redirectToPurgeView($msg ="", $type = 'success')
	{
		$this->setRedirect("index.php?option=$this->option&view=$this->view_item", Text::_($msg), $type);
		$this->redirect();
	}

	private function checkPermission($formMehod = 'get')
	{
		$this->checkToken($formMehod);
		if (!Factory::getApplication()->getIdentity()->authorise('core.admin'))
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		return true;
	}

	private function getDilerModel()
	{
		return MVCHelper::factory()->createModel("Diler", "Administrator");
	}

	private function getTillDate(bool $isJson = false)
	{
		$tillDate = $this->input->getString('purgeTillDate', '');
		if (!$tillDate)
		{
			Factory::getApplication()->enqueueMessage(DText::_('ERROR_PURGE_TILL_DATE_EMPTY'), 'error');
			
			if (!$isJson)
				$this->redirectToPurgeView();

			echo new JsonResponse(null, DText::_('ERROR_PURGE_TILL_DATE_EMPTY'), true);
			Factory::getApplication()->close();
		}
		$tillDateStandardFormat = Factory::getDate($tillDate)->toSql();

		return $tillDateStandardFormat;
	}

}