<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Router\Router;
use Joomla\Input\Input;

class DisplayController extends BaseController
{
	protected $default_view = 'dilers';

	public function __construct($config = array(), MVCFactoryInterface $factory = null, ?CMSApplication $app = null, ?Input $input = null)
	{
		parent::__construct($config, $factory, $app, $input);
		if ($this->input->get('view') == 'datamanagement')
		{
			$this->setRedirect(Route::_('index.php?option=com_diler&task=datamanagement.display', false));
			$this->redirect();
		}
	}

	public function display($cachable = false, $urlparams = array())
	{
		$input = $this->input;
		$input->set('view', $input->get('view', $this->default_view));
		parent::display();
	}
}
