<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_diler
 *
 * @copyright Copyright (C) 2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\AdminController;

/**
 * Log Events list controller class.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_diler
 * @since       1.6
 */
class LogEventsController extends AdminController
{
	protected $text_prefix = 'COM_DILER';

	public function getModel($name = 'Activity', $prefix = 'Administrator', $config = [])
	{
		$model = parent::getModel($name, $prefix, $config);

		return $model;
	}
}
