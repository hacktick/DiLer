<?php
/**
 * DiLer default controller
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Factory;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

// import Joomla controllerform library

\JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');

/**
 * DiLer Controller class
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DilerController extends FormController
{
	public function checkDbSchema()
	{
		Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		try
		{
			$checkDbSchema = $this->getModel('Diler')->checkDbSchema();
		}
		catch (\Exception $ex)
		{
            $app->enqueueMessage($ex->getMessage(), 'error');
			$app->redirect('index.php?option=com_diler&view=datamanagement');
		}
        $app->enqueueMessage( DText::_('CHECK_DATABASE_SCHEMA_SUCCESS'), 'success');
		$app->redirect('index.php?option=com_diler&view=datamanagement');
	}

	public function createSampleDb()
	{
		Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		$options['password'] = $app->input->getString('sample_password');
		try
		{
			MVCHelper::factory()->createModel('Sampledata', 'Administrator')->createSampleDb($options);
		}
		catch (\Exception $ex)
		{
			$app->redirect('index.php?option=com_diler&view=datamanagement', $ex->getMessage(), 'error');
		}
		$message = DText::_('BUTTON_SAMPLE_DATA_SUCCESS');
		if ($options['password'])
		{
			$message .= '</br>' . DText::sprintf('SAMPLE_DATA_PASSWORD', $options['password']);
		}
        $app->enqueueMessage($message, 'success');
		$app->redirect('index.php?option=com_diler&view=datamanagement');
	}

	public function moveDatesForward()
	{
		Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));
		$app = Factory::getApplication();
		try
		{
			MVCHelper::factory()->createModel('Sampledata', 'Site')->moveDatesForward();
		}
		catch (\Exception $ex)
		{
            $app->enqueueMessage($ex->getMessage(), 'error');
			$app->redirect('index.php?option=com_diler&view=datamanagement' );
		}
        $app->enqueueMessage( DText::_('BUTTON_DATE_FORWARD_SUCCESS'), 'success');
		$app->redirect('index.php?option=com_diler&view=datamanagement');
	}

	/**
	 * Create hidden menu and menu items for the DiLer Bulletin
	 */
	public function createBulletinMenuItems()
	{
		$app = Factory::getApplication();
		try
		{
			$result = $this->getModel('Diler')->createBulletinMenuItems();
		}
		catch (\Exception $ex)
		{
			$this->getModel('Diler')->logDataConversion($ex->getMessage());
            $app->enqueueMessage( $ex->getMessage(), 'error');
			$app->redirect('index.php?option=com_diler&view=datamanagement');
		}
        $app->enqueueMessage( DText::_('BUTTON_CREATE_BULLETIN_MENU_SUCCESS'), 'success');
		$app->redirect('index.php?option=com_diler&view=datamanagement');
	}

	/**
	 * Create groups for V600 initial conversion
	 */
	public function createV600Groups()
	{
		$app = Factory::getApplication();
		try
		{
			$createdcount = $this->getModel('Diler')->createV600Groups();
		}
		catch (\Exception $ex)
		{
			$this->getModel('Diler')->logDataConversion($ex->getMessage());
            $app->enqueueMessage( $ex->getMessage(), 'error');
			$app->redirect('index.php?option=com_diler&view=datamanagement');
		}
        $app->enqueueMessage(DText::sprintf('GROUPS_CREATED', $createdcount), 'success');
		$app->redirect('index.php?option=com_diler&view=datamanagement');
	}

	public function switchSchoolYear()
	{
		Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));
		try
		{
			/** @var DiLerModelDatamanagement $dataManagementModel */
			$dataManagementModel = $this->getModel('Datamanagement');
			$dataManagementModel->updateStudentActualAndTargetPhases();
			$this->setMessage(DText::_('SUCCESSFULLY_SWITCHED_SCHOOL_YEAR'));
		}
		catch (\Exception $ex)
		{
			$this->getModel('Diler')->logDataConversion($ex->getMessage());
			$this->setMessage($ex->getMessage(), 'error');
		}

		$this->setRedirect('index.php?option=com_diler&view=datamanagement');
	}
}