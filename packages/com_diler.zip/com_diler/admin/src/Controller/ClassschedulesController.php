<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Router\Route;

defined('_JEXEC') or die('Restricted access');

class ClassschedulesController extends AdminController
{
	public function getModel($name = 'Classschedule', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}

	public function setDefault()
	{
		$ids     = $this->input->get('cid', [], 'array');
		$ids     = ArrayHelper::toInteger($ids);
		$id = $ids[0];
		$task    = $this->input->get('task');
		$current = ($task == 'setDefault') ? 1 : 0;
		$this->getModel('Classschedules')->setDefaultSchedule($id);
		$this->setRedirect(Route::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));
	}
}
