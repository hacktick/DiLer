<?php
/**
 * @copyright      Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Controller;

use Audivisa\Component\DiLer\Administrator\Model\SchoolyearModel;
use DiLer\Lang\DText;
use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\Input\Input;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Router\Route;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SchoolyearsController extends AdminController
{
	public function __construct($config = array(), MVCFactoryInterface $factory = null, ?CMSApplication $app = null, ?Input $input = null)
	{
		parent::__construct($config, $factory, $app, $input);
		$this->registerTask('unsetDefault', 'setDefault');
	}

	public function getModel($name = 'Schoolyear', $prefix = 'Administrator', $config = [])
	{
		return parent::getModel($name, $prefix, $config);
	}

	public function setDefault()
	{
		$ids     = $this->input->get('cid', [], 'array');
		$ids     = ArrayHelper::toInteger($ids);
		$task    = $this->input->get('task');
		$current = ($task == 'setDefault') ? 1 : 0;
		/** @var SchoolyearModel $model */
		$model = $this->getModel();
		$model->setDefault($ids, $current);

		if ($current == 1)
			$message = DText::sprintf('N_SCHOOLYEARS_CURRENT', count($ids), DText::_('SCHOOLYEAR'));
		else
			$message = DText::plural('N_SCHOOLYEARS_UNCURRENT', count($ids), DText::_('SCHOOLYEAR'));

		$this->setRedirect(Route::_('index.php?option=com_diler&view=schoolyears', false), $message);
	}

}
