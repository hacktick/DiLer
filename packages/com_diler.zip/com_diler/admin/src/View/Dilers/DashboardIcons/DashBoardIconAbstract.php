<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons;

use Joomla\CMS\Uri\Uri;

\defined('_JEXEC') or die;


abstract class DashBoardIconAbstract
{
	public abstract function render() : string;

	protected function getIconPath(string $iconName)
	{
		return Uri::root() . 'media/com_diler/administrator/images/48x48/' . $iconName . '.png';
	}

	protected function getLink($url, $iconPath, $label)
	{
		return
		'<div class="col-sm-3 mb-3">
			<a href="' . $url . '">
				<div class="card text-dark bg-light h-100">
					<div class="card-body text-center">
						<img class="" src="' . $iconPath . '" alt="' . $label . '" />
						<div class="card-title">' . $label . '</div>
					</div>
				</div>
			</a>
		</div>';
	}
}
