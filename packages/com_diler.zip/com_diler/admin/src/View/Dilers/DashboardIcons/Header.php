<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons;

\defined('_JEXEC') or die;

class Header extends DashBoardIconAbstract
{
	private string $label;

	public function __construct($label)
	{
		$this->label = $label;
	}

	public function render() : string
	{
		return $this->label;
	}
}
