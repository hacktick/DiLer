<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons;

\defined('_JEXEC') or die;


class GroupedIcons
{
	/** @var  DashBoardIconAbstract[] */
	protected $icons = array();
	private Header $header;

	public function __construct(Header $group)
	{
		$this->header = $group;
	}

	public function add(DashBoardIconAbstract $icon)
	{
		$this->icons[] = $icon;
	}

	public function render()
	{
		echo "<h1>" . $this->header->render() . "</h1>";
		echo '<div class="row">';

		foreach ($this->icons as $icon)
			echo $icon->render();

		echo '</div>';
	}
}
