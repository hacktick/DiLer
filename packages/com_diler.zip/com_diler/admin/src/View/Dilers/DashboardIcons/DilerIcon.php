<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons;

use Joomla\CMS\Router\Route;
defined('_JEXEC') or die;

class DilerIcon extends DashBoardIconAbstract
{
	private string $label;
	private string $iconPath;
	private string $url;

	public function __construct(string $label, string $iconName, string $view)
	{
		$this->label    = $label;
		$this->iconPath = $this->getIconPath($iconName);
		$this->url = Route::_('index.php?option=com_diler&view=' . $view, false);
	}

	public function render() : string
	{
		return $this->getLink($this->url, $this->iconPath, $this->label);
	}
}
