<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons;

\defined('_JEXEC') or die;

use Joomla\CMS\Router\Route;

class JoomlaCategoryLink extends DashBoardIconAbstract
{
	private string $iconPath;
	private string $label;
	private string $url;

	public function __construct(string $label, string $iconName, string $extension)
	{
		$this->iconPath  = $this->getIconPath($iconName);
		$this->label     = $label;
		$this->url = Route::_('index.php?option=com_categories&extension=' . $extension, false);
	}

	public function render() : string
	{
		return $this->getLink($this->url, $this->iconPath, $this->label);
	}
}
