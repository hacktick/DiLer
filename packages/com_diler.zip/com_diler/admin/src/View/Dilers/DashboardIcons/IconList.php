<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

\defined('_JEXEC') or die;


class IconList implements \IteratorAggregate
{
	/** @var  GroupedIcons[] */
	protected $icons = array();

	public function add(GroupedIcons $groupedIconList)
	{
		$this->icons[] = $groupedIconList;
	}

	/**
	 * @return GroupedIcons[]
	 */
	public function getIterator()
	{
		return new \ArrayIterator($this->icons);
	}
}
