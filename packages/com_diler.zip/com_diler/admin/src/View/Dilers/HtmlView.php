<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\View\Dilers;

\defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\CachedNews;
use Audivisa\Component\DiLer\Administrator\Helper\Diglu;
use Audivisa\Component\DiLer\Administrator\Helper\DiLerToolbarHelper;
use Audivisa\Component\DiLer\Administrator\Helper\FileRootFolder;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Audivisa\Component\DiLer\Administrator\Model\DiLersModel;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\DilerIcon;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\DilerregIcon;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\ExternalLink;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\GroupedIcons;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\Header;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\IconList;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\JoomlaCategoryLink;
use Audivisa\Component\DiLer\Administrator\View\Dilers\DashboardIcons\None;
use DiLer\DConst;
use DiLer\Lang\DText;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use DilerHelperUser;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Document\Document;

class HtmlView extends BaseHtmlView implements DiLerAdministratorViewInterface
{
	private $versionInfo;

	public function display($tpl = null)
	{
		Factory::getApplication()->getLanguage()->load('com_dilerreg', JPATH_ROOT . '/administrator/components/com_dilerreg', null, true);

		/** @var DiLersModel $model */
		$model = $this->getModel();
		$this->versionInfo = $model->getPackageVersionInfo();

		$this->addToolBar();
		$document = new Document();
		$this->setDocument($document);

		$this->displayErrorWarningIfNotUsingMinimumRequiredPHP();
		$this->displayErrorIfNotUsingMinimumJoomlaVersion();

		parent::display($tpl);
	}

	private function displayErrorWarningIfNotUsingMinimumRequiredPHP() : void
	{
		if(version_compare(PHP_VERSION, DConst::MINIMUM_REQUIRED_PHP_VERSION, 'lt'))
			Factory::getApplication()->enqueueMessage(DText::sprintf('PHP_VERSION_REQUIERED', DConst::MINIMUM_REQUIRED_PHP_VERSION), CMSApplicationInterface::MSG_ERROR);
	}

	private function displayErrorIfNotUsingMinimumJoomlaVersion() : void
	{
		$versionRequired =  $this->versionInfo->minimum_joomla_version;
		if (version_compare(JVERSION, $versionRequired, 'lt'))
			Factory::getApplication()->enqueueMessage(DText::sprintf('JOOMLA_VERSION_REQUIERED', $versionRequired), CMSApplicationInterface::MSG_ERROR);
	}

	protected function addToolBar()
	{
		ToolbarHelper::title('', '');

		if (AccessHelper::getActions()->get('core.admin'))
		{
			ToolbarHelper::preferences('com_diler');
			ToolbarHelper::divider();
			DiLerToolbarHelper::addPermissionsToolbarButton();
		}
		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	public function helpName(): string
	{
		return 'Dilers';
	}

	public function setDocument(Document $document): void
	{
		$this->document = $document;
		$this->document->setTitle(DText::_('DASHBOARD') . ' - ' . DText::_('DASHBOARD'));
	}

	public function icons() : IconList
	{
		$config = Factory::getApplication()->getConfig();
		$tmp_path = $config->get('tmp_path');
		$diglu = new Diglu();
        $isDiglu = $diglu->isEnabled();
		$icons = new DashboardIcons\IconList;
		$regions = $isDiglu ? new DilerIcon(DText::_('REGIONS'), 'schoolyears', 'regions') : new None();
		$contractTypes = $isDiglu ? new DilerIcon(DText::_('CONTRACTTYPES'), 'reports', 'reporttypes&contract=1'): new None();
		$ministries = $isDiglu ? new DilerIcon(DText::_('MINISTRIES'), 'schoolyears', 'ministries') : new None();

		$wiki = new None();
		if (is_dir(str_replace("tmp", "wiki", $tmp_path)))
			$wiki = new ExternalLink(DText::_('WIKI_ADMIN'), 'wiki', Uri::root() . '/wiki');

		$userManagement = new GroupedIcons(new Header(DText::_('DASHBOARD_HEADING_USER_MANAGEMENT')));
		$userManagement->add(new JoomlaCategoryLink(DText::_('RELATIONSHIPS'), 'subject-categories', 'com_diler.relationships'));
		$userManagement->add(new DilerregIcon(Text::_('COM_DILERREG_REGISTRATION_CODES'), 'usercodes', 'codes'));
		$userManagement->add(new DilerregIcon(Text::_('COM_DILERREG_USERS'), 'users', 'users'));

		$administration = new GroupedIcons(new Header(DText::_('DASHBOARD_HEADING_ADMINISTRATION')));
		$administration->add(new DilerIcon(DText::_('MARKS_PERIODS'), 'marksperiods', 'marksperiods'));
		$administration->add(new DilerIcon(DText::_('CLASS_SCHEDULES'), 'classschedules', 'classschedules'));
		$administration->add(new DilerIcon(DText::_('SCHOOLYEARS'), 'schoolyears', 'schoolyears'));
		$administration->add(new JoomlaCategoryLink(
			DText::sprintf('GROUP_CATEGORIES', DText::_('GROUPS_PLURAL')), 'subject-categories', 'com_diler.group'
		));
		$administration->add(new JoomlaCategoryLink(
			DText::_('STUDENTRECORD_CATEGORIES'), 'subject-categories', 'com_diler.studentrecord'
		));
		$administration->add(new JoomlaCategoryLink(
			DText::sprintf('GROUP_CATEGORIES', DText::_('MEDIA')), 'subject-categories', 'com_diler.cloud'
		));
		$administration->add($contractTypes);
		$administration->add(new DilerIcon(DText::_('REPORTTYPES'), 'reports', 'reporttypes'));
		$administration->add(new DilerIcon(DText::_('REPORTPERIODS'), 'reportperiods', 'reportperiods'));
		$administration->add(new DilerIcon(DText::_('REPORTFIELDS'), 'reportfields', 'reportfields'));
		$administration->add($wiki);

		$educationalContents = new GroupedIcons(new Header(DText::_('DASHBOARD_HEADING_CONTENT')));
		$educationalContents->add(new DilerIcon(DText::_('SECTIONS'), 'sections', 'sections'));
		$educationalContents->add(new DilerIcon(DText::_('PHASES'), 'phases', 'phases'));
		$educationalContents->add(new DilerIcon(DText::_('LEVELS'), 'levels', 'levels'));
		$educationalContents->add(new JoomlaCategoryLink(
			DText::sprintf('SUBJECT_CATEGORIES', DText::_('SUBJECTS')), 'subject-categories', 'com_diler'
		));
		$educationalContents->add(new DilerIcon(DText::_('SUBJECTS'), 'subjects', 'subjects'));
		$educationalContents->add(new DilerIcon(DText::_('COMPETENCES'), 'competences', 'competences'));
		$educationalContents->add(new DilerIcon(DText::_('COMPCHARS'), 'compchar', 'compchars'));
		$educationalContents->add(new DilerIcon(DText::_('ACTIVITY_TYPES'), 'activities', 'activitytypes'));
		$educationalContents->add(new DilerIcon(DText::_('GRADING_METHODS'), 'grading', 'gradingmethods'));

		$system = new GroupedIcons(new Header(DText::_('DASHBOARD_HEADING_SYSTEM')));
		$system->add(new DilerIcon(DText::_('COUNTRIES'), 'countries', 'countries'));
		$system->add($ministries);
		$system->add($regions);
		$system->add(new DilerIcon(DText::_('SCHOOLS'), 'schoolyears', 'schools'));
		$system->add(new DilerIcon(DText::_('LANGUAGEOVERRIDES'), 'languages', 'languageoverrides'));
		$system->add(new DilerIcon(DText::_('LOG_EVENTS_LOG'), 'log', 'logevents'));
		$system->add(new DilerIcon('System Information', 'tasks', 'systeminformation'));

		if (Factory::getApplication()->getIdentity()->authorise('core.admin'))
		{
			$system->add(new DilerIcon(DText::_('DATA_MANAGEMENT'), 'datamanagement', 'datamanagement'));
			$system->add(new DilerIcon(DText::_('PURGEDATA'), 'purge', 'purge'));

            if ($isDiglu)
                $system->add(new DilerIcon(DText::_('DIGLUG_INVALID_USERS'), 'users', 'digluInvalidUsers'));
		}

		$icons->add($userManagement);
		$icons->add($administration);
		$icons->add($educationalContents);
		$icons->add($system);

		return $icons;
	}

	public function installedVersion() : string
	{
		return DText::sprintf('EDITION_' . $this->versionInfo->diler_edition, $this->dilerVersion());
	}

	public function latestVersion(): string
	{
		/** @var DiLersModel $model */
		$model = $this->getModel();
		$dilerUpdateVersion = $model->dilerUpdateVersion();
		$versionInfo = $this->versionInfo;
		$dilerInstalledEdition = $versionInfo->diler_edition;

		if($dilerUpdateVersion)
			return DText::sprintf('EDITION_' . $versionInfo->diler_edition, $dilerUpdateVersion) .
				' <a href="index.php?option=com_installer&view=update"><span class="label label-info">' .
					DText::_('UPDATE_AVAILABLE') .
				'</span></a>';

		return DText::sprintf('EDITION_' . $dilerInstalledEdition, $this->dilerVersion());
	}

	public function isMediaFolderWritable() : string
	{
		return $this->getIsWriableOrNotWritableHtml(FileRootFolder::isWritable());
	}

	public function isCacheFolderWritable() : string
	{
		return $this->getIsWriableOrNotWritableHtml(CachedNews::isWritable());
	}

	private function getIsWriableOrNotWritableHtml(bool $isWriable) : string
	{
		if ($isWriable)
			return 	'<span class="text-success">' . DText::_('WRITABLE') . '</span>';

		return '<span class="text-danger">' . DText::_('WRITABLE_NO') . '</span>';
	}

	public function dilerVersion() : string
	{
		return $this->versionInfo->diler_version;
	}

	public function includeChangeLogFrontend()
	{
		return include JPATH_COMPONENT . '/language/de-DE/changelog-frontend.php';
	}

	public function includeChangeLogBackend()
	{
		return include JPATH_COMPONENT . '/language/de-DE/changelog-backend.php';
	}

	public function mediaPath() : string
	{
		return ComponentHelper::getParams('com_diler')->get('file_root_folder', '');
	}

	public function bulletInCachePath()
	{
		return 'cache/com_diler';
	}
}