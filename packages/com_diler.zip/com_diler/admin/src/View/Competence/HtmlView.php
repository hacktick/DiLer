<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Competence;
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\View\DiLerFormView;

class HtmlView extends DiLerFormView
{
	public function helpName(): string
	{
		return 'Competence';
	}

	protected function itemId()
	{
		return $this->item->id;
	}
}