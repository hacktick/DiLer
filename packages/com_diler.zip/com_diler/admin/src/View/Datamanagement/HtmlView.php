<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Datamanagement;
use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\DiLerToolbarHelper;
use Audivisa\Component\DiLer\Administrator\Helper\FileRootFolder;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Audivisa\Component\DiLer\Administrator\Model\DilerModel;
use Audivisa\Component\DiLer\Administrator\Model\SampledataModel;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use DiLer\DDateTime;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use DiLer\Constants\ResponseCode;
use Joomla\CMS\MVC\View\HtmlView as JoomlaHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
\JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');
\JLoader::register('DiLerHelper', JPATH_ROOT . '/administrator/components/com_diler/helpers/diler.php');

class HtmlView extends JoomlaHtmlView implements DiLerAdministratorViewInterface
{
	protected $canDo;
	public $lastSchoolYearSwitchDate;

	public function display($tpl = null)
	{
		if (!Factory::getApplication()->getIdentity()->authorise('core.admin'))
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		$this->mediaPathWriteable = FileRootFolder::isWritable();
		$this->rootFileFolder = FileRootFolder::getPath();
		/** @var DilerModel $dilerModel */
		$dilerModel = $this->getModel('Diler');
		$this->dilerTables = $dilerModel->getDilerTables();
		$this->reportPeriods = \DiLerHelper::getActiveStudentReportPeriods();
		$this->statusForm = $this->get('StatusForm');
		$this->groupsExist = $this->get('GroupsExist');
		$this->bulletinTemplateStyles = $this->get('BulletinTemplateStyles');
		$this->bulletinMenuItems = $this->get('BulletinMenuItems');
		/** @var SampledataModel $sampleDataModel */
		$sampleDataModel = $this->getModel('Sampledata');
		$this->dateInfoArray = $sampleDataModel->getDbAgeInfo();
		$this->lastSchoolYearSwitchDate = $this->get('LastSchoolYearSwitch');

		$this->canDo = AccessHelper::getActions();

		$this->addToolBar();

		parent::display($tpl);
	}

	protected function addToolBar()
	{
		ToolbarHelper::title(DText::_('DATA_MANAGEMENT'), 'datamanagement');

		if ($this->canDo->get('core.admin'))
		{
			ToolbarHelper::preferences('com_diler');
			ToolbarHelper::divider();
			DiLerToolbarHelper::addPermissionsToolbarButton();
		}
		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	public function getFormattedDateOfLastSchoolSwitch() : string
	{
		return $this->lastSchoolYearSwitchDate ? DDateTime::DilerDateLC2($this->lastSchoolYearSwitchDate) : DText::_("NEVER");
	}

	public function isSwitchSchoolYearEnabled()
	{
		$model = $this->getModel();
		return $model->isHighestPhaseSet();
	}

	public function getSwitchSchoolYearModalDescriptionText() : string
	{
		$areYouSureYouWantToChangeSchoolYear = DText::_('ARE_YOU_SURE_YOU_WANT_TO_SWITCH_SCHOOL_YEAR');
		if (!$this->lastSchoolYearSwitchDate)
			return $areYouSureYouWantToChangeSchoolYear;

		if (Factory::getDate($this->lastSchoolYearSwitchDate)->year == Factory::getDate()->year)
			return '<div class="alert alert-error">' . DText::_('SCHOOL_YEAR_ALREDY_SWITCHED_THIS_YEAR') . '</div>';

		return $areYouSureYouWantToChangeSchoolYear;
	}

	public function helpName(): string
	{
		return 'Data Management';
	}
}
