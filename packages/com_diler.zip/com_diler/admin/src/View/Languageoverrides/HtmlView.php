<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Languageoverrides;
use Audivisa\Component\DiLer\Administrator\View\DiLerListViewAbstract;
use DiLer\Lang\DText;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Toolbar\Toolbar;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends DiLerListViewAbstract
{
	protected function addToolBar()
	{
		ToolbarHelper::title(DText::_('LANGUAGEOVERRIDES'), 'icon-flag');

		if ($this->canDo->get('core.admin'))
		{
			$bar = Toolbar::getInstance();
			$bar->confirmButton('check_language_tags', DText::_('LANGUAGE_TAG_CHECK'), 'languageoverride.checkTags')
			->message(DText::_('LANGUAGE_TAG_CHECK_MESSAGE'))->icon('icon-search');
		}
	}

    public function helpName(): string
    {
        return 'Language_Overrides';
    }

    protected function toolbarTitle(): string
    {
        return DText::_('LANGUAGEOVERRIDES');
    }
}