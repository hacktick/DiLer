<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Subjects;
use Audivisa\Component\DiLer\Administrator\View\DiLerListViewAbstract;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends DiLerListViewAbstract
{
	protected function addToolbar()
	{
		$canDo = $this->canDo;
		$user  = Factory::getUser();

		$bar = Toolbar::getInstance();

		$viewName         = $this->getName();
		$singularViewName = \Joomla\String\Inflector::getInstance()->toSingular($viewName);

		ToolbarHelper::title(Text::_($this->toolbarTitle), $this->toolbarIcon);

		if ($canDo->get('core.create'))
		{
			ToolbarHelper::addNew($singularViewName . '.add');
		}

		if (($canDo->get('core.edit')) || ($canDo->get('core.edit.own')))
		{
			ToolbarHelper::editList($singularViewName . '.edit');
		}

		if ($canDo->get('core.edit.state'))
		{
			ToolbarHelper::publish($viewName . '.publish', 'JTOOLBAR_PUBLISH', true);
			ToolbarHelper::unpublish($viewName . '.unpublish', 'JTOOLBAR_UNPUBLISH', true);

			ToolbarHelper::checkin($viewName . '.checkin');
		}

		if ($user->authorise('core.create', $this->option)
			&& $user->authorise('core.edit', $this->option)
			&& $user->authorise('core.edit.state', $this->option))
		{
			$bar->popupButton('batch')
				->text('JTOOLBAR_BATCH')
				->selector('collapseModal')
				->listCheck(true);
		}

		if ($this->state->get('filter.published') == -2 && $canDo->get('core.delete'))
		{
			ToolbarHelper::deleteList('JGLOBAL_CONFIRM_DELETE', $viewName . '.delete', 'JTOOLBAR_EMPTY_TRASH');
		}
		elseif ($canDo->get('core.edit.state'))
		{
			ToolbarHelper::trash($viewName . '.trash');
		}

		if ($user->authorise('core.admin', $this->option) || $user->authorise('core.options', $this->option))
		{
			ToolbarHelper::preferences($this->option);
		}

		if ($this->helpLink)
		{
			ToolbarHelper::help($this->helpLink);
		}
	}

	public function helpName(): string
    {
        return 'Subjects';
    }

    protected function toolbarTitle(): string
    {
        return DText::_('SUBJECTS');
    }
}