<?php
/**
 * @copyright  Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View;

use Audivisa\Component\DiLer\Administrator\Helper\Diglu;
use Audivisa\Component\DiLer\Administrator\Helper\DilerVersion;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Router\Route as JRoute;


// No direct access to this file
defined('_JEXEC') or die('Restricted access');

abstract class DilerListViewWithImportsAbstract extends DiLerListViewAbstract
{
	protected bool $isDiglu;
	protected bool $doesHaveExtendedFeatures;

	public function __construct(array $config)
	{
		parent::__construct($config);
		$this->diglu = isset($config['diglu']) ? $config['diglu'] : new Diglu;
		$this->isDiglu = $this->diglu->isEnabled();
		$this->doesHaveExtendedFeatures = DilerVersion::doesHaveExtendedFeatures();
	}

	protected function addToolBar()
	{
		$viewName = $this->getName();
		$headerTitle = strtoupper($viewName);
		$singularViewName = \Joomla\String\Inflector::getInstance()->toSingular($viewName);
		ToolbarHelper::title(DText::_($headerTitle), $singularViewName);

		if ($this->canDo->get('core.create'))
		{
			ToolbarHelper::addNew($singularViewName . '.add');
		}

		if ($this->canDo->get('core.edit'))
		{
			ToolbarHelper::editList($singularViewName . '.edit');
		}

		if ($this->canDo->get('core.edit.state'))
		{
			ToolbarHelper::publish($viewName . '.publish', 'JTOOLBAR_PUBLISH', true);
			ToolbarHelper::unpublish($viewName . '.unpublish', 'JTOOLBAR_UNPUBLISH', true);
		}

		if ($this->state->get('filter.published') == -2 && $this->canDo->get('core.delete'))
		{
			ToolbarHelper::deleteList(Dtext::_('WARNING_DELETE_SCHOOL'), $viewName . '.delete', 'JTOOLBAR_EMPTY_TRASH');
		}
		elseif ($this->canDo->get('core.delete'))
		{
			ToolbarHelper::trash($viewName . '.trash');
		}

		ToolbarHelper::checkin($viewName . '.checkin');

		$bar        = Toolbar::getInstance();
		if ($this->canDo->get('core.create'))
		{
			$dropdown = $bar->dropdownButton('import-group')
				->text('COM_DILER_IMPORT')
				->toggleSplit(false)
				->icon('icon-ellipsis-h')
				->buttonClass('btn btn-action');

			/** @var Toolbar $childBar */
			$childBar = $dropdown->getChildToolbar();

			$this->addOpenModalToolbarButton($childBar, 'COM_DILERREG_CHECK_LABEL', 'checkImportModal');

			$this->addToolbarOpenViewLogFileInModal($childBar, 'check-log', 'COM_DILERREG_IMPORT_VIEW_CHECK_LOG', 'checkImportLogModal');

			$this->addOpenModalToolbarButton($childBar, 'COM_DILERREG_IMPORT_LABEL', 'importModal');

			$this->addToolbarOpenViewLogFileInModal($childBar, 'import-log', 'COM_DILERREG_IMPORT_VIEW_IMPORT_LOG', 'importLogModal');
			$this->addToolbarOpenViewLogFileInModal($childBar, 'rejects', 'COM_DILERREG_IMPORT_VIEW_REJECTS', 'rejectsLogModal');

			$childBar->linkButton('example')
				->text('COM_DILERREG_IMPORT_DOWNLOAD_SAMPLE_FILE')
				->icon('icon-download')
				->url('index.php?option=com_diler&task=import.downloadFile&fileType=sample&view=' . $viewName);
		}
	}

	private function addOpenModalToolbarButton(Toolbar $childBar, $text, $selector)
	{
		$childBar->popupButton()
			->text($text)
			->selector($selector);
	}

	private function addToolbarOpenViewLogFileInModal(Toolbar $childBar, $type, $text, $selector)
    {
        $input = Factory::getApplication()->input;
        $modalDownloadUrl = '';
        $view = $input->get('view');

        if ($view === 'regions') {
        if ($selector === 'importLogModal')
            $modalDownloadUrl = 'index.php?option=com_diler&amp;task=import.downloadFile&amp;fileType=import-log&amp;view=regions';

        if ($selector === 'checkImportLogModal')
            $modalDownloadUrl = 'index.php?option=com_diler&amp;task=import.downloadFile&amp;fileType=check-log&amp;view=regions';

        if ($selector === 'rejectsLogModal')
            $modalDownloadUrl = 'index.php?option=com_diler&amp;task=import.downloadFile&amp;fileType=rejects&amp;view=regions';
        }

        if ($view === 'schools') {
            if ($selector === 'importLogModal')
                $modalDownloadUrl = 'index.php?option=com_diler&amp;task=import.downloadFile&amp;fileType=import-log&amp;view=schools';

            if ($selector === 'checkImportLogModal')
                $modalDownloadUrl = 'index.php?option=com_diler&amp;task=import.downloadFile&amp;fileType=check-log&amp;view=schools';

            if ($selector === 'rejectsLogModal')
                $modalDownloadUrl = 'index.php?option=com_diler&amp;task=import.downloadFile&amp;fileType=rejects&amp;view=schools';
        }

        $downloadButton =
            '<a class="btn btn-success" href="' . JRoute::_($modalDownloadUrl) . '">Download</a>';

        $closeModalButton =
            '<button class="btn btn-secondary" data-bs-dismiss="modal" type="button"' .
            ' onclick="window.parent.Joomla.Modal.getCurrent().close();">'
            . Text::_('JCLOSE') .
            '</button>';

        $childBar->popupButton()
            ->url($this->baseurl . '/index.php?option=' . $this->option . '&view=' . $this->getName() . '&task=import.displayFile&type=' . $type . '&tmpl=component')
            ->text($text)
            ->selector($selector)
            ->footer($closeModalButton . $downloadButton);
    }




	public function getCheckImportModal(){
		$title = Text::sprintf('COM_DILERREG_CHECK_LABEL', Text::_('COM_DILERREG'), Text::_('COM_DILERREG_IMPORT_FILE'));
		$modalId = 'checkImportModal';
		if (!$this->doesHaveExtendedFeatures)
			return $this->featuresNotAvailableModal($modalId, $title);

		return HTMLHelper::_(
			'bootstrap.renderModal', $modalId,
			[
				'title'  => $title,
				'footer' => $this->loadTemplate('import_check_footer')
			],
			$this->loadTemplate('import_check_body'));
	}

	public function getImportModal()
	{
		$title = Text::sprintf('COM_DILERREG_IMPORT_LABEL', Text::_('COM_DILERREG'));
		$modalId = "importModal";
		if (!$this->doesHaveExtendedFeatures)
			return $this->featuresNotAvailableModal($modalId, $title);

		return HTMLHelper::_(
			'bootstrap.renderModal',
			$modalId,
			[
				'title'  => $title,
				'footer' => $this->loadTemplate('import_footer')
			],
			$this->loadTemplate('import_body'));
	}

	private function featuresNotAvailableModal($modalName, $title)
	{
		return HTMLHelper::_(
			'bootstrap.renderModal',
			$modalName,
			[
				'title'  => $title,
				'footer' => $this->loadTemplate('feature_not_available_footer')
			],
			$this->loadTemplate('feature_not_available_body'));
	}
}