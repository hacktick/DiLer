<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\DigluInvalidUsers;
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\View\DiLerListViewAbstract;

class HtmlView extends DiLerListViewAbstract
{
    public function helpName(): string
	{
		return 'Diglu_invalid_users';
	}

    protected function toolbarTitle(): string
    {
        return "Invalid Users";
    }

    protected function addToolbar()
    {
        return;
    }
}