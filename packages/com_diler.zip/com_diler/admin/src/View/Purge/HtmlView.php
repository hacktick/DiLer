<?php
/**
 * @copyright  Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Purge;
use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\DiLerToolbarHelper;
use Audivisa\Component\DiLer\Administrator\Helper\FileRootFolder;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as JoomlaHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Uri\Uri;
use DiLer\Constants\ResponseCode;
use Joomla\CMS\Document\Document;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends JoomlaHtmlView implements DiLerAdministratorViewInterface
{
	protected $canDo;
	protected $form;
	protected $usersRoles = array();
	protected $cloudCategoryForm;
	protected $deleteByCategories;
	protected $deleteByUsersText;
	protected $calendarTables;

	function display($tpl = null)
	{
		if (!Factory::getApplication()->getIdentity()->authorise('core.admin'))
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		Factory::getApplication()->getLanguage()->load('com_diler', JPATH_SITE . '/components/com_diler');
		\JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
		\JLoader::register('DilerHelper', JPATH_ROOT . '/administrator/components/com_diler/helpers/diler.php');
		$dilerModel = MVCHelper::factory()->createModel('Diler', 'Administrator');
		$texterModel = MVCHelper::factory()->createModel('Texter', 'Administrator');
		$model      = $this->getModel();

		$this->form              = $this->getForm();
		$this->cloudCategoryForm = $this->get('cloudCategoryForm');

		$this->rootFileFolder = FileRootFolder::getPath();
		$this->reportPeriods  = \DiLerHelper::getActiveStudentReportPeriods();
		$this->texterTypes    = $texterModel->getTexterTypes();
		$this->canDo          = AccessHelper::getActions();
		$this->usersRoles     = $model->getUsersRoles();
		$this->calendarTables = $dilerModel->getCalendarTables();

		$this->deleteByCategories = DText::sprintf('BUTTON_CLEAR_DILER_DELETE_BY', Text::_('JCATEGORIES'));
		$this->deleteByUsersText  = DText::sprintf('BUTTON_CLEAR_DILER_DELETE_BY', DText::_('USERS'));

		$this->addToolBar();

		parent::display($tpl);
		$document = new Document();
		$this->setDocument($document);
	}

	protected function addToolBar()
	{
		ToolbarHelper::title(DText::_('PURGEDATA'), 'purge');

		if ($this->canDo->get('core.admin'))
		{
			ToolbarHelper::preferences('com_diler');
			ToolbarHelper::divider();
			DiLerToolbarHelper::addPermissionsToolbarButton();
		}
		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	public function helpName(): string
	{
		return "Purge";
	}

	public function setDocument(Document $document): void
	{
		$document->setTitle(Text::_('COM_DILER') . ' - ' . DText::_('PURGEDATA'));
		$document->addScript(Uri::root() . "/administrator/components/com_diler/views/purge/purge.js");
		DText::script('BUTTON_PURGE_EVENT_LOG_TEXT');
		Text::script('MESSAGE');
		Text::script('JALL');
		DText::script('AJAX_LOADING_FORM');
	}
}
