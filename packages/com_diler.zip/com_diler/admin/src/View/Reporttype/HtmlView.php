<?php
/**
 * @copyright Copyright (C) 2013 - 2022 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Reporttype;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\Diglu;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use DiLer\Constants\ResponseCode;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\FormView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;

class HtmlView extends FormView implements DiLerAdministratorViewInterface
{
	protected $contract;
	private Diglu $diglu;

	public function __construct(array $config)
	{
		parent::__construct($config);
		$this->diglu = isset($config['diglu']) ? $config['diglu'] : new Diglu();
	}

	public function display($tpl = null)
	{
		$this->contract = Factory::getApplication()->input->get('contract', '0');
		if ($this->contract && !$this->diglu->isEnabled())
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		$this->item = $this->get('Item');
		$this->canDo = AccessHelper::getActions($this->item->id);

		parent::display($tpl);

		$this->form->setFieldAttribute('source', 'syntax', 'php');
	}

	protected function addToolBar()
	{
		$isNew = $this->item->id == 0;
		$name  = $this->contract ? DText::_('CONTRACTTYPES') : DText::_('REPORTTYPES');
		$type  = $this->contract ? 'contracttype' : 'reporttype';
		ToolbarHelper::title($isNew ? DText::_('CREATING') . ' ' . $name : DText::_('TASK_EDIT') . ' ' . $name, $type);

		if (($isNew && $this->canDo->get('core.create')) || (!$isNew && $this->canDo->get('core.edit')))
		{
			ToolbarHelper::apply('reporttype.apply');
			ToolbarHelper::save('reporttype.save');
		}

		ToolbarHelper::cancel('reporttype.cancel', 'JTOOLBAR_CLOSE');
		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	public function helpName(): string
	{
		return 'Report_Type';
	}
}
