<?php
/**
 * @copyright  Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Systeminformation;
use DiLer\Lang\DText;
use Joomla\CMS\Access\Exception\NotAllowed;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as JoomlaHtmlView;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Document\Document;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends JoomlaHtmlView
{
	public function display($tpl = null)
	{
		if (!Factory::getApplication()->getIdentity()->authorise('core.admin'))
			throw new NotAllowed(Text::_('JERROR_ALERTNOAUTHOR'), 403);

		$this->addToolBar();

		parent::display($tpl);

		$document = new Document();
		$this->setDocument($document);
	}

	private function addToolBar()
	{
		ToolBarHelper::title(DText::_('SYSTEM_INFORMATION'));
		ToolbarHelper::link(Route::_('index.php?option=com_diler&view=' . $this->getName() . '&format=text'), 'COM_DILER_SYSTEM_INFORMATION_DOWNLOAD_SYSTEM_INFO', 'download');
	}

	public function setDocument(Document $document): void
	{
		$document->setTitle(Text::_('COM_DILER') . ' - ' . DText::_('SYSTEM_INFORMATION'));
	}
}
