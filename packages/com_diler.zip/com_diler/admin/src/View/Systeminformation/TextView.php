<?php
/**
 * @copyright  Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Systeminformation;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Component\Admin\Administrator\View\Sysinfo\TextView as JoomlaTextView;
use Joomla\Component\Admin\Administrator\Model\SysinfoModel;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class TextView extends JoomlaTextView
{
	public function __construct($config = array())
	{
		parent::__construct($config);
		Factory::getApplication()->getLanguage()->load('com_admin');
		$adminSystemInfoModel = new SysinfoModel();
		$this->setModel($adminSystemInfoModel, true);
	}

	protected function getLayoutData() : array
	{
		return $this->getSortedFinalData();
	}
	
	private function getSortedFinalData() : array
	{
		$joomlaInfoData = parent::getLayoutData();

		$dilerFinalInfo = array();
		$dilerFinalInfo['diler'] = $this->getDilerInfo();

		$dilerFinalInfo['info'] = $joomlaInfoData['info'];
		$dilerFinalInfo['phpSettings'] = $joomlaInfoData['phpSettings'];
		$dilerFinalInfo['phpInfo'] = $joomlaInfoData['phpInfo'];
		return $dilerFinalInfo;
	}
	
	private function getDilerInfo()
	{
		$dilersModel = MVCHelper::factory()->createModel('Dilers', 'Administrator');
		$packageInfo = $dilersModel->getPackageVersionInfo();
		return array(
			'title' => Text::_('COM_DILER'),
			'data'  => array(
				'version' => $packageInfo->diler_version,
				'edition' => $packageInfo->diler_edition,
				'is Diler User Plugin enabled' => PluginHelper::isEnabled('user', 'dilerreg'),
				'is Diler Override Curl Transporter enabled' => PluginHelper::isEnabled('system', 'dileroveridecurltransporter'),
				'libraries/src/Http/Transport/cacert.pem Head:' => $this->getCaCertPemHeader()
			)
		);
	}
	
	private function getCaCertPemHeader()
	{
		$file = file(JPATH_ROOT . '/libraries/src/Http/Transport/cacert.pem');
		
		if (!$file)
			return 'File not exist';
		
		$headLines = array();
		foreach ($file as $index => $line)
		{
			$lineNumber = $index + 1;
			if (substr( $line, 0,  2) === "##")
				$headLines['line ' . $lineNumber] = $line;
		}
		
		return $headLines;
	}

}
