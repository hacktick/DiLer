<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Logevents;
use Audivisa\Component\DiLer\Administrator\Helper\DiLerToolbarHelper;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as JoomlaHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends JoomlaHtmlView implements DiLerAdministratorViewInterface
{
	public $filterForm;
	public $activeFilters;

	public function display($tpl = null)
	{
		\JLoader::register('DiLerConfig', JPATH_ROOT . '/administrator/components/com_diler/helpers/configuration.php');
		if (! property_exists('DiLerConfig', 'permanentValue'))
		{
			$this->items = null;
			$this->pagination = new \JPagination(0, 0, 0);
		}
		else
		{
			$this->items = $this->get('Items');
			$this->pagination = $this->get('Pagination');
		}
		$this->state = $this->get('State');
		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');

		$mvcFactory = MVCHelper::factory();
		$subjectsModel = $mvcFactory->createModel('Subjects', 'Administrator');
		$this->subjects= $subjectsModel->getSubjectList();

		$model = $mvcFactory->createModel('Compchars', 'Administrator');
		$this->levels = $model->getLevelList();

		$this->addToolbar();
		parent::display($tpl);
	}

	public function addToolbar()
	{
		ToolbarHelper::title(DText::_('LOG_EVENTS_LOG'), '');

		if (Factory::getApplication()->getIdentity()->authorise('core.admin', 'com_diler'))
		{
			ToolbarHelper::preferences('com_diler');
			ToolbarHelper::divider();
			DiLerToolbarHelper::addPermissionsToolbarButton();
		}


		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	public function helpName(): string
	{
		return 'Log_Events';
	}

}