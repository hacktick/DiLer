<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View;

use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use DiLer\Lang\DText;
use Joomla\CMS\MVC\View\FormView;
use Joomla\CMS\Toolbar\ToolbarHelper;

defined('_JEXEC') or die('Restricted access');

abstract class DiLerFormView extends FormView implements DiLerAdministratorViewInterface
{
	protected function initializeView()
	{
		parent::initializeView();
		$this->canDo = AccessHelper::getActions($this->itemId());
		$this->toolbarTitle = $this->toolbarTitle();
	}

	public function display($tpl = null)
	{
		parent::display($tpl);
		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	protected function toolbarTitle(): string
	{
		return $this->itemId() ? DText::_('EDITING') : DText::_('CREATING');
	}

	abstract protected function itemId();
}
