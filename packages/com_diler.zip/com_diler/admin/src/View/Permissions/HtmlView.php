<?php
/**
 * @copyright  Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Permissions;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as JoomlaHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;
use DiLer\Constants\ResponseCode;
use Joomla\CMS\Document\Document;


// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends JoomlaHtmlView implements DiLerAdministratorViewInterface
{
	protected $canDo;
	protected $form;

	function display($tpl = null)
	{
		if (!Factory::getApplication()->getIdentity()->authorise('core.admin'))
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		parent::display($tpl);

        $this->addToolBar();
		$document = new Document();
		$this->setDocument($document);
	}

	protected function addToolBar()
	{
		ToolbarHelper::title(Text::_('JCONFIG_PERMISSIONS_LABEL'), '');

        $toolbar    = Toolbar::getInstance();
        $toolbar->apply('permissions.apply');
        $toolbar->divider();
        $toolbar->save('permissions.save');
        $toolbar->divider();
        $toolbar->cancel('permissions.cancel');
        $toolbar->divider();
		$toolbar->help('permissions.help');
	}

	public function helpName(): string
	{
		return "Permissions";
	}

	public function setDocument(Document $document): void
	{
		$this->document = $document;
		$this->document->setTitle(Text::_('COM_DILER') . ' - ' . Text::_('JCONFIG_PERMISSIONS_LABEL'));
	}
}
