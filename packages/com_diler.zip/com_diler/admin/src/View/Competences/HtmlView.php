<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Competences;
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\View\DiLerListViewAbstract;
use DiLer\Lang\DText;


class HtmlView extends DiLerListViewAbstract
{

	public function helpName(): string
	{
		return 'Competences';
	}

	protected function toolbarTitle(): string
	{
		return DText::_('COMPETENCES');
	}


}