<?php
/**
 * @copyright Copyright (C) 2013 - 2022 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\View\Reporttypes;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\Diglu;
use Audivisa\Component\DiLer\Administrator\Helper\DiLerToolbarHelper;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use DiLer\Constants\ResponseCode;
use DiLer\Lang\DText;
use Joomla\CMS\MVC\View\ListView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Toolbar\Toolbar;

class HtmlView extends ListView implements DiLerAdministratorViewInterface
{
	public $contract;
	private Diglu $diglu;

	public function __construct(array $config)
	{
		parent::__construct($config);
		$this->diglu = isset($config['diglu']) ? $config['diglu'] : new Diglu();
	}

	public function display($tpl = null)
	{
		$this->contract = $this->get('Contract');
		if ($this->contract && !$this->diglu->isEnabled())
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), ResponseCode::HTTP_FORBIDDEN);

		$this->canDo = AccessHelper::getActions();

		parent::display($tpl);
	}

	protected function addToolBar()
	{
		$title = $this->contract ? DText::_('CONTRACTTYPES') : DText::_('REPORTTYPES');
		ToolbarHelper::title($title, '');

		if ($this->canDo->get('core.edit'))
		{
			ToolbarHelper::editList('reporttype.edit');
		}

		if ($this->canDo->get('core.edit.state'))
		{
			ToolbarHelper::publish('reporttypes.publish', 'JTOOLBAR_PUBLISH', true);
			ToolbarHelper::unpublish('reporttypes.unpublish', 'JTOOLBAR_UNPUBLISH', true);
		}

		if ($this->state->get('filter.published') == - 2 && $this->canDo->get('core.delete'))
		{
			ToolbarHelper::deleteList('', 'reporttypes.delete', 'JTOOLBAR_EMPTY_TRASH');
		}
		elseif ($this->canDo->get('core.delete'))
		{
			ToolbarHelper::trash('reporttypes.trash');
		}
		ToolbarHelper::checkin('reporttypes.checkin');
		if ($this->contract == 0)
		{
			ToolbarHelper::custom('reporttypes.export', 'export.png', 'export.png', 'COM_DILER_EXPORT', true);

			$bar = Toolbar::getInstance();
			$bar->popupButton('import')
				->text(DText::_('IMPORT'))
				->selector('importModal');

			$bar->popupButton('copy')
				->text(DText::_('COPY'))
				->icon('icon-copy')
				->listCheck(true)
				->selector('copyModal');
		}

		if ($this->canDo->get('core.admin'))
		{
			ToolbarHelper::preferences('com_diler');
			ToolbarHelper::divider();
			DiLerToolbarHelper::addPermissionsToolbarButton();
		}

		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	public function helpName(): string
	{
		return 'Report_Types';
	}
}
