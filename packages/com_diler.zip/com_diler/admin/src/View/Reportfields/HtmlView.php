<?php
/**
 * @copyright Copyright (C) 2013 - 2022 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Reportfields;
use Audivisa\Component\DiLer\Administrator\View\DiLerListViewAbstract;
use DiLer\Lang\DText;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends DiLerListViewAbstract
{
    public function helpName(): string
    {
        return 'Report_Fields';
    }

    protected function toolbarTitle(): string
    {
        return DText::_('REPORTFIELDS');
    }
}