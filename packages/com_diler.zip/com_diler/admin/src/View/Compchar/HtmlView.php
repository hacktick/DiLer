<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\CompChar;

use Audivisa\Component\DiLer\Administrator\View\DiLerFormView;
use DiLer\Lang\DText;
use Joomla\CMS\Toolbar\ToolbarHelper;

defined('_JEXEC') or die('Restricted access');


class HtmlView extends DiLerFormView
{
    protected $canDo;

    public function display($tpl = null)
    {
        $this->form = $this->get('Form');
        $this->item = $this->get('Item');

        parent::display($tpl);
    }

    protected function addToolBar()
    {
        ToolbarHelper::title(DText::_('TASK_EDIT'), 'compchar');

        if ($this->canDo->get('core.edit'))
        {
            ToolbarHelper::apply('compchar.apply');

            ToolbarHelper::save('compchar.save');

	        ToolbarHelper::save2new('compchar.save2new');
        }
        ToolbarHelper::cancel('compchar.cancel', 'JTOOLBAR_CLOSE');
    }

	public function helpName(): string
	{
		return 'Compchar';
	}

	protected function itemId()
	{
		return $this->item->id;
	}
}