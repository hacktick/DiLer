<?php
/**
 * @copyright Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View;
use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\DiLerToolbarHelper;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\ListView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\String\Inflector;

defined('_JEXEC') or die('Restricted access');

abstract class DiLerListViewAbstract extends ListView implements DiLerAdministratorViewInterface
{

	public function __construct(array $config)
	{
		$config['option'] = 'com_diler';
		$config['supports_batch'] = false;
		parent::__construct($config);
		$this->canDo = AccessHelper::getActions();
	}

	public function display($tpl = null)
	{
		/**
		 * Load jQuery till we build custom toolbar
		 * Currently we leaving Joomla to build toolbar for us but there is since Joomla use jQuery for
		 * delete confirm message, we need to load it.
		 */
		$this->document->getWebAssetManager()->useScript('jquery');
		$this->toolbarTitle = $this->toolbarTitle();
		parent::display($tpl);

		$user  = Factory::getApplication()->getIdentity();
		if ($user->authorise('core.admin', $this->option) || $user->authorise('core.options', $this->option))
		{
			ToolbarHelper::preferences($this->option);
			ToolbarHelper::divider();
			DiLerToolbarHelper::addPermissionsToolbarButton();
		}

		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

    protected function addToolbar()
    {
        $canDo = $this->canDo;

        $viewName         = $this->getName();
        $singularViewName = Inflector::getInstance()->toSingular($viewName);

        ToolbarHelper::title(Text::_($this->toolbarTitle), $this->toolbarIcon);

        if ($canDo->get('core.create'))
        {
            ToolbarHelper::addNew($singularViewName . '.add');
        }

        if (($canDo->get('core.edit')) || ($canDo->get('core.edit.own')))
        {
            ToolbarHelper::editList($singularViewName . '.edit');
        }

        if ($canDo->get('core.edit.state'))
        {
            ToolbarHelper::publish($viewName . '.publish', 'JTOOLBAR_PUBLISH', true);
            ToolbarHelper::unpublish($viewName . '.unpublish', 'JTOOLBAR_UNPUBLISH', true);

            ToolbarHelper::checkin($viewName . '.checkin');
        }

        if ($this->state->get('filter.published') == -2 && $canDo->get('core.delete'))
        {
            ToolbarHelper::deleteList('JGLOBAL_CONFIRM_DELETE', $viewName . '.delete', 'JTOOLBAR_EMPTY_TRASH');
        }
        elseif ($canDo->get('core.edit.state'))
        {
            ToolbarHelper::trash($viewName . '.trash');
        }
    }

	abstract protected function toolbarTitle() : string;
}
