<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Languageoverride;
use Audivisa\Component\DiLer\Administrator\Helper\AccessHelper;
use Audivisa\Component\DiLer\Administrator\Helper\HelpLink;
use Audivisa\Component\DiLer\Administrator\View\DiLerAdministratorViewInterface;
use DiLer\Lang\DText;
use Joomla\CMS\Document\Document;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as JoomlaHtmlHelper;
use Joomla\CMS\Toolbar\ToolbarHelper;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends JoomlaHtmlHelper implements DiLerAdministratorViewInterface
{
	protected $form;
	protected $item;
	protected $script;
	protected $canDo;

	public function display($tpl = null)
	{
		$this->form = $this->get('form');
		$item = $this->get('Item');

		$this->languageId = Factory::getApplication()->input->getUint('id');
		$this->overrides = $item->overrides;
		$this->editLanguage = $item->language;
		$this->canDo = AccessHelper::getActions();
		$document = new Document();
		$this->addToolBar();

		parent::display($tpl);

		$this->setDocument($document);
	}

	protected function addToolBar()
	{
		ToolbarHelper::title(DText::_('TASK_EDIT'), 'languageoverride');

		if ($this->canDo->get('core.edit'))
		{
			ToolbarHelper::apply('languageoverride.apply');

			ToolbarHelper::save('languageoverride.save');
		}
		ToolbarHelper::cancel('languageoverride.cancel', 'JTOOLBAR_CLOSE');
		$helpLink = new HelpLink($this);
		ToolbarHelper::help(false, false, $helpLink->getLink());
	}

	public function setDocument(Document $document): void
	{
		$this->document = $document;
		$this->document->setTitle(DText::_('EDITING'));
	}

	public function helpName(): string
	{
		return "Language_Override";
	}
}