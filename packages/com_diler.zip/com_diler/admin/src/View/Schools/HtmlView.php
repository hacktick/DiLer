<?php
/**
 * Schools default view
 *
 * @package    DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright  Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\Schools;

use Audivisa\Component\DiLer\Administrator\View\DilerListViewWithImportsAbstract;
use DiLer\Lang\DText;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends DilerListViewWithImportsAbstract
{
	public function helpName(): string
	{
		return 'Schools';
	}

	protected function toolbarTitle(): string
	{
		return DText::_('SCHOOLS');
	}
}