<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\View\School;
use Audivisa\Component\DiLer\Administrator\Helper\Diglu;
use Audivisa\Component\DiLer\Administrator\View\DiLerFormView;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HtmlView extends DiLerFormView
{
    protected $form;
    protected $item;
    protected $canDo;
	protected Diglu $diglu;
	protected bool $isDiglu;

	public function __construct(array $config)
	{
		parent::__construct($config);

		$this->diglu = isset($config['diglu']) ? $config['diglu'] : new Diglu;
		$this->isDiglu = $this->diglu->isEnabled();
	}

    public function helpName(): string
    {
        return 'School';
    }

    protected function itemId()
    {
        return $this->item->id;
    }
}