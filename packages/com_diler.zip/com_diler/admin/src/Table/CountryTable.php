<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;

class CountryTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_country', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		// Set the publish date to now
		if ($array['published'] == 1 && (empty($array['publish_up']) || intval($array['publish_up']) == 0))
			$array['publish_up'] = Factory::getDate()->toSql();

		if (isset($array['params']) && is_array($array['params']))
		{
			// Convert the params field to a string.
			$parameter = new Registry;
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}

		return parent::bind($array, $ignore);
	}
}