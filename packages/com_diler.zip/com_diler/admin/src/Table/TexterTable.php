<?php
/**
 * @copyright  Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license    GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

// No direct access
defined('_JEXEC') or die('Restricted access');

class TexterTable extends Table
{
	 // Value used in texter table for field 'type' for manual messages
	const TYPE_MANUAL_MESSAGE = 0;

    // Value to mark message type as 'request access' to activity
	const TYPE_ACTIVITY_REQUEST_ACCESS = 1;


    // Value to mark message type as 'reply to requested access' to activity
	const TYPE_ACTIVITY_REQUEST_REPLY = 2;

    // Value to mark message type as 'activity finished'
	const TYPE_ACTIVITY_FINISHED = 3;

    // Value to mark message type as 'activity graded'
	const TYPE_ACTIVITY_GRADED = 4;

    // Value to mark message type as 'activity reset'
	const TYPE_ACTIVITY_RESET = 6;

    // Value to mark message type as 'activity started'
	const TYPE_ACTIVITY_STARTED = 7;

    // Value to mark message type as 'activity comment'
	const TYPE_ACTIVITY_COMMENT = 8;

    // Value used in texter table for field 'type' for cloud messages
	const TYPE_CLOUD_MESSAGE = 9;

	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_texter', 'id', $db);
	}

	public function getSystemMessageTypesExceptCloud()
	{
		return array(
			self::TYPE_ACTIVITY_REQUEST_ACCESS,
			self::TYPE_ACTIVITY_REQUEST_REPLY,
			self::TYPE_ACTIVITY_FINISHED,
			self::TYPE_ACTIVITY_GRADED,
			self::TYPE_ACTIVITY_RESET,
			self::TYPE_ACTIVITY_STARTED,
			self::TYPE_ACTIVITY_COMMENT
		);
	}

	public function deleteManualMessages(string $tillDate)
	{
		return $this->deleteMessageByType(self::TYPE_MANUAL_MESSAGE, $tillDate);
	}

	public function deleteCloudMessages(string $tillDate)
	{
		return $this->deleteMessageByType(self::TYPE_CLOUD_MESSAGE, $tillDate);
	}

	public function deleteSystemMessages(string $tillDate)
	{
		$systemTypes = $this->getSystemMessageTypesExceptCloud();
		return $this->deleteMessageByType(min($systemTypes) . ' AND ' . max($systemTypes), $tillDate, "BETWEEN");
	}

	private function deleteMessageByType($whereType, string $tillDate, $sqlCompare = '=')
	{
		$query = $this->_db->getQuery(true);
		$query->delete($this->getTableName());
		$query->where("type $sqlCompare $whereType");
		$query->where('DATE(created_date) <= ' . $this->_db->quote($tillDate));

		return $this->_db->setQuery($query)->execute();
	}
}