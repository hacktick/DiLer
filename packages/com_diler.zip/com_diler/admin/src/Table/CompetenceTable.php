<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;

class CompetenceTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_competence', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		if ($array['published'] == 1 && intval($array['publish_up']) == 0)
			$array['publish_up'] = Factory::getDate()->toSql();

		if (isset($array['params']) && is_array($array['params']))
		{
			// Convert the params field to a string.
			$parameter = new Registry;
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;

		}

		return parent::bind($array, $ignore);
	}

	public function getSubject()
	{
		if (!$this->id)
			return false;

		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('subject_id');
		$query->from('#__diler_subject_competence_map');
		$query->where('competence_id = ' . $this->id);
		$subjectId    = $db->setQuery($query)->loadResult();
		$subjectTable = new SubjectTable($db);
		$subjectTable->load($subjectId);

		return $subjectTable;
	}

	public function load($pk = null, $reset = true)
	{
		if (parent::load($pk, $reset))
		{
			$params = new Registry;
			$params->loadstring($this->params);

			$this->params = $params;

			return true;
		}

		return false;
	}
}