<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;
use DiLer\DataProviders\Database\SubjectDBInterface;
use DiLer\Lang\DText;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;
use Joomla\CMS\Language\Text;

// No direct access
defined('_JEXEC') or die('Restricted access');

class SubjectTable extends Table implements SubjectDBInterface
{
	public $id;
	public $asset_id;
	public $name;
	public $published;
	public $created;
	public $created_by;
	public $modified;
	public $modified_by;
	public $checked_out;
	public $checked_out_time;
	public $publish_up;
	public $publish_down;
	public $ordering;
	public $language;
	public $description;
	public $points;
	public $lowest;
	public $highest;
	public $catid;
	public $colour;
	public $comprasterview;
	public $icons;
	public $multiple_sections;
	public $initial_situation;
	public $development_target;


    public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_subject', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		if (isset($array['params']) && is_array($array['params']))
		{
			$parameter = new Registry();
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}
		return parent::bind($array, $ignore);
	}

	public function check()
	{
		$this->name = htmlspecialchars_decode($this->name, ENT_QUOTES);

		if ($this->publish_down > $this->_db->getNullDate() && $this->publish_down < $this->publish_up)
		{
			$this->setError(Text::_('JGLOBAL_START_PUBLISH_AFTER_FINISH'));

			return false;
		}

		if ($this->published < 0)
			$this->ordering = 0;

		$this->ordering = ($this->id) ? $this->ordering : self::getNextOrder();

		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->from('#__diler_subject')
			->select('COUNT(*)')
			->where('name = ' . $db->quote($this->name));
		if ($this->id)
			$query->where('id != ' . (int) $this->id);

		$duplicateRows = $db->setQuery($query)->loadResult();
		if ($duplicateRows)
		{
			$this->setError(DText::_('SUBJECT_TABLE_DUPLICATE_NAME'));
			return false;
		}

		return true;
	}

	public function id(): int
	{
		return $this->id;
	}

	public function assetId(): int
	{
		return $this->asset_id;
	}

	public function name(): string
	{
		return $this->name;
	}

	public function published(): int
	{
		return $this->published;
	}

	public function created(): string
	{
		return $this->created;
	}

	public function createdBy(): int
	{
		return $this->created_by;
	}

	public function modified(): string
	{
		return $this->modified;
	}

	public function modifiedBy(): int
	{
		return $this->modified_by;
	}

	public function checkedOut(): int
	{
		return $this->checked_out;
	}

	public function checkedOutTime(): string
	{
		return $this->checked_out_time;
	}

	public function publishUp(): string
	{
		return $this->publish_up;
	}

	public function publishDown(): string
	{
		return $this->publish_down;
	}

	public function ordering(): int
	{
		return $this->ordering;
	}

	public function language(): string
	{
		return $this->language;
	}

	public function description(): string
	{
		return $this->description;
	}

	public function points(): int
	{
		return $this->points;
	}

	public function lowest(): int
	{
		return $this->lowest;
	}

	public function highest(): int
	{
		return $this->highest;
	}

	public function catId(): int
	{
		return $this->catid;
	}

	public function colour(): string
	{
		return $this->colour;
	}

	public function comprasterView(): string
	{
		return $this->comprasterview;
	}

	public function icons(): int
	{
		return $this->icons;
	}

	public function multipleSections(): int
	{
		return $this->multiple_sections;
	}

	public function initialSituation(): string
	{
		return $this->initial_situation;
	}

	public function developmentTarget(): string
	{
		return $this->development_target;
	}
}