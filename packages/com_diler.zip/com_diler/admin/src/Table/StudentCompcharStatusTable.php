<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

// No direct access
defined('_JEXEC') or die('Restricted access');

class StudentCompcharStatusTable extends Table
{
	function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_student_compchar_status', array('student_id', 'compchar_id'), $db);
	}

}