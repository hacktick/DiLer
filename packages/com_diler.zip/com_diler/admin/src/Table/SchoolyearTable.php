<?php
/**
 * @copyright      Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;
use Joomla\CMS\Table\Table;

// No direct access
defined('_JEXEC') or die('Restricted access');

class SchoolyearTable extends Table
{
	function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_schoolyear', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		if ($array['published'] == 1 && intval($array['publish_up']) == 0)
			$array['publish_up'] = Factory::getDate()->toSql();

		if (isset($array['params']) && is_array($array['params']))
		{
			$parameter = new Registry;
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}

		return parent::bind($array, $ignore);
	}

	public function delete($pk = null)
	{
		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$query->delete('#__diler_schoolyear_marks_period_map');
		$query->where('schoolyear_id = ' . (int) $pk);
		$db->setQuery($query)->execute();

		return parent::delete($pk);
	}
}