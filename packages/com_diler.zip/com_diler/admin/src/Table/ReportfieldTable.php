<?php
/**
 * @copyright      Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use DiLer\Lang\DText;
use Joomla\CMS\Application\ApplicationHelper;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;

// No direct access
defined('_JEXEC') or die('Restricted access');

class ReportfieldTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_report_field_definition', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		if (isset($array['params']) && is_array($array['params']))
		{
			$parameter = new Registry;
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}

		return parent::bind($array, $ignore);
	}

	public function check()
	{
		$this->name = strtolower($this->name);
		$db         = $this->getDbo();
		$query      = $db->getQuery(true)
			->select('COUNT(*)')
			->from('#__diler_report_field_definition')
			->where('id != ' . (int) $this->id)
			->where('name = ' . $db->quote($this->name));
		$duplicates = $db->setQuery($query)->loadResult();
		if ($duplicates)
		{
			$this->setError(DText::_('REPORTFIELD_TABLE_DUPLICATE_NAME'));

			return false;
		}
		$this->ordering = ($this->id) ? $this->ordering : self::getNextOrder();
		$this->name     = ApplicationHelper::stringURLSafe($this->name);
		$this->name     = str_replace('-', '_', $this->name);

		// Check for validity of select_options
		if ($this->element_type == 2)
		{
			$testArray = explode('||', $this->select_options);
			if ((!is_array($testArray)) || count($testArray) < 2)
			{
				$this->setError(DText::_('REPORTFIELD_TABLE_INVALID_SELECT'));

				return false;
			}
		}
		else
			$this->select_options = '';

		if ($this->type == 4 && $this->element_type == 3)
		{
			$this->setError(DText::_('REPORTFIELDS_ELEMENT_TYPE_ERROR'));

			return false;
		}

		return true;
	}

	public function load($pk = null, $reset = true)
	{
		if (parent::load($pk, $reset))
		{
			$params = new Registry;
			$params->loadstring($this->params);

			$this->params = $params;

			return true;
		}
		else
			return false;
	}
}