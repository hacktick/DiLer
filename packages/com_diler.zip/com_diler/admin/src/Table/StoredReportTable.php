<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

// No direct access
defined('_JEXEC') or die('Restricted access');

class StoredReportTable extends Table
{
	public $id;
	public $student_id;
	public $file_name;
	public $type;
	public $params;
	public $created;
	public $created_by;
	public $modified_by;
	
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_stored_report','id', $db);
	}
	
	public function store($updateNulls = false)
	{
		$this->created_by = Factory::getApplication()->getIdentity()->id;
		$this->created = Factory::getDate()->toSql();
		return parent::store($updateNulls);
	}
}
