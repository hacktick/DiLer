<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use DiLer\DGet;
use DilerLogger;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

defined('_JEXEC') or die('Restricted access');

class Pep_DevelopmentTable extends Table
{
	public $student_id;
	public $school_interests = "";
	public $extracurricular_interests = "";
	public $future_interests = "";
	public $strengths = "";
	public $habits = "";
	public $work_methods = "";
	public $organising_strategies = "";
	public $social_type = "";
	public $responsibility_for_myself = "";
	public $responsibility_for_others = "";
	public $responsibility_for_world = "";
	public $notes = "";
	public $checked_out = 0;
	public $checked_out_time = "";

	protected $_autoincrement = false;
	
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_pep_development', 'student_id', $db);
	}
	
	public function load($keys = null, $reset = true)
	{
		if (!parent::load($keys, $reset)) 
			$this->createDefaultRecord();
			
		return parent::load($keys, $reset);
	}

	public function store($updateNulls = false)
	{
		$saveStatus = parent::store($updateNulls);
		
		if (!$saveStatus)
			return false;

		$this->doLog();

		return true;
	}

	private function doLog() : void
	{
        // @TODO Replace this class with the one that fits new Joomla structure
		$logger = new DilerLogger('pep_development', 'edit');
		$logData = array(
			'username' => DGet::user()->personalData()->username(),
			'studentUserName' => DGet::user($this->student_id)->personalData()->username(),
		);
		$logger->addAction($logData, 'COM_DILER_LOG_PEP_DEVELOPMENT_EDITED');
	}
	
	private function createDefaultRecord()
	{
		$this->_db->insertObject($this->_tbl, $this, $this->_tbl_keys[0]);
	}
	
	public function checkedOutBy() : int
	{
		return $this->checked_out;
	}
}