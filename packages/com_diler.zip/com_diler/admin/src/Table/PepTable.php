<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use DiLer\DataProviders\Database\PepDBInterface;
use DiLer\DGet;
use DilerLogger;
use DilerParams;
use Joomla\CMS\Factory;
use DiLer\Lang\DText;
use Joomla\CMS\Service\Provider\Application;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

defined('_JEXEC') or die('Restricted access');

class PepTable extends Table implements PepDBInterface
{
	public ?int $id = 0;
	public ?int $method = 0;
	public ?string $pep_action = "";
	public ?int $action_implementation = 0;
	public ?int $action_success = 0;
	public ?int $action_followup = 0;
	public ?string $action_note = "";
	public ?string $description = "";
	public ?string $period_from = "";
	public ?string $period_to = "";
	public ?string $result = "";
	public ?string $evaluation_criteria = "";
	public ?int $assessment = 0;
	public ?int $school_year_id = 0;
	public ?int $subject_group_id = 0;
	public ?int $student_id = 0;
	public ?int $create_by = 0;
	public ?string $created = "";

	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_pep', 'id', $db);
		$this->student_id = Factory::getApplication()->input->getInt('student_id');
	}

	public function store($updateNulls = false)
	{
		$currentDate = Factory::getDate()->toSql();;
		if (!$this->id)
		{
			$actionType = 'created';
			$this->create_by = DGet::user()->id();
            // @TODO Replace this class with the one that fits new Joomla structure
			$this->school_year_id =  DilerParams::getCurrentSchoolyear()->id;
			$this->created = $currentDate;
		}
		else
		{
			$actionType = 'edited';
			$this->modified = $currentDate;
		}

		$saveStatus = parent::store($updateNulls);
		if (!$saveStatus)
			return false;

		$this->doLog($actionType);
		return true;
	}
	
	public function delete($pk = null)
	{
		$deleteStatus = parent::delete($pk);
		if (!$deleteStatus)
			return false;
		$this->doLog('deleted');
		return true;
	}


	private function doLog($actionType) : void
	{
        // @TODO Replace this class with the one that fits new Joomla structure
        $logger = new DilerLogger('pep', $actionType);
		$groupTable = DGet::groupTable();
		$groupTable->load($this->subject_group_id);
		$logData = array(
			'username' => DGet::user()->personalData()->username(),
			'subjectGroupName' => $groupTable->name,
			'actionType' => DText::_($actionType)
		);
		$logger->addAction($logData, 'COM_DILER_LOG_PEP_USER_ACTION');
	}

	public function id(): int
	{
		return $this->id;
	}

	public function method(): int
	{
		return $this->method;
	}

	public function action(): string
	{
		return $this->pep_action;
	}

	public function actionImplementation() : int
	{
		return $this->action_implementation;
	}

	public function actionSuccess() : int
	{
		return $this->action_success;
	}

	public function actionFollowup() : int
	{
		return $this->action_followup;
	}

	public function actionNote() : string
	{
		return $this->action_note;
	}

	public function description(): string
	{
		return $this->description;
	}

	public function periodFrom(): string
	{
		return $this->period_from;
	}

	public function periodTo(): string
	{
		return $this->period_to;
	}

	public function result(): string
	{
		return $this->result;
	}

	public function evaluationCriteria(): string
	{
		return $this->evaluation_criteria;
	}

	public function assessment(): int
	{
		return $this->assessment;
	}

	public function schoolYearId(): int
	{
		return $this->school_year_id;
	}

	public function subjectGroupId(): int
	{
		return $this->subject_group_id;
	}

	public function studentId(): int
	{
		return $this->student_id;
	}

	public function createBy(): int
	{
		return $this->create_by;
	}

	public function created(): string
	{
		return $this->created;
	}
}