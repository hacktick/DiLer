<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

// No direct access
defined('_JEXEC') or die('Restricted access');

class MarkshistoryTable extends Table
{
	function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_marks_history', ['student_id', 'group_id', 'subject_id', 'schoolyear_id', 'marks_period_id'], $db);
	}

	public function getStudentsWithMarks(string $tillDate = null)
	{
		$tableName = $this->getTableName();
		$query = $this->_db->getQuery(true);
		$query->select('CONCAT(users.surname, " ", users.forename) as title');
		$query->select("users.user_id AS id");
		$query->select("COUNT(" . $this->getPrimayKeyWihtTableName() . ") AS total");
		$query->from($tableName);
		$query->innerJoin("#__dilerreg_users AS users ON users.user_id = " . $this->getPrimayKeyWihtTableName());
		$query->group('users.user_id');
		$query->order('users.surname');
		$query->where("mark != ''");

		if ($tillDate)
			$query->where("DATE($tableName.created) <= " . $this->_db->quote($tillDate));

		return $this->_db->setQuery($query)->loadAssocList();
	}

	public function getLearningGroupsWithMarksHistory(string $tillDate = null, bool $countTotal = false)
	{
		$query = $this->_db->getQuery(true);
		
		if ($countTotal)
			$query->select("COUNT(" . $this->getPrimayKeyWihtTableName() . ") as total");

		if ($tillDate)
			$query->where("DATE(" . $this->getTableName() . ".created) <= " . $this->_db->quote($tillDate));
			
		$query->where("mark != ''");
		$learningGroupParent = ComponentHelper::getParams('com_diler')->get('learning_group_parent_id');
		// @TODO find a way to trim all usergroup titles with mysql so we don't have to TRIM it inside select query 
		$query->select('ug.id AS id, TRIM(dg.name) AS title');
		$query->from('#__usergroups AS ug');
		$query->innerJoin('#__usergroups AS parent ON parent.id =' . (int) $learningGroupParent);
		$query->innerJoin('#__diler_group AS dg ON dg.joomla_group_id = ug.id');
		$query->innerJoin('#__user_usergroup_map AS ugm ON ug.id = ugm.group_id');
		$query->innerJoin('#__users AS u ON u.id = ugm.user_id');

		$query->innerJoin($this->getTableName() . " ON " . $this->getPrimayKeyWihtTableName() . " = u.id");

		$query->where('ug.lft > parent.lft');
		$query->where('ug.rgt < parent.rgt');
		$query->where('ug.id IS NOT NULL');

		$query->order('title');
		$query->group('title, id');

		return $this->_db->setQuery($query)->loadAssocList();
	}

	public function clearMarkHistoryByStudent(int $studentId, string $tillDate)
	{
		$query = $this->_db->getQuery(true);
		$query->update($this->getTableName());
		$query->set("mark = ''");
		$query->where("student_id = $studentId");
		$query->where('created <= ' . $this->_db->quote($tillDate));

		$this->_db->setQuery($query)->execute();
		return $this->_db->getAffectedRows();
	}

	public function clearMarkHistoryByLearningGroup(int $groupId, string $tillDate)
	{
		$tableName = $this->getTableName();
		$query = $this->_db->getQuery(true);
		$query->update($tableName);
		$query->set("mark = ''");
		$query->innerJoin("#__users AS u ON $tableName.student_id = u.id" );
		$query->innerJoin("#__user_usergroup_map AS ugm ON u.id = ugm.user_id" );
		$query->where("ugm.group_id = $groupId");
		$query->where("DATE($tableName.created) <= " . $this->_db->quote($tillDate));
		
		$this->_db->setQuery($query)->execute();
		
		return $this->_db->getAffectedRows();
	}

	private function getPrimayKeyWihtTableName()
	{
		return $this->getTableName() . '.' . $this->getKeyName();
	}
}