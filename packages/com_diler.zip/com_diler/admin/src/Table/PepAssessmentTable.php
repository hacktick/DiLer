<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\DataProviders\Database\PepAssessmentsDBInterface;
use DiLer\DGet;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;

class PepAssessmentTable extends Table implements PepAssessmentsDBInterface
{
	protected $_tbl_keys = array(
		'id',
		'subject_id',
		'student_id',
		'development_area_id'
	);
	public int $id = 0;
	public ?string $initial_situation = "";
	public ?string $development_target = "";
	public $student_id;
	public $subject_group_id;
	public $development_area_id;
	public $created_by;
	public $created;
	public $modified_by;
	public $modified;
	public $published;

	const PUBLISHED_STATE = 1;
	const ARCHIVED_STATE = 2;

	public function __construct(&$db)
	{
		parent::__construct('#__diler_pep_assessments', 'id', $db);
	}

	public function store($updateNulls = false)
	{
		$pepRecords    = array();
		$currentUserId = Factory::getUser()->get('id');
		$currentTime   = Factory::getDate()->toSql();
		if ($this->id())
		{
            $existingRecordTable = MVCHelper::factory()->createTable("PepAssessment", "Site");
			/** @var DiLerTablePepAssessment $existingRecordTable */
			$existingRecordTable->load($this->id());
			$didSubjectGroupIdOrDevelopmentAreaChaned = $existingRecordTable->subject_group_id != $this->subject_group_id
				|| $existingRecordTable->developmentAreaId() != $this->developmentAreaId();
			if ($didSubjectGroupIdOrDevelopmentAreaChaned)
				$pepRecords = $this->getPepRecordsBySubjectIdAndDevelopmentAreaId($existingRecordTable->subject_group_id, $existingRecordTable->developmentAreaId());

			$actionType        = 'edited';
			$this->modified_by = $currentUserId;
			$this->modified    = $currentTime;
		}
		else
		{
			$actionType       = 'created';
			$this->created_by = $currentUserId;
			$this->created    = $currentTime;
		}
		$saveStatus = parent::store($updateNulls);

		if (!$saveStatus)
			return false;

		$this->changeSubjectAndDevelopmentAreaForPepRecords($pepRecords);
		$this->doLog($actionType);

		return true;
	}

	public function delete($pk = null)
	{
		$deleteStatus = parent::delete($pk);
		if (!$deleteStatus)
			return false;
		$this->doLog('deleted');

		return true;
	}

	private function changeSubjectAndDevelopmentAreaForPepRecords($pepRecords): void
	{
		if (!$pepRecords)
			return;

		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$query->update('#__diler_pep');
		$query->set('subject_group_id = ' . $this->subject_group_id);
		$query->set('development_area_id = ' . $this->developmentAreaId());
		$query->where('id IN(' . implode(',', $pepRecords) . ')');

		$db->setQuery($query)->execute();
	}

	private function getPepRecordsBySubjectIdAndDevelopmentAreaId(int $subjectGroupId, int $developmentAreaId)
	{
		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_pep');
		$query->where('subject_group_id = ' . $subjectGroupId);
		$query->where('development_area_id = ' . $developmentAreaId);

		return $db->setQuery($query)->loadColumn();
	}

	private function doLog($actionType, $actionTypeInString = ''): void
	{
		$logger     = new \DilerLogger('pepassessment', $actionType);
		$groupTable = DGet::groupTable();
		$groupTable->load($this->subject_group_id);
		$logData = array(
			'username'           => DGet::user()->personalData()->username(),
			'studentUserName'    => DGet::user($this->student_id)->personalData()->username(),
			'subjectGroupName'   => $groupTable->name,
			'actionType'         => DText::_($actionType),
			'actionTypeInString' => DText::_($actionTypeInString)
		);
		if (!$actionTypeInString)
		{
			$logger->addAction($logData, 'COM_DILER_LOG_PEP_ASSESSMENT_USER_ACTION');

			return;
		}
		$logger->addAction($logData, 'COM_DILER_LOG_PEP_ASSESSMENT_USER_ACTION_ARCHIVED');
	}

	public function publish($pks = null, $state = 1, $userId = 0)
	{
		if ($published = parent::publish($pks, $state, $userId))
		{
			foreach ($pks as $pk)
			{
				$this->updateModifiedDetails($pk);
				$actionTypeInString = 'LOG_PEP_ASSESSMENT_REACTIVATE';
				$actionType         = 'reactivated';
				if ($state == self::ARCHIVED_STATE)
				{
					$actionTypeInString = 'LOG_PEP_ASSESSMENT_ARCHIVED';
					$actionType         = 'archived';
				}

				$this->load($pk);
				$this->doLog($actionType, $actionTypeInString);
			}
		}

		return $published;
	}

	public function updateModifiedDetails(int $id)
	{
		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$query->update($this->_tbl);
		$query->set('modified_by = ' . Factory::getUser()->id);
		$query->set('modified = ' . $db->quote(Factory::getDate()->toSql()));
		$query->where($this->_tbl_key . ' = ' . $id);

		return $db->setQuery($query)->execute();
	}

	public function id(): int
	{
		return $this->id;
	}

	public function initialSituation(): string
	{
		return $this->initial_situation;
	}

	public function developmentTarget(): string
	{
		return $this->development_target;
	}

	public function studentId(): int
	{
		return $this->student_id;
	}

	public function developmentAreaId(): int
	{
		return $this->development_area_id;
	}
}
