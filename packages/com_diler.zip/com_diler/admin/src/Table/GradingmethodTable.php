<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
namespace Audivisa\Component\DiLer\Administrator\Table;
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;
use Joomla\Utilities\ArrayHelper;

class GradingmethodTable extends Table
{
	function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_activity_grading_method', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		if (isset($array['params']) && is_array($array['params']))
		{
			// Convert the params field to a string.
			$parameter = new Registry();
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}

		return parent::bind($array, $ignore);
	}

	public function check()
	{
		$errors     = array();
		$return     = true;
		$this->name = htmlspecialchars_decode($this->name, ENT_QUOTES);
		// Check the publish down date is not earlier than publish up.
		if ($this->publish_down > $this->_db->getNullDate() && $this->publish_down < $this->publish_up)
			$errors[] = Text::_('JGLOBAL_START_PUBLISH_AFTER_FINISH');

		$params = new Registry($this->params);

		// If this grading method is not ungraded, make sure we have at least one that is.
		if ($this->calculation_type && !$this->checkUngraded($this->id))
			$errors[] = DText::_('FIELD_GRADING_METHOD_NO_UNGRADED');

		if (in_array($this->calculation_type, array(
			'1',
			'2'
		)))
		{
			if (!is_numeric($this->lowest_pass) || $this->lowest_pass < 0 || $this->lowest_pass > 100)
				$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_LOWEST_PASS');
		}

		if ($this->calculation_type == '1')
		{
			// Calculated type validation
			if (!is_numeric($params->get('max_percent')) || !is_numeric($params->get('min_percent'))
				|| $params->get('max_percent') <= $params->get('min_percent'))
				$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_MIN_MAX_PERCENT');

			if (!is_numeric($params->get('best_mark')) || !is_numeric($params->get('worst_mark'))
				|| $params->get('best_mark') == $params->get('worst_mark'))
				$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_BEST_WORST_MARKS');

			if (!in_array((int) $params->get('decimal_places'), array(0, 1, 2)))
				$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_DECIMALS');
		}

		if ($this->calculation_type == '2')
		{
			// Tiered type validation
			$percents = array();
			$marks    = array();
			for ($i = 1; $i <= 30; $i++)
			{
				$percents[$i] = $params->get('tiered_min_percent' . str_pad($i, 2, '0', STR_PAD_LEFT));
				$marks[$i]    = $params->get('tiered_mark' . str_pad($i, 2, '0', STR_PAD_LEFT));
				if ($i == 1 && !is_numeric($percents[$i]))
					$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_TIERS');

				if ($i > 1 && is_numeric($percents[$i]) && $percents[$i] >= $percents[$i - 1])
					$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_TIER_OUT_OF_ORDER');

				if (is_numeric($percents[$i]) && !$marks[$i])
					$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_TIER_MUST_HAVE_VALUES');

			}
		}

		if ($this->calculation_type == '3')
		{
			for ($i = 1; $i <= 15; $i++)
			{
				$pass[$i]  = $params->get('manual_pass' . str_pad($i, 2, '0', STR_PAD_LEFT));
				$marks[$i] = $params->get('manual_mark' . str_pad($i, 2, '0', STR_PAD_LEFT));
				if ($i == 1 && (!isset($marks[$i]) || !in_array($pass[$i], array(
							0,
							1
						))))
					$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_MANUAL_TIERS');

				if (isset($pass[$i]) && !in_array($pass[$i], array(
						0,
						1
					)))
					$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_PASS_VALUE');

				if (isset($marks[$i]) && !in_array($pass[$i], array(
						0,
						1
					)))
					$errors[] = DText::_('FIELD_GRADING_METHOD_INVALID_PASS_VALUE');
			}
		}

		if (count($errors))
		{
			$message = '<ul>';
			foreach ($errors as $error)
				$message = $message . '<li>' . $error . '</li>';

			$message = $message . '</ul>';
			$this->setError($message);

			return false;
		}

		return true;

	}

	public function checkUngraded($id)
	{
		// Convert to array and sanitize
		$idArray = ArrayHelper::toInteger((array) $id);

		// Check that we have at least one ungraded method
		$db     = $this->getDbo();
		$query  = $db->getQuery(true)
			->select('COUNT(*)')
			->from('#__diler_activity_grading_method')
			->where('calculation_type = 0')
			->where('published = 1')
			->where('id NOT IN(' . implode(',', $idArray) . ')');
		$result = $db->setQuery($query)->loadResult();

		return (bool) $result;
	}

	public function publish($pks = null, $value = 1, $userId = 0)
	{
		// Make sure we are not changing our only manual grading method to unpublished
		if ($value != 1 && !$this->checkUngraded($pks))
			throw new \RuntimeException(DText::_('FIELD_GRADING_METHOD_NO_UNGRADED'));

		return parent::publish($pks, $value);
	}
}