<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

class CompcharTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_compchar', 'id', $db);
	}

	public function getCompetence()
	{
		if (!$this->id)
			return false;

		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('competence_id');
		$query->from('#__diler_competence_compchar_map');
		$query->where('compchar_id = ' . $this->id);
		$competenceId = $db->setQuery($query)->loadResult();

		$competenceTable = new CompetenceTable($db);
		$competenceTable->load($competenceId);

		return $competenceTable;
	}
}