<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;

class LevelTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_level', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		if ($array['published'] == 1 && intval($array['publish_up']) == 0)
			$array['publish_up'] = Factory::getDate()->toSql();

		if (isset($array['params']) && is_array($array['params']))
		{
			// Convert the params field to a string.
			$parameter = new Registry;
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}

		return parent::bind($array, $ignore);

	}

	public function check()
	{
		// Change to lower case and check for duplicate name
		$this->ordering = ($this->id) ? $this->ordering : self::getNextOrder();

		return true;
	}

	public function delete($pk = null)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->delete('#__diler_competence_compchar_map');
		$query->where('level_id = ' . $pk);
		$db->setQuery($query);;
		$db->execute();
		return parent::delete($pk);
	}
}