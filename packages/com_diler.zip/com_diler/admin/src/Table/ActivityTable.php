<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

defined('_JEXEC') or die('Restricted access');

class ActivityTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_activity', 'id', $db);
	}

	public function getCompchar()
	{
		if (!$this->id)
			return false;
		
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('compchar_id');
		$query->from('#__diler_activity_compchar_map');
		$query->where('activity_id = ' . $this->id);
		$compCharId = $db->setQuery($query)->loadResult();
		
		$compCharTable = new CompcharTable($db);
		$compCharTable->load($compCharId);
		
		return $compCharTable;
	}

	public function getActivityType()
	{
		if (!$this->activity_type)
			return false;

		$activityTypeTable = new ActivitytypeTable($this->getDbo());
		$activityTypeTable->load($this->activity_type);
		
		return $activityTypeTable;
	}
}