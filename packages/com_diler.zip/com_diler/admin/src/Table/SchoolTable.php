<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;
use Audivisa\Component\DiLer\Administrator\Helper\Diglu;
use DiLer\Lang\DText;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;
use Joomla\CMS\Table\Table;

// No direct access
defined('_JEXEC') or die('Restricted access');

class SchoolTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_school', 'id', $db);
	}

	public function bind($array, $ignore = '')
	{
		if (isset($array['params']) && is_array($array['params']))
		{
			$parameter = new Registry;
			$parameter->loadArray($array['params']);
			$array['params'] = (string) $parameter;
		}
		return parent::bind($array, $ignore);
	}

	public function check()
	{
		$this->name = htmlspecialchars_decode($this->name, ENT_QUOTES);

		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->from('#__diler_school')
			->select('COUNT(*)')
			->where('school_id = ' . $db->quote($this->school_id));
		if ($this->id) $query->where('id != ' . (int) $this->id);
		$duplicateNameCount = $db->setQuery($query)->loadResult();
		$error = $duplicateNameCount ? [DText::sprintf('SCHOOL_TABLE_DUPLICATE', DText::_('SCHOOL_ID_LABEL'))] : [];

		$query->clear('where')->where('email = ' . $db->quote($this->email));
		if ($this->id) $query->where('id != ' . (int) $this->id);
		$duplicateEmail = $db->setQuery($query)->loadResult();

		if ($duplicateEmail) $error[] = DText::sprintf('SCHOOL_TABLE_DUPLICATE', DText::_('CONFIG_SCHOOLOPERATOR_EMAIL_LABEL'));

        $diglu = new Diglu();
		if ($diglu->isEnabled())
		{
			$validPostalCode = $this->checkPostalCode();
			if (! $validPostalCode)
				$error[] = DText::sprintf('SCHOOL_TABLE_INVALID_POSTAL_CODE', $this->postal_code);
		}

		if (count($error))
		{
			$this->setError(implode('</br>', $error));
			return false;
		}
		else
		{
			return true;
		}

	}

	protected function checkPostalCode()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('COUNT(*)')
				->from('#__diler_region')
				->where('published = 1')
				->where('postal_code = ' . $db->quote($this->postal_code));
		return $db->setQuery($query)->loadResult();
	}

    public function delete($pk = null)
    {
        $db =  $this->getDbo();
        $query = $db->getQuery(true);
        $query->delete('#__diler_user_school_history');
        $query->where('school_id = ' . $pk);
        $db->setQuery($query);;
        $db->execute();
        return parent::delete($pk);
    }
}
