<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use DiLer\DGet;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

defined('_JEXEC') or die('Restricted access');

class PepGoalTable extends Table
{
	public $id;
	public $title;
	public $checked_by;

	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_pep_goal', 'id', $db);
	}

	public function store($updateNulls = false)
	{
		$currentDate = Factory::getDate()->toSql();;
		$currentUserId = DGet::user()->id();
		if (!$this->id)
		{
            $actionType = 'created';
			$this->created_by = $currentUserId;
			$this->created = $currentDate;
		}
		else
		{
            $actionType = 'edited';
			$this->modified = $currentDate;
			$this->modified_by = $currentUserId;
		}

        $saveStatus = parent::store($updateNulls);
        if (!$saveStatus)
            return false;

        $this->doLog($actionType);
        return true;
	}

	public function delete($pk = null)
	{
		if($this->isCheckedOut())
			throw new \Exception(DText::sprintf('PEP_METHOD_DELETE_NOT_ALLOWED_CHECKED_BY_OTHER_USER', DGet::user($this->checked_by)->personalData()->fullName()));

        $deleteStatus = parent::delete($pk);
        if (!$deleteStatus)
            return false;
        $this->doLog('deleted');
        return true;
	}

    private function doLog($actionType) : void
    {
        $logger = new \DilerLogger('pepgoal', $actionType);
        $logData = array(
            'username' => DGet::user()->personalData()->username(),
            'pepGoalTitle' => $this->title,
            'actionType' => DText::_($actionType)
        );
        $logger->addAction($logData, 'COM_DILER_LOG_PEP_GOAL_USER_ACTION');
    }
}