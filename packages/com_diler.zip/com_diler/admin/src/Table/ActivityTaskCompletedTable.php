<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

// No direct access
defined('_JEXEC') or die('Restricted access');

class ActivityTaskCompletedTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_activity_task_completed', array('task_id', 'student_id'), $db);
	}
	
	public function store($updateNulls = false)
	{
		if (!$this->hasPrimaryKey())
		{
			$taskTable = new ActivitytaskTable($this->getDbo());
			$taskTable->load($this->task_id);
			$this->task_name = $taskTable->name;
			$this->task_instruction = $taskTable->instruction;
			$this->task_max_points = $taskTable->max_points;
		}
		return parent::store($updateNulls);
	}

	public function getActivityTask()
	{
		if (!$this->task_id)
			return false;

		$query = $this->_db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_activity_task');
		$query->where('id = ' . (int) $this->task_id);
		$activityTaskId = $this->_db->setQuery($query)->loadResult();
		$activityTaskTable = new ActivitytaskTable($this->getDbo());
		$activityTaskTable->load($activityTaskId);

		return $activityTaskTable;
	}
}