<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

defined('_JEXEC') or die('Restricted access');

class ReportperiodTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_report_period', 'id', $db);
	}

	public function check()
	{
		if ($this->edit_start_date >= $this->edit_end_date)
		{
			Factory::getApplication()->enqueueMessage(DText::_('REPORTFIELD_PERIOD_INVALID_EDIT_DATES'), 'error');
			return false;
		}

		return true;
	}
}