<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Audivisa\Component\DiLer\Administrator\Helper\FileRootFolder;
use DiLer\Lang\DText;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

// No direct access
defined('_JEXEC') or die('Restricted access');

// @TODO try to extend DiLerTableCloud as most of the code is the same

class GridMediaTable extends Table
{
	function __construct(DatabaseDriver $db)
	{
        parent::__construct('#__diler_grid_media', 'id', $db);
	}

	public function check()
	{
		$checkPath = str_replace('\\', '/', $this->path);
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_grid_media');
		$query->where('path = ' . $db->quote($checkPath));

		if ($this->id)
			$query->where('id !=' . $this->id);

		$alreadyExists = $db->setQuery($query)->loadResult();
		if ($alreadyExists)
			$this->setError(DText::_('MEDIA_DUPLICATE_NAME'));
		
		return ! $alreadyExists;
	}
	
	public function delete($pk = null, $path = null)
	{
		$this->load($pk);
		File::delete(FileRootFolder::getPath() . $path);
	
		return parent::delete($pk);
	}
}
