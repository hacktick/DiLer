<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

// No direct access
defined('_JEXEC') or die('Restricted access');

class StudentrecordTable extends Table
{
	private $primaryKeyNameInChildTables = "studentrecord_id";

	private $relatedTables = array(
		'history',
		'group_map',
		'tag_map',
	);

	const STUDENT_RECORD_GROUP_CATEGORY_TAG_TYPE = 2;
	const STUDENT_RECORD_JOOMLA_CATEGORY_TAG_TYPE = 3;
	const STUDENT_RECORD_SUBJECT_CATEGORY_TAG_TYPE = 1;
	const DILER_SUBJECT_TABLE = '#__diler_subject';
	const DILER_GROUP_TABLE = '#__diler_group';
	const JOOMLA_CATEGORIES_TABLE = '#__categories';
	
	private $categoryTypes = array(
		self::DILER_SUBJECT_TABLE => self::STUDENT_RECORD_SUBJECT_CATEGORY_TAG_TYPE,
		self::DILER_GROUP_TABLE => self::STUDENT_RECORD_GROUP_CATEGORY_TAG_TYPE,
		self::JOOMLA_CATEGORIES_TABLE => self::STUDENT_RECORD_JOOMLA_CATEGORY_TAG_TYPE,
	);

	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_studentrecord', 'id', $db);
	}

	public function checkOut($userId, $pk = null)
	{
		$db = $this->getDbo();
		if ($pk)
		{
			$query = $db->getQuery(true)
				->select('*')
				->from('#__diler_studentrecord_tag_map')
				->where('studentrecord_id = ' . (int) $pk);
			$rows = $db->setQuery($query)->loadObjectList();

			$tagArray = array();
			foreach ($rows as $row)
				$tagArray[] = $row->tag_type . ':' . $row->tag_id;

			$this->tags = implode(',', $tagArray);
		}
		return parent::checkOut($userId, $pk);
	}

	public function delete($pk = null)
	{
		$this->deleteFromRelatedTablesByPrimaryKey($pk);
		return parent::delete($pk);
	}

	public function deleteRowsByPrimaryKey(array $keys)
	{
		if (!$keys)
			return false;
		
		foreach ($this->getRelatedTables() as $table)
			$this->deleteFromTableByPrimaryKeys($table, $this->primaryKeyNameInChildTables, $keys);
		
		$this->deleteFromTableByPrimaryKeys($this->getTableName(), $this->_tbl_key, $keys);
	}

	protected function isClassRegisterEntry(): bool
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('SUM(CASE WHEN gmap.id IS NULL THEN 0 ELSE 1 END) AS batch_count')
			->from('#__diler_studentrecord_group_map AS gmap')
			->where('gmap.studentrecord_id = ' . (int)$this->id);
		return $db->setQuery($query)->loadObject()->batch_count > 0;
	}

	public function store($updateNulls = false)
	{
		$isUpdate = (bool) $this->id;
		$newTags = isset($this->newTags) ? $this->newTags : null;
		unset ($this->newTags);

		$user = Factory::getApplication()->getIdentity();
		if ($user->authorise('studentrecord.edit', 'com_diler') ||
			($user->authorise('studentrecord.edit.own', 'com_diler') && (! $isUpdate || $user->id == $this->created_by || $this->isClassRegisterEntry())))
		{
			if (parent::store($updateNulls) && ! isset($this->saveOrder))
			{
				$this->processTags($this->id, $isUpdate, $newTags);
				$this->insertHistory();
				if (! $isUpdate)
					$this->updateOrdering();
			}
		}
		else
			return false;

		return true;
	}

	protected function updateOrdering()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->update('#__diler_studentrecord')
			->set('ordering = ordering + 1')
			->where('student_id = ' . (int) $this->student_id)
			->where('effective_date = ' . $db->quote($this->effective_date));
		$db->setQuery($query)->execute();

	}

	protected function insertHistory()
	{
		$db = $this->getDbo();
		$createdDate = $this->modified ? $this->modified : $this->created;
		$columns = new \stdClass();
		foreach ($this as $key => $value)
		{
			if (substr($key,0,1) != '_')
				$columns->$key = $value;
		}
		$jsonData = json_encode($columns);
		$query = $db->getQuery(true)
			->insert('#__diler_studentrecord_history')
			->set('studentrecord_id = ' . $this->id)
			->set('created = ' . $db->quote($createdDate))
			->set('created_by = ' . Factory::getApplication()->getIdentity()->id)
			->set('version_data = ' . $db->quote($jsonData));
		$db->setQuery($query)->execute();
	}

	protected function processTags($id, $isUpdate, $newTags)
	{
		$db = $this->getDbo();
		$insertCount = 0;
		if ($isUpdate)
		{
			$query = $db->getQuery(true)
				->delete('#__diler_studentrecord_tag_map')
				->where('studentrecord_id = ' . (int) $id);
			$db->setQuery($query)->execute();
		}

		if (is_array($newTags) && count($newTags))
		{
			$query = $db->getQuery(true)
				->insert('#__diler_studentrecord_tag_map')
				->columns('studentrecord_id, tag_id, tag_type');
			foreach ($newTags as $tag)
			{
				$tagArray = explode(':', $tag);
				if (is_array($tagArray) && count($tagArray) == 2 && in_array($tagArray[0], array(1,2,3)))
				{
					$insertCount++;
					$query->values((int) $id . ',' . (int) $tagArray[1] . ',' . (int) $tagArray[0]);
				}
			}
			if ($insertCount)
				$db->setQuery($query)->execute();
		}
	}

	private function deleteFromRelatedTablesByPrimaryKey($pk)
	{
		foreach ($this->getRelatedTables() as $table)
		{
			$query = $this->_db->getQuery(true);
			$query->delete($table);
			$query->where($this->primaryKeyNameInChildTables . ' = ' . $pk);
			$this->_db->setQuery($query)->execute();
		}
	}

	private function deleteFromTableByPrimaryKeys(string $table, string $primaryKeyName, array $keys)
	{
		$query = $this->_db->getQuery(true);
		$query->delete($table);
		$query->where($this->_db->quoteName($primaryKeyName) . ' IN (' . implode(', ', $keys) . ')');
		$this->_db->setQuery($query)->execute();
	}

	private function getRelatedTables()
	{
		return array_map(function ($table) {
			return $this->getTableName() . "_$table";
		}, $this->relatedTables);
	}

	public function getAllCategoriesWithData(array $whereStudentRecords = array(), bool $countTotalRecordsInTable = false)
	{
		$db = $this->getDbo();
		$query = $this->prepareCategoryQuery(self::JOOMLA_CATEGORIES_TABLE, $whereStudentRecords, $countTotalRecordsInTable);
		$query->union($this->prepareCategoryQuery(self::DILER_SUBJECT_TABLE, $whereStudentRecords, $countTotalRecordsInTable));
		$query->union($this->prepareCategoryQuery(self::DILER_GROUP_TABLE, $whereStudentRecords, $countTotalRecordsInTable));
		$query->order('title');
		
		return $db->setQuery($query)->loadAssocList();
	}

	public function deleteRecordsAssignedToNonExistingUsers()
	{
		$recordsForDelete = $this->getRecordsAssignedToNonExistingUsers();
		$this->deleteRowsByPrimaryKey($recordsForDelete);

		return count($recordsForDelete);
	}

	public function getRecordsAssignedToNonExistingUsers()
	{
		$query = $this->_db->getQuery(true);
		$query->select($this->getPrimayKeyWihtTableName());
		$query->from($this->getTableName());
		foreach ($this->getRelatedTables() as $relatedTable)
			$query->leftJoin("$relatedTable ON $relatedTable.$this->primaryKeyNameInChildTables = " . $this->getPrimayKeyWihtTableName());
		$query->leftJoin('#__users as jusers ON jusers.id = ' . $this->getTableName() . '.student_id');
		$query->where('jusers.id IS NULL');

		return $this->_db->setQuery($query)->loadColumn();
	}

	private function prepareCategoryQuery(string $tableName, array $whereStudentRecords = array(), $countTotal = false)
	{
		$fieldTitleName = $tableName === self::JOOMLA_CATEGORIES_TABLE ? 'title' : 'name';
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query = $this->prepareSelectCategoryQuery($query, $countTotal, $fieldTitleName);
		$query->select($this->categoryTypes[$tableName] . ' AS catType');
		$query->from('#__diler_studentrecord_tag_map AS tag');
		$query->innerJoin($tableName . ' AS cat ON cat.id = tag.tag_id AND tag.tag_type = ' . $this->categoryTypes[$tableName]);

		if ($whereStudentRecords)
		{
			$query->innerJoin($this->getTableName() . ' ON ' . $this->getPrimayKeyWihtTableName() . ' = tag.studentrecord_id');
			foreach ($whereStudentRecords as $where)
				$query->where($where);
		}
		
		$query->group('cat.id');
		return $query;
	}

	private function prepareSelectCategoryQuery($query, bool $countTotalRecordsInTable = false, string $titleFieldName = 'name')
	{
		$query->select("cat.id, cat.$titleFieldName AS title");
		if ($countTotalRecordsInTable)
			$query->select('COUNT(' . $this->getPrimayKeyWihtTableName() .') AS total');
		return $query;
	}

	private function getPrimayKeyWihtTableName()
	{
		return $this->getTableName() . '.' . $this->getKeyName();
	}
}