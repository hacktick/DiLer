<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;

use Audivisa\Component\DiLer\Site\Model\GroupModel;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

class GroupTable extends Table
{
	function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__diler_group', 'id', $db);
	}

	public function check()
	{
		// Set ordering within the category
		$catIdArray     = (new GroupModel())->getDilerGroupCategoriesForType($this->catid);
		$where          = 'catid IN(' . implode(',', $catIdArray) . ')';
		$this->ordering = ($this->id) ? $this->ordering : self::getNextOrder($where);

		return true;
	}

	public function getGroupNamesByJoomlaIds(array $joomlaGruopIds)
	{
		$query = $this->_db->getQuery(true);
		$query->select('name');
		$query->from($this->getTableName());
		$query->where('joomla_group_id IN (' . implode(',', $joomlaGruopIds) . ')');

		return $this->_db->setQuery($query)->loadColumn();
	}

}