<?php
/**
 * Test table construct, bind, load
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

namespace Audivisa\Component\DiLer\Administrator\Table;
// No direct access
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Tag\TaggableTableInterface;
use Joomla\CMS\Tag\TaggableTableTrait;

// Import Joomla table library
\JLoader::register('JTableObserverDilerTags', JPATH_ROOT . '/administrator/components/com_diler/tables/observer/dilertags.php');

/**
 * Nimbustemplate Table class
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 5.1
 */
class NimbustemplateTable extends Table implements TaggableTableInterface
{

	use TaggableTableTrait;
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function __construct(&$db)
	{
		parent::__construct('#__diler_nimbus_template', 'id', $db);
		//\JTableObserverDilerTags::createObserver($this, array('typeAlias' => 'com_diler.nimbus', 'parentTagParam' => 'nimbusParentTag'));
	}

	public function getTypeAlias()
	{
		return "com_diler.nimbus";
	}


	/**
     * Overloaded check function
     *
     * @return  boolean
     *
     * @throws  \Exception
     * @since   3.3
     * @see     Table::check
     */
	public function check()
	{
		$this->ordering = ($this->id) ? $this->ordering : self::getNextOrder('type = ' . $this->type);

		// Check that we don't have a duplicate template name.
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('id')
			->from('#__diler_nimbus_template')
			->where('name = ' . $db->quote($this->name));

		if ($this->id)
		{
			$query->where('id !=' . $this->id);
		}

		$alreadyExists = $db->setQuery($query)->loadResult();
		$task = Factory::getApplication()->input->get('task');
		if ($alreadyExists && $task != 'save2copy')
		{
			$this->setError(DText::_('NIMBUS_TEMPLATE_DUPLICATE_NAME'));
			return false;
		}
		else if ($alreadyExists)
		{
			// Fix the name to avoid a duplicate
			$this->name .= ' (copy)';
			$query->clear()
				->select('id')
				->from('#__diler_nimbus_template')
				->where('name = ' . $db->quote($this->name));
			$alreadyExists = $db->setQuery($query)->loadResult();
			if ($alreadyExists)
			{
				$this->setError(DText::_('NIMBUS_TEMPLATE_DUPLICATE_NAME'));
				return false;
			}
		}
		return true;
	}

}