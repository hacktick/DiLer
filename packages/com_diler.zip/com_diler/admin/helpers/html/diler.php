<?php
/**
 * Helper Methods for com_diler
 *
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	@copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('JPATH_BASE') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

/**
 * HTML classes for com_diler
 *
 * @package Joomla.Libraries
 * @subpackage HTML
 * @since 1.7
 */
abstract class JHtmlDilerAdmin
{
	/**
	 * Array containing information for loaded files
	 *
	 * @var    array
	 * @since  4.0
	 */
	protected static $loaded = array();

	/**
	 * Method to get Competence list, optionally filtered by subject id
	 *
	 * @return  array
     *
	 * @since   4.0
	 */
	public static function competences($subjectId)
	{
		$result = array();
		// Create a new query object.
		$db = Factory::getDBO();

		$query = $db->getQuery(true)
			->select('c.id, c.name')
			->from('#__diler_competence AS c')
			->where('c.published IN(0,1)')
			->order('c.name ASC');

		if ($subjectId)
		{
			$query->innerJoin(('#__diler_subject_competence_map AS m ON c.id = m.competence_id'));
			$query->where('m.subject_id = ' . (int) $subjectId);
		}

		$db->setQuery($query);
		$rows = $db->loadObjectList();
		// Loop for all data set into an array/list
		foreach ($rows as $row)
		{
			$result[] = HTMLHelper::_('select.option', $row->id, Text::_($row->name));
		}

		// return listed data
		return $result;
	}

}
