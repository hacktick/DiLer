<?php
/**
 * DiLer administrator default helpers
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Audivisa\Component\DiLer\Administrator\Helper\LogToFile;
use DiLer\Lang\DText;
use Joomla\CMS\Access\Access;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Object\CMSObject;
use Joomla\CMS\Helper\MediaHelper;
use Joomla\CMS\Uri\Uri;

/**
 * DiLer component default helper abstract class
 *
 * @static
 *
 * @package DiLer.Site
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
abstract class DiLerHelper
{
	const MINIMUM_REQUIRED_PHP_VERSION = '8.1.0';

	/**
	 * Checks whether the php version meet minimum version return true or false with warning message.
	 */
	public static function checkRequiredPhpVersion()
	{
		if (strnatcmp(phpversion(), self::MINIMUM_REQUIRED_PHP_VERSION) < 0) {
			Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/administrator/components/com_diler', null, true);
			$errorMessage = DText::sprintf('WARNING_MESSAGE_IF_NOT_MEET_PHP_VERSION', self::MINIMUM_REQUIRED_PHP_VERSION);
			Factory::getApplication()->enqueueMessage($errorMessage, 'error');
		}
	}

	/**
	 * Checks whether the activity files for this database have already been converted for DiLer Version 5.0.
	 *
	 * @return  bool  true if files have been converted, otherwise false.
	 */
	public static function activityFilesConverted50()
	{
		// Check if activities table has any rows. If so, we assume the conversion has already been done.
		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->select('COUNT(*)')
			->from('#__diler_activity');
		$count = $db->setQuery($query)->loadResult();
		return ($count > 0);
	}

	/**
	 * Configure the Linkbar.
	 *
	 * @param string $subMenu A string to get submenu item.
	 * @since 2.5
	 */
	public static function addSubmenu($subMenu = NULL)
	{
		$config = Factory::getConfig();
		$live_site = $config->get('live_site');
		$tmp_path = $config->get('tmp_path');
        $isDiglu = (new Audivisa\Component\DiLer\Administrator\Helper\Diglu)->isEnabled();

		// Set Submenus
		Factory::getLanguage()->load('com_dilerreg', JPATH_ROOT . '/administrator/components/com_dilerreg', null, true);
		JHtmlSidebar::addEntry(DText::_('DASHBOARD'), 'index.php?option=com_diler', $subMenu == 'DiLers');
		JHtmlSidebar::addEntry(DText::_('RELATIONSHIPS'), 'index.php?option=com_categories&extension=com_diler.relationships', $subMenu == 'categories.relationships');
		JHtmlSidebar::addEntry(Text::_('COM_DILERREG_REGISTRATION_CODES'), 'index.php?option=com_dilerreg&view=codes', $subMenu == 'codes');
		JHtmlSidebar::addEntry(Text::_('COM_DILERREG_USERS'), 'index.php?option=com_dilerreg&view=users', $subMenu == 'users');
		JHtmlSidebar::addEntry(DText::_('MARKS_PERIODS'), 'index.php?option=com_diler&view=marksperiods', $subMenu == 'marksperiods');
		JHtmlSidebar::addEntry(DText::_('CLASS_SCHEDULES'), 'index.php?option=com_diler&view=classschedules', $subMenu == 'classschedules');
		JHtmlSidebar::addEntry(DText::_('SCHOOLYEARS'), 'index.php?option=com_diler&view=schoolyears', $subMenu == 'schoolyears');
		JHtmlSidebar::addEntry(DText::sprintf('GROUP_CATEGORIES', DText::_('GROUPS_PLURAL')), 'index.php?option=com_categories&extension=com_diler.group', $subMenu == 'categories.group');
		JHtmlSidebar::addEntry(DText::_('STUDENTRECORD_CATEGORIES'), 'index.php?option=com_categories&extension=com_diler.studentrecord', $subMenu == 'categories.studentrecord');
		JHtmlSidebar::addEntry(DText::sprintf('GROUP_CATEGORIES', DText::_('CLOUD')), 'index.php?option=com_categories&extension=com_diler.cloud', $subMenu == 'categories.cloud');
		if ($isDiglu) JHtmlSidebar::addEntry(DText::_('CONTRACTTYPES'), 'index.php?option=com_diler&view=reporttypes&contract=1', $subMenu == 'contracttypes');
		JHtmlSidebar::addEntry(DText::_('REPORTTYPES'), 'index.php?option=com_diler&view=reporttypes', $subMenu == 'reporttypes');
		JHtmlSidebar::addEntry(DText::_('REPORTPERIODS'), 'index.php?option=com_diler&view=reportperiods', $subMenu == 'reportperiods');
		JHtmlSidebar::addEntry(DText::_('REPORTFIELDS'), 'index.php?option=com_diler&view=reportfields', $subMenu == 'reportfields');
		if (is_dir(str_replace("tmp", "wiki", $tmp_path))) JHtmlSidebar::addEntry(DText::_('WIKI'), $live_site . '/wiki', $subMenu == 'wiki');
		JHtmlSidebar::addEntry(DText::_('SECTIONS'), 'index.php?option=com_diler&view=sections', $subMenu == 'sections');
		JHtmlSidebar::addEntry(DText::_('PHASES'), 'index.php?option=com_diler&view=phases', $subMenu == 'phases');
		JHtmlSidebar::addEntry(DText::_('LEVELS'), 'index.php?option=com_diler&view=levels', $subMenu == 'levels');
		JHtmlSidebar::addEntry(DText::sprintf('LEARNING_CONTENT_SUBJECT_CATEGORIES', DText::_('SUBJECTS')), 'index.php?option=com_categories&extension=com_diler', $subMenu == 'categories');
		JHtmlSidebar::addEntry(DText::sprintf('LEARNING_CONTENT_SUBJECTS', DText::_('SUBJECTS')), 'index.php?option=com_diler&view=subjects', $subMenu == 'subjects');
		JHtmlSidebar::addEntry(DText::_('COMPETENCES'), 'index.php?option=com_diler&view=competences', $subMenu == 'competences');
		JHtmlSidebar::addEntry(DText::_('COMPCHARS'), 'index.php?option=com_diler&view=compchars', $subMenu == 'compchars');
		JHtmlSidebar::addEntry(DText::_('ACTIVITY_TYPES'), 'index.php?option=com_diler&view=activitytypes', $subMenu == 'activitytypes');
		JHtmlSidebar::addEntry(DText::_('GRADING_METHODS'), 'index.php?option=com_diler&view=gradingmethods', $subMenu == 'gradingmethods');
		JHtmlSidebar::addEntry(DText::_('COUNTRIES'), 'index.php?option=com_diler&view=countries', $subMenu == 'countries');
		if ($isDiglu) JHtmlSidebar::addEntry(DText::_('MINISTRIES'), 'index.php?option=com_diler&view=ministries', $subMenu == 'ministries');
		if ($isDiglu) JHtmlSidebar::addEntry(DText::_('REGIONS'), 'index.php?option=com_diler&view=regions', $subMenu == 'regions');
		JHtmlSidebar::addEntry(DText::_('SCHOOLS'), 'index.php?option=com_diler&view=schools', $subMenu == 'schools');
		JHtmlSidebar::addEntry(DText::_('LANGUAGEOVERRIDES'), 'index.php?option=com_diler&view=languageoverrides', $subMenu == 'languageoverrides');
		JHtmlSidebar::addEntry(DText::_('LOG_EVENTS_LOG'), 'index.php?option=com_diler&view=logevents', $subMenu == 'logevents');
		JHtmlSidebar::addEntry(DText::_('SYSTEM_INFORMATION'), 'index.php?option=com_diler&view=systeminformation', $subMenu == 'systeminformation');
		if (Factory::getUser()->authorise('core.admin'))
		{
			JHtmlSidebar::addEntry(DText::_('DATA_MANAGEMENT'), 'index.php?option=com_diler&view=datamanagement', $subMenu == 'datamanagement');
			JHtmlSidebar::addEntry(DText::_('PURGEDATA'), 'index.php?option=com_diler&view=purge', $subMenu == 'purge');
		}

		HTMLHelper::_('bootstrap.framework');

		$document = Factory::getDocument();
		$v = $document->getMediaVersion();

		// Add external asset/diler.css stylesheet.
		$document->addStyleSheet(Uri::root(true) . '/media/com_diler/administrator/css/diler.css?v=' . $v);
	}

    /**
     * Downloads a file
     *
     * @param string $fullName Full path/name of file
     * @param array $options
     * @return false|void
     * @throws Exception
     * @deprecated 8.0 use insead \Audivisa\Component\DiLer\Administrator\Helper\FileHelper::download
     */
	public static function downloadFile($fullName, $options = [])
	{
		$tempFolder = Factory::getConfig()->get('tmp_path') . '/diler/';
		$tempPath = $tempFolder . '/' . basename($fullName);
		if (isset($options['newExtension']))
		{
			$path_parts = pathinfo($tempPath);
			$tempPath = $path_parts['filename'] . '.' . $options['newExtension'];
		}

		if (! (Folder::create($tempFolder) && File::copy($fullName, $tempPath)))
		{
			return false;
		}
		header("Set-Cookie: fileDownload=true; path=/");
		header("Content-Description: File Transfer");
		header("Content-type: application/octet-stream");
		header("Content-Disposition: attachment; filename=" . basename($tempPath));
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header("Content-Length: " . filesize($tempPath));

		$result = readfile($tempPath);
		Factory::getApplication()->close();
	}

	/**
	 * Checks whether bulletin cache folder is writable
	 *
	 * @return bool true if cache folder writable
	 * @deprecated 8.0 instead use \Audivisa\Component\DiLer\Administrator\Helper\CachedNews::isWritable
	 * @see \Audivisa\Component\DiLer\Administrator\Helper\CachedNews::isWritable
	 */
	public static function newsCacheWritable()
	{
		$path = JPATH_ROOT . '/cache/com_diler/';
		$result = true;
		if (!file_exists($path))
		{
			$result = mkdir($path);
		}
		return $result && is_writable($path);
	}

	/**
	 * Get the actions
	 *
	 * @param integer $messageId An integer to get actions.
	 * @since 2.5
	 * @deprecated 8.0 instead use \Audivisa\Component\DiLer\Administrator\Helper\AccessHelper::getActions
	 * @see \Audivisa\Component\DiLer\Administrator\Helper\AccessHelper::getActions
	 */
	public static function getActions($messageId = 0)
	{

		// include access.access
		

		// global user
		$user = Factory::getUser();
		$result = new CMSObject();
		if (empty($messageId))
		{
			$assetName = 'com_diler';
		}
		else
		{
			$assetName = 'com_diler.message.' . (int) $messageId;
		}

		$actions = Access::getActionsFromFile(JPATH_ADMINISTRATOR . '/components/' . 'com_diler' . '/access.xml');

		foreach ($actions as $action)
		{
			$result->set($action->name, $user->authorise($action->name, $assetName));
		}
		return $result;
	}

	/**
	 * Get a list of Student Report Periods for which there is data
	 */
	public static function getActiveStudentReportPeriods()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('p.*')
			->from('#__diler_report_period AS p')
			->order('p.end_date ASC, p.name ASC');
		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Calculates the maximum upload file size based on PHP settings and DiLer setting.
	 *
	 * @return  int    Maximum allowed upload size for this site, in MB.
	 */
	public static function getMaxUploadSize($includeDilerOption = true)
	{
		$mediaHelper = new MediaHelper;
		$postMaxSize = $mediaHelper->toBytes(ini_get('post_max_size'));
		$memoryLimit = $mediaHelper->toBytes(ini_get('memory_limit'));
		$uploadMaxFileSize = $mediaHelper->toBytes(ini_get('upload_max_filesize'));
		$result = min(array($postMaxSize, $memoryLimit, $uploadMaxFileSize));
		$result = round($result / (1024*1024), 0);

		// Include DiLer option if it is set to non-zero value (it is already in MB)
		$dilerMax = ComponentHelper::getParams('com_diler')->get('upload_maxsize', 0);
		if ($includeDilerOption && $dilerMax)
		{
			$result = min(array($result, $dilerMax));
		}
		return $result;
	}

	/**
	 * Gets the role from either the reg codes table or for the user, depending on the row type.
	 *
	 * @param int $rowType  0 = dilerreg_registration_codes table, 1 = dilerreg_users table (use normal helper).
	 *
	 * @param int $id  Id of the user (id for reg codes, user_id for users)
	 *
	 * @return string  Role (parent, student, teacher)
	 */
	public static function getRole($rowType, $id)
	{
		$result = false;
		if ($rowType == '0')
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true)
				->select('role')
				->from('#__dilerreg_registration_codes')
				->where('id = ' . (int) $id);
			$result = $db->setQuery($query)->loadResult();
		}
		elseif ($rowType == '1')
		{
			$result = DilerHelperUser::getDilerRole($id);
		}
		return $result;
	}

	/**
	 * Gets the parents for a given student id and type
	 *
	 * @param int     $id      Id of the student
	 * @param int     $type    0=code (dilerreg_codes table), 1=user (dilerreg_users table)
	 *
	 * @return  array  Array of parents, in form array(parent1 => array('parent_id' => array(<parent id type>:<parent id>), 'relationship' => <relationship id>)))
	 */
	public static function getParentsForStudent($id, $type)
	{
		$parents = array();
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from('#__dilerreg_parent_student_map')
			->where('student_id = ' . (int) $id)
			->where('student_id_type = ' . (int) $type);
		$rows = $db->setQuery($query)->loadObjectList();

		foreach ($rows as $row)
		{
			$parents[$row->relationship][] = $row->parent_id_type . ':' . $row->parent_id;
		}

		$result = array();
		$i = 1;
		foreach ($parents as $relationship => $parentArray)
		{
			foreach ($parentArray as $parent)
			{
				$result['parent' . $i]['parent_id'][] = $parent;
				$result['parent' . $i]['relationship'] = $relationship;
			}
			$i++;
		}

		return $result;
	}

	public static function getStudentsForParent($id, $type)
	{
		$students = array();
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from('#__dilerreg_parent_student_map')
			->where('parent_id = ' . (int) $id)
			->where('parent_id_type = ' . (int) $type);
		$rows = $db->setQuery($query)->loadObjectList();

		foreach ($rows as $row)
		{
			$students[$row->relationship][] = $row->student_id_type . ':' . $row->student_id;
		}

		$result = array();
		$i = 1;
		foreach ($students as $relationship => $studentArray)
		{
			foreach ($studentArray as $student)
			{
				$result['student' . $i]['student_id'][] = $student;
				$result['student' . $i]['relationship'] = $relationship;
			}
			$i++;
		}

		return $result;
	}

	public static function getDigluTrainersForMinistry($id)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select("diglu_trainer_id");
		$query->from("#__diler_school_ministry_diglu_trainers_map");
		$query->where("ministry_id =" . $id);

		return $db->setQuery($query)->loadColumn();
	}

    /**
     * Records event in Joomla text log.
     *
     * @param $logOptions
     * @deprecated 8.0 use instead \Audivisa\Component\DiLer\Administrator\Helper\LogToFile::addLog
     * @see LogToFile::addLog()
     */
	public static function logEvent($logOptions)
	{
		$options ['format'] = '{DATE}\t{TIME}\t{LEVEL}\t{CODE}\t{MESSAGE}';
		$options ['text_file'] = $logOptions['logFile'];
		$categories = isset($logOptions['categories']) ? $logOptions['categories'] :  ['diler','error','warning'];
		Log::addLogger($options, Log::ALL, $categories);
		Log::add($logOptions['message'], $logOptions['status'], $logOptions['type']);
	}

	/**
	 * Deletes log file.
	 * @param string $logFile
	 * @deprecated 8.0 use instead \Audivisa\Component\DiLer\Administrator\Helper\LogToFile::deleteLogFile
	 * @see LogToFile::deleteLogFile()
	 */
	public static function logDelete($logFile)
	{
		$logPath = Factory::getConfig()->get('log_path');
		$fullPath = $logPath . '/' . $logFile;
		return File::delete($fullPath);
	}

	/**
	 * Checks whether the current media path is defined and writeable
	 * @deprecated  8.0 use instead Audivisa\Component\DiLer\Administrator\Helper\MediaHelper::isMediaPathWritable
	 * @see         Audivisa\Component\DiLer\Administrator\Helper\FileRootFolder::isWritable
	 */
	public static function mediaPathWriteable()
	{
		JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
		$rootFileFolder = DilerHelperUser::getRootFileFolder();
		return $rootFileFolder && is_writable(DilerHelperUser::getRootFileFolder());
	}

	/**
	 * Re-writes the parent_student_map rows for a parent or student.
	 *
	 * @param int     $id         ID of the parent or student
	 *
	 * @param string  $role       Role of user being edited: 'parent' or 'student'
	 * @param int     $tableType  0 = dilerreg_registration_code, 1 = dilerreg_users
	 * @param array   $dataArray  Array of mapping data from form
	 *
	 */
	public static function saveParentStudentMapRows($id, $role, $tableType, $dataArray)
	{
		// Build arrays for each map table (removing any duplicates)
		$userArray = array();
		if ($role == 'parent')
		{
			$targetRole = 'student';
			$arrayKey = 'student_id';
			$columns = 'parent_id_type, parent_id, student_id_type, student_id, relationship';
			$whereId = 'parent_id';
			$whereIdType = 'parent_id_type';
		}
		else
		{
			$targetRole = 'parent';
			$arrayKey = 'parent_id';
			$columns = 'student_id_type, student_id, parent_id_type, parent_id, relationship';
			$whereId = 'student_id';
			$whereIdType = 'student_id_type';
		}

		if (isset($dataArray) && is_array($dataArray) && $dataArray)
		{
			foreach ($dataArray as $tempArray)
			{
				foreach ($tempArray[$arrayKey] as $userId)
				{
					$userArray[$userId] = $tempArray['relationship'];
				}
			}
		}

		// Remove old map rows for this parent
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__dilerreg_parent_student_map')
			->where($whereId . ' = ' . (int) $id)
			->where($whereIdType . ' = ' . (int) $tableType);
		$db->setQuery($query)->execute();

		// Insert new map rows
		$query->clear()
			->insert('#__dilerreg_parent_student_map')
			->columns($columns);
		foreach ($userArray as $userTypeId => $relationship)
		{
			$typeArray = explode(':', $userTypeId);
			if (is_array($typeArray) && count($typeArray) == 2)
			{
				// Check that the user is the desired target role
				$userRole = static::getRole($typeArray[0], $typeArray[1]);
				if ($userRole == $targetRole)
				{
					$query->values((int) $tableType . ',' . (int) $id . ',' . (int) $typeArray[0] . ',' . $typeArray[1] . ',' . (int) $relationship);
				}
			}
		}
		if ((string) $query->values)
		{
			$db->setQuery($query)->execute();
		}
	}

	/**
	 * Re-writes rows in table diler_ministry_diglu_trainers_map
	 * @param mixed $id
	 * @param mixed $diglu_trainers
	 * @return void
	 */

	public static function saveMinistryDigluTrainerMapRows($id, $diglu_trainers)
	{
		$db = Factory::getDbo();
		$deleteQuery = $db->getQuery(true);

		$deleteQuery->delete('#__diler_school_ministry_diglu_trainers_map');
		$deleteQuery->where('ministry_id = ' . $id);
		$db->setQuery($deleteQuery)->execute();

		if (!$diglu_trainers)
			return;

		$columns = array('ministry_id', 'diglu_trainer_id');

		$insertQuery = $db->getQuery(true);
		$insertQuery->insert('#__diler_school_ministry_diglu_trainers_map');
		$insertQuery->columns($columns);
		foreach ($diglu_trainers as $digluTrainer)
			$insertQuery->values($id . ', ' . $db->quote($digluTrainer));

		$db->setQuery($insertQuery)->execute();
	}

}
