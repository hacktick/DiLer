<?php
/**
 * @copyright      Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

defined('_JEXEC') or die('Restricted access');

/**
 * @since 6.11.0
 */
class DiLerModelRegions extends ListModel
{
	/**
	 * Method to construct configuration
	 *
	 * @param array Configuration array for model. Optional.
	 *
	 * @return void
	 * @since 6.11.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'a.country_iso2',
				'country_iso2',
				'postal_code',
				'a.postal_code',
				'a.city', 'city', 'a.community', 'community','a.state_iso','state_iso',
				'ordering',
				'a.ordering',
				'published',
				'a.published'
			);
		}

		parent::__construct($config);
	}

	/**
	 * @return JDatabaseQuery An SQL query
	 * @since 6.11.0
	 */
	protected function getListQuery()
	{
		$db    = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('a.*');
		$query->from($db->quoteName('#__diler_region') . ' AS a');
		$subquery = $db->getQuery(true)->select('country_iso2, postal_code, COUNT(*) AS school_count')
				->from('#__diler_school')
				->group('country_iso2, postal_code');
		$query->leftJoin('(' . (string) $subquery . ') AS sch ON a.country_iso2 = sch.country_iso2 AND a.postal_code = sch.postal_code');
		$query->select('sch.school_count');
		$query->group('a.id');
		$query = $this->getRegionTeachersQuery($query);

		$search = $this->state->get('filter.search');
		if (!empty($search))
		{
			$search = $db->Quote('%' . $db->escape($search, true) . '%');
			$query->where('(a.postal_code LIKE ' . $search . ' OR a.city LIKE ' . $search . ' OR a.community LIKE ' . $search . ')');
		}

		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		$orderCol  = $this->state->get('list.ordering', 'a.country_iso2,a.state_iso,a.postal_code');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		return $query;
	}

	private function getRegionTeachersQuery(JDatabaseQuery $query) : JDatabaseQuery
	{
		$db = Factory::getDBO();
		$subQuery = $db->getQuery(true);
		$subQuery->select('GROUP_CONCAT(CONCAT(du.forename, " ", du.surname) SEPARATOR ", ")');
		$subQuery->from('#__diler_region_user_map AS rum');
		$subQuery->where('rum.region_id = a.id');
		$subQuery->innerJoin('#__dilerreg_users as du ON du.user_id = rum.user_id');

		$query->select('(' . $subQuery . ') AS region_teachers');
		return $query;
	}

	/**
	 * @since 6.11.0
	 */
	public function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.id', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');

		return parent::getStoreId($id);
	}

	// Gets list of regions for a teacher for the contact display
	public function getRegionForTeacher($userId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('DISTINCT r.community')
				->from('#__diler_region_user_map AS rm')
				->innerJoin('#__diler_region AS r ON r.id = rm.region_id')
				->where('rm.user_id = '. (int) $userId)
				->where('r.published = 1');
		return $db->setQuery($query)->loadColumn();

	}
}
