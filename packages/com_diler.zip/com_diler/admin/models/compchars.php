<?php
/**
 * Comp Char list, subject list, level list, competence list,comp char data export
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

// import the Joomla modellist library
jimport('joomla.application.component.modellist');

/**
 * CompChars model.
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @since		2.5
 */
 class DiLerModelCompChars extends ListModel
{
     /**
      * Method to construct configuration
      * @param array   Configuration array for model. Optional.
      * @return void.
      * @throws Exception
      * @since 2.5
      */
        public function __construct($config = array())
		{
				if (empty($config['filter_fields'])) {
					$config['filter_fields'] = array(
						'name', 'ccname','competence','subject',
						'published', 'ccpublished',
						'id', 'ccid',
						'language', 'cclanguage',
						'cname',
						'level','level_id',
						'phase', 'ccphase',
						'sname','subject_id'
					);

					$app = Factory::getApplication();
				}

				parent::__construct($config);
		}


	    /**
         * Method to build an SQL query to load the list data.
         *
         * @return      string  An SQL query
         * @throws Exception
         */
        protected function getListQuery()
        {
        		$input = Factory::getApplication()->input;
                // Create a new query object.
                $db = Factory::getDBO();
                $query = $db->getQuery(true);

				// Select some fields
                $query->select('cc.id as ccid,'.
							'cc.name as ccname,'.
							'cc.description as ccdesc,'.
							'cc.published as ccpublished,'.
						    'cc.language as cclanguage,'.
							'cc.publish_up as ccpublish_up,'.
							'cc.publish_down as ccpublish_down,'.
							'cc.checked_out as ccchecked_out,'.
							'cc.checked_out_time as ccchecked_out_time,'.
							'cc.created_by as cccreated_by'
						);

				$query->from($db->quoteName('#__diler_compchar').' AS cc');


				// Join over the competence
				$query->select('co.id as cid, co.name as cname, co.description as cdesc, co.icon as cico');
				$query->innerJoin('#__diler_competence_compchar_map AS ccm ON ccm.compchar_id = cc.id');
				$query->innerJoin('#__diler_competence AS co ON co.id = ccm.competence_id');

				$query->select('ph.value as phase');
				$query->leftJoin('#__diler_subject_competence_map AS scm ON ccm.competence_id = scm.competence_id');
				$query->innerJoin('#__diler_phase AS ph ON ph.id = scm.phase_id');

				// Join over the level.
				$query->select('le.id as lid,'.
							'le.name as lname,'.
							'le.description as ldesc');
				$query->innerJoin('#__diler_level AS le ON le.id = ccm.level_id');

  				//if get filter BY Keyword Search
				// Filter by search in name,description
				$search = $this->getState('filter.search');
				if (!empty($search)) {
					if (stripos($search, 'id:') === 0) {
						$query->where('cc.id = '.(int) substr($search, 3));
					} else {
						$search = $db->quote('%'.$db->escape($search, true).'%');
						//search data from competence characteristic name
						$query->where('(cc.name LIKE ' . $search . ' OR cc.description LIKE ' . $search . ')');
					}
				}

				//if get filter BY competence id
				$competence = $this->getState('filter.competence');
				if($competence)
				{
					 $query->where('ccm.competence_id = ' . (int) $competence);
				}

				$level = $this->getState('filter.level');
				if(is_numeric($level)) {

						$query->where(" ccm.level_id = " . (int) $level);
				}

				$phase = $this->getState('filter.phase');
				if ($phase)
				{
					$query->where('ph.id = ' . (int) $phase);
				}

				// Join over the subject
				$subQuery = $db->getQuery(true)
					->select('scm.competence_id, GROUP_CONCAT(s.name) as sname, GROUP_CONCAT(s.description) as sdesc')
					->select('GROUP_CONCAT(s.id) AS subject_id_list')
					->from('#__diler_subject_competence_map AS scm')
					->innerJoin('#__diler_subject AS s ON scm.subject_id = s.id')
					->group('scm.competence_id');

				//if get filter BY subject id
				if($input->getUint('filter_subject')>0)
				{
					$filter_subject = $input->getUint('filter_subject');
 					$subQuery->where('scm.subject_id = ' . $db->quote((int) $filter_subject));
				}
				// Subject filter.
				$subject = $this->getState('filter.subject');
				if(is_numeric($subject))
				{
					$subQuery->where('scm.subject_id = ' . $db->quote((int) $subject));
				}

				$query->select('sname, sdesc');
				$query->innerJOIN('(' . trim((string) $subQuery) . ') AS sub ON sub.competence_id = ccm.competence_id');

				$published = $this->getState('filter.published');
				if (is_numeric($published)) {
					$query->where('cc.published = ' . (int) $published);
				}
				elseif ($published === '') {
					$query->where('(cc.published = 0 OR cc.published = 1)');
				}

        		//order by [field] [direction]
				$orderCol = $this->state->get('list.ordering', 'cc.name');
				$orderDirn = $this->state->get('list.direction', 'asc');
				$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
               return $query;
        }

		/**
		* Method to populate publish
		* @since 2.5
		*/
		protected function populateState($ordering = null, $direction = null) {
			$published = $this->getUserStateFromRequest($this->context.'.filter.published', 'filter_published', '');
			$this->setState('filter.published', $published);
			$competence = $this->getUserStateFromRequest($this->context.'.filter.competence', 'filter_competence', '');
			$this->setState('filter.competence', $competence);
			$level = $this->getUserStateFromRequest($this->context.'.filter.level', 'filter_level', '');
			$this->setState('filter.level', $level);
			$phase = $this->getUserStateFromRequest($this->context.'.filter.phase', 'filter_phase', '');
			$this->setState('filter.phase', $phase);
			$subject = $this->getUserStateFromRequest($this->context.'.filter.subject', 'filter_subject', '');
			$this->setState('filter.subject', $subject);
			$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
			$this->setState('filter.search', $search);
			parent::populateState('cc.name', 'asc');
       }


       protected function getStoreId($id = '')
	   {
	   		$id	.= ':'.$this->getState('filter.published');
			return parent::getStoreId($id);
	   }

		/**
		* Method to get level list
		* @return array $result Array select option
		* @since 2.5
		*/
		function getLevelList()
		{
				$result = array();
				 // Create a new query object.
                $db = Factory::getDBO();

				// Sql String to get level data
                $query = " SELECT id,name FROM #__diler_level where published = 1 order by name asc ";
                $db->setQuery($query);
				$rows=$db->loadObjectList();

				//loop for all data set in an array.
				foreach($rows as $row)
				{
					$result[] = HTMLHelper::_('select.option', $row->id, Text::_($row->name));
				}
                return $result;
 		}
}