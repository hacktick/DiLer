<?php

/**
 * Schoolyears list
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Schoolyears model.
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @since		2.5
 */
class DiLerModelSchoolyears extends ListModel
{

    /**
     * Method to construct configuration
     * @param       array   Configuration array for model. Optional.
     * @return      void.
     * @throws      Exception
     * @since       2.5
     */
	public function __construct($config = array()) {
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id', 'a.current',
				'published', 'a.published',
				'a.level', 'level', 'start_date', 'end_date',
			);

			$app = Factory::getApplication();
		}

		parent::__construct($config);
	}

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return      string  An SQL query
	 */
	protected function getListQuery() {
		// Create a new query object.
		$db = Factory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('*');
		$query->from($db->quoteName('#__diler_schoolyear') . ' AS a');

		//if get filter BY Keyword Search
		// Filter by search in value,description
		$search = $this->state->get('filter.search');
		if (!empty($search))
		{
			$search = $db->Quote('%' . $db->escape($search, true) . '%');
			//search data from phase value
			$query->where('(a.name LIKE ' . $search . 'OR a.description LIKE ' . $search . ')');
		}

		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		} elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		return $query;
	}

	/**
	 * Method to populate publish
	 * @since 2.5
	 */
	public function populateState($ordering = null, $direction = null) {
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.name', 'asc');
	}

	protected function getStoreId($id = '') {
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}

}
