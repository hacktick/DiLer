<?php
/**
 * Phases list
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Phases model.
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @since		2.5
 */
 class DiLerModelPhases extends ListModel
{
     /**
      * Method to construct configuration
      * @param array   Configuration array for model. Optional.
      * @return void.
      * @throws Exception
      * @since 2.5
      */


        public function __construct($config = array())
		{
				if (empty($config['filter_fields'])) {
					$config['filter_fields'] = array(
					     'id', 'a.id',
						'published', 'a.published',
						'a.level', 'level','user_count', 'a.value * 1', 'value * 1', 'a.ordering'
					);

					$app = Factory::getApplication();
				}

				parent::__construct($config);
		}

        /**
         * Method to build an SQL query to load the list data.
         *
         * @return      string  An SQL query
         */
        protected function getListQuery()
        {
			// Create a new query object.
			$db = Factory::getDBO();
			$query = $db->getQuery(true);

			// Select some fields
			$query->select('*');
			$query->from($db->quoteName('#__diler_phase') . ' AS a');

            $subQuery = $db->getQuery(true)
                ->select('du.student_phase_actual AS phase_id, COUNT(*) AS user_count')
                ->from('#__dilerreg_users as du')
	            ->innerJoin('#__users as ju on ju.id = du.user_id')
	            ->where('ju.block = 0')
                ->group('student_phase_actual');
			$query->leftJoin('(' . (string) $subQuery . ') AS uc ON uc.phase_id = a.id');
			$query->select('CASE WHEN uc.phase_id IS NULL THEN 0 ELSE uc.user_count END as user_count');

			//if get filter BY Keyword Search
			// Filter by search in value,description
			$search = $this->state->get('filter.search');
			if (!empty($search)) {
				$search = $db->Quote('%'.$db->escape($search, true).'%');
				//search data from phase value
				$query->where('(a.value LIKE ' . $search . 'OR a.description LIKE ' . $search . ')');
			}

			$published = $this->getState('filter.published');
			if (is_numeric($published)) {
				$query->where('a.published = ' . (int) $published);
			}
			elseif ($published === '') {
				$query->where('(a.published = 0 OR a.published = 1)');
			}

			$orderCol = $this->state->get('list.ordering', 'a.value * 1');
			$orderDirn = $this->state->get('list.direction', 'asc');
			$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
            //dd($db->setQuery($query)->loadObjectList());
			return $query;
        }

		/**
		* Method to populate publish
		* @since 2.5
		*/
		public function populateState($ordering = null, $direction = null) {
			$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
			$this->setState('filter.published', $published);
			$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
			$this->setState('filter.search', $search);
			parent::populateState('a.value * 1', 'asc');
       }


       protected function getStoreId($id = '')
	   {
			$id	.= ':'.$this->getState('filter.published');
			return parent::getStoreId($id);
	   }
}