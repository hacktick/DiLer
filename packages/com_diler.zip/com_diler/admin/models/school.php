<?php
/**
 * School data edit, update
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use DiLer\Models\School;
use Joomla\CMS\Form\Form;

JLoader::register('DilerModelSchools', JPATH_ADMINISTRATOR . '/components/models/schools.php');

/**
 * School model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelSchool extends AdminModel
{
	use School;

	/**
	 * Override parent function
	 *
	 * @param   array  $commands  An array of commands to perform.
	 * @param   array  $pks       An array of item ids.
	 * @param   array  $contexts  An array of item contexts.
	 *
	 * @return  boolean  Returns true on success, false on failure.
	 *
	 * @since   1.7
	 */
	public function batch($commands, $pks, $contexts)
	{
		if (empty($commands['region-id']) || empty($pks))
		{
			$this->setError(DText::_('SCHOOL_BATCH_REGION_EMPTY'));
			return false;
		}
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_school')
				->set('region_id = ' . (int) $commands['region-id'])
				->where('id IN(' . implode(',', $pks) . ')');
		return $db->setQuery($query)->execute();
	}

	public function getTable($type = 'School', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (current case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.school', 'school',
		array('control' => 'jform','load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Method to get the script that has to be included on the form-page
	 *
	 * @return string Script files
	 */
	public function getScript()
	{
		return 'administrator/components/com_diler/models/forms/reporttype.js';
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.school.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

}
