<?php
/**
 * Inputs to get test lists, test test list
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Utilities\ArrayHelper;

JLoader::register('ActionlogsHelper', JPATH_ADMINISTRATOR . '/components/com_actionlogs/helpers/actionlogs.php');

/**
 * Inputs model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 4.2
 */
class DiLerModelLogevents extends ListModel
{

	private $actionLogAlias = 'action_logs';
	private $dilerLogAlias = 'a';
	private $comptenceAlias = 'c';
	private $competenceMapAlias = "scm";

	/**
	 * @var string Alias for selected unioned tables
	 */
	private $logsAlias = 'logs';

	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'action',
				'extension',
				'subject',
				'competence',
				'level',
				'phase',
				'begin',
				'end',
				'create_time',
				'a.action',
				'a.subject',
				'a.competence',
				'a.level',
				'a.phase',
				'a.begin',
				'a.end',
				'a.create_time'
			);
		}

		parent::__construct($config);
	}

	protected function _getList($query, $limitstart = 0, $limit = 0)
	{
		try {
			return parent::_getList($query, $limitstart, $limit);
		} catch (Exception $exception)
		{

			// Make sure both Joomla and DiLer log tables have correct COLLATION
			if ($exception->getMessage() === "Illegal mix of collations for operation 'UNION'")
			{
				$this->getDbo()->alterTableCharacterSet('#__action_logs');
				$this->getDbo()->alterTableCharacterSet('#__diler_log');
			}

			Factory::getApplication()->enqueueMessage(DText::_('LOG_ACTION_AFTER_ERROR_PLEASE_RELOAD_PAGE'), 'warning');
			return false;
		}
	}

	/**
	 * Method to get an array of data items.
	 *
	 * @return  mixed  An array of data items on success, false on failure.
	 *
	 * @since   1.6
	 */
	public function getItems()
	{
		$items = parent::getItems();

		if (!$items)
			return false;

		/**
		 * Since we are loading items from #__action_logs, let's prepare messages that's displayed in event log list.
		 */
		foreach ($items as $key => $item)
		{
			if ($item->extension !== $this->option && !$item->target_type)
			{
				$loggedItem                       = new stdClass;
				$loggedItem->message              = $item->event_message;
				$loggedItem->message_language_key = $item->action;
				$items[$key]->event_message       = ActionlogsHelper::getHumanReadableLogMessage($loggedItem);
			}
		}

		return $items;
	}

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @param string $rel_type A string of input data.
	 * @return string An SQL query
	 */
	protected function getListQuery($rel_type = null)
	{
		$db          = $this->getDbo();
		$query       = $db->getQuery(true);
		$dilerTable  = $this->getDilerLogsQuery();
		$actionTable = $this->getActionLogQuery();
		$query->select('*');
		$query->from("($dilerTable UNION $actionTable) as $this->logsAlias");

		if ($filterSearch = $this->getState('filter.search'))
		{
			$query->where('event_message LIKE ' . $db->quote('%' . $filterSearch . '%'));
		}

		$phase = $this->getState('filter.phase');
		if (is_numeric($phase))
		{
			$query->leftJoin("#__diler_subject_competence_map AS $this->competenceMapAlias ON $this->logsAlias.competence_id = $this->competenceMapAlias.competence_id");
			$query->where("$this->competenceMapAlias.phase_id = " . (int) $phase);
		}

		if ($extension = $this->getState('filter.extension'))
		{
			$query->where("extension = '$extension'");
		}

		$subject = $this->getState('filter.subject');
		if (is_numeric($subject))
		{
			$query->where("$this->logsAlias.subject_id = " . (int) $subject);
		}

		$level = $this->getState('filter.level');
		if (is_numeric($level))
		{
			$query->where('level_id = ' . (int) $level);
		}
		$localTimezone = Factory::getUser()->getParam('timezone', Factory::getConfig()->get('offset'));
		$now           = Factory::getDate('now', $localTimezone);
		$offset        = $now->getOffsetFromGMT(true);

		$beginDate = $this->getState('filter.begin');
		if ($beginDate > ' ')
		{
			$query->where('DATE(create_time + INTERVAL ' . $offset . ' HOUR) >= ' . $db->quote($beginDate));
		}

		$endDate = $this->getState('filter.end');
		if ($endDate > ' ')
		{
			$query->where('DATE(create_time + INTERVAL ' . $offset . ' HOUR) <= ' . $db->quote($endDate));
		}

		$competence = $this->getState('filter.competence');
		if (is_numeric($competence))
		{
			$query->where("$this->logsAlias.competence_id = " . (int) $competence);
		}

		$action = $this->getState('filter.action');
		if ($action)
		{
			$query->where('CONCAT(target_type, ".", action) = ' . $db->quote($action));
		}

		// order by [field] [direction]
		$orderCol  = $this->state->get('list.ordering', 'create_time');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		return $query;
	}

	private function getDilerLogsQuery()
	{
		$key   = DiLerConfig::$permanentValue;
		$db    = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select(
			array(
				"$this->dilerLogAlias.id",
				"$this->dilerLogAlias.application",
				"$this->dilerLogAlias.extension",
				"$this->dilerLogAlias.target_type",
				"$this->dilerLogAlias.action",
				"$this->dilerLogAlias.create_time",
				"$this->dilerLogAlias.subject_id",
				"$this->dilerLogAlias.competence_id",
				"$this->dilerLogAlias.level_id",
				'CONVERT(AES_DECRYPT(message, SHA1(CONCAT(' . $this->dilerLogAlias . '.create_time,' . $db->quote($key) . '))) using utf8) AS event_message'
			)
		);
		$query->from("#__diler_log AS $this->dilerLogAlias");
		$query->leftJoin("#__diler_competence as $this->comptenceAlias ON $this->dilerLogAlias.competence_id = $this->comptenceAlias.id");

		return $query;
	}

	private function getActionLogQuery()
	{
		$db    = $this->getDbo();
		$query = $db->getQuery(true);

		// We need to have empty selects to match same number of rows, it's required if we are using UNION select.
		$query->select(array(
			"$this->actionLogAlias.id",
			"'' as application",
			"$this->actionLogAlias.extension",
			"'' as target_type",
			"$this->actionLogAlias.message_language_key as actions",
			"$this->actionLogAlias.log_date as create_time",
			"'' as subjet_id",
			"'' as competence_id",
			"'' as level_id",
			"$this->actionLogAlias.message as event_message"
		));
		$query->from("#__action_logs as $this->actionLogAlias");

		return $query;
	}

	/**
	 * Method to populate publish
	 *
	 * @since 2.5
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);

		$search = $this->getUserStateFromRequest($this->context . '.filter.extension', 'filter_extension', '');
		$this->setState('filter.extension', $search);

		$phase = $this->getUserStateFromRequest($this->context . '.filter.phase', 'filter_phase', '');
		$this->setState('filter.phase', $phase);

		$subject = $this->getUserStateFromRequest($this->context . '.filter.subject', 'filter_subject', '');
		$this->setState('filter.subject', $subject);

		$level = $this->getUserStateFromRequest($this->context . '.filter.level', 'filter_level', '');
		$this->setState('filter.level', $level);

		$competence = $this->getUserStateFromRequest($this->context . '.filter.competence', 'filter_competence', '');
		$this->setState('filter.competence', $competence);

		$beginDate = $this->getUserStateFromRequest($this->context . '.filter.begin', 'filter_begin', '');
		$this->setState('filter.begin', $beginDate);

		$endDate = $this->getUserStateFromRequest($this->context . '.filter.end', 'filter_end', '');
		$this->setState('filter.end', $endDate);

		$action = $this->getUserStateFromRequest($this->context . '.filter.action', 'filter_action', '');
		$this->setState('filter.action', $action);

		parent::populateState('create_time', 'desc');
	}

	/**
	 * Gets a stdClass of actions and translated text values for the action filter.
	 *
	 * @return array
	 */
	public function getLogActions()
	{
		$actions = array(
			array('value' => 'admin.edit', 'text' => 'COM_DILER_LOG_ACTION_ADMIN_EDIT'),
			array('value' => 'admin.delete', 'text' => 'COM_DILER_LOG_ACTION_ADMIN_DELETE'),
			array('value' => 'admin.purge', 'text' => 'COM_DILER_LOG_ACTION_ADMIN_PURGE'),
			array('value' => 'user.login.admin', 'text' => 'COM_DILER_LOG_ACTION_LOGIN_ADMIN'),
			array('value' => 'user.login', 'text' => 'COM_DILER_LOG_ACTION_LOGIN'),
			array('value' => 'user.login.fail', 'text' => 'COM_DILER_LOG_ACTION_LOGIN_FAIL'),
			array('value' => 'user.logout', 'text' => 'COM_DILER_LOG_ACTION_LOGOUT'),
			array('value' => 'user.register', 'text' => 'COM_DILER_LOG_ACTION_USER_REGISTER'),
			array('value' => 'user.delete', 'text' => 'COM_DILER_LOG_ACTION_USER_DELETE'),
			array('value' => 'user.learninggroups', 'text' => 'COM_DILER_LOG_ACTION_USER_LEARNING_GROUPS'),
			array('value' => 'user.phases', 'text' => 'COM_DILER_LOG_ACTION_USER_PHASES,COM_DILER_PHASES'),
			array('value' => 'user.extracurriculars', 'text' => 'COM_DILER_LOG_ACTION_USER_EXTRACURRICULARS'),
			array('value' => 'profile.update', 'text' => 'COM_DILER_LOG_ACTION_PROFILE_UPDATE'),
			array('value' => 'activity.reset', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_RESET'),
			array('value' => 'activity.request', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_REQUEST'),
			array('value' => 'activity.deny', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_REQUEST_DENY'),
			array('value' => 'activity.accept', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_REQUEST_ACCEPT'),
			array('value' => 'activity.grade', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_GRADE'),
			array('value' => 'activity.complete', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_COMPLETE'),
			array('value' => 'activity.mark.complete', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_MARK_COMPLETE'),
			array('value' => 'activity.edit', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_EDIT'),
			array('value' => 'activity.delete', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_DELETE'),
			array('value' => 'activity.comment', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_COMMENT'),
			array('value' => 'activity.error', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_ERROR'),
			array('value' => 'activity.started', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_STARTED'),
			array('value' => 'activitytask.complete', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_TASK_COMPLETE'),
			array('value' => 'activitytask.edit', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_TASK_EDIT'),
			array('value' => 'activitytask.delete', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_TASK_DELETE'),
			array('value' => 'activitytask.save.order', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_TASK_SAVE_ORDER'),
			array('value' => 'activitytask.toggle.publish', 'text' => 'COM_DILER_LOG_ACTION_ACTIVITY_TASK_TOGGLE_PUBLISH'),
			array('value' => 'compchar.save.status', 'text' => 'COM_DILER_LOG_ACTION_COMPCHAR_SAVE_STATUS'),
			array('value' => 'competences.save.status', 'text' => 'COM_DILER_LOG_ACTION_COMPETENCES_SAVE_STATUS'),
			array('value' => 'group.batch.add.users', 'text' => 'COM_DILER_LOG_ACTION_GROUP_BATCH_ADD_USERS'),
			array('value' => 'group.batch.remove.users', 'text' => 'COM_DILER_LOG_ACTION_GROUP_BATCH_REMOVE_USERS'),
			array('value' => 'group.batch.subject.process', 'text' => 'COM_DILER_LOG_ACTION_GROUP_BATCH_SUBJECT_PROCESS'),
			array('value' => 'group.delete', 'text' => 'COM_DILER_LOG_ACTION_GROUP_DELETE'),
			array('value' => 'group.rollover', 'text' => 'COM_DILER_LOG_ACTION_GROUP_ROLLOVER'),
			array('value' => 'group.assign.user', 'text' => 'COM_DILER_LOG_ACTION_GROUP_ASSIGN_USER'),
			array('value' => 'group.edit', 'text' => 'COM_DILER_LOG_ACTION_GROUP_EDIT'),
			array('value' => 'marks.edit', 'text' => 'COM_DILER_LOG_ACTION_MARKS_EDIT'),
			array('value' => 'marks.delete', 'text' => 'COM_DILER_LOG_ACTION_MARKS_DELETE'),
			array('value' => 'marks.error', 'text' => 'COM_DILER_LOG_ACTION_MARKS_ERROR'),
			array('value' => 'media.upload', 'text' => 'COM_DILER_LOG_ACTION_MEDIA_UPLOAD'),
			array('value' => 'media.download', 'text' => 'COM_DILER_LOG_ACTION_MEDIA_DOWNLOADED'),
			array('value' => 'media.delete', 'text' => 'COM_DILER_LOG_ACTION_MEDIA_DELETE'),
			array('value' => 'media.error', 'text' => 'COM_DILER_LOG_ACTION_MEDIA_ERROR'),
			array('value' => 'media.save.description', 'text' => 'COM_DILER_LOG_ACTION_MEDIA_SAVE_DESCRIPTION'),
			array('value' => 'media.share', 'text' => 'COM_DILER_LOG_ACTION_MEDIA_SHARE'),
			array('value' => 'media.background', 'text' => 'COM_DILER_LOG_ACTION_MEDIA_BACKGROUND'),
			array('value' => 'nimbus.delete.phrase', 'text' => 'COM_DILER_LOG_ACTION_NIMBUS_DELETE_PHRASE'),
			array('value' => 'nimbus.delete.template', 'text' => 'COM_DILER_LOG_ACTION_NIMBUS_DELETE_TEMPLATE'),
			array('value' => 'nimbus.edit.phrase', 'text' => 'COM_DILER_LOG_ACTION_NIMBUS_EDIT_PHRASE'),
			array('value' => 'nimbus.toggle.published', 'text' => 'COM_DILER_LOG_ACTION_NIMBUS_PUBLISH_STATUS'),
			array('value' => 'nimbus.edit.template', 'text' => 'COM_DILER_LOG_ACTION_NIMBUS_CREATE_EDIT_TEMPLATE'),
			array('value' => 'personaldata.change.password', 'text' => 'COM_DILER_LOG_PERSONALDATA_CHANGE_PASSWORD'),
			array('value' => 'personaldata.edit.student', 'text' => 'COM_DILER_LOG_PERSONALDATA_EDIT_STUDENT'),
			array('value' => 'report.export', 'text' => 'COM_DILER_LOG_ACTION_REPORT_EXPORT'),
			array('value' => 'report.import', 'text' => 'COM_DILER_LOG_ACTION_REPORT_IMPORT'),
			array('value' => 'report.error', 'text' => 'COM_DILER_LOG_ACTION_REPORT_ERROR'),
			array('value' => 'report.print', 'text' => 'COM_DILER_LOG_ACTION_REPORT_PRINT'),
			array('value' => 'report_data.edit', 'text' => 'COM_DILER_LOG_ACTION_REPORT_DATA_EDIT'),
			array('value' => 'report_data.error', 'text' => 'COM_DILER_LOG_ACTION_REPORT_DATA_ERROR'),
			array('value' => 'pep.created', 'text' => 'COM_DILER_LOG_ACTION_PEP_CREATED'),
			array('value' => 'pep.edited', 'text' => 'COM_DILER_LOG_ACTION_PEP_EDITED'),
			array('value' => 'pep.deleted', 'text' => 'COM_DILER_LOG_ACTION_PEP_DELETED'),
			array('value' => 'pepdevelopmentarea.created', 'text' => 'COM_DILER_LOG_ACTION_PEP_DEVELOPMENT_AREA_CREATED'),
			array('value' => 'pepdevelopmentarea.edited', 'text' => 'COM_DILER_LOG_ACTION_PEP_DEVELOPMENT_AREA_EDITED'),
			array('value' => 'pepdevelopmentarea.deleted', 'text' => 'COM_DILER_LOG_ACTION_PEP_DEVELOPMENT_AREA_DELETED'),
			array('value' => 'pepmethods.created', 'text' => 'COM_DILER_LOG_ACTION_PEP_METHOD_CREATED'),
			array('value' => 'pepmethods.edited', 'text' => 'COM_DILER_LOG_ACTION_PEP_METHOD_EDITED'),
			array('value' => 'pepmethods.deleted', 'text' => 'COM_DILER_LOG_ACTION_PEP_METHOD_DELETED'),
			array('value' => 'pep_development.edit', 'text' => 'COM_DILER_LOG_ACTION_PEP_DEVELOPMENT_EDITED'),
			array('value' => 'pepassessment.created', 'text' => 'COM_DILER_LOG_ACTION_PEP_ASSESSMENT_CREATED'),
			array('value' => 'pepassessment.edited', 'text' => 'COM_DILER_LOG_ACTION_PEP_ASSESSMENT_EDITED'),
			array('value' => 'pepassessment.deleted', 'text' => 'COM_DILER_LOG_ACTION_PEP_ASSESSMENT_DELETED'),
			array('value' => 'pepassessment.reactivated', 'text' => 'COM_DILER_LOG_ACTION_PEP_ASSESSMENT_REACTIVATED'),
			array('value' => 'pepassessment.archived', 'text' => 'COM_DILER_LOG_ACTION_PEP_ASSESSMENT_ARCHIVED'),
			array('value' => 'pepgoal.created', 'text' => 'COM_DILER_LOG_ACTION_PEP_GOAL_CREATED'),
			array('value' => 'pepgoal.edited', 'text' => 'COM_DILER_LOG_ACTION_PEP_GOAL_EDITED'),
			array('value' => 'pepgoal.deleted', 'text' => 'COM_DILER_LOG_ACTION_PEP_GOAL_DELETED'),
            array('value' => 'code.' . DilerLogger::ACTION_TYPE_CREATE, 'text' => 'COM_DILER_LOG_ACTION_REGISTRATION_CODES_CREATED'),
            array('value' => 'code.' . DilerLogger::ACTION_TYPE_EDIT, 'text' => 'COM_DILER_LOG_ACTION_REGISTRATION_CODES_EDITED'),
            array('value' => 'code.' . DilerLogger::ACTION_TYPE_DELETE, 'text' => 'COM_DILER_LOG_ACTION_REGISTRATION_CODES_DELETED'),
			array('value' => 'code.' . DilerLogger::ACTION_TYPE_CREATE_PDF, 'text' => 'COM_DILER_LOG_ACTION_REGISTRATION_CODES_CREATED_PDF'),
			array('value' => 'studentrecord.edit', 'text' => 'COM_DILER_LOG_ACTION_STUDENTRECORD_EDIT'),
			array('value' => 'studentrecord.delete', 'text' => 'COM_DILER_LOG_ACTION_STUDENTRECORD_DELETE'),
			array('value' => 'subject_phases.save.status', 'text' => 'COM_DILER_LOG_ACTION_SUBJECT_PHASE_SAVE_STATUS,COM_DILER_PHASE'),
			array('value' => 'texter.send.message', 'text' => 'COM_DILER_LOG_ACTION_TEXTER_SENT_MESSAGES'),
			array('value' => 'tags.add.new', 'text' => 'COM_DILER_LOG_ACTION_TAG_ADD_NEW'),
		);
		$result  = array();
		foreach ($actions as $action)
		{
			$translated = Text::_($action['text']);
			$result[]   = (object) array('value' => $action['value'], 'text' => $translated);
		}

		return ArrayHelper::sortObjects($result, 'text', 1, false);
	}

	protected function getStoreId($id = '')
	{
		return parent::getStoreId($id);
	}
}
