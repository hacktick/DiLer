<?php
/**
 * @copyright Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;

defined('_JEXEC') or die('Restricted access');

/**
 * @since 6.11.0
 */
class DiLerModelClassSchedule extends AdminModel
{
    /**
     * @param string The table type to instantiate
     * @param string A prefix for the table class name. Optional.
     * @param array Configuration array for model. Optional.
     *
     * @return Table
     * @throws Exception
     * @since 6.11.0
     */
	public function getTable($type = 'ClassSchedule', $prefix = 'DiLerTable', $config = array())
	{
		return parent::getTable($type, $prefix, $config);
	}

	/**
	 * @param array   $data     Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 * @since 6.11.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm(
			'com_diler.classschedule',
			'classschedule',
			array(
				'control'   => 'jform',
				'load_data' => $loadData
			)
		);

		if (empty($form))
			return false;

		return $form;
	}

	/**
	 * @since 6.11.0
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.classschedule.data', array());

		if (empty($data))
			$data = $this->getItem();

		return $data;
	}

	/**
	 * @since 6.11.0
	 */
	public function getItem($pk = null)
	{
		$item = parent::getItem($pk);
		$item->time_slot_list = $this->getTimeSlots($item->id);

		return $item;
	}

	/**
	 * @since 6.11.0
	 */
	public function save($data)
	{
		$result = parent::save($data);
		if(!$result)
			return $result;

		if (! $data['id'])
		{
			$data['id'] = $this->getState($this->getName() . '.id');
		}
		return $this->saveTimeSlots($data['time_slot_list'], $data['id']);
	}

	/**
	 *
	 * @since 6.11.0
	 * 
	 */
	public function assignClassScheduleToAllStudents($classScheduleId): void
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__dilerreg_users');
		$query->where('role = "student"');
		$query->set('standard_class_schedule = ' . $db->quote($classScheduleId));
		
		$db->setQuery($query)->execute();
	}

	/**
	 * @since 6.11.0
	 */
	private function getTimeSlots($classScheduleId): array
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__diler_class_schedule_time_slot');
		$query->where('class_schedule_id=' . $db->quote($classScheduleId));

		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * @since 6.11.0
	 */
	private function saveTimeSlots($timeSlotList, $classScheduleId): bool
	{
		$oldTimeSlotIds = $this->getTimeSlotsOfClassScheduleIds($classScheduleId);
		$removedSlotIds = array_diff($oldTimeSlotIds, array_column($timeSlotList, 'id'));
		$this->removeTimeSlots($removedSlotIds);
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->insert('#__diler_class_schedule_time_slot');
		$query->columns('class_schedule_id, name, start_time, end_time');
		foreach ($timeSlotList as $timeSlot)
		{
			if (!$timeSlot['id'])
			{
				$query->values($db->quote($classScheduleId)
					. ',' . $db->quote($timeSlot['name'])
					. ',' . $db->quote($timeSlot['start_time'])
					. ',' . $db->quote($timeSlot['end_time']));
			}
			else
			{
				$this->updateTimeSlotsOfClassSchedule($timeSlot);
			}
		}

		if ((string) $query->values)
			return $db->setQuery($query)->execute();

		return true;
	}

	private function removeTimeSlots($timeSlotIds): void
	{
		if ($timeSlotIds) {
			$db = Factory::getDbo();
			$query = $db->getQuery(true);
			$query->delete();
			$query->from('#__diler_class_schedule_time_slot');
			$query->where('id IN (' . implode(',', $timeSlotIds) . ')');
			$db->setQuery($query)->execute();
		}
	}

	private function updateTimeSlotsOfClassSchedule($timeSlot): void
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__diler_class_schedule_time_slot');
		$query->where('id = ' . $db->quote($timeSlot['id']));
		$query->set('name = ' . $db->quote($timeSlot['name']));
		$query->set('start_time = ' . $db->quote($timeSlot['start_time']));
		$query->set('end_time = ' . $db->quote($timeSlot['end_time']));
		$db->setQuery($query)->execute();
	}

	private function getTimeSlotsOfClassScheduleIds($classScheduleId): array
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_class_schedule_time_slot');
		$query->where('class_schedule_id = ' . $db->quote($classScheduleId));

		return $db->setQuery($query)->loadColumn();
	}

    /**
     * @param Form $form The form to validate against.
     * @param array $data The data to validate.
     * @param string $group The name of the field group to validate.
     *
     * @return array|boolean  Array of filtered data if valid, false otherwise.
     *
     * @throws Exception
     * @since 6.11.0
     */
	public function validate($form, $data, $group = null)
	{
		$app       = Factory::getApplication();
		$input     = $app->input;
		$id        = $input->getUInt('id', 0);
		$nameValue = $input->post->get('jform', array(), 'array')['name'];

		$db    = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('name');
		$query->from($db->quoteName("#__diler_class_schedule"));
		$query->where('name = ' . $db->quote($nameValue));
		if ($id)
			$query->where('id != ' . (int) $id);

		$db->setQuery($query);
		if ($db->loadObjectList())
		{
			$queryDuplicateCheckMSG = DText::sprintf('CLASS_SCHEDULE_ALREADY_EXISTS', DText::_('CLASS_SCHEDULE'));
			$url                    = 'index.php?option=com_diler&view=classschedule&layout=edit';
			if ($id)
			{
				$url .= '&id=' . $id;
			}

			$app->enqueueMessage($queryDuplicateCheckMSG, 'error');
			$app->redirect($url);

			return false;
		}
		if (!$data['time_slot_list'])
		{
			$app->enqueueMessage(DText::_('TIME_SLOTS_EMPTY_ERROR'), 'error');
			return false;
		}
		foreach ($data['time_slot_list'] as $timeSlot)
		{
			if (!$this->compareStartTimeAndEndTime($timeSlot['start_time'], $timeSlot['end_time']))
			{
				$app->enqueueMessage(DText::_('INVALID_TIMES_ERROR'), 'error');
				return false;
			}
		}

		return parent::validate($form, $data, $group);
	}

	/**
	 * compare start time and end time stings
	 *
	 * @return bool returns true if end time is bigger than start time
	 * @since 6.11.0
	 */
	private function compareStartTimeAndEndTime($startTime, $endTime)
	{
		$startTimeHour          = intval(substr($startTime, 0, 2));
		$endTimeHour            = intval(substr($endTime, 0, 2));
		$startTimeMinute        = intval(substr($startTime, 3, 2));
		$endTimeMinute          = intval(substr($endTime, 3, 2));
		$equalHourGreaterMinute = ($startTimeHour == $endTimeHour && $startTimeMinute >= $endTimeMinute);
		$greaterHour            = ($startTimeHour > $endTimeHour);

		return !($equalHourGreaterMinute || $greaterHour);
	}
}
