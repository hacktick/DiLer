<?php
/**
 * Point default model, update, load form, load script
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright	Copyright (C) 2013-15 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;

// import Joomla modelform library
jimport('joomla.application.component.modeladmin');

/**
 * Point model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelStudentrecordadmin extends AdminModel
{
	public function getForm($data = array(), $loadData = true)
	{
		return false;
	}

	public function getTable($type = 'Studentrecord', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * A protected method to get a set of ordering conditions.
	 *
	 * @param   Table  $table  A record object.
	 *
	 * @return  array  An array of conditions to add to add to ordering queries.
	 *
	 * @since   1.6
	 */
	protected function getReorderConditions($table)
	{
		$condition = array();
		$condition[] = 'student_id = ' . (int) $table->student_id;
		$condition[] = 'DATE(effective_date) = ' . substr($table->effective_date, 0, 10);

		return $condition;
	}
}