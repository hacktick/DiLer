<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2013 - 2015 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('_JEXEC') or die();

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\String\StringHelper;

/**
 * Weblinks model.
 *
 * @package Joomla.Administrator
 * @subpackage com_diler
 * @since 1.5
 */
class DilerModelReportfield extends AdminModel
{

	/**
	 * The type alias for this content type.
	 *
	 * @var string
	 * @since 3.2
	 */
	public $typeAlias = 'com_diler.reportfields';

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param object $record
	 *        	A record object.
	 *
	 * @return boolean True if allowed to delete the record. Defaults to the permission for the component.
	 *
	 * @since 1.6
	 */
	protected function canDelete($record)
	{
		if (! empty($record->id)) {
			if ($record->published != - 2) {
				return;
			}
			$user = Factory::getUser();
			return parent::canDelete($record);
		}
	}

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param object $record
	 *        	A record object.
	 *
	 * @return boolean True if allowed to change the state of the record. Defaults to the permission for the component.
	 *
	 * @since 1.6
	 */
	protected function canEditState($record)
	{
		$user = Factory::getUser();

		if (! empty($record->catid)) {
			return $user->authorise('core.edit.state', 'com_diler.category.' . (int) $record->catid);
		} else {
			return parent::canEditState($record);
		}
	}

    /**
     * Override parent delete method
     *
     * @param array &$pks An array of record primary keys.
     * @return boolean True if successful, false if an error occurs.
     *
     * @throws Exception
     * @since 12.2
     */
	public function delete(&$pks)
	{
		// Delete history if needed
		$this->checkChangeStatus($pks);

		// Delete any rows from mapping table
		if (is_array($pks) && $pks)
		{
			try {
				$pks = ArrayHelper::toInteger($pks);
				$db = Factory::getDbo();
				$query = $db->getQuery(true)
					->delete('#__diler_report_field_subject_map')
					->where('field_id IN(' . implode(',', $pks) . ')');
				$db->setQuery($query)->execute();

				// Delete from report_definition_xref tables for subform fields
				$query->clear()
						->delete('#__diler_report_definition_xref')
						->where('subform_field_id IN(' . implode(',', $pks) . ')');
				$db->setQuery($query)->execute();
			}

			catch (Exception $e)
			{
				$this->setError($e);
				return false;
			}
			return parent::delete($pks);
		}
		return false;
	}

	/**
	 * Method to change the title & alias.
	 *
	 * @param   string   $name
	 * @param   string   $label
	 *
	 * @return	array  Contains the modified name and title.
	 *
	 * @since	3.6
	 */
	protected function generateNewName($name, $label)
	{
		// Alter the title & alias
		$table = $this->getTable();
		$loadName = $name;

		while ($table->load(array('name' => $loadName)))
		{
			$name = StringHelper::increment($name, 'dash');
			$loadName = str_replace('-', '_', $name);
			$label = StringHelper::increment($label, 'default');
		}

		return array($name, $label);
	}

	/**
	 * Method to get a single reportfield record.
	 * Override of parent method to also get subjects from subject_competence_map table.
	 *
	 * @param integer $pk
	 *        	The id of the primary key.
	 *
	 * @return bool|Object Object on success, false on failure.
	 *
	 * @since 12.2
	 */
	public function getItem($pk = null)
	{
		$data = parent::getItem($pk);
		$data->subject_list = '';
		$data->member_fields = array();
		$db = Factory::getDbo();
		if ($data && $data->type == 3)
		{
			$query = $db->getQuery(true)
				->select('GROUP_CONCAT(subject_id) AS subject_list')
				->from('#__diler_report_field_subject_map')
				->where('field_id = ' . (int) $data->id)
				->group('field_id');
			if ($subjectList = $db->setQuery($query)->loadResult())
			{
				$data->subject_list = explode(',', $subjectList);
			}
		}
		if ($data && $data->element_type == 3 && $data->id)
		{
			// Get subform member fields
			$query = $db->getQuery(true)
				->select('field_id')
				->from('#__diler_report_definition_xref')
				->where('subform_field_id = ' . (int) $data->id);
			$memberFields = $db->setQuery($query)->loadColumn();
			$data->member_fields = $memberFields;
		}
		return $data;
	}

	/**
	 * Method to get a table object, load it if necessary.
	 *
	 * @param string $type
	 *        	The table name. Optional.
	 * @param string $prefix
	 *        	The class prefix. Optional.
	 * @param array $config
	 *        	Configuration array for model. Optional.
	 *
	 * @return Table
	 *
	 * @since 1.6
	 */
	public function getTable($type = 'Reportfield', $prefix = 'DilerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Abstract method for getting the form from the model.
	 *
	 * @param array $data
	 *        	Data for the form.
	 * @param boolean $loadData
	 *        	True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 *
	 * @since 1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.reportfield', 'reportfield', array(
			'control' => 'jform',
			'load_data' => $loadData
		));

		if (empty($form)) {
			return false;
		}

		// Determine correct permissions to check.
		if ($this->getState('reportfield.id')) {
			// Existing record. Can only edit in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.edit');
		} else {
			// New record. Can only create in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.create');
		}

		// Modify the form based on access controls.
		if (! $this->canEditState((object) $data)) {
			// Disable fields for display.
			$form->setFieldAttribute('ordering', 'disabled', 'true');
			$form->setFieldAttribute('state', 'disabled', 'true');
			$form->setFieldAttribute('publish_up', 'disabled', 'true');
			$form->setFieldAttribute('publish_down', 'disabled', 'true');

			// Disable fields while saving.
			// The controller has already verified this is a record you can edit.
			$form->setFieldAttribute('ordering', 'filter', 'unset');
			$form->setFieldAttribute('state', 'filter', 'unset');
			$form->setFieldAttribute('publish_up', 'filter', 'unset');
			$form->setFieldAttribute('publish_down', 'filter', 'unset');
		}

		return $form;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return array The default data is an empty array.
     *
     * @throws Exception
     * @since 1.6
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.reportfield.data', array());

		if (empty($data)) {
			$data = $this->getItem();

			// Prime some default values.
			if ($this->getState('reportfield.id') == 0) {
				$app = Factory::getApplication();
				$data->set('catid', $app->input->get('catid', $app->getUserState('com_diler.reportfields.filter.category_id'), 'int'));
			}
		}

		$this->preprocessData('com_diler.reportfield', $data);

		return $data;
	}

	/**
	 * Prepare and sanitise the table data prior to saving.
	 *
	 * @return void
	 *
	 * @since 1.6
	 */
	protected function prepareTable($table)
	{
		$date = Factory::getDate();
		$user = Factory::getUser();

		$table->name = htmlspecialchars_decode($table->name, ENT_QUOTES);
	}

	/**
	 * Checks field for any field history. Delete not allowed if history exists.
	 *
	 * @param   array  $pks  array of compchar ids
	 *
	 * @throws  Exception
	 *
	 * @return  bool
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// See if we need to delete any history rows for these report fields
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('field_id, COUNT(*) AS row_count')
			->from('#__diler_report_field_history')
			->where('field_id IN(' . implode(',', $pks) . ')')
			->group('field_id');
		$rowsToDelete = $db->setQuery($query)->loadObjectList();
		$total = 0;
		$idArray = [];
		foreach ($rowsToDelete as $row)
		{
			$total += $row->row_count;
			$idArray[] = $row->field_id;
		}

		if (is_array($rowsToDelete) && $rowsToDelete)
		{
			$query = $db->getQuery(true)
				->delete('#__diler_report_field_history')
				->where('field_id IN(' . implode(',', $idArray) . ')');
			$result = $db->setQuery($query)->execute();
			// We need to give a message and also remove these from the $pks array
			Factory::getApplication()->enqueueMessage(DText::sprintf('N_REPORTFIELDS_DELETED', count($rowsToDelete), $total), 'info');
		}
		return true;
	}

    /**
     * Override parent save() method to save rows in subject_competence_map table.
     *
     * @param array $data The form data.
     *
     * @return boolean True on success, False on error.
     *
     * @throws Exception
     * @since 12.2
     */
	public function save($data)
	{
		// Check for save2copy
		// Alter the title for save as copy
		$input = Factory::getApplication()->input;
		if ($input->get('task') == 'save2copy')
		{
			$origTable = clone $this->getTable();
			$origTable->load($input->getInt('id'));

			if ($data['name'] == $origTable->name)
			{
				list($name, $label) = $this->generateNewName($data['name'], $data['label']);
				$data['name'] = $name;
				$data['label'] = $label;
			}

			$data['published'] = 0;
		}

		$result = parent::save($data);
		if ($result)
		{
			if ($data['id'] === 0)
			{
				$db = Factory::getDbo();
				$data['id'] = (int) $this->getState()->get('reportfield.id');
			}

			$result = $this->saveSubjects($data);
			$result = $this->saveMemberFields($data);

		}
		return $result;
	}

	/**
	 * Saves member fields which are used for subform type fields (type=4)
	 *
	 * @param array  $data  Associative array of row data: <column name> => value.
	 */
	protected function saveMemberFields($data)
	{
		// Delete all old rows in mapping table
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_report_definition_xref')
			->where('subform_field_id = ' . (int) $data['id']);
		$result = $db->setQuery($query)->execute();

		// Add new rows if applicable
		if ($result && isset($data['member_fields']) && is_array($data['member_fields']) && $data['member_fields'] && $data['element_type'] == 3)
		{
			$query = $db->getQuery(true)
				->insert('#__diler_report_definition_xref')
				->columns(array($db->quoteName('subform_field_id'), $db->quoteName('field_id')
			));

			foreach ($data['member_fields'] as $memberField)
			{
				$query->values((int) $data['id'] . ',' . (int) $memberField);
			}
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}

	/**
	 * Method to save rows in report_field_subject_map_table
	 *
	 * @param array $data
	 *        	The form data.
	 *
	 * @return boolean True on success, False on error.
	 *
	 * @since 12.2
	 */
	protected function saveSubjects($data)
	{
		// Delete all old rows in mapping table
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_report_field_subject_map')
			->where('field_id = ' . (int) $data['id']);
		$result = $db->setQuery($query)->execute();

		// Add new rows if applicable
		if ($result && isset($data['subject_list']) && is_array($data['subject_list']) && $data['subject_list'] && $data['type'] == 3)
		{
			$query = $db->getQuery(true)
				->insert('#__diler_report_field_subject_map')
				->columns(array($db->quoteName('subject_id'), $db->quoteName('field_id')
			));

			foreach ($data['subject_list'] as $subject)
			{
				$query->values((int) $subject . ',' . (int) $data['id']);
			}
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}

}
