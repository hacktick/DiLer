window.addEvent('domready', function() {
        document.formvalidator.setHandler('name',
                function (value) {
                        regex=/^[^0-9]+$/;
                        return regex.test(value);
        });
});
window.addEvent('domready', function() {
        document.formvalidator.setHandler('color',
                function (value) {
                        regex=/^(#){1}([a-fA-F0-9]){6}$/;
                        return regex.test(value);
        });
});