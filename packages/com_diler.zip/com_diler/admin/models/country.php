<?php
/**
 * Country data edit, update
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

/**
 * Country model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelCountry extends AdminModel
{

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 *        * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.message.' . ((int) isset($data[$key]) ? $data[$key] : 0)) or parent::allowEdit($data, $key);
	}

		/**
	 * Checks schoolyears for any mapped subject groups.
	 * Don't allow trash or delete if found.
	 *
	 * @param array $pks array of schoolyear ids
	 *
	 * @throws Exception
	 *
	 * @return array array of allowed compchar ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no answers for these tasks
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('s.country_id')
			->from('#__diler_state AS s')
			->where('s.country_id IN(' . implode(',', $pks) . ')')
			->group('s.country_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('COUNTRY'), DText::_('STATES'));
			}
			else
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($badPks), DText::_('COUNTRIES'), DText::_('STATES'));
			}

            Factory::getApplication()->enqueueMessage($msg,'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}
		return $pks;
	}

    /**
     * Override parent delete method
     *
     * @param array &$pks An array of record primary keys.
     *
     * @return boolean True if successful, false if an error occurs.
     *
     * @throws Exception
     * @since 12.2
     */
	public function delete(&$pks)
	{
		// Don't delete if mapped
		try
		{
			$pks = $this->checkChangeStatus($pks);
		}
		catch (Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage());
			return false;
		}
		return parent::delete($pks);
	}

	protected function deleteStateRows($deleteIds)
	{
		$result = false;
		$db = Factory::getDbo();
		$validIds = ArrayHelper::toInteger((array) $deleteIds);
		if (! $validIds) return false;
		// See if there are history rows for these periods
		$query = $db->getQuery(true)->select('st.id')
				->from('#__dilerreg_users AS du')
				->innerJoin('#__diler_state AS st ON du.state_iso = st.state_iso')
				->where('st.id IN(' . implode(',', $validIds) . ')')
				->group('st.id');
		$badPks = $db->setQuery($query)->loadColumn();
		if (is_array($badPks) && $badPks)
		{
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('STATE'), DText::_('DASHBOARD_HEADING_USER_MANAGEMENT'));
			}
			else
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($badPks), DText::_('STATES'), DText::_('DASHBOARD_HEADING_USER_MANAGEMENT'));
			}
			Factory::getApplication()->enqueueMessage($msg, 'warning');
		}
		$validIds = array_diff($validIds, $badPks);
		if (is_array($validIds) && $validIds)
		{
			try
			{
				$db->transactionStart();
				// Delete schoolyear map rows
				$query = $db->getQuery(true)->delete('#__diler_state')
						->where('id IN(' . implode(',', $validIds) . ')');
				$result = $db->setQuery($query)->execute();
			}
			catch (Exception $ex)
			{
				$db->transactionRollback();
			}
			$db->transactionCommit();
		}
		return $result;
	}

	protected function getCurrentRowIds($stateId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')
				->from('#__diler_state')
				->where('country_id = ' . (int) $stateId);
		return $db->setQuery($query)->loadColumn();
	}

	public function getTable($type = 'Country', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.country', 'country',

		array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Override parent method. Add code to get detail rows for the period type
	 *
	 * {@inheritDoc}
	 * @see AdminModel::getItem()
	 */
	public function getItem($pk = null)
	{
		$item = parent::getItem($pk);
		$item->state_list = [];
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')
				->from('#__diler_state')
				->where('country_id = ' . (int) $item->id)
				->order('ordering');
		$detailRows = $db->setQuery($query)->loadObjectList();
		$count = count($detailRows);
		for ($i = 0; $i < $count; $i++)
		{
			$item->state_list['state_list' . $i] = ['ordering' => $i, 'name' => $detailRows[$i]->name, 'id' => $detailRows[$i]->id,
					'state_iso' => $detailRows[$i]->state_iso,'country_iso2' => $detailRows[$i]->country_iso2];
		}
		return $item;
	}

	/**
	 * Method to get the script that has to be included on the form-page
	 *
	 * @return string Script files
	 */
	public function getScript()
	{
		return 'administrator/components/com_diler/models/forms/country.js';
	}

	protected function isDuplicateStateName($data, $nameArray)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')
				->from('#__diler_state')
				->where('country_id = ' . $data['id'])
				->where('(name = ' . $db->quote($nameArray['name']) . ' OR ' . 'state_iso = ' . $db->quote($nameArray['state_iso']) . ')');
		if ($nameArray['id'])
		{
			$query->where('id != ' . (int) $nameArray['id']);
		}
		return $db->setQuery($query)->loadResult();
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.country.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

    /**
     * Overload of parent publish method.
     * Don't allow trashing if this has mapped subject groups
     *
     * @param array &$pks A list of the primary keys to change.
     * @param integer $value The value of the published state.
     *
     * @return void
     *
     * @throws Exception
     * @since 12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		$result = parent::publish($pks, $value);
	}

    /**
     * Override parent method to save the form data. Need to save report fields to report field history table.
     *
     * @param array $data The form data.
     *
     * @return  boolean  True on success, False on error.
     *
     * @throws Exception
     * @since   12.2
     */
	public function save($data)
	{
		$result = parent::save($data);
		if ($result)
		{
			$data['id'] = isset($data['id']) && $data['id'] ? $data['id'] : (int) $this->getState($this->getName().'.id');
			$this->saveStateRows($data);
		}
		return $result;
	}

	protected function saveStateRows($data)
	{
		$currentIds = $this->getCurrentRowIds($data['id']);
		if (isset($data['state_list']) && is_array($data['state_list']) && $data['state_list'])
		{
			$i = 0;
			$newIds = [];
			foreach ($data['state_list'] as $key => $nameArray)
			{
				if ($this->isDuplicateStateName($data, $nameArray))
				{
					Factory::getApplication()->enqueueMessage(DText::sprintf('COUNTRY_ALREADY_EXISTS', DText::_('STATE')), 'error');
					continue;
				}
				if ($nameArray['id'])
				{
					$this->updateStateRow($data, $nameArray, $i);
					$newIds[] = $nameArray['id'];
				}
				else
				{
					$this->insertStateRow($data, $nameArray, $i);
				}
				$i++;
			}
		}

		// Check for deletes of current rows
		$deleteIds = [];
		foreach ($currentIds as $currentId)
		{
			if (! in_array($currentId, $newIds)) $deleteIds[] = $currentId;
		}
		if ($deleteIds) $this->deleteStateRows($deleteIds);
		return true;
	}

	protected function updateStateRow($data, $nameArray, $i)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_state')
				->set('name = ' . $db->quote($nameArray['name']))
				->set('state_iso = ' . $db->quote($nameArray['state_iso']))
				->set('country_iso2 = ' . $db->quote($data['iso2']))
				->set('ordering = ' . (int) $i)
				->where('id = ' . (int) $nameArray['id']);
		return $db->setQuery($query)->execute();
	}

	protected function insertStateRow($data, $nameArray, $i)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->insert('#__diler_state')
				->set('state_iso = ' . $db->quote($nameArray['state_iso']))
				->set('country_iso2 = ' . $db->quote($data['iso2']))
				->set('name = ' . $db->quote($nameArray['name']))
				->set('ordering = ' . (int) $i)
				->set('country_id = ' . (int) $data['id']);
		return $db->setQuery($query)->execute();
	}
}