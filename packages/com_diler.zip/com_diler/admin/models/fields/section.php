<?php
/**
 * @copyright Copyright (C) 2013-2021 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\HTML\HTMLHelper;

// import the list field type


FormHelper::loadFieldClass('list');

class JFormFieldSection extends JFormFieldList
{
	protected $type = 'Section';

	protected function getOptions() : array
	{
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('id, value, description');
		$query->from('#__diler_section');
		$query->where('published = 1');
		$query->order('ordering');
		$sections = $db->setQuery($query)->loadObjectList();
		$options = array ();
		if($sections)
		{
			foreach($sections as $section)
			{
				$options [] = HTMLHelper::_('select.option', $section->id, $section->value);
			}
		}
		return array_merge(parent::getOptions(), $options);
	}
}
