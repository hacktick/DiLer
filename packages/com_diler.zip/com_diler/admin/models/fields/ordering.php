<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_menus
 *
 * @copyright   Copyright (C) 2013 - 2015 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Language\Text;

FormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_menus
 * @since       1.6
 */
class JFormFieldOrdering extends JFormFieldList
{
    /**
     * The form field type.
     *
     * @var     string
     * @since   1.7
     */
    protected $type = 'Ordering';

    /**
     * Method to get the list of siblings in a menu.
     * The method requires that parent be set.
     *
     * @return  array  The field option objects or false if the parent field has not been set
     * @since   1.7
     */
    protected function getOptions()
    {

       $db = Factory::getDbo();

       $db->setQuery("select ordering as value, name as text from #__diler_competence where published = 1");

       return $db->loadObjectList();
    }
    /**
     * Method to get the field input markup
     *
     * @return  string  The field input markup.
     * @since   1.7
     */
    protected function getInput()
    {
        if ($this->form->getValue('id', 0) == 0)
        {
            return '<span class="readonly">' . Text::_('COM_MENUS_ITEM_FIELD_ORDERING_TEXT') . '</span>';
        }
        else
        {
            return parent::getInput();
        }
    }
}
