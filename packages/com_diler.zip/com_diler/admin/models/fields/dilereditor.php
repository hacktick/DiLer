<?php
/**
 * Joomla! Content Management System
 *
 * @copyright  Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\CMS\Form\Field;

defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Editor\Editor;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;

FormHelper::loadFieldClass('textarea');

/**
 * A textarea field for content creation
 *
 * @see    JEditor
 * @since  1.6
 */
class DilerEditorField extends EditorField
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.6
	 */
	public $type = 'Dilereditor';

	/**
	 * Count string characters to check maximum length validation.
	 *
	 * @var    string
	 * @since  6.7
	 */
	public $stringCounter = false;

	/**
	 * Method to get a Editor object based on the form field.
	 *
	 * @return  Editor  The Editor object.
	 *
	 * @since   1.6
	 */
	protected function getEditor()
	{
		// Only create the editor if it is not already created.
		if (empty($this->editor))
		{
			$editor = null;

			if ($this->editorType)
			{
				// Get the list of editor types.
				$types = $this->editorType;

				// Get the database object.
				$db = Factory::getDbo();

				// Iterate over the types looking for an existing editor.
				foreach ($types as $element)
				{
					// Build the query.
					$query = $db->getQuery(true)
						->select('element')
						->from('#__extensions')
						->where('element = ' . $db->quote($element))
						->where('folder = ' . $db->quote('editors'))
						->where('enabled = 1');

					// Check of the editor exists.
					$db->setQuery($query, 0, 1);
					$editor = $db->loadResult();

					// If an editor was found stop looking.
					if ($editor)
					{
						break;
					}
				}
			}

			// Create the JEditor instance based on the given editor.
			if ($editor === null)
			{
				$editor = ComponentHelper::getParams('com_diler')->get('editorTaskDesc', false);
				$editor = $editor ? $editor : $editor = Factory::getConfig()->get('editor');
			}

			$this->editor = Editor::getInstance($editor);

			if($editor == 'none')
				$this->stringCounter = true;
		}

		return $this->editor;
	}

	/**
	 * Method to get a Editor should has character counter or not
	 *
	 * @return  boolean
	 *
	 * @since   6.7
	 */
	public function getStringCounter()
	{
		$this->getEditor();

		return $this->stringCounter;
	}
}
