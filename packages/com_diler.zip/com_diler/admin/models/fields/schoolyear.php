<?php
/**
 * @copyright Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Administrator\Model\SchoolyearsModel;
use Joomla\CMS\HTML\HTMLHelper;

// No direct access to this file
defined('_JEXEC') or die();

/**
 * @since 6.11.0
 */
class JFormFieldSchoolyear extends JFormFieldList
{
	protected $type = 'Schoolyear';

	protected function getOptions(): array
	{
		/** @var SchoolyearsModel $schoolYearModel */
		$schoolYearModel = MVCHelper::factory()->createModel('Schoolyears', 'Administrator');
		$schoolYearModel->setState('filter.published', 1);
		$schoolyears = $schoolYearModel->getItems();
		$options = array();
		foreach ($schoolyears as $schoolyear) {
			$options [] = HTMLHelper::_('select.option', $schoolyear->id, $schoolyear->name);
		}

		return array_merge(parent::getOptions(), $options);
	}
}
