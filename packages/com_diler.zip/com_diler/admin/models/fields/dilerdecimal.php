<?php
/**
 * @package     Diler.Site
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_PLATFORM') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;

FormHelper::loadFieldClass('number');

/**
 * Form Field class for DiLer.
 * Filters a number to 1 decimal place. Used for activity points.
 *
 * @link   http://www.w3.org/TR/html-markup/input.text.html#input.text
 * @since  5.0
 */
class JFormFieldDilerdecimal extends JFormFieldNumber
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  3.2
	 */
	protected $type = 'Range';

	/**
	 * Method to get the field input markup.
	 *
	 * @return  string  The field input markup.
	 *
	 * @since   3.2
	 */
	protected function getInput()
	{
		// Initialize some field attributes.
		$max      = !empty($this->max) ? ' max="' . $this->max . '"' : '';
		$min      = !empty($this->min) ? ' min="' . $this->min . '"' : '';
		$step     = !empty($this->step) ? ' step="' . $this->step . '"' : '';
		$class    = !empty($this->class) ? ' class="' . $this->class . '"' : '';
		$readonly = $this->readonly ? ' readonly' : '';
		$disabled = $this->disabled ? ' disabled' : '';

		$autofocus = $this->autofocus ? ' autofocus' : '';

		$value = (float) $this->value;
		$value = empty($value) ? $this->min : $value;
		$value = number_format($value, 1);

		// Initialize JavaScript field attributes.
		$onchange = !empty($this->onchange) ? ' onchange="' . $this->onchange . '"' : '';

		// Including fallback code for HTML5 non supported browsers.
		HTMLHelper::_('jquery.framework');
		HTMLHelper::_('script', 'system/html5fallback.js', false, true);

		return '<input type="number" name="' . $this->name . '" id="' . $this->id . '"' . ' value="'
			. $value . '"' . $class . $disabled . $readonly
			. $onchange . $max . $step . $min . $autofocus . ' />';
	}
}
