<?php
/**
 * @package     Diler.Administrator
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2017 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;

FormHelper::loadFieldClass('groupedlist');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Diler.Administrator
 * @subpackage  com_diler
 * @since       5.3.9
 */
class JFormFieldSubjectsgrouped extends JFormFieldGroupedList
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since   1.6
	 */
	protected $type = 'Subjectsgrouped';

	/**
	 * Method to get the field options.
	 *
	 * @return  array  The field option objects.
	 * @since   1.6
	 */
	protected function getGroups()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('c.title AS cat_title, s.name AS subject_name, c.id AS cat_id, s.id AS subject_id')
			->from('#__diler_subject AS s')
			->innerJoin('#__categories AS c ON s.catid = c.id')
			->where('s.published = 1')
			->where('c.published = 1')
			->order('c.lft, s.ordering');
		$subjects = $db->setQuery($query)->loadObjectList();

		$groups = array();
		foreach($subjects as $subject)
		{
			$select = HTMLHelper::_('select.option', $subject->subject_id, $subject->subject_name);
			$groups[$subject->cat_title][] = $select;
		}

		$groups = array_merge(parent::getGroups(), $groups);
		reset($groups);
		return $groups;
	}
}
