<?php
/**
 * Ip address
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Form\FormHelper;
 
// import the list field type


FormHelper::loadFieldClass('list');
 
/**
 * Display IP Address
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @since		2.5
 */
class JFormFieldIpaddress extends JFormFieldList
{
   
	   /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'Ipaddress';

        protected function getOptions() 
        {
               
                return $_SERVER['REMOTE_ADDR'];
        }
}