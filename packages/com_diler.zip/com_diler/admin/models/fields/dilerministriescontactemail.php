<?php
/**
 * @copyright   Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use DiLer\Lang\DText;
use Joomla\CMS\Form\FormHelper;

defined('JPATH_PLATFORM') or die;

FormHelper::loadFieldClass('email');

class JFormFieldDilerMinistriesContactEmail extends JFormFieldEMail
{
	protected $type = 'DilerMinistriesContactNote';

	protected function getInput()
	{
        $emailNote = DText::_("MINISTRY_CONTACT_EMAIL_NOTE");
		$input = parent::getInput();
		return $input . "<br><small>". $emailNote ."</small>";
	}
}

