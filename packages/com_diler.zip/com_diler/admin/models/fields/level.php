<?php
/**
 * Level select options
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;

// import the list field type


FormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of levels
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @since		2.5
 */
class JFormFieldLevel extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'Level';

        protected function getOptions()
        {
                $db = Factory::getDBO();
                $query = $db->getQuery(true);
                $query->select('id AS value, name AS text');
                $query->from('#__diler_level');
				$query->where('published = 1');
				$query->order('ordering');
                $db->setQuery((string)$query);
                $options = $db->loadObjectList();
                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }
}