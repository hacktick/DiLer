<?php
/**
 * @copyright	Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
// No direct access to this file
defined('_JEXEC') or die;

use DiLer\DConst;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\HTML\HTMLHelper;

FormHelper::loadFieldClass('list');

class JFormFieldSchoolhistory extends JFormFieldList
{
	protected $type = 'Schoolhistory';
	
	private $options = array();

	public function setup(\SimpleXMLElement $element, $value, $group = null)
	{
		$limit = DConst::SELECTIZE_MAX_OPTIONS;
		$selectedSchools = array();

		if ($value)
		{
			$selectedSchools = $this->getSelectSchoolQuery(1, $value);
			$limit--;
		}

		$notSelectedSchools = $this->getSelectSchoolQuery($limit);
		$rows = array_merge($selectedSchools, $notSelectedSchools);
		$options = [];
		if ($rows)
		{
			foreach ($rows as $row)
			{
				$optionName = $row['city'] . ' | ' . $row['name'] . ' | ' . $row['school_id'];
				$options[] = array('text' => $optionName, 'value' => $row['id']);
			}
		}
		$this->options = $options;
		return parent::setup($element, $value, $group);
	}

	private function getSelectSchoolQuery($limit, $schoolId = 0)
	{
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('s.school_id');
		$query->select('s.id');
		$query->select('s.city');
		$query->select('s.name');
		$query->from('#__diler_school AS s');
		$query->where('s.published = 1');
		$query->order('s.city, s.name');

		if ($schoolId)
			$query->where('id = ' . (int) $schoolId);

		return $db->setQuery($query, 0, $limit)->loadAssocList();
	}

	protected function getInput()
	{
		$selectizeConfig = $this->getSelectizeConfig();
		HTMLHelper::_('diler.selectize', '#' . $this->id, $selectizeConfig);
		DText::script('STUDENTRECORD_SEARCH_FULLTEXT_ERROR_DESC');
		$document = Factory::getDocument();
		$document->addScriptOptions('useAjaxToLoadSchools', (count($this->options) == DConst::SELECTIZE_MAX_OPTIONS));
		$document->addScriptOptions('schoolHistorySelectConfig', $selectizeConfig);
		return parent::getInput() . $this->getMessageIfWeHaveSchoolMoreThanAllowedInSelectize();
	}


	private function getSelectizeConfig()
	{
		$options = array();
		$options['customPlugins'] = array('schools');
		$options['options'] = $this->options;
		$options['items'] = array($this->value);
		$options['plugins'] = array('schools');
		return $options;
	}
	
	private function getMessageIfWeHaveSchoolMoreThanAllowedInSelectize()
	{
		if (count($this->options) == DConst::SELECTIZE_MAX_OPTIONS)
			return '<small class="form-text text-muted selectize-search-hint">' .
		DText::sprintf('SELECTIZE_SEARCH_HINT', DConst::SELECTIZE_MAX_OPTIONS, DText::_('SCHOOL')) .
		'</small>';
		
		return "";
	}
}
