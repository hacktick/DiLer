<?php
/**
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;

// import the list field type


FormHelper::loadFieldClass('groupedlist');

/**
 * Student Record Tag select option - combines subjects, extracurriculars, and student record categories into one list.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 4.3
 */
class JFormFieldStudentrecordtag extends JFormFieldGroupedList
{

	/**
	 * The field type.
	 *
	 * @var string
	 */
	public $type = 'Studentrecordtag';

	protected function getGroups()
	{
		$options = ComponentHelper::getParams('com_diler');
		$categorySort = $options->get('studentRecordCategoriesManualOrdering', 2);
		$extracurricularSort = $options->get('studentRecordCategoriesExtrasOrdering', 2);
		$subjectSort = $options->get('studentRecordCategoriesSubjectsOrdering', 2);
		$groups = array();

		$subjects = $this->getSubjects($subjectSort);
		$extracurriculars = $this->getExtracurriculars($extracurricularSort);
		$categories = $this->getCategories($categorySort);

		$group = DText::_('STUDENTRECORD_CATEGORY');
		foreach ($categories as $item)
		{
			$select = HTMLHelper::_('select.option', $item->value, $item->text);
			$groups[$group][] = $select;
		}

		// Group the subjects by category and create a group for each one
		$categoryArray = array();
		foreach ($subjects as $subject)
		{
			$categoryArray[$subject->cat_title][] = $subject;
		}

		foreach ($categoryArray as $category => $subjects)
		{
			$group = $category;
			foreach ($subjects as $item)
			{
				$select = HTMLHelper::_('select.option', $item->value, $item->text);
				$groups[$group][] = $select;
			}
		}

		$categoryArray = array();
		foreach ($extracurriculars as $extracurricular)
		{
			$categoryArray[$extracurricular->cat_title][] = $extracurricular;
		}
		foreach ($categoryArray as $category => $extracurriculars)
		{
			$group = $category;
			foreach ($extracurriculars as $item)
			{
				$select = HTMLHelper::_('select.option', $item->value, $item->text);
				$groups[$group][] = $select;
			}
		}
		reset($groups);

		return $groups;
	}

	/**
	 * Method to get a list of options for a list input.
	 *
	 * @return array An array of HTMLHelper options.
	 */
	protected function getSubjects($subjectSort)
	{
		$subjects = array();
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('CONCAT("1:", s.id) AS value, s.name AS text')
			->from('#__diler_subject AS s')
			->innerJoin('#__categories AS c ON s.catid = c.id')
			->select('c.title AS cat_title')
			->where('s.published = 1');
		if ($subjectSort == 3)
		{
			$query->order('c.title, s.name');
		}
		else
		{
			$query->order('c.lft, s.ordering');
		}

		$db->setQuery($query);
		return $db->loadObjectList();
	}

	/**
	 * Method to get a list of extracurriculars for a list input.
	 *
	 * @return array An array of HTMLHelper options.
	 */
	protected function getExtracurriculars($extracurricularSort)
	{
        if(\Audivisa\Component\DiLer\Site\Helper\VersionHelper::isJoomla4())
            $groupModel = MVCHelper::factory()->createModel('Group', 'Site');
        else
		    $groupModel = MVCHelper::factory()->createModel('Group', 'Site');

		$ecList = $groupModel->getDilerGroupCategories();
		if (! is_array($ecList) || count($ecList) < 4) return [];
		foreach ($ecList[3] as $cat)
		{
			$extraCurricularCatIds[] = $cat->id;
		}
		if (!count($extraCurricularCatIds)) return [];
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('CONCAT("2:",g.id) AS value, g.name AS text')
			->from('#__diler_group AS g')
			->innerJoin('#__categories AS c ON g.catid = c.id')
			->select('c.title as cat_title')
			->where('g.catid IN(' . implode(',', $extraCurricularCatIds) . ')')
			->where('g.published = 1');

		if ($extracurricularSort == 3)
		{
			$query->order('c.title, g.name');
		}
		else
		{
			$query->order('c.lft, g.ordering');
		}

		$db->setQuery($query);
		return $db->loadObjectList();
	}

	/**
	 * Method to get a list of student record categories for a list input.
	 *
	 * @return array An array of HTMLHelper options.
	 */
	protected function getCategories($categorySort)
	{
		$db = Factory::getDBO();
		$options = ComponentHelper::getParams('com_diler');
		$query = $db->getQuery(true);
		$query->select('CONCAT("3:",id) AS value, title AS text');
		$query->from('#__categories');
		$query->where('published = 1');
		$query->where('extension = "com_diler.studentrecord"');
		$query->where('id NOT IN(' . $options->get('studentRecordExcusedAbsence', 0) . ',' . $options->get('studentRecordUnexcusedAbsence', 0) .')');
		if ($categorySort == 3)
		{
			$query->order('title');
		}
		else
		{
			$query->order('lft');
		}
		$db->setQuery($query);
		return $db->loadObjectList();
	}
}