<?php
/**
 * Teacher select option
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;

// import the list field type


FormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of teacher
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class JFormFieldBaseTeacher extends JFormFieldList
{

	/**
	 * The field type.
	 *
	 * @var string
	 */
	protected $type = 'Teacher';

	/**
	 * Cached array of the category items.
	 *
	 * @var array
	 * @since 3.2
	 */
	protected static $options = array();

	protected function getOptions()
	{
		$params = ComponentHelper::getParams('com_diler');
		$baseSchoolTeacherGroupId = $params->get('base_school_teacher_group_id');
		$teacherGroups = $params->get('teacher_group_ids', 0);

		$hash = md5($this->element);

		if (! isset(static::$options[$hash]))
		{
			$options = parent::getOptions();

			$db = Factory::getDBO();
			$query = $db->getQuery(true);
			$query->select('du.user_id AS value, CONCAT(du.forename, " ", du.surname) AS text')
					->from('#__dilerreg_users AS du')
					->innerJoin('#__users AS ju ON ju.id = du.user_id')
					->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = du.user_id AND uum.group_id IN(' . implode(',', $teacherGroups) . ')')
					->innerJoin('#__usergroups AS ug ON ug.id = uum.group_id')
                    ->leftJoin('#__diler_school AS uu ON uu.id = du.user_id')
					->where('du.acceptedterms = ' . $db->quote(1))
					->where('ju.block = 0')
					->where('du.base_school_id is not NULL')
					->where('ug.id =' . $baseSchoolTeacherGroupId)
					->order('du.surname, du.forename')
					->group('du.user_id');
			$db->setQuery($query);
			$teachers = $db->loadObjectList();
			if ($teachers !== null)
			{
				static::$options[$hash] = array_merge(parent::getOptions(), $teachers);
			}
		}
		return static::$options[$hash];
	}
}