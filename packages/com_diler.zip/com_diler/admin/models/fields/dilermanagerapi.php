<?php
/**
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;

defined('_JEXEC') or die;

// import the list field type


/**
 * Text field for entering DiLer Manager API key defined on  https://www.digitale-lernumgebung.de
 * Field is disable for all users except DiLer Support users.
 * 
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @since          6.4.1
 */
class JFormFieldDiLerManager extends JFormFieldText
{
	/**
	 * The field type.
	 *
	 * @var string
	 * @since 6.4.1
	 */
	protected $type = 'DiLerManagerApi';

	public function getInput()
	{
		if (Factory::getUser()->username !== 'service.admin')
			$this->disabled = true;
		
		return parent::getInput();
	}

}