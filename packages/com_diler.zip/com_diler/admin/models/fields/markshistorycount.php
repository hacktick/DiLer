<?php
/**
 * Test table construct, bind, load
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access
defined('JPATH_BASE') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Language\Text;

FormHelper::loadFieldClass('text');

/**
 * Supports a modal article picker.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_advancedmodules
 * @since       1.6
 */
class JFormFieldMarksHistoryCount extends JFormFieldText
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since    1.6
	 */
	protected $type = 'MarksHistoryCount';

	/**
	 * Gets read-only count of marks history rows for this period. Used to determine whether marks period may be deleted.
	 *
	 * @return    string    The field input markup.
	 * @since    1.6
	 */
	protected function getInput()
	{
		$marksPeriodId = $this->form->getData()->get('id');
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('COUNT(*)')->from('#__diler_marks_history')->where('marks_period_id = ' . (int) $marksPeriodId);
		$result = $db->setQuery($query)->loadResult();
		$this->value = number_format($result, 0, Text::_('DECIMALS_SEPARATOR'), Text::_('THOUSANDS_SEPARATOR'));
		$this->readonly = 'readonly';
		return parent::getInput();
	}

}
