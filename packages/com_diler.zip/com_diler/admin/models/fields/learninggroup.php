<?php
/**
 * @copyright Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\HTML\HTMLHelper;

// No direct access to this file
defined('_JEXEC') or die();

FormHelper::loadFieldClass('list');
/**
 * @since 6.11.0
 */
class JFormFieldLearninggroup extends JFormFieldList
{
	protected $type = 'Learninggroup';

	protected function getOptions(): array
	{
		$learningGroupParentId = ComponentHelper::getParams('com_diler')->get('learning_group_parent_id');
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
        $query->select('ug.id, dilerGroup.name as title')
            ->from('#__usergroups AS ug')
            ->innerJoin('#__usergroups AS parent ON parent.id = ' . (int) $learningGroupParentId)
            ->innerJoin('#__diler_group AS dilerGroup ON ug.id = dilerGroup.joomla_group_id')
            ->where('ug.lft > parent.lft AND ug.rgt < parent.rgt')
            ->order('ug.title');
        $db->setQuery($query);
		$learningGroups = $db->loadObjectList();
		$options = array();
		foreach ($learningGroups as $loadingGroup) {
			$options [] = HTMLHelper::_('select.option', $loadingGroup->id, $loadingGroup->title);
		}

		return array_merge(parent::getOptions(), $options);
	}
}
