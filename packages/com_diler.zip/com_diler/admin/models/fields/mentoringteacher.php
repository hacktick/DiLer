<?php
/**
 * @copyright Copyright (C) 2013-2022 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use DiLer\DGet;
use DiLer\DUrl;
use DiLer\Views\Contact;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;

JLoader::register('JFormFieldTeacher', __DIR__ .'/teacher.php');
class JFormFieldMentoringTeacher extends JFormFieldTeacher
{
	protected $type = 'Mentoringteacher';

	protected function getInput()
	{
		$this->class = 'hide-in-view-mode';

		$input = parent::getInput();
		if ($this->value)
		{
			$lang = Factory::getLanguage();
			$langTag = explode('-', $lang->getTag())[0];
			$contactPageMenuItemId = Contact::getMenuItemId($langTag);

			$teacher = DGet::user($this->value);
			$linkToContactPage = DUrl::viewContact($this->value, $contactPageMenuItemId, $langTag, $teacher->role());
			$input .= HTMLHelper::_('link', $linkToContactPage, $teacher->personalData()->fullName(), array('class' => 'hide-in-edit-mode'));
		}
		HTMLHelper::_('diler.selectize', '#' . $this->id, $this->getOptions());
		return $input;
	}
}
