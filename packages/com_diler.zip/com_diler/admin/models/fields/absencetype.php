<?php

defined('_JEXEC') or die('Restricted access');

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Form\FormHelper;



FormHelper::loadFieldClass('radio');

/**
 * Supports an HTML radio inputs of student record absence categories
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 *
 * @since		6.8.0
 */
class JFormFieldAbsencetype extends JFormFieldRadio {

	/**
	 * The field type.
	 *
	 * @var string
	 */
	public $type = 'absencetype';

	public function getOptions()
	{
		$this->__set('value', ComponentHelper::getParams('com_diler')->get('studentRecordExcusedAbsence', 0));
		return $this->getAbsenceCategories();
	}

	private function getAbsenceCategories()
	{
        if(\Audivisa\Component\DiLer\Site\Helper\VersionHelper::isJoomla4())
		    $studentRecordModel = MVCHelper::factory()->createModel('Studentrecord', 'Site');
        else
            $studentRecordModel = MVCHelper::factory()->createModel('Studentrecord', 'Site');
		$absenceCategories = $studentRecordModel->getAbsenceCategories();
		$output = array();
		foreach($absenceCategories as $absenceCategory) {
			$output[] = (object) [
				'value' => $absenceCategory->id,
				'text' => $absenceCategory->title,
			];
		}

		return $output;
	}
}
