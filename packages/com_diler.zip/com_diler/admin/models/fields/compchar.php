<?php
/**
 * Compchar field options
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;

// import the list field type


FormHelper::loadFieldClass('list');
 
/**
 * Supports an HTML select list of compchars
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @since		2.5
 */
class JFormFieldCompChar extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'CompChar';
 
        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of HTMLHelper options.
         */
        protected function getOptions() 
        {
			$db = Factory::getDBO();
			$query = $db->getQuery(true);
			$query->select('id,name,description');
			$query->from('#__diler_compchar');
			$db->setQuery((string)$query);
			$messages = $db->loadObjectList();
			$options = array();
			if ($messages)
			{
				foreach($messages as $message) 
				{
					$options[] = HTMLHelper::_('select.option', $message->id, $message->name, $message->description);
				}
			}
			$options = array_merge(parent::getOptions(), $options);
			return $options;
        }
}