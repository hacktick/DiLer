<?php
/**
 * @copyright Copyright (C) 2013-2025 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;



FormHelper::loadFieldClass('list');

class JFormFieldSchoolContractSignedBy extends JFormFieldList
{

	protected $type = 'SchoolContractSignedBy';

	protected static $options = array();

	protected function getOptions()
	{
		$params = ComponentHelper::getParams('com_diler');
		$baseSchoolTeacherGroupId = \Audivisa\Component\DiLer\Administrator\Helper\DiLerSettings::init()->baseSchoolUserGroupId();
		$teacherGroups = $params->get('teacher_group_ids', 0);

		$hash = md5($this->element);

		if (! isset(static::$options[$hash]))
		{
			$db = Factory::getDBO();
			$query = $db->getQuery(true);
			$query->select('du.user_id AS value, CONCAT(du.forename, " ", du.surname, " | ",  s.name) AS text')
					->from('#__dilerreg_users AS du')
					->innerJoin('#__users AS ju ON ju.id = du.user_id')
					->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = du.user_id AND uum.group_id IN(' . implode(',', $teacherGroups) . ')')
					->innerJoin('#__usergroups AS ug ON ug.id = uum.group_id')
                    ->innerJoin('#__diler_school AS s ON s.id = du.base_school_id')
					->where('du.acceptedterms = ' . $db->quote(1))
					->where('ju.block = 0')
					->where('du.base_school_id is not NULL')
					->where('ug.id =' . $baseSchoolTeacherGroupId)
					->order('du.surname, du.forename')
					->group('du.user_id');
			$db->setQuery($query);
			$teachers = $db->loadObjectList();
			if ($teachers !== null)
			{
				static::$options[$hash] = array_merge(parent::getOptions(), $teachers);
			}
		}
		return static::$options[$hash];
	}
}