<?php
/**
 * phase field options
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;

// import the list field type


FormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of Phases
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class JFormFieldPhase extends JFormFieldList
{
	/**
	 * The field type.
	 *
	 * @var string
	 */
	protected $type = 'Phase';

	protected function getOptions()
	{
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->select('id,value,description');
		$query->from('#__diler_phase');
		$query->where('published = 1');
		if ($this->getAttribute('data-order-by-ordering', 0))
			$query->order('ordering ASC, id ASC');
		else
			$query->order('CAST(value AS UNSIGNED)');
		$phases = $db->setQuery($query)->loadObjectList();
		$options = array ();
		if($phases)
		{
			foreach($phases as $phase)
			{
				if ($this->getAttribute('data-load-ids-as-value', 0))
					$options [] = HTMLHelper::_('select.option', $phase->id, $phase->value);
				else
					$options [] = HTMLHelper::_('select.option', $phase->value);
			}
		}
		return array_merge(parent::getOptions(), $options);
	}
}