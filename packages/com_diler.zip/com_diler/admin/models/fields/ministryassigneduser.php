<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2023 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;

FormHelper::loadFieldClass('list');

class JFormFieldMinistryAssignedUser extends JFormFieldList
{
	protected $type = 'Ministryassigneduser';

	protected function getOptions()
	{
        $ministry_trainer_group_id = ComponentHelper::getParams('com_diler')->get('ministry_teacher_group_id');
		
        $db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('id AS value, name AS text')
			->from('#__users AS u')
			->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = u.id')
			->where('uum.group_id = '. $ministry_trainer_group_id);

		$options = $db->setQuery($query)->loadObjectList();

		return array_merge(parent::getOptions(), $options);
	}

    protected function getInput()
    {
        $input = parent::getInput();
        return $input;
    }
}
