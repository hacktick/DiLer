<?php
/**
 * Level select options
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;

// import the list field type


FormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of levels
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class JFormFieldCompetencelevel extends \Joomla\CMS\Form\Field\ListField
{

	/**
	 * The field type.
	 *
	 * @var string
	 */
	protected $type = 'Competencelevel';

	protected static $options = array();

	protected function getOptions()
	{
		// Accepted modifiers
		$hash = md5($this->element);

		if (! isset(static::$options[$hash]))
		{
			static::$options[$hash] = parent::getOptions();

			$options = array();
			$db = Factory::getDBO();
			$query = $db->getQuery(true);
			$query->select('CONCAT(c.id, "-", l.id) AS value, CONCAT(' . $db->quote(DText::_('PHASE')) . '," ",p.value, " - ", s.name, " - ", c.name, " - ", l.name) AS text');
			$query->from('#__diler_competence AS c');
			$query->innerJoin('#__diler_level AS l ON l.published = 1');
			$query->innerJoin('#__diler_subject_competence_map AS scm ON scm.competence_id = c.id');
			$query->innerJoin('#__diler_phase AS p ON scm.phase_id = p.id');
			$query->innerJoin('#__diler_subject AS s ON s.id = scm.subject_id');
			$query->leftJoin('#__diler_competence_compchar_map AS ccm ON ccm.competence_id = c.id AND l.id = ccm.level_id');
			$query->leftJoin('#__diler_compchar AS cc ON cc.id = ccm.compchar_id AND l.id = ccm.level_id');
			$query->where('ccm.competence_id IS NULL');
			$query->where('c.published = 1');
			$query->select('p.value AS phase_value');
			$query->order('p.ordering, s.ordering, c.ordering, c.name, l.id');

			$options = $db->setQuery($query)->loadObjectList();

			$currentOption = array();
			$currentValueArray = explode('-', $this->value);
			if (is_array($currentValueArray) && $currentValueArray && $currentValueArray[0])
			{
				$currentOption = array((object) array('text' => $this->getCurrentValue($this->value), 'value' => $this->value));
			}
			// Return the result
			static::$options[$hash] = array_merge(static::$options[$hash], $currentOption, $options);
		}

		return static::$options[$hash];
	}

	protected function getCurrentValue($value)
	{
		$db = Factory::getDBO();
		$array = explode('-', $value);
		$query = $db->getQuery(true)
			->select('c.name, GROUP_CONCAT(s.name ORDER BY s.ordering SEPARATOR " / ") AS subject_name')
			->from('#__diler_competence AS c')
			->innerJoin('#__diler_subject_competence_map AS scm ON c.id = scm.competence_id')
			->innerJoin('#__diler_phase AS p ON scm.phase_id = p.id')
			->innerJoin('#__diler_subject AS s ON scm.subject_id = s.id')
			->select('p.value as phase_value')
			->where('c.id = ' . (int) $array[0])
			->group('c.id');
		$competenceObject = $db->setQuery($query)->loadObject();

		$query = $db->getQuery(true)
			->select('name')
			->from('#__diler_level')
			->where('id = ' . (int) $array[1]);
		$levelName = $db->setQuery($query)->loadResult();

		return DText::_('PHASE') . ' ' . $competenceObject->phase_value . ' - ' . $competenceObject->subject_name . ' - ' . $competenceObject->name . ' - ' . $levelName;

	}
}