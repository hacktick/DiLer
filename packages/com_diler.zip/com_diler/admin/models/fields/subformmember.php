<?php
/**
 * Subject select option
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;

// import the list field type


FormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of subject
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class JFormFieldSubformMember extends JFormFieldList
{

	/**
	 * The field type.
	 *
	 * @var string
	 */
	protected $type = 'SubformMember';

	/**
	 * Cached array of the category items.
	 *
	 * @var array
	 * @since 3.2
	 */
	protected static $options = array();

	protected function getOptions()
	{
		$hash = md5($this->element);

		if (! isset(static::$options[$hash]))
		{
			static::$options[$hash] = parent::getOptions();
			$options = array();
			$db = Factory::getDBO();
			$query = $db->getQuery(true);
			$query->select('id AS value, label AS text');
			$query->from('#__diler_report_field_definition');
			$query->where('published = 1');
			$query->where('type = 4');
			$query->order('ordering');
			$db->setQuery($query);
			if ($fields = $db->loadObjectList())
			{
				static::$options[$hash] = array_merge(parent::getOptions(), $fields);
			}
		}
		return static::$options[$hash];
	}
}