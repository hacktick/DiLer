<?php
/**
 * Level select options
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2018 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Joomla\CMS\Form\FormHelper;

// import the list field type


FormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of log actions from DiLer log
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @since		6.0
 */
class JFormFieldLogactions extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'Logactions';

        protected function getOptions()
        {

			$options = MVCHelper::factory()->createModel('Logevents', 'Administrator')->getLogActions();
			$options = array_merge(parent::getOptions(), $options);
            return $options;
        }
}