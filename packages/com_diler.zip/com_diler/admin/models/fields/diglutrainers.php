<?php
/**
 * @package     Dilerreg.Administrator
 * @subpackage  com_dilerreg
 *
 * @copyright   Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('JPATH_BASE') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;

FormHelper::loadFieldClass('groupedlist');

class JFormFieldDiglutrainers extends JFormFieldGroupedList
{
	protected $type = 'Diglutrainers';

	protected function getGroups()
	{

		$diglu_trainer_group_id = ComponentHelper::getParams('com_diler')->get('diglu_trainer_group_id');

		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->select('id AS value, name AS text')
			->from('#__users AS u')
			->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = u.id')
			->where('uum.group_id = '. $diglu_trainer_group_id);


		$trainers = $db->setQuery($query)->loadObjectList();

		$options = array();

		foreach($trainers as $trainer)
		{
			$select = HTMLHelper::_('select.option', $trainer->value, $trainer->text);
			$options[0][] = $select;
		}

		reset($options);

		return $options;
	}
}
