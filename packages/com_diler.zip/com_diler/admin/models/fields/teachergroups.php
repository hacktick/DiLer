<?php
/**
 * Teacher select option
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;

// import the list field type


JLoader::register('DiLerParams', JPATH_ROOT . '/components/com_diler/helpers/dilerparams.php');
FormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of teacher
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class JFormFieldTeachergroups extends JFormFieldList
{

	/**
	 * The field type.
	 *
	 * @var string
	 */
	protected $type = 'Teachergroups';

	/**
	 * Cached array of the category items.
	 *
	 * @var array
	 * @since 3.2
	 */
	protected static $options = [];

	protected function getOptions()
	{
		$hash = md5($this->element);
		if (! isset(static::$options[$hash]))
		{
			static::$options[$hash] = parent::getOptions();
			$options = [];
			$groupIds = ComponentHelper::getParams('com_diler')->get('teacher_group_ids', [0]);
			if (! is_array($groupIds) || ! $groupIds) return [];
			$db = Factory::getDBO();
			$query = $db->getQuery(true);
			$query->select('jug.id AS value, jug.title AS text')
					->from('#__usergroups AS jug')
					->where('jug.id IN(' . implode(',', $groupIds) . ')')
					->order('jug.title');
			$db->setQuery($query);
			$teacherGroups = $db->loadObjectList();
			if ($teacherGroups !== null)
			{
				static::$options[$hash] = array_merge(parent::getOptions(), $teacherGroups);
			}
		}

		$options = static::$options[$hash];
		return $this->getWithoutMinistryGroupIfItIsFieldForSettingUserGroupForNotificationsForNewRegistrations($options);
	}

	private function getWithoutMinistryGroupIfItIsFieldForSettingUserGroupForNotificationsForNewRegistrations($teacherGroups)
	{
		if ($this->fieldname === 'user_group_ids_for_notification_about_diglu_registration')
		{
			$ministryUserGrupId = DilerParams::init()->getMinistryUserGroupIds();
			foreach ($teacherGroups as $key => $teacherGroup)
			{
				if ($teacherGroup->value === $ministryUserGrupId)
					unset($teacherGroups[$key]);
			}
		}
		return $teacherGroups;
	}
}