<?php
/**
 * Teacher select option
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Component\ComponentHelper;

// import the list field type


FormHelper::loadFieldClass('list');

class JFormFieldSchoolConnectedTeacherUser extends JFormFieldList
{
	protected $type = 'SchoolConnectedTeacherUser';
	protected static $options = array();

	protected function getOptions()
	{
		$params = ComponentHelper::getParams('com_diler');
		$teacherGroups = $params->get('teacher_group_ids', 0);

		$hash = md5($this->element);

		if (! isset(static::$options[$hash]))
		{
			$db = Factory::getDBO();
			$query = $db->getQuery(true);
			$query->select('du.user_id AS value, CONCAT(du.forename, " ", du.surname) AS text')
					->from('#__dilerreg_users AS du')
					->innerJoin('#__users AS ju ON ju.id = du.user_id')
					->innerJoin('#__user_usergroup_map AS uum ON uum.user_id = du.user_id AND uum.group_id IN(' . implode(',', $teacherGroups) . ')')
					->innerJoin('#__usergroups AS ug ON ug.id = uum.group_id')
					->where('du.acceptedterms = ' . $db->quote(1))
					->where('ju.block = 0')
					->order('du.surname, du.forename')
					->group('du.user_id');
			$db->setQuery($query);
			$teachers = $db->loadObjectList();
			if ($teachers !== null)
			{
				static::$options[$hash] = array_merge(parent::getOptions(), $teachers);
			}
		}
		return static::$options[$hash];
	}
}