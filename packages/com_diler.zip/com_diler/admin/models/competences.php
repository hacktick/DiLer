<?php
/**
 * Competences list, Competence export,phase list
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

// import the Joomla modellist library
jimport('joomla.application.component.modellist');

/**
 * Competences model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelCompetences extends ListModel
{

	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array('name','cc.name','ccordering','ccpublished','cc.id', 'phase','subject');

			$app = Factory::getApplication();
		}

		parent::__construct($config);
	}

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return string An SQL query
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('cc.id as ccid, cc.name as ccname, cc.description as ccdesc, cc.published as ccpublished');
		$query->select('cc.icon as ccicon,cc.publish_up as ccpublish_up,cc.publish_down as ccpublish_down');
		$query->select('cc.language as cclanguage,cc.checked_out as ccchecked_out,cc.checked_out_time as ccchecked_out_time');
		$query->select('cc.created_by as cccreated_by,cc.ordering as ccordering');

		// From the competence table
		$query->from($db->quoteName('#__diler_competence') . ' AS cc');

		// Join over the phase.
		$query->select('ph.id as phid, ph.value as phvalue');
		$query->leftJoin('#__diler_subject_competence_map AS scm ON cc.id = scm.competence_id');
		$query->leftJoin('#__diler_phase AS ph ON ph.id = scm.phase_id');

		// Filter by search in title
		$search = $this->getState('filter.search');
		if (! empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('cc.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('cc.name LIKE ' . $search);
			}
		}

		$published = $this->getState('filter.ccpublished');
		if (is_numeric($published))
		{
			$query->where('cc.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(cc.published = 0 OR cc.published = 1)');
		}

		// if get filter BY phase id
		$phaseId = $this->getState('filter.phase');
		if ($phaseId > 0)
		{
			$query->where('scm.phase_id=' . (int) $phaseId);
		}
		$phase = $this->getState('filter.phase');
		if (is_numeric($phase))
		{
			$query->where('scm.phase_id = ' . (int) $phase);
		}

		// Join over the subject
		$subQuery = $db->getQuery(true)
			->select('scm.competence_id, GROUP_CONCAT(s.name) as ccsubject, GROUP_CONCAT(s.description) as sdesc')
			->select('GROUP_CONCAT(s.id) AS subject_id_list')
			->from('#__diler_subject_competence_map AS scm')
			->innerJoin('#__diler_subject AS s ON scm.subject_id = s.id')
			->group('scm.competence_id');

		// Filter on subject
		$subject = $this->getState('filter.subject');
		if (is_numeric($subject) && $subject)
		{
			$subQuery->where('scm.subject_id = ' . $db->quote((int) $subject));
		}

		$query->select('ccsubject, subject_id_list');
		$query->innerJOIN('(' . trim((string) $subQuery) . ') AS sub ON sub.competence_id = cc.id');

		$query->group('cc.id');

		// order by [field] [direction]
		$orderCol = $this->state->get('list.ordering', 'ccname');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		return $query;
	}

	/**
	 * Method to populate publish
	 *
	 * @since 2.5
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$phase = $this->getUserStateFromRequest($this->context . '.filter.phase', 'filter_phase', '');
		$subject = $this->getUserStateFromRequest($this->context . '.filter.subject', 'filter_subject', '');
		$this->setState('filter.phase', $phase);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('cc.ordering', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}
}