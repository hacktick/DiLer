<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2013 - 2015 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use DiLer\Lang\DText;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;

/**
 * Weblinks model.
 *
 * @package Joomla.Administrator
 * @subpackage com_diler
 * @since 1.5
 */
class DilerModelReportperiod extends AdminModel
{

	/**
	 * The type alias for this content type.
	 *
	 * @var string
	 * @since 3.2
	 */
	public $typeAlias = 'com_diler.reportperiods';

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param object $record
	 *        	A record object.
	 *
	 * @return boolean True if allowed to delete the record. Defaults to the permission for the component.
	 *
	 * @since 1.6
	 */
	protected function canDelete($record)
	{
		if (! empty($record->id)) {
			if ($record->published != - 2) {
				return;
			}
			$user = Factory::getUser();
			return parent::canDelete($record);
		}
	}

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param object $record
	 *        	A record object.
	 *
	 * @return boolean True if allowed to change the state of the record. Defaults to the permission for the component.
	 *
	 * @since 1.6
	 */
	protected function canEditState($record)
	{
		$user = Factory::getUser();

		if (! empty($record->catid)) {
			return $user->authorise('core.edit.state', 'com_diler.category.' . (int) $record->catid);
		} else {
			return parent::canEditState($record);
		}
	}

    /**
     * Override parent delete method
     *
     * @param array &$pks An array of record primary keys.
     * @return boolean True if successful, false if an error occurs.
     *
     * @throws Exception
     * @since 12.2
     */
	public function delete(&$pks)
	{
		// Can't delete if this period has history rows
		$pks = $this->checkChangeStatus($pks);

		// Delete any rows from mapping table
		if (is_array($pks) && $pks)
		{
			return parent::delete($pks);
		}
		return false;
	}

	/**
	 * Method to get a table object, load it if necessary.
	 *
	 * @param string $type
	 *        	The table name. Optional.
	 * @param string $prefix
	 *        	The class prefix. Optional.
	 * @param array $config
	 *        	Configuration array for model. Optional.
	 *
	 * @return Table
	 *
	 * @since 1.6
	 */
	public function getTable($type = 'Reportperiod', $prefix = 'DilerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Abstract method for getting the form from the model.
	 *
	 * @param array $data
	 *        	Data for the form.
	 * @param boolean $loadData
	 *        	True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 *
	 * @since 1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.reportperiod', 'reportperiod', array(
			'control' => 'jform',
			'load_data' => $loadData
		));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return array The default data is an empty array.
     *
     * @throws Exception
     * @since 1.6
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.reportperiod.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		$this->preprocessData('com_diler.reportperiod', $data);

		return $data;
	}

	/**
	 * Prepare and sanitise the table data prior to saving.
	 *
	 * @param Table $table
	 *        	A reference to a Table object.
	 *
	 * @return void
	 *
	 * @since 1.6
	 */
	protected function prepareTable($table)
	{
		$date = Factory::getDate();
		$user = Factory::getUser();

		$table->name = htmlspecialchars_decode($table->name, ENT_QUOTES);
	}

    /**
     * Overload of parent publish method.
     * Don't allow trashing if this has report history data.
     *
     * @param   array    &$pks A list of the primary keys to change.
     * @param   integer $value The value of the published state.
     *
     * @return  boolean  True on success.
     *
     * @throws  Exception
     * @since   12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == -2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		if (is_array($pks) && $pks)
		{
			return parent::publish($pks, $value);
		}
	}

	/**
	 * Checks report period for any linked report history rows. Don't allow trash or delete if found.
	 *
	 * @param   array  $pks  array of compchar ids
	 *
	 * @throws  Exception
	 *
	 * @return  array  array of allowed compchar ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no history rows for these report periods
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('h.period_id')
			->from('#__diler_report_field_history AS h')
			->innerJoin('#__diler_report_field_definition AS f ON f.id = h.field_id AND f.type = 1')
			->where('h.period_id IN(' . implode(',', $pks) . ')')
			->where('h.field_value > ""')
			->group('h.period_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
            Factory::getApplication()->enqueueMessage(DText::plural('N_REPORTPERIODS_CANNOT_CHANGE_STATUS', count($badPks)),'WARNING');
			$pks = array_diff($pks, $badPks);
		}
		return $pks;
	}

	/**
	 * Gets all of the fields and values for this period where field type is 'report'
	 * These fields are entered in the back end under period edit.
	 * This model gets all of the fields for the edit layout.
	 *
	 * @param    int     $periodId Id of the period
	 * @return   array   array of row objects with field information, including the current value if any
	 */
	public function getPeriodReportFields($periodId = null)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->from('#__diler_report_field_definition AS f')
			->select('f.*')
			->where('f.type = 1')
			->where('f.published = 1')
			->order('f.ordering ASC');
		if ($periodId)
		{
			$query->leftJoin('#__diler_report_field_history AS fh ON f.id = fh.field_id AND fh.period_id = ' . (int) $periodId);
			$query->select('CASE WHEN ISNULL(fh.field_id) THEN "" ELSE fh.field_value END AS value');
		}
		else
		{
			$query->select('"" AS value');
		}
		$reportFields = $db->setQuery($query)->loadObjectList();

		// Escape values for output
		foreach ($reportFields as $reportField)
		{
			$reportField->value = htmlspecialchars($reportField->value, ENT_QUOTES);
		}
		return $reportFields;
	}

    /**
     * Override parent method to save the form data. Need to save report fields to report field history table.
     *
     * @param   array $data The form data.
     *
     * @return  boolean  True on success, False on error.
     *
     * @throws  Exception
     * @since   12.2
     */
	public function save($data)
	{
		$result = parent::save($data);
		if ($result)
		{
			$id =  isset($id) ? $id : (int) $this->getState($this->getName().'.id');
			// Save form data to report field history table for the period.
			$app = Factory::getApplication();
			$fieldArray = $app->input->get('reportFields', array(), 'array');
			$result = $this->saveReportField($id, $fieldArray);
		}
		return $result;
	}

	protected function saveReportField($period, $fieldArray)
	{
		$db = Factory::getDbo();
		$fieldIds = array_keys($fieldArray);

		// Delete existing values
		$query = $db->getQuery(true)
			->delete('#__diler_report_field_history')
			->where('period_id = ' . (int) $period)
			->where('field_id IN(' . implode(',', $fieldIds) . ')');
		$db->setQuery($query)->execute();

		// Insert new values
		$query = $db->getQuery(true)
			->insert('#__diler_report_field_history')
			->columns('field_id, period_id, student_id, subject_id, field_value, created, created_by, modified, modified_by');
		$userId = Factory::getUser()->id;
		$date = Factory::getDate()->toSql();

		foreach ($fieldArray as $id => $value)
		{
			if ($value != '')
			{
				$query->values($id . ',' . $period . ',' . '0,0,' . $db->quote($value) . ',' . $db->quote($date) . ',' . $userId . ',' . $db->quote($date) . ',' . $userId);
			}
		}
		$result = true;
		if ((string) $query->values)
		{
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}
}
