<?php
/**
 * DiLer Purge model
 * @package        DiLer.Administrator
 * @subpackage     com_diler
 * @filesource
 * @copyright      Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license        GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die ('Restricted access');

use DiLer\Groups\LearningGroups;
use DiLer\Lang\DText;
use DiLer\Reports\LoadStoredReport;
use DiLer\Reports\StoredReport;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;

// import the Joomla modellist library
Factory::getLanguage()->load('com_diler', JPATH_SITE . '/components/com_diler');
/**
 * Purge model.
 *
 * @package    DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since      2.5
 */
class DiLerModelPurge extends AdminModel
{
	private $gridTables = array(
		'diler_activity_compchar_map',
		'diler_subject_competence_map',
		'diler_competence_compchar_map',
		'diler_activity_completed',
		'diler_activity_task_completed',
		'diler_student_compchar_status',
		'diler_student_competence_status',
		'diler_student_subject_phase_status',
		'diler_compchar',
		'diler_competence',
	);
	
	private $activityAndCompDynamicTables = array(
		'diler_activity_completed',
		'diler_activity_task_completed',
		'diler_student_compchar_status',
		'diler_student_competence_status',
		'diler_student_subject_phase_status'
	);

	private $studentRecordsTables = array(
		'diler_studentrecord_history',
		'diler_studentrecord_group_map',
		'diler_studentrecord_tag_map',
		'diler_studentrecord'
	);
	
	private $marksHistoryTables = array('diler_marks_history');
	
	private $cloudTables = array(
		"diler_cloud",
		"diler_group_cloud_map"
	);
	
	private $pepTable = array(
		'diler_pep'
	);
	
	
	private $studentReportTables = array (
		'diler_report_field_history',
		'diler_report_period'
	);
	
	private $texterTables = array('diler_texter');
	
	protected $logEventTables = array('diler_log');
	
	private $storedReportTables = array('diler_stored_report');
	/**
	 * This is int number used to pass from purge form if we want to delete system messages
	 * @TODO Move this to other generic place. We use this to indicate that we need to delete message with
	 *      'type' BETWEEN 1 AND 9 in #__texter table
	 * @var int 
	 * @since 6.4.1 
	 */
	private $texterSystemMessageType = -2;

	public function getTable($name = '', $prefix = 'DiLerTable', $options = array())
	{
		return parent::getTable($name, $prefix, $options); 
	}

	/**
	 * Abstract method for getting the form from the model.
	 *
	 * @param array   $data     Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return  Form|boolean  A Form object on success, false on failure
	 *
	 * @since   1.6
	 */
	public function getForm($data = array(), $loadData = false)
	{
		// Get the form.
		return $this->loadForm('com_diler.purge', 'purge', array('load_data' => $loadData));
	}

	public function deleteGridTables()
	{
		$db = Factory::getDbo();
		try
		{
			foreach ($this->getDbTablesByGroup('gridTables') as $table)
			{
				$query = $db->getQuery(true)->delete($db->quoteName($table));
				$db->setQuery($query)->execute();
			}
		}
		catch (Exception $e)
		{
			Factory::getApplication()->enqueueMessage($e->getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Purge rows from event log table
	 *
	 * @param string $tillDate Date to purge up through
	 *
	 * @throws RuntimeException
	 */
	public function purgeEventLog($tillDate)
	{
		$query = $this->_db->getQuery(true);
		$query->delete('#__diler_log');
		$query->where('DATE(create_time) <= DATE(' . $this->_db->quote($tillDate) . ')');
		$this->_db->setQuery($query)->execute();
		
		$coreLogQuery = $this->_db->getQuery(true);
		$coreLogQuery->delete('#__action_logs');
		$coreLogQuery->where('DATE(log_date) <= DATE(' . $this->_db->quote($tillDate) . ')');
		$this->_db->setQuery($coreLogQuery)->execute();
		
		/** @var DiLerModelDiLer $dilerModel */
		$dilerModel = BaseDatabaseModel::getInstance('Diler', 'DiLerModel');
		$dilerModel->logDataAction(DText::_('BUTTON_PURGE_EVENT_LOG'), DText::sprintf('BUTTON_PURGE_EVENT_LOG_DATE', $tillDate));
	}

	public function getDbTablesByGroup($group)
	{
		$tables = array();
		foreach ($this->{$group} as $table)
		{
			$tables[] = "#__$table";
		}
		return $tables;
	}
	
	public function getCloudCategoryForm($loadData = false)
	{
		// Get the form.
		return $this->loadForm('category.cloud', 'category.cloud', array('load_data' => $loadData));
	}

	public function getCloudPerCategories(int $categoryId, string $tillDate = "", $limit = 0)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id, path');
		$query->from('#__diler_cloud');
		$query->where('catid = ' . $db->quote($categoryId));
		$query->where('DATE(created) <= ' . $db->quote($tillDate));
		$query->setLimit($limit);
		
		return $db->setQuery($query)->loadAssocList();
	}

	public function getCloudPerUsers(int $userId, string $tillDate = "", $limit = 0)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id, path');
		$query->from('#__diler_cloud AS cloud');
		$query->leftJoin('#__diler_group_cloud_map AS cloud_map ON cloud.id = cloud_map.media_id');
		$query->where('cloud_map.media_id IS NULL');
		$query->where('owned_by = ' . $db->quote($userId));
		$query->where('DATE(created) <= ' . $db->quote($tillDate));
		$query->setLimit($limit);

		return $db->setQuery($query)->loadAssocList();
	}

	public function getCategoriesPerCloud(string $tillDate = null)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('cat.id, cat.title, COUNT(cloud.id) as total, cat.params AS selectorGroup');
		$query->from('#__categories AS cat');
		$query->leftJoin('#__diler_cloud AS cloud ON cloud.catid = cat.id');
		$query->where('cloud.id IS NOT NULL');
		
		if ($tillDate)
			$query->where("DATE(cloud.created) <= " . $db->quote($tillDate));
		
		$query->group('cat.id');
		$query->order('cat.title');
		
		$results = $db->setQuery($query)->loadAssocList();
		foreach ($results as $key => $result)
			$results[$key]['selectorGroup'] = json_decode($result['selectorGroup'])->cloud_type;
		
		return  $this->prepareLoadedData($results);
	}
	
	public function getUsersPerCloud(string $tillDate = null)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('users.user_id AS id, CONCAT(users.surname, " ", users.forename) AS title, users.role AS selectorGroup,COUNT(cloud.id) AS total');
		$query->from('#__dilerreg_users AS users');
		$query->leftJoin('#__diler_cloud AS cloud ON users.user_id = cloud.owned_by');
		$query->leftJoin('#__diler_group_cloud_map AS cloud_map ON cloud.id = cloud_map.media_id');
		$query->where('cloud.id IS NOT NULL');
		$query->where('cloud_map.media_id IS NULL');
		$query->where('DATE(cloud.created) <= ' . $db->quote($tillDate));
		$query->group('users.user_id, users.surname');
		$query->order('users.surname');
		
		$results = $db->setQuery($query)->loadAssocList();
		return $this->prepareLoadedData($results);
	}

	/**
	 * @return int
	 * @since 6.4.1 
	 */
	public function deleteCloudFilesMissingDbRecords()
	{
		$deleted = 0;
		foreach ($this->getAllCloudFilesOnHdd() as $filePath)
		{
			if (!$this->isPathInCloudDb($filePath))
			{
				if (File::delete(DilerHelperUser::getRootFileFolder() . $filePath))
					$deleted += 1;
			}
		}
		
		return $deleted;
	}
	
	public function deleteCloudDBEntriesMissingRealFile()
	{
		$deleted = 0;
		foreach ($this->getAllCloudDbRecords() as $dbEntry)
		{
			if(!File::exists(DilerHelperUser::getRootFileFolder() . $dbEntry['path']))
			{
				$this->deleteCloudData($dbEntry['id']);
				$deleted += 1;
			}
		}
		
		return $deleted;
	}
	
	public function getUsersRoles()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('DISTINCT(role)');
		$query->from('#__dilerreg_users');
		
		return $db->setQuery($query)->loadColumn();
	}

	public function getLearningGroupsPerMarksHistory(string $tillDate = null)
	{
		/** @var DiLerTableMarkshistory $marksHistoryTable */
		$marksHistoryTable = $this->getTable('Markshistory');
		$results = $marksHistoryTable->getLearningGroupsWithMarksHistory($tillDate, true);

		return $this->prepareLoadedData($results);
	}

	public function getStudentsPerMarksHistory(string $tillDate = null)
	{
		/** @var DiLerTableMarkshistory $marksHistoryTable */
		$marksHistoryTable = $this->getTable('Markshistory');
		$students = $marksHistoryTable->getStudentsWithMarks($tillDate, true);

		return $this->prepareLoadedData($students);
	}

	public function getCategoriesPerStudentRecords(string $tillDate = null)
	{
		/** @var DiLerTableStudentrecord $studentRecordTbl */
		$db = $this->getDbo();
		$studentRecordTbl = $this->getTable('Studentrecord');
		$results = $studentRecordTbl->getAllCategoriesWithData(
			array("DATE(" . $studentRecordTbl->getTableName() . ".created) <= " . $db->quote($tillDate)), 
			true
		);
		$results = array_map(function ($row) {
			$row['id'] = $row['catType'] . "_" . $row['id'];
			return $row;
		}, $results);

		return $this->prepareLoadedData($results);
	}

	public function getLearningGroupsPerStudentRecords($tillDate = null)
	{
		$db         = $this->getDbo();
		$query      = $db->getQuery(true);
		$tableAlias = 'studentRecords';
		$query      = $this->prepareSelectLearingGroupsQuery($query, '#__diler_studentrecord', $tableAlias);
		$query->select("COUNT($tableAlias.id) as total");

		if ($tillDate)
			$query->where("DATE($tableAlias.created) <= " . $db->quote($tillDate));

		$results = $db->setQuery($query)->loadAssocList();

		return $this->prepareLoadedData($results, $this->studentRecordsTables);
	}

	public function getStudentsPerStudentRecords(string $tillDate = null)
	{
		$db         = $this->getDbo();
		$tableAlias = 'studentrecords';
		$query      = $db->getQuery(true);
		$query      = $this->prepareSelectStudentsQuery($query, '#__diler_studentrecord', $tableAlias);

		if ($tillDate)
			$query->where("DATE($tableAlias.created) <= " . $db->quote($tillDate));
		$results = $db->setQuery($query)->loadAssocList();

		return $this->prepareLoadedData($results, $this->studentRecordsTables);
	}

	public function getStudentsPerActivitiesAndCompetences(string $tillDate = null)
	{
		$preparedData = array();
		foreach ($this->activityAndCompDynamicTables as $table)
		{
			foreach ($this->getStudentsPerActivitiesAndCompetenceTable($table, $tillDate) as $student)
			{
				if (!isset($preparedData[$student['id']]))
				{
					$preparedData[$student['id']] = $student;
					// We set total to 0 as we are appending it in next lines
					// So, if it's first time added to array, let's set 0
					$preparedData[$student['id']]['total'] = 0;
				}

				$preparedData[$student['id']]['total']        += $student['total'];
				$preparedData[$student['id']]['deleteKeys'][] = $student['id'] . "__" . $table;
			}
		}

		return $preparedData;
	}

	public function getLearningGroupsPerActivitiesAndCompetences(string $tillDate = null)
	{
		$results = array();
		foreach ($this->activityAndCompDynamicTables as $table)
		{
			foreach ($this->getLearningGroupsPerActivitiesAndCompetenceTable($table, $tillDate) as $group)
			{
				if (!isset($results[$group['id']]))
				{
					$results[$group['id']] = $group;
					// We set total to 0 as we are appending it in next lines
					// So, if it's first time added to array, let's set 0
					$results[$group['id']]['total'] = 0;
				}

				$results[$group['id']]['total']           += $group['total'];
				$results[$group['id']]['counter'][$table] = $group['total'];
				$results[$group['id']]['deleteKeys'][]    = $group['id'] . "__" . $table;
			}
		}

		return $results;
	}

	public function getLearningGroupsPerStoredStudentRecordsReports(string $tillDate)
	{
		return $this->prepareLoadedData(
			$this->getLearningGroupsPerStoredReports($tillDate, StoredReport::STUDENT_RECORDS)
		);
	}
	
	public function getStudentsPerStoredStudentRecordsReports(string $tillDate)
	{
		return $this->prepareLoadedData($this->getStudentsPerStoredReports($tillDate, StoredReport::STUDENT_RECORDS));
	}
	
	public function getStudentsPerStoredStudentReports(string $tillDate)
	{
		return $this->prepareLoadedData($this->getStudentsPerStoredReports($tillDate, StoredReport::STUDENT_REPORTS));
	}

	public function getStudentsPerStoredMarksTableReports(string $tillDate)
	{
		return $this->prepareLoadedData($this->getStudentsPerStoredReports($tillDate, StoredReport::MARKS_TABLES));
	}

	public function getLearningGroupsPerStoredStudentReports(string $tillDate)
	{
		return $this->prepareLoadedData(
			$this->getLearningGroupsPerStoredReports($tillDate, StoredReport::STUDENT_REPORTS)
		);
	}
	
	public function getLearningGroupsPerStoredMarksTableReports(string $tillDate)
	{
		return $this->prepareLoadedData(
			$this->getLearningGroupsPerStoredReports($tillDate, StoredReport::MARKS_TABLES)
		);
	}

	private function getLearningGroupsPerStoredReports(string $tillDate, string $type)
	{
		$query = $this->_db->getQuery(true);
		$query = $this->prepareSelectLearingGroupsQuery($query, "#__diler_stored_report", "storedReport");
		$query->select("COUNT(storedReport.id) as total");
		$query->where("type = " . $this->_db->quote($type));
		$query->where('DATE(storedReport.created) <= DATE('. $this->_db->quote($tillDate) .')');
		
		return $this->_db->setQuery($query)->loadAssocList();
	}
	
	private function getStudentsPerStoredReports(string $tillDate, string $type)
	{
		$query = $this->_db->getQuery(true);
		$query->select("u.user_id as id, CONCAT(u.surname, ' ', u.forename) as title, count(sr.id) as total");
		$query->from('#__diler_stored_report as sr');
		$query->innerJoin('#__dilerreg_users as u ON u.user_id = sr.student_id');
		$query->where('sr.type = ' . $this->_db->quote($type));
		$query->where('DATE(sr.created) <= DATE('. $this->_db->quote($tillDate) .')');
		$query->group('u.user_id, title');
		$query->order('title');
		
		return $this->_db->setQuery($query)->loadAssocList();
	}


	public function getStudentsPerPep(string $tillDate)
	{
		$query = $this->_db->getQuery(true);
		$query->select("u.user_id as id, CONCAT(u.surname, ' ', u.forename) as title, count(pep.id) as total");
		$query->from('#__diler_pep as pep');
		$query->innerJoin('#__dilerreg_users as u ON u.user_id = pep.student_id');
		$query->where('DATE(pep.created) <= DATE('. $this->_db->quote($tillDate) .')');
		$query->group('u.user_id, title');
		$query->order('title');

		return $this->prepareLoadedData($this->_db->setQuery($query)->loadAssocList());
	}
	
	public function deletePepByStudents(int $deleteKey, string $tillDate)
	{
		/** @var DiLerTablePep $pepTable */
		$pepTable = $this->getTable('Pep');
		if ($affectedRows = $pepTable->deleteByStudentTillDate($deleteKey, $tillDate))
		{
			$this->enqueueSuccessMessage(DText::_('PEP'), DText::placehoder('Students'));
			return $affectedRows;
		}

		return 0;
	}

	public function deleteStoredStudentRecordsReportsByLearningGroups(int $deleteKey, string $tillDate)
	{
		$reports = LearningGroups::init()->getStoredReportsByGroup($deleteKey, StoredReport::STUDENT_RECORDS, $tillDate);
		$this->enqueueSuccessMessage(DText::_('STORED_STUDENT_RECORDS'), Text::_('COM_DILERREG_LG_PLURAL'));
		return $this->deleteStoredReports($reports);
	}

	public function deleteStoredStudentReportsByLearningGroups(int $deleteKey, string $tillDate)
	{
		$reports = LearningGroups::init()->getStoredReportsByGroup($deleteKey, StoredReport::STUDENT_REPORTS, $tillDate);
		$this->enqueueSuccessMessage(DText::_('STORED_STUDENT_REPORTS'), Text::_('COM_DILERREG_LG_PLURAL'));
		return $this->deleteStoredReports($reports);
	}

	public function deleteStoredMarksTableReportsByLearningGroups(int $deleteKey, string $tillDate)
	{
		$reports = LearningGroups::init()->getStoredReportsByGroup($deleteKey, StoredReport::MARKS_TABLES, $tillDate);
		$this->enqueueSuccessMessage(DText::_('STORED_MARKS_TABLES'), Text::_('COM_DILERREG_LG_PLURAL'));
		return $this->deleteStoredReports($reports);
	}
	
	public function deleteStoredStudentRecordsReportsByStudents(int $studentId, string $tillDate)
	{
		$this->enqueueSuccessMessage(DText::_('STORED_STUDENT_RECORDS'), DText::placehoder('Students'));
		$storedReports = $this->getStoredReportsByStudentAndType($studentId, StoredReport::STUDENT_RECORDS, $tillDate);
		return $this->deleteStoredReports($storedReports);
	}
	
	public function deleteStoredStudentReportsByStudents(int $studentId, string $tillDate)
	{
		$this->enqueueSuccessMessage(DText::_('STORED_STUDENT_REPORTS'), DText::placehoder('Students'));
		$storedReports = $this->getStoredReportsByStudentAndType($studentId, StoredReport::STUDENT_REPORTS, $tillDate);
		return $this->deleteStoredReports($storedReports);
	}
	
	public function deleteStoredMarksTableReportsByStudents(int $studentId, string $tillDate)
	{
		$this->enqueueSuccessMessage(DText::_('STORED_MARKS_TABLES'), DText::placehoder('Students'));
		$storedReports = $this->getStoredReportsByStudentAndType($studentId, StoredReport::MARKS_TABLES, $tillDate);
		return $this->deleteStoredReports($storedReports);
	}
	
	private function getStoredReportsByStudentAndType(int $studentId, string $type, string $tillDate)
	{
		
		BaseDatabaseModel::addIncludePath(JPATH_COMPONENT_SITE . '/models');
		/** @var DiLerModelStoredReports $storedReportsModel */
		$storedReportsModel = BaseDatabaseModel::getInstance('StoredReports', 'DiLerModel');
		$reports = $storedReportsModel->getReportsByStudent($studentId, $type, $tillDate);

		$storedReports = array();
		foreach ($reports as $report)
		{
			$storedReports[] = new LoadStoredReport($type, $report);
		}
		
		return $storedReports;
	}
	
	private function deleteStoredReports(array $reports)
	{
		$numberDeleted = 0;
		/** @var LoadStoredReport $report */
		foreach ($reports as $report)
		{
			try {
				/** @var DiLerModelStoredReport $storedReportsModel */
				BaseDatabaseModel::addIncludePath(JPATH_COMPONENT_SITE . "/models");
				$storedReportsModel = BaseDatabaseModel::getInstance("StoredReport", "DiLerModel");
				$storedReportsModel->deleteStoredReport($report);
			} catch (Exception $e)
			{
				Factory::getApplication()->enqueueMessage($e->getMessage(), 'error');
			}
			// Even if there is error we count as it's deleted
			// NOT best solution but it will work for a now.
			// We do this so we stop Ajax requests. If error with any of files, it will display error message.
			$numberDeleted++;
		}

		return $numberDeleted;
	}

	public function deleteActivitiesAndCompetencesByLearningGroups(string $deleteKey, $tillDate)
	{
		$deleteKeys = explode('__', $deleteKey);
		$groupId    = $deleteKeys[0];
		$table      = $deleteKeys[1];

		if (!in_array($table, $this->activityAndCompDynamicTables))
			throw new Exception("Invalid table name '$table' while trying to delete student records by learning groups");

		$db  = $this->getDbo();
		$sql = "DELETE $table " .
			"FROM #__usergroups AS ug " .
			"INNER JOIN #__user_usergroup_map AS ugm ON ug.id = ugm.group_id " .
			"INNER JOIN #__users AS u ON u.id = ugm.user_id " .
			"LEFT JOIN #__$table AS $table ON u.id = $table.student_id " .
			"WHERE ug.id = $groupId " .
			"AND (" . $this->buildTillDateQueryByDateTableFields("#__$table", $tillDate, $table) . ")";
		$db->setQuery($sql)->execute();

		$this->enqueueSuccessMessage(DText::_('ACTIVITIES_AND_COMPETENCE_STATUS'), Text::_('COM_DILERREG_LG_PLURAL'));
		return $db->getAffectedRows();
	}

	public function deleteActivitiesAndCompetencesByStudents(string $deleteKey, $tillDate)
	{
		$deleteKeys = explode('__', $deleteKey);
		$studentId  = $deleteKeys[0];
		$table      = $deleteKeys[1];

		if (!in_array($table, $this->activityAndCompDynamicTables))
			throw new Exception("Invalid table name '$table' while trying to delete student records by learning groups");
		$db = $this->getDbo();
		$db->setQuery("DELETE $table FROM #__$table AS $table " .
			"WHERE student_id = $studentId " .
			"AND (" . $this->buildTillDateQueryByDateTableFields("#__$table", $tillDate, $table) . ")"
		)->execute();

		$this->enqueueSuccessMessage(DText::sprintf('ACTIVITIES_AND_COMPETENCE_STATUS'), DText::placehoder('Student'));
		return $db->getAffectedRows();
	}

	public function deleteCloudData(int $cloudId, string $path = null)
	{
		/** @var DiLerTableCloud $cloudTable */
		$cloudTable = $this->getTable('Cloud', 'DilerTable');
		return $cloudTable->delete($cloudId, $path);
	}

	public function cleanStudentRecordsGarbage()
	{
		/** @var DiLerTableStudentrecord $studentRecordTable */
		$studentRecordTable = $this->getTable('Studentrecord');
		return $studentRecordTable->deleteRecordsAssignedToNonExistingUsers();
	}
	
	public function deleteStudentRecordsByCategories(string $catTypeAndId, string $tillDate)
	{
		$keys = explode('_', $catTypeAndId);
		$catType = $keys[0];
		$catId = $keys[1];
		$deletedAssignedToMany = $this->deleteStudentRecordsAssignedToMultipleCategories($catType, $catId, $tillDate);
		$deletedAssignedToOne = $this->deleteStudentRecordsAssignedToOneCategory($catType, $catId, $tillDate);
		
		$this->enqueueSuccessMessage(DText::_('STUDENT_RECORDS'), Text::_('JCATEGORIES'));

		return $deletedAssignedToMany + $deletedAssignedToOne;
	}

	private function deleteStudentRecordsAssignedToOneCategory($tagType, $categoryId, $tillDate)
	{
		$recordsQueryAssignedToOneCat = $this->getStudentRecordsQueryByCategoryAssingedToOneOrManyCats($tagType, $categoryId,  $tillDate, true);
		if (!$recordsQueryAssignedToOneCat)
			return 0;
		$studentRecordIDs = ArrayHelper::getColumn($recordsQueryAssignedToOneCat, 'studentrecord_id');
		/** @var DiLerTableStudentrecord $studentRecordsTable */
		$studentRecordsTable = Table::getInstance('Studentrecord', 'DiLerTable');
		$studentRecordsTable->deleteRowsByPrimaryKey($studentRecordIDs);

		return count($studentRecordIDs);
	}

	private function deleteStudentRecordsAssignedToMultipleCategories($tagType, $categoryId, $tillDate)
	{
		$recordsQueryAssignedToOtherCats = $this->getStudentRecordsQueryByCategoryAssingedToOneOrManyCats($tagType, $categoryId,  $tillDate);
		if (!$recordsQueryAssignedToOtherCats)
			return 0;
		$forDelete = array_map(function ($row) {
			return "($row->studentrecord_id, $row->tag_id, $row->tag_type)";
		}, $recordsQueryAssignedToOtherCats);
		
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->delete('#__diler_studentrecord_tag_map');
		$query->where('(studentrecord_id, tag_id, tag_type) in (' . implode(',', $forDelete) . ')');
		$db->setQuery($query)->execute();
		
		return count($forDelete);
	}

    /**
     * @param int $tagType
     * @param int $catId
     * @param string $tillDate
     * @param bool $assignedToOnlyOneCat
     *
     * @return mixed
     * @since 6.4.1
     */
	private function getStudentRecordsQueryByCategoryAssingedToOneOrManyCats(int $tagType, int $catId, string $tillDate, bool $assignedToOnlyOneCat = false)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('tagByCat.studentrecord_id, tagByCat.tag_id, tagByCat.tag_type');
		$query->from('#__diler_studentrecord_tag_map AS tagByCat');
		$query->innerJoin('#__diler_studentrecord_tag_map AS tagByStudentRecordID ON tagByStudentRecordID.studentrecord_id = tagByCat.studentrecord_id');
		$query->innerJoin('#__diler_studentrecord AS studentRecords ON tagByCat.studentrecord_id = studentRecords.id');
		$query->where('tagByCat.tag_id =' . $catId);
		$query->where('tagByCat.tag_type =' . $tagType);
		$query->where('DATE(studentRecords.created) <= ' . $db->quote($tillDate));
		$query->group('tagByCat.studentrecord_id');
		
		$compareSymbol = $assignedToOnlyOneCat ? " = " : " > ";
		$query->having("COUNT(tagByCat.studentrecord_id) $compareSymbol 1");
		
		return $db->setQuery($query)->loadObjectList();
	}

	public function deleteStudentRecordsByLearningGroups(string $deleteKey, string $tillDate)
	{
		$db = $this->getDbo();
		$db->getQuery(true);
		$deleteKeys = explode('__', $deleteKey);
		$groupId    = $deleteKeys[0];
		$table      = $deleteKeys[1];

		if (!in_array($table, $this->studentRecordsTables))
			throw new Exception("Invalid table name '$table' while trying to delete student records by learning groups");

		$joinChildTable = "";
		$deleteTable    = "DELETE studentRecords";
		if ($table != 'diler_studentrecord')
		{
			$joinChildTable = "LEFT JOIN " . $db->quoteName("#__$table") . " AS $table ON $table.studentrecord_id = studentRecords.id ";
			$deleteTable    = "DELETE $table";
		}

		$sql = "$deleteTable " .
			"FROM #__usergroups AS ug " .
			"INNER JOIN #__user_usergroup_map AS ugm ON ug.id = ugm.group_id " .
			"INNER JOIN #__users AS u ON u.id = ugm.user_id " .
			"INNER JOIN #__diler_studentrecord AS studentRecords ON u.id = studentRecords.student_id " .
			"$joinChildTable " .
			"WHERE ug.id = $groupId " .
			"AND DATE(studentRecords.created) <= " . $db->quote($tillDate);

		$db->setQuery($sql)->execute();

		$this->enqueueSuccessMessage(DText::_('STUDENT_RECORDS'), Text::_('COM_DILERREG_LG_PLURAL'));
		return ($table != 'diler_studentrecord') ? 0 : $db->getAffectedRows();
	}

	public function deleteStudentRecordsByStudents(string $deleteKey, string $tillDate)
	{
		$db = $this->getDbo();
		$db->getQuery(true);
		$deleteKeys = explode('__', $deleteKey);
		$studentId  = $deleteKeys[0];
		$table      = $deleteKeys[1];

		if (!in_array($table, $this->studentRecordsTables))
			throw new Exception("Invalid table name '$table' while trying to delete student records by learning groups");

		$joinChildTable = "";
		$deleteTable    = "DELETE studentRecords";
		if ($table != 'diler_studentrecord')
		{
			$joinChildTable = "LEFT JOIN " . $db->quoteName("#__$table") . " AS $table ON $table.studentrecord_id = studentRecords.id ";
			$deleteTable    = "DELETE $table";
		}

		$sql = "$deleteTable " .
			"FROM #__diler_studentrecord AS studentRecords " .
			"$joinChildTable " .
			"WHERE student_id = $studentId " .
			"AND DATE(studentRecords.created) <= " . $db->quote($tillDate);
		$db->setQuery($sql)->execute();

		$this->enqueueSuccessMessage(DText::_('STUDENT_RECORDS'), DText::placehoder('Students'));
		return ($table != 'diler_studentrecord') ? 0 : $db->getAffectedRows();
	}

	public function deleteMarksHistoryByLearningGroups(int $groupId, string $tillDate)
	{
		/** @var DiLerTableMarkshistory $marksHistoryTable */
		$marksHistoryTable = $this->getTable('Markshistory');
		$affectedRows = $marksHistoryTable->clearMarkHistoryByLearningGroup($groupId, $tillDate);
		$this->enqueueSuccessMessage(DText::_('MARKS'), Text::_('COM_DILERREG_LG_PLURAL'));
		return $affectedRows;
	}

	public function deleteMarksHistoryByStudents(int $studentId, string $tillDate)
	{
		/** @var DiLerTableMarkshistory $marksHistoryTable */
		$marksHistoryTable = $this->getTable('Markshistory');
		$affectedRows = $marksHistoryTable->clearMarkHistoryByStudent($studentId, $tillDate);
		$this->enqueueSuccessMessage(DText::_('MARKS'), DText::placehoder('Students'));
		return $affectedRows;
	}

    /**
     * @param array $types
     * @param string $tillDate
     *
     * @return bool
     * @throws Exception
     */
	public function deleteTexterData(array $types, string $tillDate)
	{
		/** @var DiLerTableTexter $texterTable */
		$texterTable = $this->getTable('Texter');
		foreach ($types as $type)
		{
			if ($type == $texterTable::TYPE_CLOUD_MESSAGE)
				$texterTable->deleteCloudMessages($tillDate);
			
			if ($type == $texterTable::TYPE_MANUAL_MESSAGE)
				$texterTable->deleteManualMessages($tillDate);
			
			if ($type == $this->texterSystemMessageType)
				$texterTable->deleteSystemMessages($tillDate);
		}
		
		return true;
	}
	
	private function isPathInCloudDb($path)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id');
		$query->from('#__diler_cloud');
		$query->where('path = ' . $db->quote($path));
		$query->setLimit(1);

		return $db->setQuery($query)->loadColumn();
	}

	private function getAllCloudDbRecords() 
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('id, path');
		$query->from('#__diler_cloud');
		
		return $db->setQuery($query)->loadAssocList();
	}
	
	private function getAllCloudFilesOnHdd()
	{
		// Thanks to https://stackoverflow.com/a/24784020
		$rootMediaFolder = DilerHelperUser::getRootFileFolder();
		$rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($rootMediaFolder));

		$files = array();
		foreach ($rii as $file) {
			/** @var SplFileInfo $file */
			if (!$file->isDir() && strpos($file->getPathName(), $rootMediaFolder . "cloud-") !== false)
				$files[] = str_replace($rootMediaFolder, "", $file->getPathname());

		}
		return $files;
	}

	/**
	 * @param $query JDatabaseQuery
	 */
	private function prepareSelectStudentsQuery($query, $table, $tableAlias)
	{
		$query->select('CONCAT(users.surname, " ", users.forename) as title');
		$query->select("users.user_id AS id");
		$query->select("COUNT($tableAlias.student_id) AS total");
		$query->from($table . " AS " . $tableAlias);
		$query->innerJoin("#__dilerreg_users AS users ON users.user_id = $tableAlias.student_id");
		$query->group('users.user_id');
		$query->order('users.surname');

		return $query;
	}

	/**
	 * @param $query JDatabaseQuery
	 */
	private function prepareSelectLearingGroupsQuery($query, $associatedTable, $tableAlias)
	{
		// @TODO find a way to trim all usergroup titles with mysql so we don't have to TRIM it inside select query 
		$query->select('ug.id AS id, TRIM(diler_group.name) AS title');
		$query = LearningGroups::init()->getInnerJoinUsers($query);
		$query->innerJoin("$associatedTable AS $tableAlias ON u.id = $tableAlias.student_id");

		$query->order('title');
		$query->group('title, id');

		return $query;
	}

	private function prepareLoadedData(array $dbLoadedData, array $appendTableNamesToDeleteKeys = array())
	{
		$preparedData = array();
		foreach ($dbLoadedData as $key => $result)
		{
			$deleteKeys = array($result['id']);
			if ($appendTableNamesToDeleteKeys)
				$deleteKeys = array_map(function ($key) use ($result) {
					return $result['id'] . "__$key";
				}, $appendTableNamesToDeleteKeys);

			$preparedData[$result['id']]               = $result;
			$preparedData[$result['id']]['deleteKeys'] = $deleteKeys;
		}

		return $preparedData;
	}

	private function getStudentsPerActivitiesAndCompetenceTable($byTable, $tillDate = null)
	{
		$db         = $this->getDbo();
		$byTable    = "#__$byTable";
		$query      = $db->getQuery(true);
		$tableAlias = 'acTable';
		$query      = $this->prepareSelectStudentsQuery($query, $byTable, $tableAlias);

		if ($tillDate)
			$query->where('(' . $this->buildTillDateQueryByDateTableFields($byTable, $tillDate, $tableAlias) . ')');

		return $db->setQuery($query)->loadAssocList();
	}


    /**
     * Use this method to load all Learning Groups with records in passed table.
     *
     * @param $byTable
     * @param null $tillDate
     * @return mixed
     */
	private function getLearningGroupsPerActivitiesAndCompetenceTable($byTable, $tillDate = null)
	{
		$db         = $this->getDbo();
		$byTable    = "#__$byTable";
		$tableAlias = 'tableAlias';
		$query      = $db->getQuery(true);
		$query      = $this->prepareSelectLearingGroupsQuery($query, $byTable, $tableAlias);
		$query->select("COUNT($tableAlias.student_id) as total");

		if ($tillDate)
			$query->where('(' . $this->buildTillDateQueryByDateTableFields($byTable, $tillDate, $tableAlias) . ')');

		return $db->setQuery($query)->loadAssocList();
	}

	/**
	 * We use this method to prepare query to match any datetime table field
	 *
	 * @param string $table
	 * @param string $tillDate
	 * @param string $tableAlias
	 *
	 * @return string
	 */
	private function buildTillDateQueryByDateTableFields(string $table, string $tillDate, string $tableAlias)
	{
		$db      = $this->getDbo();
		$columns = $db->getTableColumns($table);

		$dateFields = array();
		foreach ($columns as $columnName => $type)
		{
			if ($type == 'datetime' && $columnName !== 'checked_out_time')
				$dateFields[] = "(DATE($tableAlias.$columnName) <= " . $db->quote($tillDate) . " AND $tableAlias.$columnName IS NOT NULL)";
		}

		return implode(' OR ', $dateFields);
	}

	private function enqueueSuccessMessage($section, $type)
	{
		Factory::getApplication()->enqueueMessage(
		    DText::sprintf('PURGE_SUCCESS_DELETED_SECTION_BY_TYPE', $section, $type)
		);
	}
}