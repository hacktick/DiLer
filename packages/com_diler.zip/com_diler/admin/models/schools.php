<?php

/**
 * schools list
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Users\DPermission;
use Joomla\CMS\User\User;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\Session\Session;

/**
 * schools model.
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @since		2.5
 */
class DiLerModelschools extends ListModel
{
	private User $user;
	private DPermission $dPermission;

    /**
     * Method to construct configuration
     * @param       array   Configuration array for model. Optional.
     * @return      void.
     * @throws      Exception
     * @since       2.5
     */
	public function __construct($config = array()) {
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'published', 'a.published',
				'a.level', 'level', 'start_date', 'end_date','a.school_id','a.city','a.base_school',
				'CASE WHEN ISNULL(a.contract_signed_date) THEN 0 ELSE 1 END','COUNT(DISTINCT h.user_id)'
			);

			$app = Factory::getApplication();
		}

		$this->user = Factory::getUser();
		$this->dPermission = new DPermission($this->user);
		parent::__construct($config);
	}

	/**
	 * Override parent method
	 */
	public function getItems()
	{
		$itemsRaw = parent::getItems();
		$items = $this->getTeacherCount($itemsRaw);
//		Add link for contract download
		$token = '&' . Session::getFormToken() . '=1';
		foreach ($items as $item)
		{
			$item->downloadLink = '';
			if ($item->contract_signed_date > Factory::getDbo()->getNullDate())
			{
				$item->downloadLink = 'index.php?option=com_diler&task=school.download&file=' . base64_encode($item->contract_file_name) . $token;
			}
		}
		return $items;
	}

	/**
	 * Method to build an SQL query to load the list data.
     *
	 * @return JDatabaseQuery  An SQL query
	 */
	protected function getListQuery() {
		// Create a new query object.
		$db = Factory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('a.*, GROUP_CONCAT(DISTINCT h.user_id) AS student_id_list, COUNT(DISTINCT h.user_id) AS student_count');
		$query->select('GROUP_CONCAT(CONCAT(h.base_school, ":", h.branch_teacher)) AS teacher_list');
		$query->from($db->quoteName('#__diler_school') . ' AS a');
		$query->leftJoin('#__diler_user_school_history AS h ON h.school_id = a.id');
		$query->group('a.id');

		//if get filter BY Keyword Search
		// Filter by search in value,description
		$search = $this->state->get('filter.search');

		if ($this->canRestrict())
			$query = $this->restrictByStateAndPostalCodes($query);

		$query = $this->setSearchQuery($query, $search);

		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		} elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}
		$baseSchool = $this->getState('filter.base_school', '');
		if ($baseSchool !== '')
		{
			$query->where('a.base_school = ' . (int) $baseSchool);
		}
		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn) . ',a.name ASC');
		return $query;
	}

	private function canRestrict() : bool
	{
		$isAdministrator = Factory::getApplication()->isClient('administrator');
		return !$this->dPermission->canTeacherViewAllSchools() && !$isAdministrator;
	}

	private function restrictByStateAndPostalCodes(JDatabaseQuery $query) : JDatabaseQuery
	{
		$isRestrictedByState = $this->dPermission->canTeacherViewSchoolsByState();
		$isRestrictedByPostalCodes = $this->dPermission->canTeacherViewSchoolsByPostalCodes();

		if (!$isRestrictedByState && !$isRestrictedByPostalCodes)
			return $query;

		if ($isRestrictedByState && $isRestrictedByPostalCodes)
			return $query->where(
				'((' .
					$this->getRestrictedByStateCondition() . ') or (' .
					$this->getRestrictedByPostalCodesCondition() .
				'))'
			);

		if ($isRestrictedByState)
			return $query->where($this->getRestrictedByStateCondition());

		return $query->where($this->getRestrictedByPostalCodesCondition());
	}

	private function getRestrictedByStateCondition() : string
	{
		$state = DilerHelperUser::getUserStateIso();
		$db = Factory::getDbo();

		return 'a.state_iso = ' . $db->quote($state);
	}

	private function getRestrictedByPostalCodesCondition() : string
	{
		$db = Factory::getDbo();
		$assignedPostalCodes = $db->getQuery(true)
			->select('postal_code')
			->from('#__diler_region AS r')
			->innerJoin('#__diler_region_user_map as rum ON rum.region_id = r.id')
			->where('rum.user_id = ' . $this->user->id);

		return 'a.postal_code IN (' . $assignedPostalCodes . ')';
	}

	private function setSearchQuery(JDatabaseQuery $query, $search) : JDatabaseQuery
	{
		if (empty($search))
			return $query;

		if (stripos($search, 'id:') !== false)
			return $query->where('a.id = ' . (int) substr($search, 3));

		$db = Factory::getDBO();
		$search = $db->Quote('%' . $db->escape($search, true) . '%');
		return $query->where('(a.name LIKE ' . $search . 'OR a.email LIKE ' . $search .
			'OR a.school_id LIKE ' . $search . 'OR a.city LIKE ' . $search . ')');
	}

	/**
	 * Gets count of teachers for each school
	 *
	 * @param array $items  Result of sql query
	 * @return array stdClass array with user ids by role
	 */
	public function getTeacherCount(array $items)
	{
		foreach ($items as $item)
		{
			$item->base_teacher_array = $item->branch_teacher_array = [];
			$teacherArray = $item->teacher_list ? explode(',', $item->teacher_list) : [];
			foreach ($teacherArray as $teacherString)
			{
				$workArray = explode(':', $teacherString);
				if (is_array($workArray) && count($workArray) === 2 && $workArray[1] && $workArray[0])
				{
					$item->base_teacher_array[] = $workArray[1];
				}
				elseif (is_array($workArray) && count($workArray) === 2 && $workArray[1])
				{
					$item->branch_teacher_array[] = $workArray[1];
				}
			}
			$item->base_teacher_array = array_unique($item->base_teacher_array);
			$item->branch_teacher_array = array_unique($item->branch_teacher_array);
			$item->base_principal_array = ($item->contract_signed_by) ? [$item->contract_signed_by] : [];
			$item->teacher_count = count($item->base_teacher_array) + count($item->branch_teacher_array) + count($item->base_principal_array);
		}
		return $items;
	}

	/**
	 * Method to populate publish
	 * @since 2.5
	 */
	public function populateState($ordering = null, $direction = null) {
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '');
		$this->setState('filter.search', $search);
		parent::populateState('a.name', 'asc');
	}

	public function getRegions()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*, CONCAT(postal_code, " | ", place, " | ", community, " | ", state_iso) AS select_text')
				->from('#__diler_region')
				->where('published = 1')
				->order('ordering, country_iso2, state_iso, postal_code');
		return $db->setQuery($query)->loadObjectList();
	}

	protected function getStoreId($id = '') {
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}
}
