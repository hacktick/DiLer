<?php
/**
 * Subject default model, update, load form, load script
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

// import Joomla modelform library
jimport('joomla.application.component.modeladmin');

/**
 * Subject model.
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource
 * @since		2.5
 */
class DiLerModelSubject extends AdminModel
{

	/**
	* Method override to check if you can edit an existing record.
	*
	* @param       array   $data   An array of input data.
	* @param       string  $key    The name of the key for the primary key.
	*         * @return      boolean
	* @since       2.5
	*/
	protected function allowEdit($data = array(), $key = 'id')
	{
	// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.subject.'.((int) isset($data[$key]) ? $data[$key] : 0))	or parent::allowEdit($data, $key);
	}

	public function getTable($type = 'Subject', $prefix = 'DiLerTable', $config = array())
	{
			return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Checks subject for any mapped subject groups.
	 * Don't allow trash or delete if found.
	 *
	 * @param array $pks array of subject ids
	 *
	 * @throws Exception
	 *
	 * @return array array of allowed subject ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('m.subject_id')
			->from('#__diler_group_subject_section_map AS m')
			->where('m.subject_id IN(' . implode(',', $pks) . ')')
			->group('m.subject_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('SUBJECT'), DText::_('SUBJECT'));
			}
			else
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS', count($badPks), DText::_('SUBJECTS'), DText::_('SUBJECT'));
			}
			// We need to give a message and also remove these from the $pks array
			Factory::getApplication()->enqueueMessage($msg, 'warning');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}
		return $pks;
	}

	private function deleteMappedRecords($tableNames, $pks) : void
	{
		$db = Factory::getDbo();
		foreach ($tableNames as $tableName)
		{
			$query = $db->getQuery(true)
				->delete($tableName)
				->where('subject_id IN (' . implode(',', $pks) . ')');
			$db->setQuery($query)->execute();
		}
	}

    /**
     * Override parent delete method
     *
     * @param   array  &$pks An array of record primary keys.
     *
     * @return  boolean  True if successful, false if an error occurs.
     *
     * @throws  Exception
     * @since   12.2
     */
	public function delete(&$pks)
	{
		try
		{
			$db = Factory::getDbo();
			$db->transactionStart();
			// Can't delete if this subject has mapped subject group rows
			$pks = $this->checkChangeStatus($pks);
			// Delete any rows from mapping tables
			$pks = ArrayHelper::toInteger($pks);
			$relatedTables = array(
				'#__diler_subject_competence_map',
				'#__diler_user_phase_map',
				'#__diler_student_subject_phase_status',
				'#__diler_marks_history',
				'#__diler_report_field_subject_map'
			);
			$this->deleteMappedRecords($relatedTables, $pks);
		}

		catch (Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage(), 'error');
			$db->transactionRollback();
			return false;
		}

		$result = parent::delete($pks);
		if ($result)
		{
			$db->transactionCommit();
		}
		else
		{
			$db->transactionRollback();
		}
		return $result;

	}

	/**
	 * Method to get the record form.
	 *
	 * @param       array   $data           Data for the form.
	 * @param       boolean $loadData       True if the form is to load its own data (default case), false if not.
	 * @return      bool   A Form object on success, false on failure
	 * @since       2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.subject', 'subject', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;

	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return      mixed   The data for the form.
     * @throws      Exception
     * @since       2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.subject.data', array());

		if (empty($data))
		{
				$data = $this->getItem();

		}

		return $data;
	}

	/**
	 * Override parent function. Trim and remove extra spaces from subject name.
	 *
	 * @param   Table  $table  A reference to a Table object.
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function prepareTable($table)
	{
		$table->name = trim(preg_replace('/(\s{2,})/', ' ', $table->name));
	}

    /**
     * Overload of parent publish method.
     * Don't allow trashing if this subject has mapped subject groups
     *
     * @param array &$pks A list of the primary keys to change.
     * @param integer $value The value of the published state.
     *
     * @return boolean True on success.
     *
     * @throws Exception
     * @since 12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		return parent::publish($pks, $value);
	}

}