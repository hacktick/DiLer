<?php
/**
 * Section data edit, update
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

/**
 * Section model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelSection extends AdminModel
{

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 *        * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.message.' . ((int) isset($data[$key]) ? $data[$key] : 0)) or parent::allowEdit($data, $key);
	}

		/**
	 * Checks schoolyears for any mapped subject groups.
	 * Don't allow trash or delete if found.
	 *
	 * @param array $pks array of schoolyear ids
	 *
	 * @throws Exception
	 *
	 * @return array array of allowed compchar ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no answers for these tasks
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('m.section_id')
			->from('#__diler_group_subject_section_map AS m')
			->where('m.section_id IN(' . implode(',', $pks) . ')')
			->group('m.section_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('SECTION'), DText::_('SUBJECT'));
			}
			else
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS', count($badPks), DText::_('SECTIONS'), DText::_('SUBJECT'));
			}

            Factory::getApplication()->enqueueMessage($msg,'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}
		return $pks;
	}

    /**
     * Override parent delete method
     *
     * @param array &$pks An array of record primary keys.
     *
     * @return boolean True if successful, false if an error occurs.
     *
     * @throws Exception
     * @since 12.2
     */
	public function delete(&$pks)
	{
		// Don't delete if mapped
		try
		{
			$pks = $this->checkChangeStatus($pks);
		}
		catch (Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage());
			return false;
		}
		return parent::delete($pks);
	}

	public function getTable($type = 'Section', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.section', 'section',

		array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Method to get the script that has to be included on the form-page
	 *
	 * @return string Script files
	 */
	public function getScript()
	{
		return 'administrator/components/com_diler/models/forms/section.js';
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.section.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

    /**
     * Overload of parent publish method. Don't allow trashing if this has mapped subject groups
     *
     * @param array &$pks A list of the primary keys to change.
     * @param integer $value The value of the published state.
     * @return void True on success.
     * @throws Exception
     * @since 12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		$db = Factory::getDbo();
		$db->transactionStart();
		$result = parent::publish($pks, $value);

		$query = $db->getQuery(true)->select('COUNT(*)')->from('#__diler_section')->where('published = 1');
		$count = $db->setQuery($query)->loadResult();
		if (! $count)
		{
			$db->transactionRollback();
			$result = false;
			throw new Exception(DText::sprintf('SECTIONS_CANNOT_UNPUBLISH', DText::_('SECTION')));
		}
		else
		{
			$db->transactionCommit();
		}
	}
}