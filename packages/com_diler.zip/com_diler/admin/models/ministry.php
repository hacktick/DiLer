<?php
/**
 * Ministry data edit, update
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Factory;

/**
 * Ministry model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelMinistry extends AdminModel
{

	public function getTable($type = 'Ministry', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (current case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.ministry', 'ministry',
		array('control' => 'jform','load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.ministry.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

	public function getItem($pk = null)
	{
		$item = parent::getItem($pk);
		$item->diglu_trainers = $item->id ? DilerHelper::getDigluTrainersForMinistry($item->id) : array();

		return $item;
	}

	 public function save($data)
	 {
		 $save = parent::save($data);
		 if ($save && DilerHelperUser::isDiglu())
		 {
			 BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');

			 $id = $this->getState($this->getName() . '.id');

			 DilerHelper::saveMinistryDigluTrainerMapRows($id, $data['diglu_trainers']);
			 /** @var DilerModelState $stateModel */
			 $stateModel = BaseDatabaseModel::getInstance('State', 'DiLerModel');
			 $state      = $this->getStateForMinistry($data['state_iso']);

			 /** @var DiLerModelGroup $groupModel */
			 $groupModel = BaseDatabaseModel::getInstance('Group', 'DiLerModel');
			 $stateModel->refreshAssignedUsersToStateGroup($state, $groupModel);
		 }

		 return $save;
	 }

	private function getStateForMinistry($ministryStateIso)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__diler_state');
		$query->where('state_iso = ' . $db->quote($ministryStateIso));

		return $db->setQuery($query)->loadObject();

	}
}