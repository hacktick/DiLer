<?php
/**
 * Gradingmethod data edit, update
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

// import Joomla modelform library
jimport('joomla.application.component.modeladmin');

/**
 * Gradingmethod model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelGradingmethod extends AdminModel
{

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 *        * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.message.' . ((int) isset($data[$key]) ? $data[$key] : 0)) or parent::allowEdit($data, $key);
	}

	public function getTable($type = 'Gradingmethod', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.gradingmethod', 'gradingmethod',
			array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.gradingmethod.data', array());

		if (empty($data))
		{
			$data = ArrayHelper::fromObject($this->getItem());
		}
		$this->preprocessData('com_diler.gradingmethod', $data);
		return $data;
	}

	protected function preprocessData($context, &$data, $group = 'content')
	{
		// Convert '.' to local decimal value (if different)
		$data = $this->localiseDecimal($data, 'toLocal');
		parent::preprocessData($context, $data, $group);
	}

	public function save($data)
	{
		// Convert language decimal separator to '.' for saving in the db.
		$data = $this->localiseDecimal($data, 'toDb');
		return parent::save($data);
	}

	/**
	 * Substitutes local decimal separator for '.' for user input ('.' is always stored in the db).
	 *
	 * @param   array   $data    Array of grading method data, including params, which is an array.
	 * @param   string  $action  'toLocal' used to replace '.' with local value (for example, ',').
	 *                         'toDb' used to replace local value with '.' for saving in the db.
	 *
	 * @return  array   $data array with correct decimal separators.
	 */
	protected function localiseDecimal($data, $action)
	{
		if (Text::_('DECIMALS_SEPARATOR') != '.')
		{
			$data['lowest_pass'] = $this->localiseDecimalForField($data['lowest_pass'], $action);
			foreach ($data['params'] as $key => $value)
			{
				$data['params'][$key] = $this->localiseDecimalForField($value, $action);
			}
		}
		return $data;
	}

	// Substitutes decimal separator for one value
    protected function localiseDecimalForField($value, $action)
	{
		$localDecimal = Text::_('DECIMALS_SEPARATOR');
		$result = $value;
		if ($action == 'toDb')
		{
			$result = str_replace($localDecimal, '.', $value);
		}
		elseif ($action == 'toLocal')
		{
			$result = str_replace('.', $localDecimal, $value);
		}
		return $result;
	}
}