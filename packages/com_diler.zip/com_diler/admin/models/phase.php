<?php
/**
 * Phase data edit, update
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

/**
 * Phase model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelPhase extends AdminModel
{

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 *        * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.message.' . ((int) isset($data[$key]) ? $data[$key] : 0)) or parent::allowEdit($data, $key);
	}
	
	/**
	 * Checks phase for any mapped subject groups.
	 * Don't allow trash or delete if found.
	 *
	 * @param array $pks array of phase ids
	 *
	 * @throws Exception
	 *
	 * @return array array of allowed phase ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no answers for these tasks
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('m.phase_id')
			->from('#__diler_group_subject_section_map AS m')
			->where('m.phase_id IN(' . implode(',', $pks) . ')')
			->group('m.phase_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('PHASE'), DText::_('SUBJECT'));
			}
			else
			{
				$msg = DText::sprintf('N_SCHOOLYEARS_CANNOT_CHANGE_STATUS', count($badPks), DText::_('PHASES'), DText::_('SUBJECT'));
			}
			// We need to give a message and also remove these from the $pks array
			Factory::getApplication()->enqueueMessage($msg, 'warning');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}	
		}
		return $pks;
	}

    /**
     * Override parent delete method
     *
     * @param array &$pks An array of record primary keys.
     *
     * @return boolean True if successful, false if an error occurs.
     *
     * @throws Exception
     * @since 12.2
     */
	public function delete(&$pks)
	{
		try 
		{
			$pks = $this->checkChangeStatus($pks);
		} 
		catch (Exception $ex) 
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage(), 'error');
			return false;
		}
		return parent::delete($pks);
	}

	public function getTable($type = 'Phase', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.phase', 'phase',

		array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Method to get the script that has to be included on the form-page
	 *
	 * @return string Script files
	 */
	public function getScript()
	{
		return 'administrator/components/com_diler/models/forms/phase.js';
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.phase.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

    /**
     * Overload of parent publish method.
     * Don't allow trashing if this phase has mapped subject groups
     *
     * @param array &$pks A list of the primary keys to change.
     * @param integer $value The value of the published state.
     *
     * @return boolean result of parent::publish method.
     *
     * @throws Exception
     * @since 12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		return parent::publish($pks, $value);
	}
}