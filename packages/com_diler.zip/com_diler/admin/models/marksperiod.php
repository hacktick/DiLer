<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2013 - 2015 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('_JEXEC') or die();

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

/**
 * Weblinks model.
 *
 * @package Joomla.Administrator
 * @subpackage com_diler
 * @since 1.5
 */
class DilerModelMarksperiod extends AdminModel
{

	/**
	 * The type alias for this content type.
	 *
	 * @var string
	 * @since 3.2
	 */
	public $typeAlias = 'com_diler.marksperiods';

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param object $record
	 *        	A record object.
	 *
	 * @return boolean True if allowed to delete the record. Defaults to the permission for the component.
	 *
	 * @since 1.6
	 */
	protected function canDelete($record)
	{
		if (! empty($record->id)) {
			if ($record->published != - 2) {
				return;
			}
			$db = Factory::getDbo();
			$query = $db->getQuery(true)->select('COUNT(*)')->from('#__diler_marks_period')
					->where('marks_period_calendar_id = ' . (int) $record->id);
			$count = $db->setQuery($query)->loadResult();
			if ($count) return;
			$user = Factory::getUser();
			return parent::canDelete($record);
		}
	}

	/**
	 * Checks if any periods for this calendar have existing student history. If so, trashing or deleting not allowed.
	 * Don't allow trash or delete if found.
	 *
	 * @param array $pks array of subject ids
	 *
	 * @throws Exception
	 *
	 * @return array array of allowed subject ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('mp.marks_period_calendar_id')
			->from('#__diler_marks_period AS mp')
			->innerJoin('#__diler_marks_history AS h ON h.marks_period_id = mp.id')
			->where('mp.marks_period_calendar_id IN(' . implode(',', $pks) . ')')
			->group('mp.marks_period_calendar_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('MARKS_PERIOD_CALENDAR_LABEL'), DText::_('MARKS_PERIODS'));
			}
			else
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($badPks), DText::_('MARKS_PERIOD_CALENDAR_LABEL_PLURAL'), DText::_('MARKS_PERIODS'));
			}
			// We need to give a message and also remove these from the $pks array
			Factory::getApplication()->enqueueMessage($msg, 'warning');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}
		return $pks;
	}

    /**
     * Checks marks periods to see if marks history exists. If force delete is set, history is deleted.
     * Otherwise, periods with history are not deleted and a warning is shown to the user.
     *
     * @param array $validIds Marks period ids.
     * @return array of marks period ids with history which cannot be deleted.
     * @throws Exception
     */
	protected function checkMarksHistory($validIds)
	{
		// See if there are history rows for these periods
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('marks_period_id')
				->from('#__diler_marks_history')
				->where('marks_period_id IN(' . implode(',', $validIds) . ')')
				->group('marks_period_id');
		$pksWithHistory = $db->setQuery($query)->loadColumn();
		if (is_array($pksWithHistory) && $pksWithHistory)
		{
			if (count($pksWithHistory) == 1)
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($pksWithHistory), DText::_('MARKS_PERIOD'), DText::_('MARKS_HISTORY_ENTRIES'));
			}
			else
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($pksWithHistory), DText::_('MARKS_PERIODS'), DText::_('MARKS_HISTORY_ENTRIES'));
			}
			Factory::getApplication()->enqueueMessage($msg, 'warning');
		}
		return $pksWithHistory;
	}

    /**
     * Override parent delete method
     *
     * @param array  &$pks An array of record primary keys.
     *
     * @return  boolean  True if successful, false if an error occurs.
     *
     * @throws  Exception
     * @since   12.2
     */
	public function delete(&$pks)
	{
		try
		{
			$db = Factory::getDbo();
			$db->transactionStart();
			$pks = ArrayHelper::toInteger($pks);

			// Can't delete if this calendar has marks history
			$pks = $this->checkChangeStatus($pks);

			// Get array of marks_period_ids
			$query = $db->getQuery(true)
					->select('id')
					->from('#__diler_marks_period')
					->where('marks_period_calendar_id IN(' . implode(',', $pks) . ')');
			$marksPeriodIdArray = $db->setQuery($query)->loadColumn();

			// Delete schoolyear mapping rows
			if (is_array($marksPeriodIdArray) && $marksPeriodIdArray)
			{
				$query = $db->getQuery(true)
					->delete('#__diler_schoolyear_marks_period_map')
					->where('marks_period_id IN(' . implode(',', $marksPeriodIdArray) . ')');
				$db->setQuery($query)->execute();

				// Delete marks_period_rows
				$query = $db->getQuery(true)
					->delete('#__diler_marks_period')
					->where('id IN(' . implode(',', $marksPeriodIdArray) . ')');
				$db->setQuery($query)->execute();
			}
		}

		catch (Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage(), 'error');
			$db->transactionRollback();
			return false;
		}

		$result = parent::delete($pks);
		if ($result)
		{
			$db->transactionCommit();
		}
		else
		{
			$db->transactionRollback();
		}
		return $result;

	}

	/**
	 * Deletes marks history rows for an array of marks period ids.
	 *
	 * @param array $deleteIds marks period ids
	 * @return bool true on success, false otherwise.
	 */
	protected function deleteMarksHistory($deleteIds)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->delete('#__diler_marks_history')
				->where('marks_period_id IN(' . implode(',', $deleteIds) . ')');
		return $db->setQuery($query)->execute();
	}

    /**
     * Processes any marks periods that the user is trying to delete. If force delete is set,
     * marks history rows for this period will be deleted. If not, will not allow
     * period delete if marks history exists for a period.
     *
     * @param array $deleteIds
     * @return bool true if successful, false otherwise.
     * @throws Exception
     */
	protected function deletePeriodRows($deleteIds, $data)
	{
		$result = false;
		$db = Factory::getDbo();
		$validIds = ArrayHelper::toInteger((array) $deleteIds);
		if (! $validIds) return false;
		$pksWithHistory = [];
		if ($data['delete_marks'] === '1')
		{
			$this->deleteMarksHistory($deleteIds);
		}
		else
		{
			$pksWithHistory = $this->checkMarksHistory($validIds);
		}
		$okIds = array_diff($validIds, $pksWithHistory);
		if (is_array($okIds) && $okIds)
		{
			try
			{
				$db->transactionStart();
				// Delete schoolyear map rows
				$query = $db->getQuery(true)->delete('#__diler_schoolyear_marks_period_map')
						->where('marks_period_id IN(' . implode(',', $okIds) . ')');
				$result = $db->setQuery($query)->execute();
				// Delete group marks period map
				$query = $db->getQuery(true)->delete('#__diler_group_marks_period_map')
						->where('marks_period_id IN(' . implode(',', $okIds) . ')');
				$result = $db->setQuery($query)->execute();
				// Delete period rows
				$query = $db->getQuery(true)->delete('#__diler_marks_period')
						->where('id IN(' . implode(',', $okIds) . ')');
				$result = $db->setQuery($query)->execute();
			}
			catch (Exception $ex)
			{
				$db->transactionRollback();
			}
			$db->transactionCommit();
		}
		return $result;
	}

	public function getTable($type = 'Marksperiod', $prefix = 'DilerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	protected function getCurrentMarksPeriodRowIds($calendarId)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')
				->from('#__diler_marks_period')
				->where('marks_period_calendar_id = ' . (int) $calendarId);
		return $db->setQuery($query)->loadColumn();
	}

	/**
	 * Abstract method for getting the form from the model.
	 *
	 * @param array $data
	 *        	Data for the form.
	 * @param boolean $loadData
	 *        	True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 *
	 * @since 1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.marksperiod', 'marksperiod', array(
			'control' => 'jform',
			'load_data' => $loadData
		));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Override parent method. Add code to get detail rows for the period type
	 *
	 * {@inheritDoc}
	 * @see AdminModel::getItem()
	 */
	public function getItem($pk = null)
	{
		$item = parent::getItem($pk);
		$item->periodtypedetails = array();
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')
				->from('#__diler_marks_period')
				->where('marks_period_calendar_id = ' . (int) $item->id)
				->order('ordering');
		$detailRows = $db->setQuery($query)->loadObjectList();
		$count = count($detailRows);
		for ($i = 0; $i < $count; $i++)
		{
			$item->periodtypedetails['periodtypedetails' . $i] = ['ordering' => $i, 'name' => $detailRows[$i]->name, 'id' => $detailRows[$i]->id, 'include_in_average' => $detailRows[$i]->include_in_average];
		}
		return $item;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return array The default data is an empty array.
     *
     * @throws Exception
     * @since 1.6
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.marksperiod.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		$this->preprocessData('com_diler.marksperiod', $data);

		return $data;
	}

	/**
	 * Prepare and sanitise the table data prior to saving.
	 *
	 * @param Table $table
	 *        	A reference to a Table object.
	 *
	 * @return void
	 *
	 * @since 1.6
	 */
	protected function prepareTable($table)
	{
		$date = Factory::getDate();
		$user = Factory::getUser();

		$table->name = htmlspecialchars_decode($table->name, ENT_QUOTES);
	}

    /**
     * Overload of parent publish method.
     * Don't allow trashing if this subject has mapped subject groups
     *
     * @param array &$pks A list of the primary keys to change.
     * @param integer $value The value of the published state.
     *
     * @return boolean True on success.
     *
     * @throws Exception
     * @since 12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		return parent::publish($pks, $value);
	}

    /**
     * Override parent method to save the form data. Need to save report fields to report field history table.
     *
     * @param array $data The form data.
     *
     * @return  boolean  True on success, False on error.
     *
     * @throws Exception
     * @since   12.2
     */
	public function save($data)
	{
		$result = parent::save($data);
		if ($result)
		{
			$data['id'] = isset($data['id']) && $data['id'] ? $data['id'] : (int) $this->getState($this->getName().'.id');
			$this->saveMarksPeriodRows($data);
		}
		return $result;
	}

	protected function saveMarksPeriodRows($data)
	{
		$currentIds = $this->getCurrentMarksPeriodRowIds($data['id']);
		if (isset($data['periodtypedetails']) && is_array($data['periodtypedetails']) && $data['periodtypedetails'])
		{
			$i = 0;
			$newIds = [];
			foreach ($data['periodtypedetails'] as $key => $nameArray)
			{
				if ($nameArray['id'])
				{
					$this->updatePeriodRow($nameArray, $i);
					$newIds[] = $nameArray['id'];
				}
				else
				{
					$this->insertPeriodRow($data, $nameArray, $i);
				}
				$i++;
			}
		}

		// Check for deletes of current rows
		$deleteIds = [];
		foreach ($currentIds as $currentId)
		{
			if (! in_array($currentId, $newIds)) $deleteIds[] = $currentId;
		}
		if ($deleteIds) $this->deletePeriodRows($deleteIds, $data);
		return true;
	}

	protected function updatePeriodRow($nameArray, $i)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_marks_period')
				->set('name = ' . $db->quote($nameArray['name']))
				->set('ordering = ' . (int) $i)
				->set('include_in_average = ' . (int) $nameArray['include_in_average'])
				->where('id = ' . (int) $nameArray['id']);
		return $db->setQuery($query)->execute();
	}

	protected function insertPeriodRow($data, $nameArray, $i)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->insert('#__diler_marks_period')
				->set('name = ' . $db->quote($nameArray['name']))
				->set('ordering = ' . (int) $i)
				->set('include_in_average = ' . (int) $nameArray['include_in_average'])
				->set('marks_period_calendar_id = ' . (int) $data['id']);
		return $db->setQuery($query)->execute();
	}

}
