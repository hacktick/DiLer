<?php
/**
 * @copyright Copyright (C) 2013-2020 digitale-lernumgebung.de. All rights reserved.
 * @license   GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die('Restricted access');

/**
 * @since 6.11.0
 */
class DiLerModelRegion extends AdminModel
{

	/**
	 * Checks that no schools assigned to this region.
	 * Don't allow trash or delete if found.
	 *
	 * @param array $pks array of compchar ids
	 *
	 * @throws Exception
	 *
	 * @return array array of allowed compchar ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no answers for these tasks
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('DISTINCT sch.postal_code')
			->from('#__diler_school AS sch')
			->where('sch.postal_code IN(SELECT postal_code FROM #__diler_region WHERE id IN(' . implode(',', $pks) . '))');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
			if (count($badPks) == 1)
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS_1', count($badPks), DText::_('REGION'), DText::_('SCHOOLS'));
			}
			else
			{
				$msg = DText::sprintf('N_CANNOT_CHANGE_STATUS', count($badPks), DText::_('REGIONS'), DText::_('SCHOOLS'));
			}
            Factory::getApplication()->enqueueMessage($msg,'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}
		return $pks;
	}

    /**
     * Override parent delete. Check no mapped schools. Delete region_user_map rows.
     *
     * @param array &$pks An array of record primary keys.
     *
     * @return boolean True if successful, false if an error occurs.
     *
     * @throws Exception
     * @since 6.10.1
     */
	public function delete(&$pks)
	{
		try
		{
			$pks = $this->checkChangeStatus($pks);
		}
		catch (Exception $ex)
		{
			Factory::getApplication()->enqueueMessage($ex->getMessage());
			return false;
		}

		// Delete the mapped subjects from map table
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_region_user_map')
			->where('region_id IN (' . implode(',', $pks) . ')');
		$result = $db->setQuery($query)->execute();

		if ($result)
		{
			$result = parent::delete($pks);
		}

		return $result;
	}

	/**
	 * Override parent function. Get region user map rows.
	 *
	 * @param int $pk
	 * @return bool
	 */
	public function getItem($pk = null)
	{
		$data = parent::getItem($pk);
		if ($data->id)
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true)
				->select('user_id AS region_teacher_list')
				->from('#__diler_region_user_map')
				->where('region_id = ' . (int) $data->id);
			$data->teacher_list = $db->setQuery($query)->loadColumn();
		}
		return $data;
	}

    /**
     * @param string The table type to instantiate
     * @param string A prefix for the table class name. Optional.
     * @param array Configuration array for model. Optional.
     *
     * @return Table
     * @throws Exception
     * @since 6.11.0
     */
	public function getTable($type = 'Region', $prefix = 'DiLerTable', $config = array())
	{
		return parent::getTable($type, $prefix, $config);
	}

	/**
	 * @param array   $data     Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return bool|Form A Form object on success, false on failure
	 * @since 6.11.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		$form = $this->loadForm(
			'com_diler.region',
			'region',
			array(
				'control'   => 'jform',
				'load_data' => $loadData
			)
		);

		if (empty($form))
			return false;

		return $form;
	}

	/**
	 * @since 6.11.0
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.region.data', array());

		if (empty($data))
			$data = $this->getItem();

		return $data;
	}

	// Checks that this postal code already exists in the table.
	protected function regionExists($data)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('id')
				->from('#__diler_region')
				->where('postal_code = ' . $db->quote($data['postal_code']))
				->where('country_iso2 = ' . $db->quote($data['country_iso2']))
				->where('id != ' . $data['id']);
		return (bool) $db->setQuery($query)->loadResult();
	}

    /**
     * Overload of parent publish method.
     * Don't allow trashing if this has completed activities
     *
     * @param array &$pks A list of the primary keys to change.
     * @param integer $value The value of the published state.
     *
     * @return boolean True on success.
     *
     * @throws Exception
     * @since 12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		return parent::publish($pks, $value);
	}

	// Override parent method. Save rows in region_user_map table.
	public function save($data)
	{
		if ($this->regionExists($data))
		{
			$this->setError(DText::sprintf('CLASS_SCHEDULE_ALREADY_EXISTS', DText::_('REGION')));
			return false;
		}

		$result = parent::save($data);
		if ($result)
		{
			$state = $this->getState();
			$data['id'] = ($data['id']) ? $data['id'] : $this->getState()->get('region.id');
			$result = $this->saveRegionTeachers($data);
		}
		return $result;
	}

	/**
	 * Delete and insert rows into region_user_map table.
	 * @param array $data
	 * @return bool true on success.
	 */
	protected function saveRegionTeachers($data)
	{
		$db = Factory::getDbo();
		// Delete old values
		$query = $db->getQuery(true)
			->delete('#__diler_region_user_map')
			->where('region_id = ' . (int) $data['id']);
		$result = $db->setQuery($query)->execute();

		// Add new rows if applicable
		if ($result && isset($data['teacher_list']) && is_array($data['teacher_list']) && $data['teacher_list'])
		{
			$query = $db->getQuery(true)
				->insert('#__diler_region_user_map')
				->columns([$db->quoteName('region_id'),$db->quoteName('user_id')]);

			foreach ($data['teacher_list'] as $userId)
			{
				$query->values((int) $data['id'] . ',' . (int) $userId);
			}
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}

}
