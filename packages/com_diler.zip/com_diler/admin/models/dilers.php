<?php
/**
 * DiLer default model
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

// import the Joomla modellist library
jimport('joomla.application.component.modellist');

/**
 * DiLers model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelDiLers extends ListModel
{

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return string An SQL query
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = Factory::getDBO();

		$query = $db->getQuery(true);

		// Select some fields
		$query->select('id,name,description');

		// From the di ler table
		$query->from('#__diler_subject');
		return $query;
	}

    /**
     * Gets the minimum joomla version from the package xml file.
     *
     * @return  stdClass  contains Diler version, Diler edition, minimum joomla version
     * @throws Exception
     */
	public function getPackageVersionInfo()
	{
		$xmlContent = file_get_contents(JPATH_ADMINISTRATOR . '/manifests/packages/pkg_diler.xml', true);
		$extension = new SimpleXMLElement($xmlContent);
		$dilerInstalledVersion = (string) $extension->version[0];
		$dilerInstalledEdition = (string) $extension->version[0]['data-edition'];
		$joomlaVersion = (string) $extension->dependencies->dependency[0]['version'];

		return (object) array('diler_version' => $dilerInstalledVersion,
			'diler_edition' => $dilerInstalledEdition,
			'minimum_joomla_version' => $joomlaVersion
		);
	}
}