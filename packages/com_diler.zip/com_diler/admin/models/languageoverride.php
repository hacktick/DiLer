<?php

/**
 * Subject default model, update, load form, load script
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Registry\Registry;
use Joomla\CMS\Language\Text;

// import Joomla modelform library
jimport('joomla.application.component.modeladmin');
JLoader::register('LanguagesHelper', JPATH_ADMINISTRATOR . '/components/com_languages/helpers/languages.php');
JLoader::register('DilerHelper', JPATH_ADMINISTRATOR . '/components/com_diler/helpers/diler.php');

/**
 * Subject model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelLanguageoverride extends AdminModel
{
	public $fileTypes = ['xml', 'php'];
	public $foldersAdmin = ['administrator/components/com_diler', 'administrator/components/com_dilerajax', 'administrator/components/com_dilerreg',
		'administrator/templates/isis/html'];
	public $foldersSite = ['components/com_diler', 'components/com_dilerajax', 'components/com_dilerreg', 'templates/diler3/html'];
	public $ignoreForMissingAdmin = ['COM_DILER_', 'COM_DILER_DASHBOARD]]>', 'COM_DILER_EDITION_',
		'COM_DILER_UNINSTALL_TEXT', 'COM_DILER_PREFLIGHT_', 'COM_DILER_UPDATE_TEXT', 'COM_DILER_POSTFLIGHT_', 'COM_DILER_INSTALL_TEXT',
		'COM_DILER_INSTALL_FINISHED_LINK', 'COM_DILER_FIELD_PHASE_DESC',
		'COM_DILER_MARKS_PERIODS_DETAIL', 'COM_DILER_SECTION_ALREADY_EXISTS', 'COM_DILER_LOG_DILERTAGS_ADD_NEW_TAG', 'COM_DILER_MEDIA_DUPLICATE_NAME',
		'COM_DILER_NIMBUS_TEMPLATE_DUPLICATE_NAME','COM_DILER_GRADING_METHOD_TEST_TITLE button','COM_DILER_LOG_CONFIRM_DELETE','COM_DILER_AJAX_LOADING_FORM'];
	public $ignoreForMissingSite = ['COM_DILER_DASHBOARD]]>', 'COM_DILER_','COM_DILER_DILER_MENU_ITEM_SETTINGS_LABEL','COM_DILER_DILER_VIEW_NAME_DESC',
		'COM_DILER_DILER_VIEW_NAME_LABEL','COM_DILER_FIELD_','COM_DILERREG_IMPORT_VIEW_CHECK_LOG','COM_DILERREG_IMPORT_VIEW_CHECK_LOG',
		'COM_DILERREG_IMPORT_VIEW_IMPORT_LOG','COM_DILERREG_IMPORT_VIEW_REJECTS','COM_DILER_NOT_FOUND','COM_DILERREG_IMPORT_FILE',
		'COM_DILER_GRADING_METHOD_TEST_HEADING','COM_DILER_GRADING_METHOD_TEST_PERCENT','COM_DILER_GRADING_METHOD_TEST_PASS','COM_DILER_STUDENT_SCHOOL_TYPE_',
		'COM_DILER_STUDENTREPORTS_DATA=','COM_DILER_LOG_SAVE_STUDENT_','COM_DILER_LOG_GROUP_ADD_USER_TO_','COM_DILER_STUDENT_REPORT_TYPE_',
		'COM_DILER_login_view_default_option'];
	public $ignoreForUnusedAdmin = ['COM_DILER', 'COM_DILERREG', 'COM_DILER_HELP', 'COM_DILER_STUDENTRECORD_3_DAYS_NUM', 'COM_DILER_STUDENTRECORD_10_DAYS_NUM',
		'COM_DILER_STUDENTRECORD_30_DAYS_NUM', 'COM_DILER_STUDENTRECORD_180_DAYS_NUM', 'COM_DILER_STUDENTRECORD_ALL_DAYS', 'COM_DILER_STUDENTRECORD_SCHOOLYEAR_NUM',
		'COM_DILER_CONFIGURATION'];
	public $ignoreForUnusedSite = [];
	public $lang = 'en-GB';

	// Format: ['admin' | 'site' => [{tag name} => [['file', 'line']]
	public $tagsInUse = [];

	// Format ['admin' | 'site'] => [{tag name}]
	public $tagsDefined = [];

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 *        * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler');
	}

	protected function checkFile($fileName, $type)
	{
		$lineArray = file($fileName);
		$i = 1;
		foreach ($lineArray as $line)
		{
			$this->extractTagsInUse($line, $fileName, $i, $type);
			$i++;
		}
	}

	protected function extractTagsFromLangFile($type)
	{
		$folder = ($type === 'admin') ? JPATH_ADMINISTRATOR : JPATH_SITE;
		$langFile = $folder	. '/components/com_diler/language/' . $this->lang . '/' . $this->lang . '.com_diler.ini';
		$langLines = file($langFile);
		foreach ($langLines as $line)
		{
			if (strpos($line, 'COM_DILER') !== 0) continue;
			$pos = strpos($line, "=");
			if ($pos === false) continue;
			$tag = substr($line, 0, $pos);
			$this->tagsDefined[$type][$tag] = 1;
		}
	}

	/**
	 * Adds tags found in the line to $this->tagsInUse
	 *
	 * @param string $line
	 * @param string $fileName
	 * @param int $i
	 * @param string $type
	 * @return null
	 */
	protected function extractTagsInUse($line, $fileName, $i, $type)
	{
		$stripCount = strlen(JPATH_ROOT) + 1;
		$regex = '/(COM_DILER[A-Z,_].*?)[\'|"|,|<]/';
		$regex2 = '/DText::(sprintf|_)\(\'([\w]*)/';
		$match = preg_match_all($regex, $line, $matchArray);
		$match2 = preg_match_all($regex2, $line, $matchArray2);
		if ($match && is_array($matchArray) && count($matchArray) >= 2 && is_array($matchArray[1]))
		{
			foreach ($matchArray[1] as $tag)
			{
				if (! isset($this->tagsInUse[$type][$tag])) $this->tagsInUse[$type][$tag] = [];
				$this->tagsInUse[$type][$tag][] = ['file' => substr($fileName, $stripCount), 'line' => $i];
			}
		}
		if ($match2 && is_array($matchArray2) && count($matchArray2) >=3 && is_array($matchArray2[2]))
		{
			foreach ($matchArray2[2] as $tag2)
			{
				$tag = 'COM_DILER_' . $tag2;
				if (! isset($this->tagsInUse[$type][$tag])) $this->tagsInUse[$type][$tag] = [];
				$this->tagsInUse[$type][$tag][] = ['file' => substr($fileName, $stripCount), 'line' => $i];
			}
		}
	}

	public function checkTags($options)
	{
		$this->adminFiles = $this->getFiles('admin');
		$this->siteFiles = $this->getFiles('site');
		$this->extractTagsFromLangFile('admin');
		$this->extractTagsFromLangFile('site');
		$this->tagExtract('admin');
		$this->tagExtract('site');
		$this->logUnusedTags('admin');
		$this->logUnusedTags('site');
		$this->logMissingTags('admin');
		$this->logMissingTags('site');
		$msg = 'Language tags were checked and results were logged in the following files: language-check-missing-admin.php, language-check-missing-site.php, language-check-unused-admin.php, language-check-unused-site.php';
		$result = ['status' => 1, 'message' => $msg, 'html' => '', 'heading' => Text::_('SUCCESS')];
		$result['html'] = LayoutHelper::render('simple_system_message', $result, JPATH_ROOT . '/components/com_diler/layouts');
		return (object) $result;
	}

    /**
     * Method to get language override values for this language
     *
     * @param int $pk Id of language
     * @return  object
     * @throws Exception
     */
	public function getItem($pk = null)
	{
		if ($pk == null)
		{
			$pk = Factory::getApplication()->input->getUint('id');
		}
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from('#__languages')
			->where('lang_id = ' . (int) $pk);
		$language = $db->setQuery($query)->loadObject();

		if (!$language)
		{
			throw new Exception(DText::_('LANGUAGEOVERRIDE_NO_LANGUAGE'));
		}

		$standardFilename = JPATH_ROOT . '/components/com_diler/language/' . $language->lang_code . '/' . $language->lang_code . '.com_diler.ini';
		if (!File::exists($standardFilename))
		{
			throw new Exception(DText::_('LANGUAGEOVERRIDE_NO_DILER_FILE'));
		}
		$standardTags = LanguagesHelper::parseFile($standardFilename);

		$this->mergeDistributionFile($language);

		// Get the override file
		$fileName = JPATH_ROOT . '/language/overrides/' . $language->lang_code . '.override.ini';
		if (!File::exists($fileName))
		{
			throw new Exception(DText::_('LANGUAGEOVERRIDE_NOT_FOUND'));
		}

		// Get the com_diler override language tags
		$allOverrides = LanguagesHelper::parseFile($fileName);
		$dilerOverrides = array();
		foreach($allOverrides as $key => $value)
		{
			if (strpos($key, 'COM_DILER') === 0)
			{
				if (isset($standardTags[$key]))
				{
					$dilerOverrides[$key] = new stdClass();
					$dilerOverrides[$key]->defaultValue = $standardTags[$key];
					$dilerOverrides[$key]->overrideValue = $value;
				}
			}
		}

		return (object) array('language' => $language, 'overrides' => $dilerOverrides);
	}

	protected function getFiles($type)
	{
		$folders = ($type === 'admin') ? $this->foldersAdmin : $this->foldersSite;
		$tempFiles = $result = [];
		foreach ($folders as $folder)
		{
			foreach ($this->fileTypes as $fileType)
			{
				$tempFiles = Folder::files(JPATH_ROOT . '/' . $folder, '.' . $fileType, true, true);
				$result = array_merge($result, $tempFiles);
			}
		}
		return $result;
	}

	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.languageoverride', 'languageoverride', array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

    /**
     * Saves site and admin language override file
     *
     * @param int $id id of language
     * @param array $data array of fields
     *
     * @return boolean  true on success
     * @throws Exception
     */
	public function saveLanguageOverride($id, $data)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from('#__languages')
			->where('lang_id = ' . (int) $id);
		$language = $db->setQuery($query)->loadObject();

		if (!$language)
		{
			throw new Exception(DText::_('LANGUAGEOVERRIDE_NO_LANGUAGE'));
		}

		// Get the override file
		$fileName = JPATH_ROOT . '/language/overrides/' . $language->lang_code . '.override.ini';
		if (!File::exists($fileName))
		{
			throw new Exception(DText::_('LANGUAGEOVERRIDE_NOT_FOUND'));
		}

		$allOverrides = LanguagesHelper::parseFile($fileName);

		// Replace with updated values
		foreach ($data as $key => $string)
		{
			$data[$key] = str_replace('"', '"_QQ_"', $string);
			$allOverrides[$key] = $data[$key];
		}

		// Write override.ini file with the strings
		$registry = new Registry;
		$registry->loadObject($allOverrides);
		$reg = $registry->toString('INI');

		if (!File::write($fileName, $reg))
		{
			throw new Exception(DText::_('LANGUAGEOVERRIDE_WRITE_ERROR'));
		}

		// Save admin override file
		$adminOverrideName = JPATH_ROOT . '/administrator/language/overrides/' . $language->lang_code . '.override.ini';
		if (! File::exists($adminOverrideName))
		{
			if (!File::copy($fileName, $adminOverrideName))
			{
				throw new Exception(DText::_('LANGUAGEOVERRIDE_WRITE_ERROR'));
			}
		}
		else
		{
			// We need to merge the values of the site override file with the admin override file
			$adminOverrideArray = LanguagesHelper::parseFile($adminOverrideName);
			$adminOverrideArray = array_merge($adminOverrideArray, $data);

			// Write override.ini file with the strings
			$registry = new Registry;
			$registry->loadObject($adminOverrideArray);
			$reg = $registry->toString('INI');
			if (!File::write($adminOverrideName, $reg))
			{
				throw new Exception(DText::_('LANGUAGEOVERRIDE_WRITE_ERROR'));
			}
		}
		// Trigger after content save
		$table = (object) array('name' => $language->title);
		// Include the plugins for the save events.
		PluginHelper::importPlugin($this->events_map['save']);
		Factory::getApplication()->triggerEvent('onContentAfterSave', array('com_diler.languageoverrides', $table, false));
		return true;
	}

	protected function getLogFileName($type, $check)
	{
		return 'language-check-' . $check . '-' . $type . '.txt';
	}

	protected function logMissingTags($type)
	{
		$ignore = ($type === 'admin') ? $this->ignoreForMissingAdmin : $this->ignoreForMissingSite;
		$logHandle = $this->logPrepare(['type' => $type, 'check' => 'missing']);
		$logFile = $this->getLogFileName($type, 'missing');
		$message = 'Missing tags in ' . $type;
		$this->writeLog($logHandle, $message);
		foreach ($this->tagsInUse[$type] as $tagInUse => $fileInfoArray)
		{
			if (! isset($this->tagsDefined[$type][$tagInUse]) && ! in_array($tagInUse, $ignore))
			{
				foreach ($fileInfoArray as $fileInfo)
				{
					// Exclude language override strings
					if (strpos($fileInfo['file'], 'languageoverride') == false)
					{
						$message = 'Undefined Tag: ' . $tagInUse . ' in File: ' . $fileInfo['file'] . ' line ' . $fileInfo['line'];
						$this->writeLog($logHandle, $message);
					}
				}
			}
		}
		fclose($logHandle);
	}

	protected function logPrepare($options)
	{
		$userId = Factory::getUser()->id;
		$logFile = $this->getLogFileName($options['type'], $options['check']);
		$logPath = Factory::getConfig()->get('log_path');
		$fileName = $logPath . '/' . $logFile;
		$logHandle = fopen($fileName, "w");
		$msg = 'Log file ' . $logFile . ' created ' . Factory::getDate()->format('Y-m-d h:i:s', false);
		$this->writeLog($logHandle, $msg);
		$this->writeLog($logHandle, ' ');
		return $logHandle;
	}

	protected function logUnusedTags($type)
	{
		$ignore = ($type === 'admin') ? $this->ignoreForUnusedAdmin : $this->ignoreForUnusedSite;
		$logHandle = $this->logPrepare(['type' => $type, 'check' => 'unused']);
		$message = 'Unused tags in ' . $type;
		$this->writeLog($logHandle, $message);
		foreach ($this->tagsDefined[$type] as $tag => $value)
		{
			if (! isset($this->tagsInUse[$type][$tag]) && ! in_array($tag, $ignore))
			{
				$this->writeLog($logHandle, $tag);
			}
		}
		fclose($logHandle);
	}

	/**
	 * Merges .dist file with existing override file for this language.
	 * Creates the override file if it doesn't exist.
	 *
	 * @param  object  $language  Row object for the current language.
	 *
	 */
	protected function mergeDistributionFile($language)
	{
		// Create override file if it doesn't exist.
		$overrideFileName = JPATH_ROOT . '/language/overrides/' . $language->lang_code . '.override.ini';
		$distroFileName = JPATH_ROOT . '/components/com_diler/language/' . $language->lang_code . '/' . $language->lang_code . '.override.dist.ini';
		$distroFileExists = File::exists($distroFileName);
		if ($distroFileExists && ! File::exists($overrideFileName))
		{
			File::copy($distroFileName, $overrideFileName);
		}
		elseif ($distroFileExists)
		{
			// We need to merge contents of the two files, giving priority to the override file
			$distroArray = LanguagesHelper::parseFile($distroFileName);
			$overrideArray = LanguagesHelper::parseFile($overrideFileName);
			$overrideArray = array_merge($distroArray, $overrideArray);

			// Write override.ini file with the strings
			$registry = new Registry;
			$registry->loadObject($overrideArray);
			$reg = $registry->toString('INI');
			File::write($overrideFileName, $reg);
		}

	}

	protected function tagExtract($type)
	{
		$fileList = ($type === 'admin') ? $this->adminFiles : $this->siteFiles;
		$tempArray = [];
		foreach ($fileList as $fileName)
		{
			$this->checkFile($fileName, $type);
		}
	}

	protected function writeLog($handle, $message)
	{
		fwrite($handle, $message . "\n");
	}

}