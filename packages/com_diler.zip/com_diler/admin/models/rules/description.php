<?php
/**
 * Description field rules
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @copyright	Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Form\FormRule;

// import Joomla formrule library

 
/**
 * Form Rule class for the Joomla Framework.
 *
 * @package		DiLer.Administrator
 * @subpackage	com_diler
 * @filesource 
 * @since		2.5
 */
 class JFormRuleDescription extends FormRule
{
        /**
         * The regular expression.
         *
         * @access      protected
         * @var         string
         * @since       2.5
         */
        protected $regex = '^[^0-9]+$';
}