<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_diler
 *
 * @copyright   Copyright (C) 2013 - 2015 digitale-lernumgebung.de, Inc. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('_JEXEC') or die();

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Table\Table;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Filesystem\Path;

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

/**
 * Weblinks model.
 *
 * @package Joomla.Administrator
 * @subpackage com_diler
 * @since 1.5
 */
class DilerModelReporttype extends AdminModel
{

	/**
	 * The type alias for this content type.
	 *
	 * @var string
	 * @since 3.2
	 */
	public $typeAlias = 'com_diler.reporttypes';

	public $reportTypes = [];

	// Makes a backup copy of existing report type definition (by renaming layout_file_name, and unpublishing, and changing name and description).
	protected function backupReportType($importObject)
	{
		$pathParts = pathinfo($importObject->layoutFile);
		$layoutFileName = $pathParts['filename'];
		$newLayoutName = $layoutFileName . '_' . DText::_('BACKUP');
		// Make new name unique
		$checkName = $newLayoutName;
		$i = 1;
		while (isset($this->reportTypes[$checkName]) && $i < 99)
		{
			$checkName = $newLayoutName . '_' . $i;
			$i++;
		}
		$newLayoutName = $checkName;
		$newReportName = $this->reportTypes[$layoutFileName]['name'] . ' ' . DText::_('BACKUP');
		// Backup existing to new name.
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_report_type')
				->set('layout_file_name = ' . $db->quote($newLayoutName))
				->set('name = ' . $db->quote($newReportName))
				->set('published = 0')
				->where('id = ' . (int) $this->reportTypes[$layoutFileName]['id']);
		$update = $db->setQuery($query)->execute();
		if ($update)
		{
			$newPath = JPATH_ROOT . '/' . $pathParts['dirname'] . '/' . $newLayoutName . '.php';
			$rename = rename(JPATH_ROOT . '/' . $importObject->layoutFile, $newPath);
		}
		$result = ($update && $newPath) ? $newLayoutName : '';
		return $result;
	}

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param object $record
	 *        	A record object.
	 *
	 * @return boolean True if allowed to delete the record. Defaults to the permission for the component.
	 *
	 * @since 1.6
	 */
	protected function canDelete($record)
	{
		if (! empty($record->id)) {
			if ($record->published != - 2) {
				return;
			}
			$user = Factory::getUser();
			return parent::canDelete($record);
		}
	}

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param object $record
	 *        	A record object.
	 *
	 * @return boolean True if allowed to change the state of the record. Defaults to the permission for the component.
	 *
	 * @since 1.6
	 */
	protected function canEditState($record)
	{
		$user = Factory::getUser();

		if (! empty($record->catid)) {
			return $user->authorise('core.edit.state', 'com_diler.category.' . (int) $record->catid);
		} else {
			return parent::canEditState($record);
		}
	}

	/**
	 * Copies an existing report type to a new report type.
	 *
	 * @param int     $fromId   Id of existing report type
	 * @param string  $newName  Name for new report type.
	 */
	public function copy($fromId, $newName)
	{
		// Get information from existing type
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from('#__diler_report_type')
			->where('id = ' . $fromId);
		$oldType = $db->setQuery($query)->loadObject();

		$templateName = $this->getDefaultTemplate();
		$folder = $oldType->report_or_contract ? 'contract_layouts' : 'report_layouts';

		$path = JPATH_ROOT . '/templates/' . $templateName . '/html/com_diler/' . $folder . '/';
		if ((! $templateName) || ! file_exists($path))
		{
			throw new RuntimeException(DText::_('REPORT_TYPE_COPY_LAYOUT_NOT_FOUND'));
		}

		// Check that the old layout exists and the new one does not. Add digit on to new one if already exists.
		if (!file_exists($path . $oldType->layout_file_name . '.php'))
		{
			throw new RuntimeException(DText::_('REPORT_TYPE_COPY_LAYOUT_NOT_FOUND'));
		}

		// Make $newName if blank or invalid
		$newLayoutName = File::makeSafe($newName);
		$newLayoutName = strtolower(str_ireplace(' ', '-', $newLayoutName));
		if (file_exists($path . $newLayoutName . '.php'))
		{
			// Try adding digits to the end of the file name
			$success = false;
			for ($i = 1; $i < 10; $i++)
			{
				$testName = $newLayoutName . '-' . $i;
				if (! file_exists($path . $testName . '.php'))
				{
					$newLayoutName = $testName;
					$success = true;
					break;
				}
			}
			if (! $success)
			{
				throw new RuntimeException(DText::_('REPORT_TYPE_COPY_LAYOUT_EXISTS'));
			}
		}

		// Create new layout file name
		File::copy($path . $oldType->layout_file_name . '.php', $path . $newLayoutName . '.php');

		// Create new row in #__report_type table.
		$query->clear()
			->insert('#__diler_report_type')
			->set('name = ' . $db->quote($newName))
			->set('published = 1')
			->set('description = ' . $db->quote(DText::sprintf('REPORT_TYPE_COPY_DEFAULT_DESCRIPTION', $oldType->name)))
			->set('layout_file_name = ' . $db->quote($newLayoutName));
		$db->setQuery($query)->execute();

	}

	/**
	 * Creates the return success message for the import.
	 *
	 * @param stdClass  $resultObject  Contains the counts of rows updated and files moved
	 *
	 * @return string   Text of return message.
	 */
	protected function createMessage($resultObject)
	{
		$message = array();
		$message[] = DText::_('REPORT_TYPE_IMPORT_SUCCESS');
		$typeRows = $resultObject->inserts['#__diler_report_type']['afterCount'] - $resultObject->inserts['#__diler_report_type']['beforeCount'];
		if ($resultObject->reportExists)
		{
			$message[] = DText::sprintf('REPORT_TYPE_EXPORT_TYPE_ROW_REPLACED', $resultObject->reportExists, $resultObject->backupName);
		}

		$rowsNotInserted = $resultObject->inserts['#__diler_report_field_definition']['totalRows'] - ($resultObject->inserts['#__diler_report_field_definition']['afterCount'] - $resultObject->inserts['#__diler_report_field_definition']['beforeCount']);
		if ($rowsNotInserted)
		{
			$message[] = DText::plural('REPORT_TYPE_EXPORT_FIELD_ROW_NOT_INSERTED', $rowsNotInserted);
		}

		if (isset($resultObject->moves['exists']) && $resultObject->moves['exists'])
		{
			$message[] = DText::plural('REPORT_TYPE_EXPORT_FILE_NOT_IMPORTED', $resultObject->moves['exists']);
		}

		return implode(' ', $message);
	}

	/**
	 * Override parent delete method to also delete report layout file.
	 *
	 * @param   array  &$pks  An array of record primary keys.
	 *
	 * @return  boolean  True if successful, false if an error occurs.
	 *
	 * @since   12.2
	 */
	public function delete(&$pks)
	{
		$pks = (array) $pks;
		$table = $this->getTable();

		// Include the content plugins for the on delete events.
		PluginHelper::importPlugin('content');

		// Iterate the items to delete each one.
		foreach ($pks as $i => $pk)
		{

			if ($table->load($pk))
			{

				if ($this->canDelete($table))
				{

					$context = $this->option . '.' . $this->name;

					// Trigger the onContentBeforeDelete event.
					$result = Factory::getApplication()->triggerEvent($this->event_before_delete, array($context, $table));

					if (in_array(false, $result, true))
					{
						$this->setError($table->getError());
						return false;
					}

					if (!$table->delete($pk))
					{
						$this->setError($table->getError());
						return false;
					}

					// Delete the report layout
					$this->deleteLayoutFile($table);

					// Trigger the onContentAfterDelete event.
                    Factory::getApplication()->triggerEvent($this->event_after_delete, array($context, $table));

				}
				else
				{

					// Prune items that you can't change.
					unset($pks[$i]);
					$error = $this->getError();
					if ($error)
					{
						Log::add($error, Log::WARNING, 'jerror');
						return false;
					}
					else
					{
						Log::add(Text::_('JLIB_APPLICATION_ERROR_DELETE_NOT_PERMITTED'), Log::WARNING, 'jerror');
						return false;
					}
				}

			}
			else
			{
				$this->setError($table->getError());
				return false;
			}
		}

		// Clear the component's cache
		$this->cleanCache();

		return true;
	}

	// Deletes the layout file for a report type
	protected function deleteLayoutFile($table)
	{
		// We don't know the template name, so we have to search the templates folder to find the layout.
		$files = Folder::files(JPATH_ROOT . '/templates', $table->layout_file_name . '.php', 5, true);
		if (! is_array($files) || count($files) == 0)
		{
			return;
		}
		File::delete($files[0]);
	}

	/**
	 * Exports a report type to a tmp folder for future import into another DiLer site.
	 *
	 * @param int $reportId  Id of report type to export.
	 * @throws RuntimeException
	 */
	public function export($reportId)
	{
		// Get name of report layout file
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from('#__diler_report_type')
			->where('id = ' . (int) $reportId);
		$reportType = $db->setQuery($query)->loadObject();
		unset($reportType->id);

		$files = Folder::files(JPATH_ROOT . '/templates', $reportType->layout_file_name . '.php', 5, true);
		if (! is_array($files) || count($files) == 0)
		{
			$templates = JPATH_ROOT . '/templates';
			throw new RuntimeException(DText::sprintf('STUDENT_REPORT_EXPORT_LAYOUT_NOT_FOUND', $reportType->layout_file_name . '.php', $templates), 10001);
		}

		$layoutFile = file_get_contents($files[0]);
        $regex = "#JHtml::_\('diler\.studentReport's*,.*?,.*?,(.*?),#";
		$regex2 = "#JHtml::_\('diler\.studentReportGetValueObject's*,.*,.*,.*(\'.*\')#";
		preg_match_all($regex, $layoutFile, $matches);
		preg_match_all($regex2, $layoutFile, $matches2);
		$regexValue = "#echo.*->fields->(.*?)->value#";
		preg_match_all($regexValue, $layoutFile, $matchesValue);

		$allMatches = array_merge($matches[1], $matches2[1], $matchesValue[1]);
		// At this point, $matches[1] should contain the field names in quotes.
		$fieldNames = array();
		if (count($allMatches) == 0)
		{
			throw new RuntimeException(DText::sprintf('STUDENT_REPORT_EXPORT_LAYOUT_NO_FIELDS', $files[0]), 1001);
		}
		foreach ($allMatches as $match)
		{
			$fieldNames[] = $db->quote(trim(str_replace(array("'", '"'), '', $match)));
		}
		$fieldNames = array_unique($fieldNames);

		$query = $db->getQuery(true)
			->select('name, published, description, label, type, params, element_type, max_length, select_options, displayEmpty, ordering')
			->from('#__diler_report_field_definition')
			->where('name IN(' . implode(',', $fieldNames) . ')');
		$fieldRows = $db->setQuery($query)->loadObjectList();

		$missingFields = $this->exportCheckFields($fieldNames, $fieldRows);
		if (is_array($missingFields) && $missingFields)
		{
			throw new RuntimeException(DText::sprintf('STUDENT_REPORT_EXPORT_FIELDS_NOT_FOUND', $reportType->name, '<br>' . implode('<br>', $missingFields)), 10001);
		}

		// Now get the list of media files to export
		$regex2 = '#@mediaFiles\s*[\/{0|1}]*(.*)#';
		preg_match_all($regex2, $layoutFile, $matches2);
		// At this point, $matches2[1] should contain the media file names (full path).
		$mediaFiles = array();
		foreach ($matches2[1] as $match)
		{
			$match = Folder::makeSafe($match);
			if (File::exists(JPATH_ROOT . '/' . $match))
			{
				$mediaFiles[] = $match;
			}
		}

		// Create JSON file and save to temp folder.
		$tables = array();
		$tables[0] = (object) array('name' => '#__diler_report_type', 'rows' => array($reportType));
		$tables[1] = (object) array('name' => '#__diler_report_field_definition', 'rows' => $fieldRows);

		$jsonObject = (object) array('tables' => $tables);
		$jsonObject->media = $mediaFiles;
		$relativeLayoutPath = substr($files[0], strpos($files[0], 'templates'));
		$jsonObject->layoutFile = $relativeLayoutPath;

		// Create output folder tmp/diler/report-export/<layout name>
		$config = new JConfig();
		$outputFolder = $config->tmp_path . '/diler/report-export/' . $reportType->layout_file_name;
		if (Folder::exists($outputFolder))
		{
			Folder::delete($outputFolder);
		}
		Folder::create($outputFolder);
		// Copy media files to tmp folder
		foreach ($mediaFiles as $mediaFile)
		{
			$fileName = basename($mediaFile);
			File::copy(JPATH_ROOT . '/' . $mediaFile, $outputFolder . '/' . $fileName);
		}

		// Copy any files that have the same root name as the main file
		$fileRoot = File::stripExt(basename($files[0]));
		$relatedFilesFull = glob(dirname($files[0]) . '/' . $fileRoot . '.*');

		$reportCss = dirname($files[0]) . '/' . $reportType->layout_file_name . '.css';
		$relatedFiles = array();
		foreach ($relatedFilesFull as $relatedFileFull)
		{
			$relativeName = substr($relatedFileFull, strpos($relatedFileFull, 'templates') - 1);
			$basename = basename($relatedFileFull);
			$copy = File::copy($relatedFileFull, $outputFolder . '/' . $basename);
			$relatedFiles[] = $relativeName;
		}

		$jsonObject->relatedFiles = $relatedFiles;
		$jsonString = json_encode($jsonObject);

		File::write($outputFolder . '/export-data.txt', $jsonString, true);

		$sourceDir = $outputFolder;
		$zipFile = $outputFolder . '/' . $reportType->layout_file_name . '.zip';
		$fileList = Folder::files($sourceDir, null, false, true);

		$zip = new ZipArchive();
		if ($zip->open($zipFile, ZIPARCHIVE::CREATE) === true)
		{
			foreach ($fileList as $file)
			{
				if ($file !== $zipFile)
				{
					$zip->addFile($file, basename($file));
				}
			}
			$zip->close();
		}

		header("Set-Cookie: fileDownload=true; path=/");
		header("Content-Description: File Transfer");
		header("Content-type: application/octet-stream");
		header("Content-Disposition: attachment; filename=" . $reportType->layout_file_name . '.zip');
		header("Content-Transfer-Encoding: binary");
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header("Content-Length: " . filesize($zipFile));

		readfile($zipFile);
		Folder::delete(dirname($zipFile));
		return $reportType->name;
	}

	/**
	 * Checks for fieldsNames that are missing from $fieldRows
	 * @param array $fieldNames array of field names found in report layout (single quoted).
	 * @param array $fieldRows array of stdClass rows from report_field_definition table
	 * @return array Any names not found in table.
	 */
	protected function exportCheckFields(array $fieldNames, array $fieldRows)
	{
		$foundNames = ArrayHelper::getColumn($fieldRows, 'name');
		$fieldNamesTrimmed = array_map(function ($name){
			return trim($name, "'");
			}, $fieldNames);
		return array_diff($fieldNamesTrimmed, $foundNames);
	}

	/**
	 * Gets the name of the default site template
	 *
	 * @return string  template name (for use in the path to overrides layout files)
	 */
	public function getDefaultTemplate()
	{
		return 'diler3';
	}

    /**
     * @param array $data Data for the form.
     * @param boolean $loadData True if the form is to load its own data (default case), false if not.
     * @return bool|Form A Form object on success, false on failure
     * @throws Exception
     */
	public function getForm($data = array(), $loadData = true)
	{
		$app = Factory::getApplication();

		// Codemirror or Editor None should be enabled
		$db = $this->getDbo();
		$query = $db->getQuery(true)
			->select('COUNT(*)')
			->from('#__extensions as a')
			->where(
				'(a.name =' . $db->quote('plg_editors_codemirror') .
				' AND a.enabled = 1) OR (a.name =' .
				$db->quote('plg_editors_none') .
				' AND a.enabled = 1)'
			);
		$db->setQuery($query);
		$state = $db->loadResult();

		if ((int) $state < 1)
		{
			$app->enqueueMessage(Text::_('COM_TEMPLATES_ERROR_EDITOR_DISABLED'), 'warning');
		}
		// Get the form.
		$form = $this->loadForm('com_diler.reporttype', 'reporttype', array(
			'control' => 'jform',
			'load_data' => $loadData
		));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	public function getSource($layoutFileName)
	{
		$templateName = $this->getDefaultTemplate();
		$layoutFileName = File::makeSafe($layoutFileName);
		$app = Factory::getApplication();
		$contract = $app->input->get('contract', '0');
		$folder = $contract ? 'contract_layouts' : 'report_layouts';
		$path = JPATH_ROOT . '/templates/' . $templateName . '/html/com_diler/' . $folder . '/' . $layoutFileName . '.php';
		try
		{
			$filePath = Path::check($path);
		}
		catch (Exception $e)
		{
			$app->enqueueMessage(DText::_('ERROR_SOURCE_FILE_NOT_FOUND'), 'warning');
			return false;
		}

		if (file_exists($filePath))
		{
			$source = file_get_contents($filePath);
		}
		else
		{
			$app->enqueueMessage(DText::_('ERROR_SOURCE_FILE_NOT_FOUND'), 'error');
			return false;
		}
		return $source;
	}

	/**
	 * Method to get a table object, load it if necessary.
	 *
	 * @param string $type
	 *        	The table name. Optional.
	 * @param string $prefix
	 *        	The class prefix. Optional.
	 * @param array $config
	 *        	Configuration array for model. Optional.
	 *
	 * @return Table
	 *
	 * @since 1.6
	 */
	public function getTable($type = 'Reporttype', $prefix = 'DilerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	protected function getTotalCount($tableName)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('COUNT(*)')->from($db->quoteName($tableName));
		return $db->setQuery($query)->loadResult();
	}

	/**
	 * Import report type archive
	 *
	 * @param string $tmpFolder  Folder where archive file is stored.
	 * @return  string true on success, false on fail.
	 * @throws Exception
	 */
	public function import($tmpFolder)
	{
		$importString = file_get_contents($tmpFolder . '/export-data.txt');
		$importObject = json_decode($importString);
		if (! $this->isValid($importObject))
		{
			throw new RuntimeException(DText::_('REPORT_TYPE_IMPORT_FAIL_INVALID_FILE'), 1001);
		}

		$insertResults = array();
		$importObject->reportExists = $this->reportExists($importObject);
		foreach ($importObject->tables as $table)
		{
			$insertResults[$table->name] = $this->insertJSONData($table, $importObject);
			$insertResults[$table->name]['totalRows'] = count($table->rows);
		}

		$resultObject = (object) array('inserts' => $insertResults);

		// Move layout and media files and get counts of moved files
		$result = ['exists' => 0, 'moved' => 0];
		foreach ($importObject->media as $file)
		{
			$result[$this->moveFile($file, $tmpFolder)] += 1;
		}
		$layoutFileName = $importObject->tables[0]->rows[0]->layout_file_name;
		foreach ($importObject->relatedFiles as $relatedFile)
		{
			$result[$this->moveFile($relatedFile, $tmpFolder)] += 1;
		}
		$resultObject->moves = $result;
		$resultObject->reportExists = $importObject->reportExists;
		$resultObject->backupName = isset($importObject->backupName) ? $importObject->backupName : '';

		return $this->createMessage($resultObject);
	}

	/**
	 * Processes insert or update query for a table array and returns before and after counts.
	 *
	 * @param  string  $table  Name of table to insert
	 * @param  array  $importObject  Array of stdClass objects in format <column name>-><value>
	 */
	public function insertJSONData($table, $importObject)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$beforeCount = $this->getTotalCount($table->name);
		foreach ($table->rows as $row)
		{
			if ($table->name === '#__diler_report_type' && $importObject->reportExists)
			{
				$importObject->backupName = $this->backupReportType($importObject);
			}
			$query->clear();
			foreach ($row as $column => $value)
			{
				$query->set($db->quoteName($column) . ' = ' . $db->quote($value));
			}
			$query->insert($db->quoteName($table->name));
			$insertIgnoreQuery = str_ireplace('INSERT INTO ', 'INSERT IGNORE INTO ', (string) $query);
			$result = $db->setQuery($insertIgnoreQuery)->execute();
		}
		$afterCount = $this->getTotalCount($table->name);
		return array('beforeCount' => $beforeCount, 'afterCount' => $afterCount);
	}

	/**
	 * Checks that report export object is valid and has the expected fields.
	 *
	 * @param  stdClass   $importObject  Has the fields tables, media, layoutFile.
	 *
	 * @return boolean    true if valid, false otherwise
	 */
	protected function isValid($importObject)
	{
		$result = false;
		if (! is_object($importObject) || ! isset($importObject->tables) || ! isset($importObject->media) || ! isset($importObject->layoutFile)
			|| ! is_array($importObject->tables) || ! is_array($importObject->media))
		{
			return $result;
		}

		return true;
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return array The default data is an empty array.
     *
     * @throws Exception
     * @since 1.6
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.reporttype.data', array());

		if (empty($data))
		{
			$data = ArrayHelper::fromObject($this->getItem());
		}
		$data['source'] = $this->getSource($data['layout_file_name']);

		$this->preprocessData('com_diler.reporttype', $data);

		return $data;
	}

	/**
	 * Moves a file from the temp folder to the permenant location, only if file doesn't exist.
	 *
	 * @param  string   $file        Permanent location of the file, relative to the JPATH_ROOT.
	 * @param  string   $tmpFolder   Temp folder where file is located.
	 *
	 * @return string   missing/exists/moved/error.
	 */
	protected function moveFile(string $file, string $tmpFolder)
	{
		$name = basename($file);
		if (! File::exists($tmpFolder . '/' . $name))
			return 'missing';
		$destination = JPATH_ROOT . '/' . $file;
		$result = File::move($tmpFolder . '/' . $name, $destination);
		return $result ? 'moved' : 'error';
	}

	/**
	 * Prepare and sanitise the table data prior to saving.
	 *
	 * @return void
	 *
	 * @since 1.6
	 */
	protected function prepareTable($table)
	{
		$date = Factory::getDate();
		$user = Factory::getUser();

		$table->name = htmlspecialchars_decode($table->name, ENT_QUOTES);
	}

	/**
	 * Checks whether the imported report already exists in the db.
	 *
	 * @param stdClass $importObject Object containing report row for DiLer report type.
	 * @return boolean true if report exists, false if not.
	 */
	protected function reportExists($importObject)
	{
		$tableObject = new stdClass();
		$result = '';
		foreach ($importObject->tables as $tableObject)
		{
			if ($tableObject->name === '#__diler_report_type')
			{
				break;
			}
		}
		if (! isset($tableObject->name))
		{
			return false;
		}
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('id, layout_file_name, name')->from('#__diler_report_type');
		$rows = $db->setQuery($query)->loadObjectList();
		$this->reportTypes = [];
		foreach ($rows as $row)
		{
			$this->reportTypes[$row->layout_file_name] = ['id' => $row->id, 'name' => $row->name];
		}
		if (isset($this->reportTypes[$tableObject->rows[0]->layout_file_name]))
		{
			$result = $tableObject->rows[0]->layout_file_name;
		}
		return $result;
	}

	/**
	 * Override parent save method to also save changes to the layout file.
	 * {@inheritDoc}
	 * @see AdminModel::save()
	 */
	public function save($data)
	{
		$app = Factory::getApplication();
		parent::save($data);
		// Save the layout file.
		$templateName = $this->getDefaultTemplate();
		$layoutFileName = File::makeSafe($data['layout_file_name']);
		$contract = $app->input->get('contract', '0');
		$folder = $contract ? 'contract_layouts' : 'report_layouts';
		$filePath = JPATH_ROOT . '/templates/' . $templateName . '/html/com_diler/' . $folder . '/' . $layoutFileName . '.php';

		$user = get_current_user();
		chown($filePath, $user);
		Path::setPermissions($filePath);

		// Try to make the template file writable.
		if (!is_writable($filePath))
		{
			$app->enqueueMessage(DText::_('ERROR_SOURCE_FILE_NOT_WRITABLE'), 'warning');
			$app->enqueueMessage(DText::sprintf('FILE_PERMISSIONS', Path::getPermissions($filePath)), 'warning');

			if (file_exists($filePath) && !Path::isOwner($filePath))
			{
				$app->enqueueMessage(DText::_('CHECK_FILE_OWNERSHIP'), 'warning');
			}

			$this->setError(DText::sprintf('ERROR_FAILED_TO_SAVE_FILENAME', $layoutFileName . '.php'), 'error');
			return false;
		}

		$return = File::write($filePath, $data['source']);
		if (!$return)
		{
			$this->setError(DText::sprintf('ERROR_FAILED_TO_SAVE_FILENAME', $layoutFileName . '.php'), 'error');
			return false;
		}
		return true;
	}

}
