<?php

/**
 * DiLer default model to update diler data
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\DMailer;
use Joomla\CMS\Access\Access;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\User\UserHelper;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Filesystem\Path;

/**
 * DiLer model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DilerModelSampledata extends BaseDatabaseModel
{

	public $forenamesFemale = ['Adele','Adrian','Ahmet','Aksel','Alice','Amelie','Angelo','Anna','Antoni',
		'Aoife','Azra','Basira','Berat','Caoimhe','Charlotte','Chloe','Ciara','Clara','Ecrin','Elif','Emilia','Emily','Emma',
		'Hannah','Hanne','Imene','Ines','Inger',
		'Jan','Jeanne','Joanna','Johanna','Kari','Kirsten','Lilly','Lina','Liv','Louisa','Louise','Magdalena','Maria',
		'Mette','Mia','Mila','Mirac','Miray','Sabrina',
		'Samia','Saoirse','Sarah','Sofia','Sophie','Szymon','Yasmine','Zehra','Zeynep','Zofia',
		'Adele', 'Adelheid', 'Agathe', 'Agnes', 'Alexandra', 'Alice', 'Alma', 'Almut', 'Aloisia', 'Alwine', 'Amalie', 'Ana', 'Anastasia', 'Andrea', 'Anett', 'Anette', 'Angela', 'Angelika', 'Anika', 'Anita', 'Anja', 'Anke', 'Anna', 'Anna-Maria', 'Anne', 'Annegret', 'Annelie', 'Annelies', 'Anneliese', 'Annelore', 'Annemarie', 'Annerose', 'Annett', 'Annette', 'Anni', 'Annika', 'Anny', 'Antje', 'Antonia', 'Antonie', 'Ariane', 'Astrid', 'Auguste', 'Ayse',
        'Babette', 'Barbara', 'Beate', 'Beatrice', 'Beatrix', 'Bernadette', 'Berta', 'Bettina', 'Betty', 'Bianca', 'Bianka', 'Birgit', 'Birgitt', 'Birgitta', 'Birte', 'Brigitta', 'Brigitte', 'Britta', 'Brunhild', 'Brunhilde', 'Bärbel',
        'Carina', 'Carla', 'Carmen', 'Carola', 'Carolin', 'Caroline', 'Cathrin', 'Catrin', 'Centa', 'Charlotte', 'Christa', 'Christel', 'Christiane', 'Christin', 'Christina', 'Christine', 'Christl', 'Cindy', 'Claudia', 'Conny', 'Constanze', 'Cordula', 'Corina', 'Corinna', 'Cornelia', 'Cäcilia', 'Cäcilie',
        'Dagmar', 'Dana', 'Daniela', 'Danuta', 'Denise', 'Diana', 'Dietlinde', 'Dora', 'Doreen', 'Doris', 'Dorit', 'Dorothea', 'Dorothee', 'Dunja', 'Dörte',
        'Edda', 'Edelgard', 'Edeltraud', 'Edeltraut', 'Edith', 'Elena', 'Eleonore', 'Elfi', 'Elfriede', 'Elisabeth', 'Elise', 'Elke', 'Ella', 'Ellen', 'Elli', 'Elly', 'Elsa', 'Elsbeth', 'Else', 'Elvira', 'Emilia', 'Emilie', 'Emine', 'Emma', 'Emmi', 'Emmy', 'Erika', 'Erna', 'Ernestine', 'Esther', 'Eugenie', 'Eva', 'Eva-Maria', 'Evelin', 'Eveline', 'Evelyn', 'Evelyne', 'Evi', 'Ewa',
        'Fatma', 'Felicitas', 'Franziska', 'Frauke', 'Frida', 'Frieda', 'Friederike',
        'Gabi', 'Gabriela', 'Gabriele', 'Gaby', 'Galina', 'Gerda', 'Gerhild', 'Gerlinde', 'Gerta', 'Gerti', 'Gertraud', 'Gertraude', 'Gertrud', 'Gertrude', 'Gesa', 'Gesine', 'Giesela', 'Gisela', 'Gitta', 'Grete', 'Gretel', 'Grit', 'Gudrun', 'Gunda', 'Gundula',
        'Halina', 'Hanna', 'Hanne', 'Hannelore', 'Hatice', 'Hedi', 'Hedwig', 'Heide', 'Heidemarie', 'Heiderose', 'Heidi', 'Heidrun', 'Heike', 'Helen', 'Helena', 'Helene', 'Helga', 'Hella', 'Helma', 'Henny', 'Henri', 'Henriette', 'Hermine', 'Herta', 'Hertha', 'Hilda', 'Hilde', 'Hildegard', 'Hiltrud',
        'Ida', 'Ilka', 'Ilona', 'Ilse', 'Imke', 'Ina', 'Ines', 'Inga', 'Inge', 'Ingeborg', 'Ingeburg', 'Ingelore', 'Ingrid', 'Inka', 'Inna', 'Irena', 'Irene', 'Irina', 'Iris', 'Irma', 'Irmgard', 'Irmhild', 'Irmtraud', 'Irmtraut', 'Isa', 'Isabel', 'Isabell', 'Isabella', 'Isabelle', 'Isolde', 'Ivonne',
        'Jacqueline', 'Jana', 'Janet', 'Janina', 'Janine', 'Jaqueline', 'Jasmin', 'Jeanette', 'Jeannette', 'Jennifer', 'Jenny', 'Jessica', 'Joanna', 'Johanna', 'Johanne', 'Jolanta', 'Josefa', 'Josefine', 'Judith', 'Julia', 'Juliane', 'Jutta',
        'Karen', 'Karin', 'Karina', 'Karla', 'Karola', 'Karolina', 'Karoline', 'Katarina', 'Katharina', 'Kathleen', 'Kathrin', 'Kati', 'Katja', 'Katrin', 'Kerstin', 'Kirsten', 'Kirstin', 'Klara', 'Klaudia', 'Konstanze', 'Kornelia', 'Kristin', 'Kristina', 'Krystyna', 'Kunigunde', 'Käte', 'Käthe',
        'Larissa', 'Laura', 'Lena', 'Leni', 'Leonore', 'Liane', 'Lidia', 'Liesbeth', 'Liesel', 'Lieselotte', 'Lilli', 'Lilly', 'Lilo', 'Lina', 'Linda', 'Lisa', 'Lisbeth', 'Liselotte', 'Loni', 'Lore', 'Lotte', 'Lucia', 'Lucie', 'Ludmila', 'Ludmilla', 'Luise', 'Luzia', 'Luzie', 'Lydia',
        'Madeleine', 'Magda', 'Magdalena', 'Magdalene', 'Maike', 'Maja', 'Mandy', 'Manja', 'Manuela', 'Mareike', 'Maren', 'Marga', 'Margareta', 'Margarete', 'Margaretha', 'Margarethe', 'Margarita', 'Margit', 'Margitta', 'Margot', 'Margret', 'Margrit', 'Maria', 'Marianne', 'Marie', 'Marie-Luise', 'Marietta', 'Marija', 'Marika', 'Marina', 'Marion', 'Marita', 'Maritta', 'Marlen', 'Marlene', 'Marlies', 'Marliese', 'Marlis', 'Marta', 'Martha', 'Martina', 'Mathilde', 'Mechthild', 'Meike', 'Melanie', 'Melitta', 'Meta', 'Michaela', 'Mina', 'Minna', 'Miriam', 'Mirjam', 'Mona', 'Monica', 'Monika', 'Monique',
        'Nadine', 'Nadja', 'Nancy', 'Natalia', 'Natalie', 'Natalja', 'Natascha', 'Nathalie', 'Nelli', 'Nicole', 'Nina', 'Nora',
        'Olga', 'Ortrud', 'Ottilie',
        'Pamela', 'Patricia', 'Patrizia', 'Paula', 'Pauline', 'Peggy', 'Petra', 'Pia',
        'Ramona', 'Rebecca', 'Regina', 'Regine', 'Reinhild', 'Reinhilde', 'Renata', 'Renate', 'Resi', 'Ria', 'Ricarda', 'Rita', 'Romy', 'Rosa', 'Rosalinde', 'Rose', 'Rosel', 'Rosemarie', 'Rosi', 'Rosina', 'Rosita', 'Rosmarie', 'Roswitha', 'Ruth',
        'Sabina', 'Sabine', 'Sabrina', 'Sandra', 'Sandy', 'Sara', 'Sarah', 'Saskia', 'Selma', 'Sibylle', 'Sieglinde', 'Siegrid', 'Siglinde', 'Sigrid', 'Sigrun', 'Silke', 'Silvana', 'Silvia', 'Simona', 'Simone', 'Sina', 'Sofia', 'Sofie', 'Sonja', 'Sophia', 'Sophie', 'Stefanie', 'Steffi', 'Stephanie', 'Susan', 'Susann', 'Susanna', 'Susanne', 'Svenja', 'Svetlana', 'Swetlana', 'Sybille', 'Sylke', 'Sylvia',
        'Tamara', 'Tanja', 'Tatjana', 'Teresa', 'Thea', 'Thekla', 'Theresa', 'Therese', 'Theresia', 'Tina', 'Traudel', 'Traute', 'Trude',
        'Ulla', 'Ulrike', 'Ursel', 'Ursula', 'Uschi', 'Uta', 'Ute',
        'Valentina', 'Valeri', 'Valerie', 'Vanessa', 'Vera', 'Verena', 'Veronika', 'Viktoria', 'Viola',
        'Walburga', 'Wally', 'Waltraud', 'Waltraut', 'Wanda', 'Wendelin', 'Wera', 'Wiebke', 'Wilhelmine', 'Wilma', 'Wiltrud',
        'Yvonne','Änne',
		];

	public $forenamesMale = ['Achim', 'Adalbert', 'Adam', 'Adolf', 'Adrian', 'Ahmed', 'Ahmet', 'Albert', 'Albin', 'Albrecht', 'Alex', 'Alexander', 'Alfons', 'Alfred', 'Ali', 'Alois', 'Aloys', 'Alwin', 'Anatoli', 'Andre', 'Andreas', 'Andree', 'Andrej', 'Andrzej', 'André', 'Andy', 'Angelo', 'Ansgar', 'Anton', 'Antonio', 'Antonius', 'Armin', 'Arnd', 'Arndt', 'Arne', 'Arno', 'Arnold', 'Arnulf', 'Arthur', 'Artur', 'August', 'Axel',
        'Bastian', 'Benedikt', 'Benjamin', 'Benno', 'Bernard', 'Bernd', 'Berndt', 'Bernhard', 'Bert', 'Berthold', 'Bertram', 'Björn', 'Bodo', 'Bogdan', 'Boris', 'Bruno', 'Burghard', 'Burkhard',
        'Carl', 'Carlo', 'Carlos', 'Carsten', 'Christian', 'Christof', 'Christoph', 'Christopher', 'Christos', 'Claudio', 'Claus', 'Claus-Dieter', 'Claus-Peter', 'Clemens', 'Cornelius',
        'Daniel', 'Danny', 'Darius', 'David', 'Denis', 'Dennis', 'Detlef', 'Detlev', 'Dierk', 'Dieter', 'Diethard', 'Diethelm', 'Dietmar', 'Dietrich', 'Dimitri', 'Dimitrios', 'Dirk', 'Domenico', 'Dominik',
        'Eberhard', 'Eckard', 'Eckart', 'Eckehard', 'Eckhard', 'Eckhardt', 'Edgar', 'Edmund', 'Eduard', 'Edward', 'Edwin', 'Egbert', 'Egon', 'Ehrenfried', 'Ekkehard', 'Elmar', 'Emanuel', 'Emil', 'Engelbert', 'Enno', 'Enrico', 'Erhard', 'Eric', 'Erich', 'Erik', 'Ernst', 'Ernst-August', 'Erwin', 'Eugen', 'Ewald',
        'Fabian', 'Falk', 'Falko', 'Felix', 'Ferdinand', 'Florian', 'Francesco', 'Franco', 'Frank', 'Franz', 'Franz Josef', 'Franz-Josef', 'Fred', 'Fredi', 'Fridolin', 'Friedbert', 'Friedemann', 'Frieder', 'Friedhelm', 'Friedrich', 'Friedrich-Wilhelm', 'Fritz',
        'Gabriel', 'Gebhard', 'Georg', 'Georgios', 'Gerald', 'Gerd', 'Gerhard', 'Gernot', 'Gero', 'Gerold', 'Gert', 'Gilbert', 'Giovanni', 'Gisbert', 'Giuseppe', 'Gottfried', 'Gotthard', 'Gottlieb', 'Gregor', 'Guenter', 'Guido', 'Guiseppe', 'Gunnar', 'Gunter', 'Gunther', 'Gustav', 'Götz', 'Günter', 'Günther',
        'Hagen', 'Halil', 'Hannes', 'Hanni', 'Hanno', 'Hanns', 'Hans', 'Hans Dieter', 'Hans Georg', 'Hans Jürgen', 'Hans Peter', 'Hans-Christian', 'Hans-Dieter', 'Hans-Georg', 'Hans-Gerd', 'Hans-Günter', 'Hans-Günther', 'Hans-Heinrich', 'Hans-Hermann', 'Hans-J.', 'Hans-Joachim', 'Hans-Jochen', 'Hans-Josef', 'Hans-Jörg', 'Hans-Jürgen', 'Hans-Martin', 'Hans-Otto', 'Hans-Peter', 'Hans-Ulrich', 'Hans-Walter', 'Hans-Werner', 'Hans-Wilhelm', 'Hansjörg', 'Hanspeter', 'Harald', 'Hardy', 'Harri', 'Harro', 'Harry', 'Hartmut', 'Hartwig', 'Hasan', 'Heiko', 'Heiner', 'Heino', 'Heinrich', 'Heinz', 'Heinz-Dieter', 'Heinz-Georg', 'Heinz-Günter', 'Heinz-Joachim', 'Heinz-Josef', 'Heinz-Jürgen', 'Heinz-Peter', 'Heinz-Werner', 'Helfried', 'Helge', 'Hellmut', 'Hellmuth', 'Helmar', 'Helmut', 'Helmuth', 'Hendrik', 'Henning', 'Henrik', 'Henry', 'Henryk', 'Herbert', 'Heribert', 'Hermann', 'Hermann-Josef', 'Herwig', 'Hilmar', 'Hinrich', 'Holger', 'Horst', 'Horst-Dieter', 'Hubert', 'Hubertus', 'Hugo', 'Hüseyin',
        'Ibrahim', 'Ignaz', 'Igor', 'Ingo', 'Ingolf', 'Ismail', 'Ivan', 'Ivo',
        'Jakob', 'Jan', 'Janusz', 'Jens', 'Jens-Uwe', 'Joachim', 'Jochen', 'Johann', 'Johannes', 'John', 'Jonas', 'Jonas', 'Jose', 'Josef', 'Joseph', 'Josip', 'Jost', 'Juergen', 'Julian', 'Julius', 'Juri', 'Jörg', 'Jörn', 'Jürgen',
        'Kai-Uwe', 'Karl', 'Karl Heinz', 'Karl-Ernst', 'Karl-Friedrich', 'Karl-Heinrich', 'Karl-Heinz', 'Karl-Josef', 'Karl-Ludwig', 'Karl-Otto', 'Karl-Wilhelm', 'Karlheinz', 'Karsten', 'Kaspar', 'Kevin', 'Klaus', 'Klaus Dieter', 'Klaus Peter', 'Klaus-Dieter', 'Klaus-Jürgen', 'Klaus-Peter', 'Klemens', 'Knut', 'Konrad', 'Konstantin', 'Konstantinos', 'Kuno', 'Kurt',
        'Lars', 'Leo', 'Leonhard', 'Leonid', 'Leopold', 'Lorenz', 'Lothar', 'Ludger', 'Ludwig', 'Luigi', 'Lukas', 'Lutz',
        'Magnus', 'Maik', 'Malte', 'Manfred', 'Manuel', 'Marc', 'Marcel', 'Marco', 'Marcus', 'Marek', 'Marian', 'Mario', 'Marius', 'Mark', 'Marko', 'Markus', 'Martin', 'Mathias', 'Matthias', 'Max', 'Maximilian', 'Mehmet', 'Meinhard', 'Meinolf', 'Metin', 'Michael', 'Michel', 'Mike', 'Milan', 'Mirco', 'Mirko', 'Miroslav', 'Miroslaw', 'Mohamed', 'Moritz', 'Murat', 'Mustafa',
        'Nico', 'Nicolas', 'Niels', 'Nikola', 'Nikolai', 'Nikolaj', 'Nikolaos', 'Nikolaus', 'Nils', 'Norbert', 'Norman',
        'Olaf', 'Oliver', 'Ortwin', 'Oskar', 'Osman', 'Oswald', 'Otmar', 'Ottmar', 'Otto',
        'Pascal', 'Patrick', 'Paul', 'Peer', 'Peter', 'Philip', 'Philipp', 'Pierre', 'Pietro', 'Piotr',
        'Rafael', 'Raimund', 'Rainer', 'Ralf', 'Ralph', 'Ramazan', 'Raphael', 'Reimund', 'Reiner', 'Reinhard', 'Reinhardt', 'Reinhold', 'Rene', 'René', 'Richard', 'Rico', 'Robert', 'Roberto', 'Robin', 'Roger', 'Roland', 'Rolf', 'Rolf-Dieter', 'Roman', 'Ronald', 'Ronny', 'Rudi', 'Rudolf', 'Rupert', 'Rüdiger',
        'Salvatore', 'Samuel', 'Sandro', 'Sebastian', 'Sergej', 'Siegbert', 'Siegfried', 'Siegmar', 'Siegmund', 'Sigmund', 'Sigurd', 'Silvio', 'Simon', 'Stanislaw', 'Stefan', 'Steffen', 'Stephan', 'Steven', 'Sven', 'Swen', 'Sönke', 'Sören',
        'Theo', 'Theodor', 'Thilo', 'Thomas', 'Thorsten', 'Till', 'Tilo', 'Tim', 'Timo', 'Tino', 'Tobias', 'Tom', 'Toni', 'Torben', 'Torsten',
        'Udo', 'Ulf', 'Uli', 'Ullrich', 'Ulrich', 'Uwe',
        'Valentin', 'Veit', 'Victor', 'Viktor', 'Vincenzo', 'Vinzenz', 'Vitali', 'Vladimir', 'Volker', 'Volkmar',
        'Waldemar', 'Walter', 'Walther', 'Wenzel', 'Werner', 'Wieland', 'Wilfried', 'Wilhelm', 'Willi', 'William', 'Willibald', 'Willy', 'Winfried', 'Wladimir', 'Wolf', 'Wolf-Dieter', 'Wolfgang', 'Wolfram', 'Wulf',
        'Xaver','Yusuf',
		'Abraham','Adam','Adrian','Ahmet','Aksel','Albert','Aleksandra','Alexander','Angelo','Antoni','Antonio',
		'Aoife','Azra','Basira','Berat','Caoimhe','Conor','Ecrin','Elif','Emir','Eric',
		'Ernst','Eylül','Eymen','Felix','Franciszek','Gabriel','Giovanni','Henrik','Hiranur','Imene','Ines','Inger','Jack','Jakub','James',
		'Jan','Jules','Leo','Louis','Lucas','Marco',
		'Marit','Matteo','Mette','Mila','Mirac','Miray','Mustafa','Niamh','Noah','Oliver','Omer','Oscar','Phillip','Raphaël','Roberto',
		'Samia','Saoirse','Szymon','Victor','William','Yusuf','Zehra','Zeynep'];

	public $surnames = ['Aksoy','Andersen','Aydın','Bakker','Becker','Bernard','Bianchi','Brahimi','Brown','Byrne ','Christensen','Dahmani','Davis',
		'De Jong','De Vries','Demir','Dubois','Durand','Erdoğan','Esposito','Fernández','Ferrari','Fischer','Garcia','García','Gómez','González',
		'Haddad','Hansen','Jansen','Janssen','Jensen','Johnson','Jones','Jørgensen','Kaminska','Kaya','Kelly ','Kim','Kowalczyk','Kowalska',
		'Larsen','Laurent','Lee','Lewandowska','López','Mansouri','Martín','Martínez','Messaoudi','Meyer','Michel','Miller','Moreau','Murphy ',
		'Nielsen','Nowak','Özdemir','Öztürk','Pedersen','Pérez','Polat','Rahmani','Rasmussen','Regio',
		'Ricci','Richard','Robert','Rodríguez','Romano','Rossi','Russo','Ryan ','Şahin','Saidi','Sánchez','Schmidt','Schneider','Simon','Slimani',
		'Smith','Sørensen','Touati','Van de Berg','Van Dijk','Visser','Wagner','Walsh ','Weber','Williams','Wisniewska','Wojcik','Yahiaoui','Yıldız','Zielinska',
		'Ackermann', 'Adam', 'Adler', 'Ahrens', 'Albers', 'Albert', 'Albrecht', 'Altmann', 'Anders', 'Appel', 'Arndt', 'Arnold', 'Auer',
        'Bach', 'Bachmann', 'Bader', 'Baier', 'Bartels', 'Barth', 'Barthel', 'Bartsch', 'Bauer', 'Baum', 'Baumann', 'Baumgartner', 'Baur', 'Bayer', 'Beck', 'Becker',
		'Beckmann', 'Beer', 'Behrendt', 'Behrens', 'Beier', 'Bender', 'Benz', 'Berg', 'Berger', 'Bergmann', 'Berndt', 'Bernhardt', 'Bertram', 'Betz', 'Beyer', 'Binder',
		'Bischoff', 'Bittner', 'Blank', 'Block', 'Blum', 'Bock', 'Bode', 'Born', 'Brand', 'Brandl', 'Brandt', 'Braun', 'Brenner', 'Breuer', 'Brinkmann', 'Brunner',
		'Bruns', 'Brückner', 'Buchholz', 'Buck', 'Burger', 'Burkhardt', 'Busch', 'Busse', 'Bär', 'Böhm', 'Böhme', 'Böttcher', 'Bühler', 'Büttner',
        'Christ', 'Conrad', 'Decker', 'Diehl', 'Dietrich', 'Dietz', 'Dittrich', 'Dorn', 'Döring', 'Dörr',
        'Eberhardt', 'Ebert', 'Eckert', 'Eder', 'Ehlers', 'Eichhorn', 'Engel', 'Engelhardt', 'Engelmann', 'Erdmann', 'Ernst', 'Esser',
        'Falk', 'Feldmann', 'Fiedler', 'Fink', 'Fischer', 'Fleischer', 'Fleischmann', 'Forster', 'Frank', 'Franke', 'Franz', 'Freitag', 'Freund', 'Frey', 'Fricke',
		'Friedrich', 'Fritsch', 'Fritz', 'Fröhlich', 'Fuchs', 'Fuhrmann', 'Funk', 'Funke', 'Förster',
        'Gabriel', 'Gebhardt', 'Geiger', 'Geisler', 'Geißler', 'Gerber', 'Gerlach', 'Geyer', 'Giese', 'Glaser', 'Gottschalk', 'Graf', 'Greiner', 'Grimm', 'Gross',
		'Groß', 'Großmann', 'Gruber', 'Gärtner', 'Göbel', 'Götz', 'Günther',
        'Haag', 'Haas', 'Haase', 'Hagen', 'Hahn', 'Hamann', 'Hammer', 'Hanke', 'Hansen', 'Harms', 'Hartmann', 'Hartung', 'Hartwig', 'Haupt', 'Hauser', 'Hecht', 'Heck',
		'Heil', 'Heim', 'Hein', 'Heine', 'Heinemann', 'Heinrich', 'Heinz', 'Heinze', 'Held', 'Heller', 'Hempel', 'Henke', 'Henkel', 'Hennig', 'Henning', 'Hentschel',
		'Herbst', 'Hermann', 'Herold', 'Herrmann', 'Herzog', 'Hess', 'Hesse', 'Heuer', 'Heß', 'Hildebrandt', 'Hiller', 'Hinz', 'Hirsch', 'Hoffmann', 'Hofmann',
		'Hohmann', 'Holz', 'Hoppe', 'Horn', 'Huber', 'Hummel', 'Hübner',
        'Jacob', 'Jacobs', 'Jahn', 'Jakob', 'Jansen', 'Janssen', 'Janßen', 'John', 'Jordan', 'Jost', 'Jung', 'Jäger', 'Jürgens',
        'Kaiser', 'Karl', 'Kaufmann', 'Keil', 'Keller', 'Kellner', 'Kern', 'Kessler', 'Keßler', 'Kiefer', 'Kirchner', 'Kirsch', 'Klaus', 'Klein', 'Klemm',
		'Klose', 'Kluge', 'Knoll', 'Koch', 'Kohl', 'Kolb', 'Konrad', 'Kopp', 'Kraft', 'Kramer', 'Kraus', 'Krause', 'Krauß', 'Krebs', 'Kremer', 'Kretschmer',
		'Krieger', 'Kroll', 'Krug', 'Kruse', 'Krämer', 'Kröger', 'Krüger', 'Kuhlmann', 'Kuhn', 'Kunz', 'Kunze', 'Kurz', 'Köhler', 'König', 'Körner', 'Köster',
		'Kühn', 'Kühne',
        'Lang', 'Lange', 'Langer', 'Lauer', 'Lechner', 'Lehmann', 'Lemke', 'Lenz', 'Lindemann', 'Lindner', 'Link', 'Linke', 'Lohmann', 'Lorenz', 'Ludwig', 'Lutz', 'Löffler',
        'Mack', 'Mai', 'Maier', 'Mann', 'Marquardt', 'Martens', 'Martin', 'Marx', 'Maurer', 'May', 'Mayer', 'Mayr', 'Meier', 'Meister', 'Meißner', 'Menzel',
		'Merkel', 'Mertens', 'Merz', 'Metz', 'Metzger', 'Meyer', 'Michel', 'Michels', 'Miller', 'Mohr', 'Moll', 'Moritz', 'Moser', 'Möller', 'Müller', 'Münch',
        'Nagel', 'Naumann', 'Neubauer', 'Neubert', 'Neuhaus', 'Neumann', 'Nickel', 'Niemann', 'Noack', 'Noll', 'Nolte', 'Nowak',
        'Opitz', 'Oswald', 'Ott', 'Otto',
        'Pape', 'Paul', 'Peter', 'Peters', 'Petersen', 'Pfeifer', 'Pfeiffer', 'Philipp', 'Pieper', 'Pietsch', 'Pohl', 'Popp', 'Preuß', 'Probst',
        'Raab', 'Rapp', 'Rau', 'Rauch', 'Rausch', 'Reich', 'Reichel', 'Reichert', 'Reimann', 'Reimer', 'Reinhardt', 'Reiter', 'Renner', 'Reuter', 'Richter',
		'Riedel', 'Riedl', 'Rieger', 'Ritter', 'Rohde', 'Rose', 'Roth', 'Rothe', 'Rudolph', 'Ruf', 'Runge', 'Rupp', 'Röder', 'Römer',
        'Sander', 'Sauer', 'Sauter', 'Schade', 'Schaller', 'Scharf', 'Scheffler', 'Schenk', 'Scherer', 'Schiller', 'Schilling', 'Schindler', 'Schlegel',
		'Schlüter', 'Schmid', 'Schmidt', 'Schmitt', 'Schmitz', 'Schneider', 'Scholz', 'Schott', 'Schrader', 'Schramm', 'Schreiber', 'Schreiner', 'Schröder',
		'Schröter', 'Schubert', 'Schuler', 'Schulte', 'Schultz', 'Schulz', 'Schulze', 'Schumacher', 'Schumann', 'Schuster', 'Schwab', 'Schwarz', 'Schweizer',
		'Schäfer', 'Schön', 'Schüler', 'Schütte', 'Schütz', 'Schütze', 'Seeger', 'Seidel', 'Seidl', 'Seifert', 'Seiler', 'Seitz', 'Siebert', 'Simon', 'Singer',
		'Sommer', 'Sonntag', 'Springer', 'Stadler', 'Stahl', 'Stark', 'Steffen', 'Steffens', 'Stein', 'Steinbach', 'Steiner', 'Stephan', 'Stock', 'Stoll',
		'Straub', 'Strauß', 'Strobel', 'Stumpf', 'Sturm',
        'Thiel', 'Thiele', 'Thomas', 'Ullrich', 'Ulrich', 'Unger', 'Urban',
        'Vetter', 'Vogel', 'Vogt', 'Voigt', 'Vollmer', 'Voss', 'Voß', 'Völker',
        'Wagner', 'Wahl', 'Walter', 'Walther', 'Weber', 'Wegener', 'Wegner', 'Weidner', 'Weigel', 'Weis', 'Weise', 'Weiss', 'Weiß', 'Wendt', 'Wenzel',
		'Werner', 'Westphal', 'Wetzel', 'Wiedemann', 'Wiegand', 'Wieland', 'Wiese', 'Wiesner', 'Wild', 'Wilhelm', 'Wilke', 'Will', 'Wimmer', 'Winkler',
		'Winter', 'Wirth', 'Witt', 'Witte', 'Wittmann', 'Wolf', 'Wolff', 'Wolter', 'Wulf', 'Wunderlich',
        'Zander', 'Zeller', 'Ziegler', 'Zimmer', 'Zimmermann'];

	public $streets = ['Hauptstraße', 'Schulstraße', 'Gartenstraße', 'Bahnhofsstraße','Birkenweg','Lindenstraße','Schillerstraße','Goethestraße','Mozartstraße',
		'Beethovenstraße','Haydnstraße','Invalidenstrasse','Genslerstraße','Rosenstrasse'];

	public $cities = ['Stuttgart','Karlsruhe','Mannheim','Freiburg im Breisgau','Heidelberg','Ulm'];

	public $lorem = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc auctor eros ex, eu viverra erat vestibulum ac. Nam eu scelerisque nulla. ' .
			'Phasellus dignissim tincidunt metus eu aliquam. Cras luctus elementum arcu, sit amet blandit enim laoreet maximus. Mauris venenatis dictum posuere.' .
			' Duis ipsum ipsum, luctus ac purus quis, congue luctus magna. Praesent consequat, libero in auctor bibendum, felis eros egestas ex, a egestas nibh' .
			' tellus nec risus. Pellentesque interdum dolor vitae ante luctus, ut euismod neque tempor. Nullam vitae leo sed tellus condimentum bibendum eget' .
			' vulputate augue. Donec ante elit, mattis ut lacus at, maximus varius elit. Sed quis leo.';

	public $letters = [];

	public $cutoffDate2Years = '';
	public $cutoffDate90Days = '';
	public $cutoffDate30Days = '';
	public $newPeriodStartDate = '';
	public $newPeriodEndDate = '';

	/**
	 * Array of all table names in the database. Used to check whether table exists before deleting rows.
	 * @var array
	 */
	public $databaseTables = [];

	/**
	 * Array of tables and date columns to adjust in the moveDatesForward function.
	 * @var Array: {table name} => [column names]
	 */
	public $dateColumns = [
		'#__dilerreg_users' => ['first_school_enrollment_date'],
		'#__diler_activity_task_completed' => ['created', 'confirmed_date'],
		'#__diler_activity_completed' => ['requested_date', 'accept_deny_date', 'started_date', 'completed_date', 'mark_calculate_date', 'mark_override_date'],
		'#__diler_marks_history' => ['created', 'modified'],
		'#__diler_report_field_history' => ['created', 'modified'],
		'#__diler_report_period' => ['start_date', 'end_date','edit_start_date','edit_end_date'],
		'#__diler_schoolyear' => ['start_date', 'end_date'],
		'#__diler_schoolyear_marks_period_map' => ['start_date', 'end_date'],
		'#__diler_studentrecord' => ['effective_date', 'created'],
		'#__diler_student_compchar_status' => ['completed_date'],
		'#__diler_student_competence_status' => ['completed_date'],
		'#__diler_student_subject_phase_status' => ['completed_date'],
		'#__diler_texter' => ['created_date','read_date', 'receiver_trash_date', 'sender_trash_date'],
		'#__diler_user_school_history' => ['enroll_start', 'enroll_end'],
		'#__dpcalendar_events' => ['start_date', 'end_date', 'created', 'modified'],
	];

	public $superUserArray = [];

	/**
	 * Checks whether proposed Joomla usergroup name already exists. Name must unique within category.
	 *
	 * @param string $groupName
	 * @return int 1 or more if group name exists, 0 otherwise.
	 */
	protected function checkGroupNameExists($groupName)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('COUNT(*)')
				->from('#__usergroups')
				->where('title = ' . $db->quote($groupName));
		return $db->setQuery($query)->loadResult();
	}


	public function createSampleDb($options)
	{
		$this->setCutoffDates();
		$this->superUserArray = $this->getSuperUserIds();
		$this->databaseTables = $this->getDatabaseTables();
		$this->processDilerUsers($options);
		$this->processJoomlaUsers();
		$this->processJoomlaArticles();
		$this->processRegCodes();
		$this->processActivityCompleted();
		$this->processActivityTask();
		$this->processActivityTaskCompleted();
		$this->deleteTable('#__diler_activity_task_grid_media_map');
		$this->deleteTable('#__diler_group_cloud_map');
		$this->deleteTable('#__diler_cloud');
		$this->deleteTable('#__diler_grid_media');
		$this->deleteTable('#__diler_log');
		$this->processGroups();
		$this->processReportFieldHistory();
		$this->processReportPeriod();
		$this->deleteTable('#__diler_stored_report');
		$this->deleteTable('#__diler_student_reports');
		$this->processStudentrecords();
		$this->processTeacherMyNotes();
		$this->processTexter();
		$this->deleteTable('#__diler_user_grid_media_map');
		$this->updatePasswords($options);
		$this->processSchools();
		$this->processJoomlaOptions();
		$this->processDilerOptions();
		$this->processDpCalendarOptions();
		$this->processAkeebaOptions();
		$this->refreshDPCalendarCaldavPrincipalsTable();
	}

	protected function deleteTable($table, $where = null)
	{
		$db = Factory::getDbo();
		if (! in_array($table, $this->databaseTables)) return;

		$query = $db->getQuery(true)->delete($db->quoteName($table));
		if (is_array($where))
		{
			$query->where($db->quoteName($where['column']) . ' ' . $where['condition']);
		}
		return $db->setQuery($query)->execute();
	}

	protected function deleteTableByDate($options)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->delete($db->quoteName($options['table']));
		if ($options['subqueryTable'])
		{
			$subquery = $db->getQuery(true)->select($db->quoteName($options['subqueryColumn']));
			$subquery->from($db->quoteName($options['subqueryTable']));
			$subquery->where($db->quoteName($options['dateColumn']) . ' < ' . $db->quote($options['cutoffDate']));
			$query->where($db->quoteName($options['subqueryIdColumn']) . ' IN(' . (string) $subquery . ')');
		}
		else
		{
			$query->where($db->quoteName($options['dateColumn']) . ' < ' . $db->quote($options['cutoffDate']));
		}
		return $db->setQuery($query)->execute();
	}

	protected function getContactNote()
	{
		return $this->getRandomFromArray($this->streets) . ' ' . rand(1,999) . ' ' . $this->getLorem(250);
	}

	protected function getDatabaseTables()
	{
		$db = Factory::getDbo();
		$tablesWithPrefix = $db->getTableList();
		$prefix = $db->getPrefix();
		return str_replace($prefix, '#__', $tablesWithPrefix);
	}

	protected function getDate($minDate, $maxDate = 'now')
	{
		$maxDate = ($maxDate === 'now') ? Factory::getDate()->toSql() : $maxDate;
		$minTime = strtotime($minDate);
		$maxTime = strtotime($maxDate);
		$newTime = rand($minTime, $maxTime);
		return date("Y-m-d", $newTime);
	}

	protected function getDilerregData($row)
	{
		$data = [];
		$data['forename'] = $this->getForname($row);
		$data['surname'] = $this->getRandomFromArray($this->surnames);
		$data['address'] = ($row->address) ? $this->getRandomFromArray($this->streets) . ' ' . rand(1,999) : $row->address;
		$data['portalcode'] = ($row->portalcode) ? rand(70000, 79999) : $row->portalcode;
		$data['city'] = ($row->city) ? $this->getRandomFromArray($this->cities) : $row->city;
		$data['state_iso'] = ($row->state_iso) ? 'BW' : $row->state_iso;
		$data['country_iso2'] = ($row->country_iso2) ? 'DE' : $row->country_iso2;
		$data['phonehome'] = ($row->phonehome) ? $this->getPhone() : $row->phonehome;
		$data['phonework'] = ($row->phonework) ? $this->getPhone() : $row->phonework;
		$data['phonemobile'] = ($row->phonemobile) ? $this->getPhone() : $row->phonemobile;
		$data['qualifications'] = ($row->qualifications) ? 'Qualifikationen: ' . $this->getLorem(50) : $row->qualifications;
		$data['registercode'] = '';
		$data['citizenship_iso2'] = $data['country_iso2'];
		$data['phonework2'] = ($row->phonework2) ? $this->getPhone() : $row->phonework2;
		$data['phonemobile2'] = ($row->phonemobile2) ? $this->getPhone() : $row->phonemobile2;
		$data['address2'] = '';
		$data['dob'] = ($row->dob) ? $this->getDate('2005-01-01', '2014-01-01') : $row->dob;
		$data['pob'] = $data['city'];
		$data['picture'] = '';
		$data['notebyteacherptmprivate'] = ($row->notebyteacherptmprivate) ? $this->getLorem(250) : $row->notebyteacherptmprivate;
		$data['student_alert_note'] = ($row->student_alert_note) ? $this->getLorem(250) : $row->student_alert_note;
		$data['student_alert_note_teacher'] = ($row->student_alert_note_teacher) ? $this->getLorem(250) : $row->student_alert_note_teacher;
		$data['contact_note'] = ($row->contact_note) ? $this->getContactNote() : $row->contact_note;
		return $data;
	}

	protected function getForname($row)
	{
		// use gender
		if (($row->salutation && in_array($row->salutation, ['Frau', 'Mrs.', 'Ms.'])) || $row->gender == '2')
		{
			$result = $this->getRandomFromArray($this->forenamesFemale);
		}
		else
		{
			$result = $this->getRandomFromArray($this->forenamesMale);
		}
		return $result;
	}

	public function getDbAgeInfo()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('MAX(created_date)')->from('#__diler_texter');
		$latestDate = $db->setQuery($query)->loadResult();
		$today = Factory::getDate()->toSql();
		$query->clear()->select('DATEDIFF(' . $db->quote(substr($today,0,10)) . ',' . $db->quote(substr($latestDate,0,10)) . ')');
		$daysOld = $db->setQuery($query)->loadResult();
		return ['latestDate' => substr($latestDate,0,10), 'daysOld' => $daysOld];
	}

	protected function processAkeebaOptions()
	{
		$options = ComponentHelper::getParams('com_akeeba');
		$options->set('update_dlid', '');
		return $this->updateOptions('com_akeeba', $options);
	}

	public function refreshDPCalendarCaldavPrincipalsTable()
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->delete('#__dpcalendar_caldav_principals');
		$db->setQuery($query)->execute();
		JLoader::register('DPCalendarControllerCaldav', JPATH_ADMINISTRATOR . '/components/com_dpcalendar/controllers/caldav.php');
		$controller = new DPCalendarControllerCaldav();
		$controller->sync();
	}

	protected function processDpcalendarOptions()
	{
		$options = ComponentHelper::getParams('com_dpcalendar');
		$options->set('downloadid', '');
		return $this->updateOptions('com_dpcalendar', $options);
	}

	protected function processDilerOptions()
	{
		$options = ComponentHelper::getParams('com_diler');
		$options->set('loginContactformEmail', 'demo@bounce.digitale-lernumgebung.de');
		$options->set('schoolname', 'Demo School');
		$options->set('schooladdressZipcode', '79999');
		$options->set('schooladdressCity', 'Stuttgart');
		$options->set('schooladdressCountryIso2', '1');
		$options->set('schooladdressStateIso', '1');
		$options->set('schooladdress', 'Schulstraße 123');
		$options->set('schoolhead', 'George Washington');
		$options->set('schoolheadPosition', 'Principal');
		$options->set('schoolphone', '799999999999');
		$options->set('schoolfax', '799999999999');
		$options->set('schooladdressWebsite', 'digitale-lernumgebung.de');
		$options->set('schoolemail', 'demo@bounce.digitale-lernumgebung.de');
		$options->set('schooltype', 'Public');
		$options->set('schoolid', 'ABC123');
		$options->set('schoollogo', '');
		$options->set('statearms', '');
		$options->set('cityarms', '');
		$options->set('schoolseals', '');
		$options->set('schooloperatorname', 'Demonstration School Operator');
		$options->set('schooloperatoraddressZipcode', '79999');
		$options->set('schooloperatoraddressCity', 'Karlsruhe');
		$options->set('schooloperatoraddress', 'Bahnhofsstraße 123');
		$options->set('schooloperatorphone', '799999999999');
		$options->set('schooloperatoremail', 'demo@bounce.digitale-lernumgebung.de');
		$options->set('schooloperatorcontactperson', 'Charlotte Becker');
		$options->set('accidentinsurancename', 'William Ferrari');
		$options->set('accidentinsuranceaddressZipcode', '79999');
		$options->set('accidentinsuranceaddressCity', 'Mannheim');
		$options->set('accidentinsuranceaddress', 'Schulstraße 321');
		$options->set('accidentinsurancephone', '799999999999');
		$options->set('accidentinsuranceemail', 'demo@bounce.digitale-lernumgebung.de');
		$options->set('accidentinsurancecontactperson', 'Franciszek Strobel');
		$options->set('accidentinsuranceCustomerId', '123');
		$options->set('download_id', '');
		return $this->updateOptions('com_diler', $options);
	}

	/**
	 * Gets first teacher name in learnign group
	 *
	 * @param stdClass $dilerGroup Row from diler_group table
	 * @return string
     */
	protected function getLgName($dilerGroup)
	{
		$this->letters = str_split('ABCDEFGHIJKLMNOPQRLTUVWXYZ');
		$newName = $this->getRandomFromArray($this->letters) . '. ' . $this->getRandomFromArray($this->surnames);
		$nameExists = $this->checkGroupNameExists($newName);
		$newName = $nameExists ? $newName . '-' . $dilerGroup->id : $newName;
		return $newName;
	}

	protected function getLorem($length)
	{
		return substr($this->lorem, 0, $length);
	}

	protected function getPhone()
	{
		return rand(711111111111, 799999999999);
	}

	protected function getRandomFromArray($array)
	{
		$max = count($array) - 1;
		return $array[rand(0,$max)];
	}

	protected function getSuperUserIds()
	{
		$rulesData = Access::getAssetRules(1)->getData();
		$superAdminGroups = array_keys($rulesData['core.admin']->getData());
		$superUsers = [];
		foreach ($superAdminGroups as $group)
		{
			$superUsers = array_merge($superUsers, Access::getUsersByGroup($group));
		}
		return $superUsers;
	}

	protected function getUserData($dilerregData, $row)
	{
		$result = [];
		$result['name'] = $dilerregData['forename'] . ' ' . $dilerregData['surname'];
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_dilerreg/models');
		/** @var DiLerregModelRegistration $registrationModel */
		$registrationModel = BaseDatabaseModel::getInstance('Registration', 'DilerregModel');
		$result['username'] = $registrationModel->getUsername($dilerregData['forename'], $dilerregData['surname']);
		$result['email'] = DMailer::getDummyEmail($result['username']);
		return $result;
	}

	protected function processActivityTask()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_activity_task')
				->set('media = ""')
				->where('media > ""');
		return $db->setQuery($query)->execute();
	}

	protected function processActivityTaskCompleted()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_activity_task_completed')
				->set('answer_from_student = CASE WHEN answer_from_student > "" THEN ' . $db->quote($this->getLorem(100)) . ' ELSE "" END')
				->set('reply_from_teacher = CASE WHEN reply_from_teacher > "" THEN ' . $db->quote($this->getLorem(100)) . ' ELSE "" END')
				->set('student_media = ""')
				->where('answer_from_student > "" OR reply_from_teacher > "" OR student_media > ""');
		return $db->setQuery($query)->execute();
	}

	protected function processGroups()
	{
		// Get list of LG's
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models/');
		$groupCategories = BaseDatabaseModel::getInstance('Group', 'DilerModel')->getDilerGroupCategories();
		$lgCatArray = ArrayHelper::getColumn($groupCategories[1], 'id');
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')
				->from('#__diler_group')
				->where('catid IN(' . implode(',', $lgCatArray) . ')');
		$dilerLgArray = $db->setQuery($query)->loadObjectList();
		// Change names in diler_groups and usergroups
		foreach ($dilerLgArray as $dilerGroup)
		{
			$newName = $this->getLgName($dilerGroup);
			$this->updateGroupName($dilerGroup, $newName);
		}
	}

	/**
	 * Moves dates in db forward by number of days. This is calculated as the difference between today and the last date in the diler_texter table.
	 * Only dates with real values (not 0000-00-00) are adjusted.
	 *
	 * @return null
	 */
	public function moveDatesForward()
	{
		$this->dbAgeInfo = $this->getDbAgeInfo();
		if (! $this->dbAgeInfo['daysOld']) return;
		$db = Factory::getDbo();
		foreach ($this->dateColumns as $table => $columnArray)
		{
			$query = $db->getQuery(true)->update($db->quoteName($table));
			foreach ($columnArray as $column)
			{
				$query->set($db->quoteName($column) . ' = CASE WHEN ' . $db->quoteName($column) . '> "0000-00-00" THEN DATE_ADD( ' . $db->quoteName($column) . ', INTERVAL ' . $this->dbAgeInfo['daysOld'] . ' DAY) ELSE ' .
						$db->quoteName($column) . ' END');
			}
			$result = $db->setQuery($query)->execute();
		}
	}

	protected function processActivityCompleted()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_activity_completed')
				->set('teacher_note = CASE WHEN teacher_note > "" THEN ' . $db->quote($this->getLorem(100)) . ' ELSE "" END')
				->set('teacher_comment = CASE WHEN teacher_comment > "" THEN ' . $db->quote($this->getLorem(100)) . ' ELSE "" END')
				->where('teacher_comment > "" OR teacher_note > ""');
		return $db->setQuery($query)->execute();
	}

	protected function processRegCodes()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->delete('#__dilerreg_registration_code_user_map');
		$db->setQuery($query)->execute();
		$query->clear()->delete('#__dilerreg_registration_codes');
		$db->setQuery($query)->execute();
		$query->clear()->delete('#__dilerreg_parent_student_map')
				->where('student_id_type = 0');
		$db->setQuery($query)->execute();
	}

	protected function processReportFieldHistory()
	{
		// Delete > 2 years old if not type period (type=1)
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->delete('#__diler_report_field_history')
				->where('created < ' . $db->quote($this->cutoffDate2Years));
		$deleteSubquery = $db->getQuery(true)->select('id')
				->from('#__diler_report_field_definition')
				->where('type = 1');
		$query->where('field_id NOT IN(' . (string) $deleteSubquery . ')');
		$db->setQuery($query)->execute();

		// Lorem ipso for non-period types with element types other than 2 (select list) or 4 (teacher)
		$lorem = $this->getLorem(250);
		$query->clear()->update('#__diler_report_field_history')
				->set('field_value = ' . $db->quote($lorem))
				->where('field_value > ""');
		$subquery = $db->getQuery(true)->select('id')
				->from('#__diler_report_field_definition')
				->where('element_type IN(2,4)');
		$query->where('field_id NOT IN(' . (string) $subquery . ')');
		$query->where('field_id NOT IN(' . (string) $deleteSubquery . ')');
		return $db->setQuery($query)->execute();
	}

	protected function processReportPeriod()
	{
		$db = Factory::getDbo();
		$start = $db->quote($this->newPeriodStartDate);
		$end = $db->quote($this->newPeriodEndDate);
		$query = $db->getQuery(true);
		$query->update('#__diler_report_period')
				->set('start_date = ' . $start)
				->set('edit_start_date = ' . $start)
				->set('end_date = ' . $end)
				->set('edit_end_date = ' . $end);
		return $db->setQuery($query)->execute();
	}

	protected function processSchools()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__diler_school')
				->set('email = ' . $db->quote('demo@bounce.digitale-lernumgebung.de'))
				->set('contact_email = '. $db->quote('demo@bounce.digitale-lernumgebung.de'));
		$db->setQuery($query)->execute();
		$query->update('#__diler_school_ministry');
		return $db->setQuery($query)->execute();
	}

	protected function processStudentrecords()
	{
		$options = [];
		// Delete all studentrecord history
		$this->deleteTable('#__diler_studentrecord_history');

		$options['cutoffDate'] = $this->cutoffDate90Days;
		$options['table'] = '#__diler_studentrecord_group_map';
		$options['subqueryTable'] = '#__diler_studentrecord';
		$options['subqueryColumn'] = 'id';
		$options['dateColumn'] = 'effective_date';
		$options['subqueryIdColumn'] = 'studentrecord_id';
		$this->deleteTableByDate($options);

		$options['table'] = '#__diler_studentrecord_tag_map';
		$this->deleteTableByDate($options);

		$options['subqueryTable'] = '';
		$options['table'] = '#__diler_studentrecord';
		$this->deleteTableByDate($options);

		// Lorem ipso
		$lorem = $this->getLorem(250);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_studentrecord')
				->set('entry = ' . $db->quote($lorem))
				->where('entry > ""');
		return $db->setQuery($query)->execute();
	}

	protected function processTeacherMyNotes()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_teacher_mynotes')
				->set('note = ' . $db->quote($this->getLorem(250)))
				->where('note > ""');
		$db->setQuery($query)->execute();
	}

	protected function processTexter()
	{
		$db = Factory::getDbo();
		$this->deleteTable('#__diler_texter', ['column' => 'created_date', 'condition' => ' < ' . $db->quote($this->cutoffDate90Days)]);
		$query = $db->getQuery(true)->update('#__diler_texter')
				->set('title = CASE WHEN title > "" THEN ' . $db->quote($this->getLorem(20)) . ' ELSE "" END')
				->set('message = ' . $db->quote($this->getLorem(250)))
				->where('type = 0');
		$db->setQuery($query)->execute();
	}

	protected function processDilerUsers()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('*')->from('#__dilerreg_users');
		$query->where('user_id NOT IN(' . implode(',', $this->superUserArray) . ')');
		$rows = $db->setQuery($query)->loadObjectList();
		foreach ($rows as $row)
		{
			$dilerregData = $this->getDilerregData($row);
			$this->updateDilerregUsers($dilerregData, $row);
			$userData = $this->getUserData($dilerregData, $row);
			$this->updateUsers($userData, $row);
		}
	}

	protected function processJoomlaArticles()
	{
		$db = Factory::getDbo();
		$metadata = '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}';
		$nullDate = $db->getNullDate();
		$query = $db->getQuery(true)->update('#__content')
				->set('`title` = ' . $db->quote($this->getLorem(20)))
				->set('`alias` = CONCAT("alias-", `id`)')
				->set('`introtext` = CASE WHEN `introtext` > "" THEN ' . $db->quote($this->getLorem(250)) . ' ELSE "" END')
				->set('`fulltext` = CASE WHEN `fulltext` > "" THEN ' . $db->quote($this->getLorem(250)) . ' ELSE "" END')
				->set('`publish_down` = ' . $db->quote($nullDate))
				->set('`metadata` = ' . $db->quote($metadata));
		return $db->setQuery($query)->execute();
	}

	protected function processJoomlaOptions()
	{
		$config = Factory::getConfig();
		$config->set('mailfrom', 'demo@bounce.digitale-lernumgebung.de');
		$config->remove('themeParams');
		$config->remove('theme');
		$config->set('MetaDesc', "Lorem Ipsum dolore set amet.");
		$config->set('MetaKeys', "");
		$config->set('MetaTitle', "");
		$config->set('fromname', "DiLer | Demo School");
		$config->set('ftp_enable', "0");
		$config->set('ftp_enable', '0');
		$config->set('ftp_host', '');
		$config->set('ftp_pass', '');
		$config->set('ftp_port', '');
		$config->set('ftp_root', '');
		$config->set('ftp_user', '');
		$config->set('sitename', "DiLer | Demo School");
		$config->set('smtphost', 'localhost');
		$config->set('smtppass', '');
		$config->set('smtpuser', '');
		$config->set('replyto', '');
		$config->set('replytoname', '');
		$configuration = $config->toString('PHP', array('class' => 'JConfig', 'closingtag' => false));
		$file = JPATH_CONFIGURATION . '/configuration.php';
		if (! Path::setPermissions($file) || ! File::write($file, $configuration))
		{
			throw new RuntimeException(Text::_('Error: Configuration file could not be updated!'));
		}
	}

	/**
	 * Process Joomla users who are not DiLer users and not super admins.
	 *
	 */
	protected function processJoomlaUsers()
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->select('ju.*')->from('#__users AS ju')
				->leftJoin('#__dilerreg_users AS du ON du.user_id = ju.id');
		$query->where('id NOT IN(' . implode(',', $this->superUserArray) . ')')
				->where('du.user_id IS NULL');
		$rows = $db->setQuery($query)->loadObjectList();
		foreach ($rows as $row)
		{
			$data['forename'] = $this->getRandomFromArray($this->forenamesFemale);
			$data['surname'] = $this->getRandomFromArray($this->surnames);
			$row->user_id = $row->id;
			$userData = $this->getUserData($data, $row);
			$this->updateUsers($userData, $row);
		}
	}

	protected function setCutoffDates()
	{
		$cutoff2Years = (new DateTime())->sub(new DateInterval('P2Y'));
		$this->cutoffDate2Years = date_format($cutoff2Years, 'Y-m-d');
		$cutoff90Days = (new DateTime())->sub(new DateInterval('P90D'));
		$this->cutoffDate90Days = date_format($cutoff90Days, 'Y-m-d');
		$cutoff30Days = (new DateTime())->sub(new DateInterval('P30D'));
		$this->cutoffDate30Days = date_format($cutoff30Days, 'Y-m-d');
		$newPeriodEndDate = (new DateTime())->add(new DateInterval('P1M'));
		$this->newPeriodEndDate = date_format($newPeriodEndDate, 'Y-m-d');
		$newPeriodStartDate = $newPeriodEndDate->sub(new DateInterval('P1Y'));
		$this->newPeriodStartDate = date_format($newPeriodStartDate, 'Y-m-d');
	}

	protected function updateDilerregUsers($data, $row)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__dilerreg_users');
		foreach($data as $column => $value)
		{
			$query->set($db->quoteName($column) . '=' . $db->quote($value));
		}
		$query->where('user_id = ' . $row->user_id);
		return $db->setQuery($query)->execute();
	}

	protected function updateGroupName($dilerGroup, $newName)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_group')
				->set('name = ' . $db->quote($newName))
				->where('id = ' . $dilerGroup->id);
		$db->setQuery($query)->execute();
		$query->clear()->update('#__usergroups')
				->set('title = ' . $db->quote($newName))
				->where('id = ' . $dilerGroup->joomla_group_id);
		$db->setQuery($query)->execute();
	}

	protected function updateOptions($componentName, $registry)
	{
		$db = Factory::getDbo();
		$updateParamsQuery = $db->getQuery(true)
			->update($db->quoteName('#__extensions'))
			->set($db->quoteName('params') . ' = ' . $db->quote($registry->toString()))
			->where($db->quoteName('type') . ' = ' . $db->quote('component'))
			->where($db->quoteName('element') . ' = ' . $db->quote($componentName));
		return $db->setQuery($updateParamsQuery)->execute();
	}

	protected function updatePasswords($options)
	{
		if (! $options['password']) return true;
		$passwordHash = UserHelper::hashPassword($options['password']);
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__users')
				->set('password = ' . $db->quote($passwordHash));
		return $db->setQuery($query)->execute();
	}

	protected function updateUsers($userData, $row)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__users');
		foreach ($userData as $column => $value)
		{
			$query->set($db->quoteName($column) . '=' . $db->quote($value));
		}
		$query->where('id = ' . $row->user_id);
		return $db->setQuery($query)->execute();
	}
}
