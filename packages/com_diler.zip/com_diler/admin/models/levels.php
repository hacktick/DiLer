<?php
/**
 * levels to get level lists, export level list.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Utilities\ArrayHelper;

// import the Joomla modellist library
jimport('joomla.application.component.modellist');

/**
 * Levels model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelLevels extends ListModel
{

	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array('a.name','name','a.published','published','a.id','id','language','language','a.ordering','ordering');

			$app = Factory::getApplication();
		}

		parent::__construct($config);
	}

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return string An SQL query
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = Factory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select($this->getState('list.select', 'a.*'));

		// From the di ler table
		$query->from('#__diler_level AS a');

		// Filter by search in title
		$search = $this->getState('filter.search');
		if (! empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('(a.name LIKE ' . $search . ' OR a.description LIKE ' . $search . ')');
			}
		}

		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'asc');
		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		return $query;
	}

	/**
	 * Method to populate publish
	 *
	 * @since 2.5
	 */
	public function populateState($ordering = null, $direction = null)
	{
		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);
        $input = Factory::getApplication()->input;
		$filter_order = $input->get('filter_order', 'ordering');
		$filter_order_Dir = $input->get('filter_order_Dir', 'asc');
		$this->setState('filter_order', $filter_order);
		$this->setState('filter_order_Dir', $filter_order_Dir);
		parent::populateState('ordering', 'asc');
	}

	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.published');
		return parent::getStoreId($id);
	}
}