<?php
/**
 * Competence default model
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use DiLer\Lang\DText;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;

// import Joomla modelform library
jimport('joomla.application.component.modeladmin');

/**
 * Competence model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelCompetence extends AdminModel
{

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 *        * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.message.' . ((int) isset($data[$key]) ? $data[$key] : 0)) or parent::allowEdit($data, $key);
	}

    /**
     * Method to delete one or more records.
     *
     * @param array &$pks An array of record primary keys.
     *
     * @return boolean True if successful, false if an error occurs.
     *
     * @throws Exception
     * @since 12.2
     */
	public function delete(&$pks)
	{
		$pks = $this->checkChangeStatus($pks);
		// Delete the mapped subjects from map table
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_subject_competence_map')
			->where('competence_id IN (' . implode(',', $pks) . ')');
		$result = $db->setQuery($query)->execute();

		if ($result)
		{
			$result = parent::delete($pks);
		}

		return $result;
	}

	public function getTable($type = 'Competence', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (default case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.competence', 'competence', array('control' => 'jform','load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Method to get the script that has to be included on the form-page
	 *
	 * @return string Script files
	 */
	public function getScript()
	{
		return 'administrator/components/com_diler/models/forms/competence.js';
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.competence.data', array());
		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

	/**
	 * Method to get a single competence record.
	 * Override of parent method to also get subjects from subject_competence_map table.
	 *
	 * @param integer $pk The id of the primary key.
	 *
	 * @return bool|JObject Object on success, false on failure.
	 *
	 * @since 12.2
	 */
	public function getItem($pk = null)
	{
		$data = parent::getItem($pk);
		if ($data->id)
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true)
				->select('GROUP_CONCAT(subject_id) AS subject_list, phase_id')
				->from('#__diler_subject_competence_map')
				->where('competence_id = ' . (int) $data->id)
				->group('competence_id');
			$row = $db->setQuery($query)->loadObject();
			if ($subjectList = $row->subject_list)
			{
				$data->subject_list = explode(',', $subjectList);
				$data->phase_id = $row->phase_id;
			}
			else
			{
				$data->subject_list = '';
				$data->phase_id = '';
			}

		}
		return $data;
	}

	/**
	 * Override parent save() method to save rows in subject_competence_map table.
	 *
	 * @param array $data The form data.
	 *
	 * @return boolean True on success, False on error.
	 *
	 * @since 12.2
	 */
	public function save($data)
	{
		$result = parent::save($data);
		if ($result)
		{
			$state = $this->getState();
			$data['id'] = ($data['id']) ? $data['id'] : $this->getState()->get('competence.id');
			$result = $this->saveSubjects($data);
		}
		return $result;
	}

	/**
	 * Method to save rows in subject_competence_map_table
	 *
	 * @param array $data The form data.
	 *
	 * @return boolean True on success, False on error.
	 *
	 * @since 12.2
	 */
	protected function saveSubjects($data)
	{
		// Delete all old rows in mapping table
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->delete('#__diler_subject_competence_map')
			->where('competence_id = ' . (int) $data['id']);
		$result = $db->setQuery($query)->execute();

		// Add new rows if applicable
		if ($result && is_array($data['subject_list']) && $data['subject_list'])
		{
			$query = $db->getQuery(true)
				->insert('#__diler_subject_competence_map')
				->columns(array($db->quoteName('subject_id'),$db->quoteName('competence_id'), $db->quoteName('phase_id')));

			foreach ($data['subject_list'] as $subject)
			{
				$query->values((int) $subject . ',' . (int) $data['id'] . ',' . (int) $data['phase_id']);
			}
			$result = $db->setQuery($query)->execute();
		}
		return $result;
	}

	/**
	 * Checks compchar for any linked compchar rows.
	 * Don't allow trash or delete if found.
	 *
	 * @param array $pks array of compchar ids
	 *
	 * @throws Exception
	 *
	 * @return array array of allowed compchar ids
	 */
	protected function checkChangeStatus($pks)
	{
		$pks = ArrayHelper::toInteger($pks);
		// Make sure there are no compchar rows for these competences
		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('competence_id')
			->from('#__diler_competence_compchar_map')
			->where('competence_id IN(' . implode(',', $pks) . ')')
			->group('competence_id');
		$badPks = $db->setQuery($query)->loadColumn();

		if (is_array($badPks) && $badPks)
		{
			// We need to give a message and also remove these from the $pks array
            Factory::getApplication()->enqueueMessage(DText::plural('N_COMPETENCES_CANNOT_CHANGE_STATUS', count($badPks)),'WARNING');
			$pks = array_diff($pks, $badPks);
			if (empty($pks))
			{
				throw new Exception(Text::_('JGLOBAL_NO_ITEM_SELECTED'));
			}
		}
		return $pks;
	}

    /**
     * Overload of parent publish method.
     * Don't allow trashing if this has mapped compchar rows.
     *
     * @param array &$pks A list of the primary keys to change.
     * @param integer $value The value of the published state.
     *
     * @return boolean True on success.
     *
     * @throws Exception
     * @since 12.2
     */
	public function publish(&$pks, $value = 1)
	{
		if ($value == - 2)
		{
			$pks = $this->checkChangeStatus($pks);
		}
		return parent::publish($pks, $value);
	}
}