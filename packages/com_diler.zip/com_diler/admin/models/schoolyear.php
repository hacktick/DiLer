<?php
/**
 * Schoolyear data edit, update
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2013-2015 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Language\Text;

/**
 * Schoolyear model.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @since 2.5
 */
class DiLerModelSchoolyear extends AdminModel
{

    /**
     * Dynamically adds start and end dates for each marks period to the schoolyear form.
     *
     * @param Form $form Form for the schoolyear.
     * @param array $marksPeriods Assoc. array of information for the defined marks periods. [<period type>] => 'period_calendar_name', 'period_calendar_id', 'rows' => [<period row>]
     * @throws Exception
     */
	public function addMarksPeriodsToForm($form, $marksPeriods)
	{
		foreach ($marksPeriods as $periodType => $periodData)
		{
			foreach ($periodData['rows'] as $row)
			{
				$startFieldName = 'start_date_marks_period-' .  $row->period_id;
				$endFieldName = 'end_date_marks_period-' .  $row->period_id;
				$this->addFieldToForm($form, $startFieldName, $row->start_date);
				$this->addFieldToForm($form, $endFieldName, $row->end_date);
			}
		}
	}

    /**
     * Adds one Form field to the form.
     *
     * @param Form $form Targe form
     * @param string $fieldName New field name to add
     * @param string $value Date in SQL format from database.
     * @throws Exception
     */
	protected function addFieldToForm($form, $fieldName, $value)
	{
		$label = (substr($fieldName, 0, 5) === 'start') ? 'COM_DILER_PERIOD_START_DATE_LABEL' : 'COM_DILER_PERIOD_END_DATE_LABEL';
		$desc = (substr($fieldName, 0, 5) === 'start') ? 'COM_DILER_MARKS_PERIOD_START_DATE_DESC' : 'COM_DILER_MARKS_PERIOD_END_DATE_DESC';
		$xml = '<field name="' . $fieldName . '" type="calendar" required="true" label="' . $label . '"
						description="' . $desc . '" size="22" translateformat="true" filter="none" />';
		$element = new SimpleXMLElement($xml);
		$test = $form->setField($element, null, true, 'marksPeriodsDates');
		$form->setValue($fieldName, null, $value);
	}

	/**
	 * Method override to check if you can edit an existing record.
	 *
	 *
	 * @param array $data An array of input data.
	 * @param string $key The name of the key for the primary key.
	 *        * @return boolean
	 * @since 2.5
	 */
	protected function allowEdit($data = array(), $key = 'id')
	{
		// Check specific edit permission then general edit permission.
		return Factory::getUser()->authorise('core.edit', 'com_diler.message.' . ((int) isset($data[$key]) ? $data[$key] : 0)) or parent::allowEdit($data, $key);
	}

	/**
	 * Gets all of the marks periods defined plus any existing marks period start and end dates for the school year.
	 *
	 * @param stdClass $item  Current school year row
	 * @return array Associative array by marks period type with existing start and end dates if any. SQL null dates are used if no dates exist.
	 */
	public function getMarksPeriods($item)
	{
		$db = Factory::getDbo();
		// Get all period rows for this schoolyear
		$query = $db->getQuery(true)->select('dmp.name AS period_name, dmp.id AS period_id, dmpt.name AS period_calendar, dmpt.id AS period_calendar_id')
				->from('#__diler_marks_period AS dmp')
				->innerJoin('#__diler_marks_period_calendar AS dmpt ON dmp.marks_period_calendar_id = dmpt.id')
				->where('dmpt.published = 1')
				->order('dmpt.name, dmp.ordering');
		$periodRows = $db->setQuery($query)->loadObjectList();

		// Get any existing marks periods for this schoolyear
		$query->clear()->select('*')
				->from('#__diler_schoolyear_marks_period_map')
				->where('schoolyear_id = ' . (int) $item->id);
		$schoolyearRows = $db->setQuery($query)->loadObjectList();
		$periodIdArray = [];
		foreach ($schoolyearRows as $schoolyearRow)
		{
			$periodIdArray[$schoolyearRow->marks_period_id] = $schoolyearRow;
		}

		// Create array by marks period type with any existing data
		$periodsByType = [];
		foreach ($periodRows as $periodRow)
		{
			if (! isset($periodsByType[$periodRow->period_calendar_id]))
			{
				$periodsByType[$periodRow->period_calendar_id] = ['period_calendar' => $periodRow->period_calendar, 'period_calendar_id' => $periodRow->period_calendar_id, 'rows' => []];
			}
			$periodRow->start_date = $db->getNullDate();
			$periodRow->end_date = $db->getNullDate();
			if (isset($periodIdArray[$periodRow->period_id]))
			{
				$periodRow->start_date = $periodIdArray[$periodRow->period_id]->start_date;
				$periodRow->end_date = $periodIdArray[$periodRow->period_id]->end_date;
			}
			$periodsByType[$periodRow->period_calendar_id]['rows'][] = $periodRow;
		}
		return $periodsByType;
	}

	public function getTable($type = 'Schoolyear', $prefix = 'DiLerTable', $config = array())
	{
		return Table::getInstance($type, $prefix, $config);
	}

	// Inserts or updates map row for the schoolyear and marks period.
	protected function insertUpdateMapTable($valueArray, $data)
	{
		$db = Factory::getDbo();
		$result = true;
		$query = $db->getQuery(true)->select('CONCAT(schoolyear_id, ":", marks_period_id)')
				->from('#__diler_schoolyear_marks_period_map')
				->where('schoolyear_id = ' . (int) $data['id']);
		$existingArray = $db->setQuery($query)->loadColumn();
		foreach ($valueArray as $periodId => $dateArray)
		{
			$validStart = DilerHelperUser::filterDate($dateArray['start_date'], "%Y-%m-%d");
			$validEnd = DilerHelperUser::filterDate($dateArray['end_date'], "%Y-%m-%d");
			$query->clear()->set('start_date = ' . $db->quote($validStart))
						->set('end_date = ' . $db->quote($validEnd));
			if (in_array($data['id'] . ':' . $periodId, $existingArray))
			{
				$query->update('#__diler_schoolyear_marks_period_map')
						->where('schoolyear_id = ' . (int) $data['id'])
						->where('marks_period_id = ' . (int) $periodId);
			}
			else
			{
				$query->insert('#__diler_schoolyear_marks_period_map')
						->set('schoolyear_id = ' . (int) $data['id'])
						->set('marks_period_id = ' . (int) $periodId);
			}
			$result = $result && $db->setQuery($query)->execute();
		}
		return $result;
	}

    /**
     * Don't allow the current schoolyear to be unpublished
     *
     * @param array $pks
     * @param int $value
     * @return bool
     * @throws Exception
     */
	public function publish(&$pks, $value = 1)
	{
		foreach ($pks as $pk)
		{
			$table = $this->getTable();
			$table->load($pk);
			if ($table->current && $value !== 1)
			{
				Factory::getApplication()->redirect('index.php?option=com_diler&view=schoolyears', DText::_('SCHOOLYEAR_UNPUBLISH_ERROR'), 'error');
			}
		}
		return parent::publish($pks, $value);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param array $data Data for the form.
	 * @param boolean $loadData True if the form is to load its own data (current case), false if not.
	 * @return bool|Form A Form object on success, false on failure
	 * @since 2.5
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_diler.schoolyear', 'schoolyear',

		array('control' => 'jform','load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Method to get the script that has to be included on the form-page
	 *
	 * @return string Script files
	 */
	public function getScript()
	{
		return 'administrator/components/com_diler/models/forms/reporttype.js';
	}

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return mixed The data for the form.
     * @throws Exception
     * @since 2.5
     */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_diler.edit.schoolyear.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}
		return $data;
	}

	// Override parent method to set current. Only one current allowed.
	public function save($data)
	{
        $startDate = DateTime::createFromFormat ( Text::_('DATE_FORMAT_FILTER_DATE') , $data['start_date']);
        $endDate = DateTime::createFromFormat ( Text::_('DATE_FORMAT_FILTER_DATE') , $data['end_date']);
        $data['start_date'] = $startDate->format("Y-m-d");
        $data['end_date'] = $endDate->format("Y-m-d");

		// Check that end date is > start date
		if ($data['end_date'] <= $data['start_date'])
		{
			$this->setError(DText::_('SCHOOLYEAR_BAD_DATE'));
			return false;
		}
		$data['publish_up'] = $this->_db->getNullDate();
		$data['publish_down'] = $this->_db->getNullDate();
		$result = parent::save($data);
		$data['id'] = $data['id'] ? $data['id'] : $this->getState($this->getName() . '.id');
		if ($result && $data['current'])
		{
			// If this one is current, others must not be.
			$result = $this->setDefault([$data['id']], $data['current']);
		}
		$formData = Factory::getApplication()->input->get('jform', [], 'array');
		$formResult = $this->saveMarksPeriodDates($formData, $data);
		if (! $formResult)
		{
			$this->setError(DText::_('SCHOOLYEAR_BAD_MARKS_PERIOD_DATE'));
			return false;
		}
		return $result;
	}

	protected function saveMarksPeriodDates($formData, $data)
	{
		$valueArray = [];
		$db = Factory::getDbo();
		foreach ($formData as $field => $value)
		{
			if (strpos($field, 'marks_period') === false) continue;
			$nameArray = explode('-', $field);
			if (count($nameArray) !== 2) continue;
			if (! isset($valueArray[$nameArray[1]]))
			{
				$valueArray[$nameArray[1]] = ['start_date' => $db->getNullDate(), 'end_date' => $db->getNullDate()];
			}
            
            $dateValue = DateTime::createFromFormat ( Text::_('DATE_FORMAT_FILTER_DATE') , $value);
            $value = $dateValue->format("Y-m-d");
            
			if (strpos($field, 'start') !== false)
			{
				$valueArray[$nameArray[1]]['start_date'] = $value;
			}
			else
			{
				$valueArray[$nameArray[1]]['end_date'] = $value;
			}
		}
		$result = $this->insertUpdateMapTable($valueArray, $data);
		return $result;
	}

	/**
	 * Sets a schoolyear to current 1 or 0. If 1, then it sets all others to 0.
	 *
	 * @param array $idArray    Array of schoolyear id's.
	 * @param int $current  1 if current, 0 if not current. If current=1, we only set the first one to current=1 and set all others to 0.
	 * @return bool   True on success.
	 */
	public function setDefault($idArray, $current)
	{
		$db = Factory::getDbo();
		if (! $current) return $this->unsetDefault($idArray);

		// Set this one to current and the others to 0
		$query = $db->getQuery(true)->update('#__diler_schoolyear');
		$query->set('current = CASE WHEN id = ' . (int) $idArray[0] . ' THEN 1 ELSE 0 END');
		return $db->setQuery($query)->execute();
	}

	/**
	 * Sets a schoolyear to current = 0 (not the current year).
	 *
	 * @param array  $idArray  Array of schoolyear id's to set to current=0
	 * @return bool   True on success.
	 */
	public function unsetDefault($idArray)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true)->update('#__diler_schoolyear')->set('current = 0')->where('id IN(' . implode(',', $idArray) . ')');
		return $db->setQuery($query)->execute();
	}
}