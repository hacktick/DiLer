ALTER TABLE `#__dilerreg_registration_codes`
    ALTER COLUMN `user_id` SET DEFAULT 0;
ALTER TABLE `#__dilerreg_users`
    ALTER COLUMN `family_id` SET DEFAULT 0,
    ALTER COLUMN `diglu_trainer_country` SET DEFAULT '',
    ALTER COLUMN `diglu_trainer_state` SET DEFAULT '',
    ALTER COLUMN `student_section_id` SET DEFAULT 0,
    ALTER COLUMN `default_section_id` SET DEFAULT 0,
    CHANGE`created` `created` DATETIME NULL,
    ALTER COLUMN `created_by` SET DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    ALTER COLUMN `modified_by` SET DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`first_school_enrollment_date` `first_school_enrollment_date` DATETIME NULL,
    ALTER COLUMN `student_phase_target` SET DEFAULT 0,
    ALTER COLUMN `student_phase_actual` SET DEFAULT 0;
ALTER TABLE `#__dilerreg_registration_codes`
    CHANGE`user_id` `user_id` INT NOT NULL DEFAULT 0,
    CHANGE`lg` `lg` INT NOT NULL DEFAULT 0,
    CHANGE`code` `code` TEXT NULL;

ALTER TABLE `#__diler_school`
    CHANGE`contract_type_id` `contract_type_id` INT NOT NULL DEFAULT 0,
    CHANGE`contact_state_iso` `contact_state_iso` VARCHAR(10) NOT NULL DEFAULT '',
    CHANGE`contact_country_iso2` `contact_country_iso2` VARCHAR(10) NOT NULL DEFAULT '',
    CHANGE`contract_signed_by` `contract_signed_by` INT NOT NULL DEFAULT 0,
    CHANGE`params` `params` TEXT NULL,
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0,
    CHANGE`principal_name` `principal_name` VARCHAR(255) NOT NULL DEFAULT '',
    CHANGE`state_iso` `state_iso` VARCHAR(10) NULL;

ALTER TABLE `#__diler_marks_period_calendar`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '',
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_report_period`
    CHANGE`checked_out` `checked_out` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_report_field_definition`
    CHANGE`checked_out` `checked_out` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_activity`
    CHANGE`duration` `duration` INT(10) NOT NULL DEFAULT 0,
    CHANGE`max_points` `max_points` DECIMAL(10,3) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '';

ALTER TABLE `#__diler_activity_task_completed`
    CHANGE`answer_from_student` `answer_from_student` TEXT NULL,
    CHANGE`reply_from_teacher` `reply_from_teacher` TEXT NULL,
    CHANGE`student_media` `student_media` VARCHAR(255) NOT NULL DEFAULT '',
    CHANGE`confirmed_date` `confirmed_date` DATETIME NULL,
    CHANGE`confirmed_by_id` `confirmed_by_id` INT(11) UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`points` `points` DECIMAL(10, 3) NOT NULL DEFAULT 0,
    CHANGE`task_max_points` `task_max_points` DECIMAL(10, 3) NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_activity_completed`
    CHANGE`confirmed_date` `confirmed_date` DATETIME NULL,
    CHANGE`requested_date` `requested_date` DATETIME NULL,
    CHANGE`mark_calculate_date` `mark_calculate_date` DATETIME NULL,
    CHANGE`confirmed_by_id` `confirmed_by_id` INT(11) UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`accept_deny_by_id` `accept_deny_by_id` INT(11) UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`activity_max_points` `activity_max_points` DECIMAL(10, 3) NOT NULL DEFAULT 0,
    CHANGE`points` `points` DECIMAL(10, 3) NOT NULL DEFAULT 0,
    CHANGE`mark_override_date` `mark_override_date` DATETIME NULL,
    CHANGE`mark_override_by` `mark_override_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`teacher_note` `teacher_note` TEXT NULL,
    CHANGE`teacher_comment` `teacher_comment` TEXT NULL,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`started_date` `started_date` DATETIME NULL,
    CHANGE`completed_date` `completed_date` DATETIME NULL,
    CHANGE`accept_deny_date` `accept_deny_date` DATETIME NULL;

ALTER TABLE `#__diler_activity_grading_method`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '';

ALTER TABLE `#__diler_activity_task`
    CHANGE`max_points` `max_points` DECIMAL(10, 3) NOT NULL DEFAULT 0,
    CHANGE`linktext` `linktext` VARCHAR(255) NOT NULL DEFAULT '',
    CHANGE`media` `media` VARCHAR(255) NOT NULL DEFAULT '',
    CHANGE`calendar_item` `calendar_item` INT NOT NULL DEFAULT 0,
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '';

ALTER TABLE `#__diler_activity_type`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_class_schedule`
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '',
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_cloud`
    CHANGE`params` `params` TEXT NULL,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_compchar`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0,
    CHANGE`old_subject_id` `old_subject_id` INT NOT NULL DEFAULT 0,
    CHANGE`params` `params` TEXT NULL;

ALTER TABLE `#__diler_competence`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0,
    CHANGE`params` `params` TEXT NULL;

ALTER TABLE `#__diler_country`
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '',
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_grid_media`
    CHANGE`catid` `catid` INT(10) NOT NULL DEFAULT 0,
    CHANGE`params` `params` TEXT NULL,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`access` `access` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_group`
    CHANGE`params` `params` TEXT NULL,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '';

ALTER TABLE `#__diler_level`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`langauge` `langauge` CHAR(7) NOT NULL DEFAULT '';

ALTER TABLE `#__diler_log`
    CHANGE`subject_id` `subject_id` INT NOT NULL DEFAULT 0,
    CHANGE`competence_id` `competence_id` INT NOT NULL DEFAULT 0,
    CHANGE`level_id` `level_id` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_marks_history`
    CHANGE`mark` `mark` VARCHAR(50) NOT NULL DEFAULT '',
    CHANGE`comment` `comment` VARCHAR(100) NOT NULL DEFAULT '',
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_marks_period`
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_nimbus_phrase`
    CHANGE`text` `text` VARCHAR(2000) NOT NULL DEFAULT '',
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_nimbus_template`
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`language` `language` CHAR(7) NOT NULL DEFAULT '';

ALTER TABLE `#__diler_pep`
    CHANGE`assessment` `assessment` INT(3) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL;

ALTER TABLE `#__diler_pep_development`
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_phase`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`params` `params` TEXT NULL;

ALTER TABLE `#__diler_region`
    CHANGE`province` `province` VARCHAR(255) NOT NULL DEFAULT '',
    CHANGE`province_code` `province_code` VARCHAR(10) NOT NULL DEFAULT '',
    CHANGE`params` `params` TEXT NULL,
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_report_field_history`
    CHANGE`student_id` `student_id` INT(11) UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`subject_id` `subject_id` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_report_type`
    CHANGE`checked_out` `checked_out` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`params` `params` TEXT NULL;

ALTER TABLE `#__diler_school_ministry`
    CHANGE`params` `params` TEXT NULL,
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_schoolyear`
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`checked_out` `checked_out` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_section`
    CHANGE`checked_out` `checked_out` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL,
    CHANGE`params` `params` TEXT NULL,
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_state`
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_student_compchar_status`
    CHANGE`activities_available` `activities_available` TEXT NULL,
    CHANGE`comment` `comment` TEXT NULL,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_student_competence_status`
    CHANGE`comment` `comment` TEXT NULL,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_student_subject_phase_status`
    CHANGE`comment` `comment` TEXT NULL,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_studentrecord`
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_subject`
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL;

ALTER TABLE `#__diler_texter`
    CHANGE`title` `title` VARCHAR(255) NOT NULL DEFAULT '',
    CHANGE`activity_id` `activity_id` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`activity_type_id` `activity_type_id` INT UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`value` `value` VARCHAR(255) NOT NULL DEFAULT '',
    CHANGE`created_date` `created_date` DATETIME NULL,
    CHANGE`read_date` `read_date` DATETIME NULL,
    CHANGE`receiver_trash_date` `receiver_trash_date` DATETIME NULL,
    CHANGE`sender_trash_date` `sender_trash_date` DATETIME NULL,
    CHANGE`reply_id` `reply_id` INT NOT NULL DEFAULT 0,
    CHANGE`student_id` `student_id` INT(10) NOT NULL DEFAULT 0,
    CHANGE`cloud_id` `cloud_id` INT(10) NOT NULL DEFAULT 0,
    CHANGE`cloud_catid` `cloud_catid` INT(10) NOT NULL DEFAULT 0,
    CHANGE`cloud_group_id` `cloud_group_id` INT(10) NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_user_school_history`
    CHANGE`enroll_start` `enroll_start` DATETIME NULL,
    CHANGE`enroll_end` `enroll_end` DATETIME NULL,
    CHANGE`branch_teacher` `branch_teacher` INT(11) UNSIGNED NOT NULL DEFAULT 0,
    CHANGE`leaving_email_date` `leaving_email_date` DATETIME NULL,
    CHANGE`group_unassign_date` `group_unassign_date` DATETIME NULL;

ALTER TABLE `#__dilerreg_users`
    CHANGE`state_iso` `state_iso` VARCHAR(10) NULL DEFAULT '',
    CHANGE`country_iso2` `country_iso2` VARCHAR(10) NULL DEFAULT '',
    CHANGE`diglu_trainer_country` `diglu_trainer_country` VARCHAR(10) NOT NULL DEFAULT '',
    CHANGE`diglu_trainer_state` `diglu_trainer_state` VARCHAR(10) NOT NULL DEFAULT '',
    CHANGE`citizenship_iso2` `citizenship_iso2` VARCHAR(10) NULL DEFAULT '',
    CHANGE`student_alert_note` `student_alert_note` TEXT NULL,
    CHANGE`student_alert_note_teacher` `student_alert_note_teacher` TEXT NULL,
    CHANGE`first_school_enrollment_date` `first_school_enrollment_date` DATETIME NULL,
    CHANGE`student_phase_target` `student_phase_target` INT(10) NOT NULL DEFAULT 0,
    CHANGE`student_phase_actual` `student_phase_actual` INT(10) NOT NULL DEFAULT 0,
    CHANGE`student_section_id` `student_section_id` INT NOT NULL DEFAULT 0,
    CHANGE`default_section_id` `default_section_id` INT(10) NOT NULL DEFAULT 0,
    CHANGE`created` `created` DATETIME NULL,
    CHANGE`created_by` `created_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`family_id` `family_id` INT NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL;

ALTER TABLE `#__diler_extra_curricular`
    CHANGE`modified` `modified` DATETIME NULL,
    CHANGE`modified_by` `modified_by` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0,
    CHANGE`checked_out_time` `checked_out_time` DATETIME NULL,
    CHANGE`publish_up` `publish_up` DATETIME NULL,
    CHANGE`publish_down` `publish_down` DATETIME NULL;

ALTER TABLE `#__diler_subject_competence_map`
    CHANGE`ordering` `ordering` INT NOT NULL DEFAULT 0;