-- 2020-11-12 New table for region teachers map to schools
CREATE TABLE IF NOT EXISTS `#__diler_school_user_map` (
  `school_id` int(10) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`school_id`,`user_id`),
  KEY `idx_school_id` (`school_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `#__diler_school_user_map`
  ADD CONSTRAINT `FK_school_user_map_school` FOREIGN KEY (`school_id`) REFERENCES `#__diler_school` (`id`),
  ADD CONSTRAINT `FK_school_user_map_user` FOREIGN KEY (`user_id`) REFERENCES `#__dilerreg_users` (`user_id`);

ALTER TABLE `#__diler_school` CHANGE `region_teacher_id` `old_region_teacher_id` int(11) NOT NULL;

INSERT INTO `#__diler_school_user_map` (`school_id`, `user_id`)
  SELECT s.`id`, s.`old_region_teacher_id`
  FROM `#__diler_school` AS s
  WHERE s.`old_region_teacher_id` > 0;

-- 2020-11-19 Add school principal column
ALTER TABLE `#__diler_school` ADD COLUMN `principal_name` varchar(255) NOT NULL AFTER `email`;
