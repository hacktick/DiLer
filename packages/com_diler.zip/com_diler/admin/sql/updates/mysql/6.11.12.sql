-- 2021-10-20 add learning group to stored reports
ALTER TABLE `#__diler_stored_report` ADD COLUMN `learning_group_id` INT(10) UNSIGNED AFTER `schoolyear_id`;
ALTER TABLE `#__diler_stored_report`
    ADD CONSTRAINT `diler_stored_report_usergroups__fk`
        FOREIGN KEY (`learning_group_id`) REFERENCES `#__usergroups` (`id`)
            ON UPDATE CASCADE ON DELETE CASCADE;

-- 2021-10-22 make student_id related to #__users.id
SET FOREIGN_KEY_CHECKS=0;
ALTER TABLE `#__diler_stored_report`
    ADD CONSTRAINT `diler_stored_report_users__fk`
        FOREIGN KEY (`student_id`) REFERENCES `#__users` (`id`)
            ON UPDATE CASCADE ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;