-- 04-08-2023 set student_phase_actual to 0 if not exist in related table
UPDATE `#__dilerreg_users` as u
    LEFT JOIN `#__diler_phase` AS p ON p.id = u.student_phase_actual
SET u.student_phase_actual = 0
WHERE p.id is null
  AND student_phase_actual != 0;

-- 04-08-2023 set student_phase_target to 0 if not exist in related table
UPDATE `#__dilerreg_users` as u
    LEFT JOIN `#__diler_phase` AS p ON p.id = u.student_phase_target
SET u.student_phase_target = 0
WHERE p.id is null
  AND student_phase_target != 0;

-- 04-08-2023 set student_phase_actual and student_phase_target to 0 if role not sutdent
UPDATE `#__dilerreg_users` as u
SET u.student_phase_actual = 0,
    student_phase_target   = 0
WHERE role != 'student'
