UPDATE `#__diler_texter`
    SET read_date = '0000-00-00 00:00:00'
    WHERE read_date IS NULL;

SET sql_mode = '';

UPDATE `#__diler_subject`
SET publish_down = '0000-00-00 00:00:00'
WHERE publish_down != '0000-00-00 00:00:00';