-- 2022-04-25 add datetime field for "date of birthday", we already have `dob` but it's varchar and allows bad formats
ALTER TABLE `#__dilerreg_users` CHANGE `dob` `dob_obsolete` VARCHAR(255);
ALTER TABLE `#__dilerreg_users` ADD COLUMN `dob` DATE NULL AFTER `dob_obsolete`;
