ALTER TABLE `#__dilerreg_users` ADD COLUMN `teacher_role` varchar(255) DEFAULT NULL AFTER `teacher_function`;
ALTER TABLE `#__dilerreg_users` ADD COLUMN `teacher_department` varchar(255) DEFAULT NULL AFTER `teacher_function`;
