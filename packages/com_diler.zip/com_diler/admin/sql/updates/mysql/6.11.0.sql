-- 2020-10-18 creating #__diler_class_schedule table for saving class schedule data
CREATE TABLE IF NOT EXISTS `#__diler_class_schedule` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(100) NOT NULL,
	`published` tinyint(3) NOT NULL DEFAULT '0',
	`publish_up` datetime NOT NULL,
	`publish_down` datetime NOT NULL,
	`created` datetime NOT NULL,
	`created_by` int(10) NOT NULL,
	`modified` datetime NOT NULL,
	`modified_by` int(10) NOT NULL,
	`checked_out` int(10) NOT NULL,
	`checked_out_time` datetime NOT NULL,
	`language` char(7) NOT NULL,
	`ordering` int(11) NOT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2020-12-18 creating #__diler_class_schedule_time_slot table to save time spans for class schedule
CREATE TABLE IF NOT EXISTS `#__diler_class_schedule_time_slot` (
	`class_schedule_id` int(11) NOT NULL,
	`name` varchar(100) NOT NULL,
	`start_time` varchar(10) NOT NULL,
	`end_time` varchar(10) NOT NULL,
	FOREIGN KEY (`class_schedule_id`) REFERENCES `#__diler_class_schedule` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2020-11-2 insert room column into group table in order to extend group with room
ALTER TABLE `#__diler_group` ADD COLUMN `room` int(10) DEFAULT NULL AFTER `description`;

-- 2020-11-2 insert id column into class schedule time slots
ALTER TABLE `#__diler_class_schedule_time_slot` ADD `id` INT PRIMARY KEY AUTO_INCREMENT AFTER `class_schedule_id`;

-- 2020-11-12 groups time and location information table
CREATE TABLE IF NOT EXISTS `#__diler_group_schedule` (
`group_id` int(10) NOT NULL,
`weekday` int(10) NOT NULL,
`location_id` int(10) NOT NULL,
`class_schedule_slot_id` int(10) DEFAULT NULL,
`class_schedule_id` int(10) DEFAULT NULL,
`start_time` varchar(10) NOT NULL,
`end_time` varchar(10) NOT NULL,
`time_type` varchar(10) NOT NULL,
FOREIGN KEY (`group_id`) REFERENCES `#__diler_group` (`id`)
	ON DELETE CASCADE
	ON UPDATE CASCADE,
FOREIGN KEY (`class_schedule_slot_id`) REFERENCES `#__diler_class_schedule_time_slot` (`id`)
  ON DELETE CASCADE
  ON UPDATE CASCADE,
FOREIGN KEY (`class_schedule_id`) REFERENCES `#__diler_class_schedule` (`id`)
  ON DELETE CASCADE
  ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 2020-11-15 Add column for include parents checkbox
ALTER TABLE `#__diler_group` ADD COLUMN `include_parents` BOOL DEFAULT 0 AFTER `description`;

-- 2020-12-10 Add marker so students and parents can set their email as family email address.
ALTER TABLE `#__dilerreg_users` ADD COLUMN `family_email_user_id` INT(11) UNSIGNED DEFAULT 0 AFTER `role`;

-- 2021-1-15 Add standard class schedule so teacher can assign a class schedule to students.
ALTER TABLE `#__dilerreg_users` ADD COLUMN `standard_class_schedule` INT(11) UNSIGNED DEFAULT 0 AFTER `role`;
