ALTER TABLE `#__diler_user_school_history`
    ADD `base_teacher` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `branch_teacher`;

UPDATE `#__diler_user_school_history`
SET `base_teacher` = `branch_teacher`
WHERE `base_school` = 1;

UPDATE `#__diler_user_school_history`
SET `branch_teacher` = 0
WHERE `base_school` = 1;
