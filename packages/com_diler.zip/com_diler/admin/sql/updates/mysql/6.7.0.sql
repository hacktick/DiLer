-- 2020-06-10 Add `contact_note` to dilerreg_users table.
ALTER TABLE `#__dilerreg_users` ADD COLUMN `contact_note` TEXT DEFAULT NULL AFTER `student_alert_note_teacher`;
-- 2020-06-25 Add `ordering` to task_grid_media_map for sorting task medias.
ALTER TABLE `#__diler_activity_task_grid_media_map` ADD COLUMN `ordering` int(11) NOT NULL DEFAULT 0;
