-- 2020-12-06 Drop access_completed column from diler_activity_type table
ALTER TABLE `#__diler_activity_type` DROP COLUMN `access_completed`
