-- 2021-02-10 change field type from BOOLEAN to TINYINT to keep consistency
ALTER TABLE `#__diler_level` MODIFY `display_progressbar` TINYINT(1);

-- 2021-02-27 add building col to diler group table
ALTER TABLE `#__diler_group` ADD COLUMN `room_sub_location` varchar(255) DEFAULT NULL AFTER `description`;

-- 2021-02-27 add room col to group schedule table so room string could be saved
ALTER TABLE `#__diler_group_schedule` ADD COLUMN `room` varchar(255);

-- 2021-02-26 Add enroll dates to mapping table for revised workflow issue #2794
ALTER TABLE  `#__dilerreg_registration_code_user_map` ADD COLUMN `enroll_start` datetime;
ALTER TABLE  `#__dilerreg_registration_code_user_map` ADD COLUMN `enroll_end` datetime;

-- 2021-03-11 Add swimmer field to dilerreg_users table
ALTER TABLE  `#__dilerreg_users` ADD COLUMN `swimmer` tinyint(3) NOT NULL DEFAULT '3' COMMENT '1-yes 2-no 3-unknown' AFTER `student_alert_note_teacher`;
