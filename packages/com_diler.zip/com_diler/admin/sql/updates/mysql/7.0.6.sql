ALTER TABLE `#__diler_class_schedule_time_slot`
DROP COLUMN `start_time_obsolete`,
    DROP COLUMN `end_time_obsolete`;

ALTER TABLE `#__diler_group_schedule`
DROP COLUMN `start_time_obsolete`,
    DROP COLUMN `end_time_obsolete`;