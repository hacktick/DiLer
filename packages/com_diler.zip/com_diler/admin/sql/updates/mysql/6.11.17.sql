-- 2022-05-05 add field for student_particulars
ALTER TABLE `#__dilerreg_users` ADD COLUMN `student_particulars` varchar(255) DEFAULT '' AFTER `student_function`;
