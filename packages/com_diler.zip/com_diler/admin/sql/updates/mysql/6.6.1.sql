-- 2020-06-19 Schema changes for activity type default show media download on task
ALTER TABLE `#__diler_activity_type` ADD `default_show_media_download` TINYINT(1) NOT NULL DEFAULT '1' AFTER `default_offline`;

-- 2020-06-20 Schema changes for activity task default show media download on task
ALTER TABLE `#__diler_activity_task_grid_media_map` ADD `show_media_download` TINYINT(1) NOT NULL DEFAULT '1';
