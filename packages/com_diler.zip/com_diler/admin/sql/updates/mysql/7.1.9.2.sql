CREATE TABLE IF NOT EXISTS `#__dilerauth_user_uuid`
(
    `user_id`              INT,
    `uuid`                 VARCHAR(36),
    FOREIGN KEY (`user_id`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    UNIQUE KEY `unique_user_uuid` (`user_id`, `uuid`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;
