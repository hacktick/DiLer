-- 2021-06-26 creating region and region_teacher table
CREATE TABLE IF NOT EXISTS `#__diler_region` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(100) NOT NULL,
	`params` text NOT NULL,
	`created` datetime NOT NULL,
	`created_by` int(10) NOT NULL,
	`modified` datetime NOT NULL,
	`modified_by` int(10) NOT NULL,
	`checked_out` int(10) NOT NULL,
	`checked_out_time` datetime NOT NULL,
	`published` tinyint(3) NOT NULL DEFAULT 0,
	`publish_up` datetime NOT NULL,
	`publish_down` datetime NOT NULL,
	`ordering` int(11) NOT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `#__diler_region_user_map` (
  `region_id` int(10) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`region_id`,`user_id`),
  KEY `idx_region_id` (`region_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `#__diler_region_user_map`
  ADD CONSTRAINT `FK_diler_region_user_map_region` FOREIGN KEY (`region_id`) REFERENCES `#__diler_region` (`id`),
  ADD CONSTRAINT `FK_diler_region_user_map_user` FOREIGN KEY (`user_id`) REFERENCES `#__dilerreg_users` (`user_id`);

ALTER TABLE `#__diler_school` ADD COLUMN `region_id` int(11) NOT NULL AFTER `base_school`;
ALTER TABLE `#__diler_school` DROP COLUMN `old_region_teacher_id`;

-- 2021-06-23 creating #__diler_pep_assessments table
CREATE TABLE IF NOT EXISTS `#__diler_pep_assessments` (
	`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`initial_situation` TEXT,
	`development_target` TEXT,
	`student_id` INT(11) NOT NULL,
	`subject_group_id` INT(11) NOT NULL,
	`checked_out` INT(10) NOT NULL DEFAULT '0',
	`checked_out_time` DATETIME NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `#__users` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE,
	FOREIGN KEY (`subject_group_id`) REFERENCES `#__diler_group` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE,
	UNIQUE KEY `unique_student_subject` (`student_id`, `subject_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2021-06-23 Adding PEP column to dilerreg users table
ALTER TABLE `#__dilerreg_users` ADD COLUMN `pep_enabled` tinyint(1) DEFAULT 0 AFTER default_section_id;

-- 2021-06-23 create PEP table
CREATE TABLE IF NOT EXISTS `#__diler_pep`
(
    id             INT(11)  NOT NULL AUTO_INCREMENT PRIMARY KEY,
    method         INT(3)   NOT NULL,
    pep_action     TEXT     NOT NULL,
    action_note           TEXT,
    action_implementation INT(3) DEFAULT 0,
    action_followup       INT(3) DEFAULT 0,
    action_success        INT(3) DEFAULT 0,
    description    TEXT     NOT NULL,
    period_from    DATETIME NOT NULL,
    period_to      DATETIME NOT NULL,
    result         TEXT     NOT NULL,
    assessment     INT(3)   NOT NULL,
    school_year_id INT(11)  NOT NULL,
    subject_group_id     INT(11)  NOT NULL,
    student_id     INT(11)  NOT NULL,
    create_by      INT(11)  NOT NULL,
    created        DATETIME NOT NULL,
    modified       DATETIME NOT NULL,
    FOREIGN KEY (subject_group_id) REFERENCES `#__diler_group` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (create_by) REFERENCES `#__users` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (student_id) REFERENCES `#__users` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (school_year_id) REFERENCES `#__diler_schoolyear` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 2021-08-16 create PEP Development table
CREATE TABLE IF NOT EXISTS `#__diler_pep_development`
(
    student_id                INT(11) NOT NULL UNIQUE,
    school_interests          TEXT,
    extracurricular_interests TEXT,
    future_interests          TEXT,
    strengths                 TEXT,
    habits                    TEXT,
    work_methods              TEXT,
    organising_strategies     TEXT,
    social_type               TEXT,
    responsibility_for_myself TEXT,
    responsibility_for_others TEXT,
    responsibility_for_world  TEXT,
    notes                     TEXT,
    checked_out               INT(11)  NOT NULL DEFAULT '0',
    checked_out_time          DATETIME NOT NULL,
    FOREIGN KEY (student_id) REFERENCES `#__users` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- 2021-07-08 New columns for Diglu trainer
ALTER TABLE `#__dilerreg_users` ADD COLUMN `diglu_trainer_state` varchar(10) NOT NULL AFTER `base_school_id`;
ALTER TABLE `#__dilerreg_users` ADD COLUMN `diglu_trainer_country` varchar(10) NOT NULL AFTER `base_school_id`;

-- 2021-07-15 Drop #__diler_school_user_map table
DROP TABLE `#__diler_school_user_map`;
-- 2021-07-16 Add temp field to #__dilerreg_users and #__diler_teacher_mynotes
-- to mark if problematic fields cleaned or NOT
-- If server gets out of memory or hit max execution time, we will ask user to keep trying again
-- until all users get cleaned. If field `cleaned == 1`, it will skip that row, so eventually
-- we will get cleaned all rows and then we will remove this field in next version
ALTER TABLE `#__dilerreg_users` ADD COLUMN `temp_clean` INT (1) DEFAULT 0;
ALTER TABLE `#__diler_teacher_mynotes` ADD COLUMN `temp_clean` INT (1) DEFAULT 0;

-- 2021-07-18 Make sure region name is unique
CREATE UNIQUE INDEX `region_name` ON `#__diler_region` (`name`);

-- 2021-08-06 Add signatory to region table
ALTER TABLE `#__diler_school_ministry` ADD COLUMN `signatory` varchar(255) NOT NULL AFTER `contact_email`;

-- 2021-1-23 Add column for time slot description of group edit
ALTER TABLE `#__diler_group_schedule` ADD COLUMN `time_slot_description` varchar(255) AFTER `time_type`;

-- 2021-08-31 Add Section field to Persona Data table for Students
ALTER TABLE `#__dilerreg_users` ADD COLUMN `student_section_id` INT(11) NOT NULL AFTER `student_phase_actual`;
