-- 09-03-2023 delete unused column
ALTER TABLE `#__dilerreg_registration_codes`
    DROP COLUMN `activation_code`,
    DROP COLUMN `registration_attempts`,
    DROP COLUMN `fam_id`;

ALTER TABLE `#__dilerreg_registration_codes`
    ADD COLUMN `dob` DATE AFTER `student_phase_target`;
-- 17 March 2023 create table to store related schools and diler other groups
CREATE TABLE IF NOT EXISTS `#__diler_group_school_map`
(
    `school_id`        INT(11) NOT NULL,
    `joomla_group_id` INT(10) UNSIGNED NOT NULL,
    CONSTRAINT school_id_group_id_key UNIQUE (school_id, joomla_group_id),
    CONSTRAINT FK_diler_group_school_map_school_id FOREIGN KEY (school_id)
        REFERENCES `#__diler_school` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_diler_group_school_map_group_id FOREIGN KEY (joomla_group_id)
        REFERENCES `#__usergroups` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;

-- 22 March 2023 create table to store related region teachers for student at time of enrollment
CREATE TABLE IF NOT EXISTS `#__diler_student_region_teacher_at_time_of_enrollment`
(
    `student_id` INT(11) NOT NULL,
    `teacher_id` INT(11) NOT NULL,
    CONSTRAINT UC_Person UNIQUE (student_id, teacher_id),
    CONSTRAINT FK_diler_student_region_teacher_student_id FOREIGN KEY (student_id)
        REFERENCES `#__users` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_diler_student_region_teacher_teacher_id FOREIGN KEY (teacher_id)
        REFERENCES `#__users` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE

) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;