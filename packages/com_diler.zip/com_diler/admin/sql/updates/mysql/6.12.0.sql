-- 08-08-2022 create table for PEP methods
CREATE TABLE IF NOT EXISTS `#__diler_pep_methods`
(
    `id`               INT(11)      NOT NULL AUTO_INCREMENT,
    `title`            VARCHAR(100) NOT NULL,
    `checked_out_time` DATETIME              DEFAULT NULL,
    `checked_out`      INT(11)               DEFAULT 0,
    `created`          DATETIME     NOT NULL DEFAULT NOW(),
    `created_by`       INT(11),
    `modified`         DATETIME              DEFAULT NULL,
    `modified_by`      INT(11)               DEFAULT 0,
    FOREIGN KEY (`created_by`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;

-- 08-08-2022 create table for PEP development area
CREATE TABLE IF NOT EXISTS `#__diler_pep_development_area`
(
    `id`               INT(11)      NOT NULL AUTO_INCREMENT,
    `title`            VARCHAR(100) NOT NULL,
    `checked_out_time` DATETIME              DEFAULT NULL,
    `checked_out`      INT(11)               DEFAULT 0,
    `created`          DATETIME     NOT NULL DEFAULT NOW(),
    `created_by`       INT(11),
    `modified`         DATETIME              DEFAULT NULL,
    `modified_by`      INT(11)               DEFAULT 0,
    FOREIGN KEY (`created_by`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;

-- 08-24-2022 add development_area_id to #__diler_pep table
ALTER TABLE `#__diler_pep`
    ADD COLUMN `development_area_id` INT(11) NOT NULL AFTER subject_group_id;

-- 08-25-2022 add development_area_id to #__diler_pep_assessments table
ALTER TABLE `#__diler_pep_assessments`
    ADD COLUMN `development_area_id` INT(11) NOT NULL AFTER subject_group_id;

-- 08-25-2022 make foreign key development_area_id related to #__diler_pep_development_area table
SET FOREIGN_KEY_CHECKS=0;
ALTER TABLE `#__diler_pep_assessments`
    ADD CONSTRAINT `diler_pep_development_area_pep_assessment__fk`
        FOREIGN KEY (`development_area_id`) REFERENCES `#__diler_pep_development_area` (`id`)
            ON UPDATE CASCADE ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

-- 08-29-2022 use development_area_id in unique key
ALTER TABLE `#__diler_pep_assessments`
DROP KEY unique_student_subject,
ADD UNIQUE KEY `unique_student_subject_pep_development_area` (`student_id`, `subject_group_id`, `development_area_id`);

-- 09-07-2022 add create and created_by to pep_assessments
ALTER TABLE `#__diler_pep_assessments`
    ADD COLUMN `created_by` INT(11) NOT NULL,
    ADD COLUMN `created` DATETIME,
    ADD COLUMN `modified_by` INT(11) DEFAULT 0,
    ADD COLUMN `modified` DATETIME,
    ADD COLUMN `published` TINYINT(1) DEFAULT 1;

-- 09-07-2022 add default time for `created`
ALTER TABLE `#__diler_pep_assessments`
MODIFY `created` DATETIME DEFAULT NOW();

-- 09-07-2022 add pep_assessment_id to pep table
ALTER TABLE `#__diler_pep`
    ADD COLUMN `pep_assessment_id` INT(11) NOT NULL AFTER `school_year_id`;

-- 09-07-2022 create backup of pep table as we will maybe delete some of the records
CREATE TABLE `#__diler_pep_diLerBackup` AS SELECT * FROM `#__diler_pep`;

-- 09-07-2022 populate pep_assessment_id in pep table
UPDATE `#__diler_pep` AS pep
    INNER JOIN `#__diler_pep_assessments` AS pa on pa.development_area_id = pep.development_area_id AND
                                                   pa.subject_group_id = pep.subject_group_id AND
                                                   pa.student_id = pep.student_id
SET pep.pep_assessment_id = pa.id;

-- 09-07-2022 delete pep records without pep_assessment_id as it's not valid records
DELETE FROM `#__diler_pep` WHERE `pep_assessment_id` = 0;

-- 09-07-2022 make pep_assessment_id in pep table reference to pep_assessments table
ALTER TABLE `#__diler_pep`
    ADD CONSTRAINT `diler_pep_diler_pep_assessment__fk`
        FOREIGN KEY (`pep_assessment_id`) REFERENCES `#__diler_pep_assessments` (`id`)
            ON UPDATE CASCADE ON DELETE CASCADE;

-- 09-20-2022 drop development_area_id from #__diler_pep table
ALTER TABLE `#__diler_pep`
    DROP COLUMN `development_area_id`;


-- 09-08-2022 create table for PEP goal
CREATE TABLE IF NOT EXISTS `#__diler_pep_goal`
(
    `id`                    INT(11)         NOT NULL AUTO_INCREMENT,
    `title`                 VARCHAR(100)    NOT NULL,
    `description`           TEXT,
    `evaluation_criteria`   TEXT,
    `checked_out_time`      DATETIME        DEFAULT NULL,
    `checked_out`           INT(11)         DEFAULT 0,
    `created`               DATETIME        NOT NULL DEFAULT NOW(),
    `created_by`            INT(11),
    `modified`              DATETIME        DEFAULT NULL,
    `modified_by`           INT(11)         DEFAULT 0,
    FOREIGN KEY (`created_by`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;

-- 09-12-2022 add goal_id to #__diler_pep table
ALTER TABLE `#__diler_pep`
    ADD COLUMN `goal_id` INT(11) AFTER pep_assessment_id;

-- 09-12-2022 make foreign key goal_id related to #__diler_pep_goal table
SET FOREIGN_KEY_CHECKS=0;
ALTER TABLE `#__diler_pep`
    ADD CONSTRAINT `diler_pep_goal_id__fk`
        FOREIGN KEY (`goal_id`) REFERENCES `#__diler_pep_goal` (`id`)
            ON UPDATE CASCADE ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

-- 09-08-2022 delete column result, pep_action, description, evaluation_criteria from #__diler_pep table
ALTER TABLE `#__diler_pep`
    DROP COLUMN `result`,
    DROP COLUMN `pep_action`,
    DROP COLUMN `description`,
    DROP COLUMN `evaluation_criteria`;

ALTER TABLE `#__diler_pep_assessments`
    ADD COLUMN `evaluation_modified_by`          INT(11)  DEFAULT 0 AFTER `development_area_id`,
    ADD COLUMN `evaluation_modified`             DATETIME DEFAULT NULL AFTER `development_area_id`,
    ADD COLUMN `evaluation_note`                 TEXT     DEFAULT '' AFTER `development_area_id`,
    ADD COLUMN `evaluation_follow_up`            TINYINT(1) AFTER `development_area_id`,
    ADD COLUMN `evaluation_development_target`   TINYINT(1) AFTER `development_area_id`,
    ADD COLUMN `evaluation_level_of_achievement` TINYINT(1) AFTER `development_area_id`;