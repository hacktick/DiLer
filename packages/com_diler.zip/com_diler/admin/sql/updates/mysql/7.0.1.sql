-- 31-08-2023 populate first #__diler_studentrecord_history related to studentrecord as it wasn't populated
UPDATE `#__diler_studentrecord_history` as sh
    INNER JOIN `#__diler_studentrecord` as sr ON sh.studentrecord_id = sr.id
SET sh.created = sr.created
WHERE sh.created IS NULL
   OR sh.created = '0000-00-00 00:00:00';

ALTER TABLE `#__diler_pep_development_area`
    CHANGE`checked_out` `checked_out` INT(11) NOT NULL DEFAULT 0;

ALTER TABLE `#__diler_pep_methods`
    CHANGE`checked_out` `checked_out` INT(11) NOT NULL DEFAULT 0;
