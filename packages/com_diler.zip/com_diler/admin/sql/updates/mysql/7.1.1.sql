ALTER TABLE `#__diler_marks_history`
    ADD `mark_cut` BOOL DEFAULT 0 AFTER `phase_id`;

UPDATE `#__diler_studentrecord_history` as sh
    INNER JOIN `#__diler_studentrecord` as sr ON sh.studentrecord_id = sr.id
    SET sh.created = sr.created
WHERE sh.created IS NULL
   OR sh.created = '0000-00-00 00:00:00';