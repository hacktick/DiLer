-- 2022-06-10 add temp field as marker to know do we need to update `dob` field with data from `dob_obsolete`
ALTER TABLE `#__dilerreg_users` ADD COLUMN `dob_not_populated` TINYINT;
