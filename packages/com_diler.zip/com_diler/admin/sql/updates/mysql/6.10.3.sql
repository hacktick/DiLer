-- 2020-11-30 Drop contact state, country from school_ministry table
ALTER TABLE `#__diler_school_ministry` DROP COLUMN `contact_state_iso`;
ALTER TABLE `#__diler_school_ministry` DROP COLUMN `contact_country_iso2`;
