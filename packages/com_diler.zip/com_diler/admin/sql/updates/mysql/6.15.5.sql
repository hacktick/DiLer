-- 25-08-2023 add table for storing when last time phases switched

CREATE TABLE IF NOT EXISTS `#__diler_switch_school_year_history`
(
    `switch_id`   INT(11) AUTO_INCREMENT,
    `switch_date` DATETIME DEFAULT NOW() NOT NULL,
    PRIMARY KEY (`switch_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;

ALTER TABLE `#__diler_phase` ADD COLUMN `is_highest_phase` TINYINT(1) DEFAULT 0 AFTER `value`;