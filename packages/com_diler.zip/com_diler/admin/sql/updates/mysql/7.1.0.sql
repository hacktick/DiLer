ALTER TABLE `#__diler_pep_goal`
    ALTER COLUMN `checked_out` set default NULL;