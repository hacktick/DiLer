-- 2021-05-09 Override all duplicates emails (keeping the original) with dummy addresses
UPDATE `#__users` SET `email` = CONCAT(`username`, `id`, '@bounce.digitale-lernumgebung.de')
WHERE `id` NOT IN (SELECT MIN(u.`id`) FROM `#__users` as u GROUP BY u.`email`);
