-- 2021-01-17 Add `display_progressbar` column to the `diler_level`
ALTER TABLE `#__diler_level` ADD `display_progressbar` BOOLEAN NOT NULL DEFAULT TRUE AFTER `name`;
