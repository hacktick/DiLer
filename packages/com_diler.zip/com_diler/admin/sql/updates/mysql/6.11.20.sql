ALTER TABLE `#__diler_marks_period_calendar`
    ADD COLUMN `delete_marks` INT NOT NULL DEFAULT 2 AFTER `mark_precision`;