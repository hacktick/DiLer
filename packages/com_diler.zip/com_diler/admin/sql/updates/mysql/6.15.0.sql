-- 22-03-2023 Delete #__diler_region_teachers_at_time_of_student_enrolment table since is replaced with #__diler_student_region_teacher_at_time_of_enrollment
DROP TABLE IF EXISTS `#__diler_region_teachers_at_time_of_student_enrolment`;

ALTER TABLE `#__diler_school_ministry`
    ADD COLUMN `send_notifications` TINYINT(1) DEFAULT 0 AFTER `assigned_user_id`;