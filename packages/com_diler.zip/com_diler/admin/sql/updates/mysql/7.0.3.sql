ALTER TABLE `#__diler_activity_completed`
    MODIFY `activity_description` TEXT NULL;

ALTER TABLE `#__diler_activity_type`
    DROP COLUMN `share_tasks`;

ALTER TABLE `#__diler_competence`
    CHANGE`publish_up` `publish_up` DATETIME NULL;