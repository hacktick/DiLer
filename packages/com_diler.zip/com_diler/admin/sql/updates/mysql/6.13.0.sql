-- 23-11-2022 Table to store region teachers
CREATE TABLE IF NOT EXISTS `#__diler_region_teachers_at_time_of_student_enrolment`
(
    `teacher_id`        INT(11) NOT NULL,
    `school_history_id` INT(10) NOT NULL,
    CONSTRAINT FK_drtatose_teacher_id FOREIGN KEY (teacher_id)
        REFERENCES `#__users` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_drtatose_school_history_id FOREIGN KEY (school_history_id)
        REFERENCES `#__diler_user_school_history` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;


-- 12-12-2022 add data_protection_officer_position, data_protection_officer_name, data_protection_officer_address,
-- data_protection_officer_postalcode, data_protection_officer_city, data_protection_officer_phone,
-- data_protection_officer_email, and data_protection_officer_website to #__diler_school_ministry table
ALTER TABLE `#__diler_school_ministry`
    ADD COLUMN `data_protection_officer_position` VARCHAR(255) DEFAULT '',
    ADD COLUMN `data_protection_officer_name` VARCHAR(255) DEFAULT '',
    ADD COLUMN `data_protection_officer_address` VARCHAR(255) DEFAULT '',
    ADD COLUMN `data_protection_officer_postal_code` VARCHAR(255) DEFAULT '',
    ADD COLUMN `data_protection_officer_city` VARCHAR(255) DEFAULT '',
    ADD COLUMN `data_protection_officer_phone` VARCHAR(255) DEFAULT '',
    ADD COLUMN `data_protection_officer_email` VARCHAR(100) DEFAULT '',
    ADD COLUMN `data_protection_officer_website` VARCHAR(255) DEFAULT '';

-- 08-08-2022 create table for user consents
CREATE TABLE IF NOT EXISTS `#__diler_consents`
(
    `id`         INT(11)      NOT NULL AUTO_INCREMENT,
    `type`       VARCHAR(100) NOT NULL,
    `created`    DATETIME     NOT NULL DEFAULT NOW(),
    `created_by` INT(11),
    FOREIGN KEY (`created_by`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;



-- 12-31-2022 create table for ministry and diglu trainers relationship
CREATE TABLE IF NOT EXISTS `#__diler_school_ministry_diglu_trainers_map`
(
    `id`               INT(11)      NOT NULL AUTO_INCREMENT,
    `ministry_id`      INT(11)      NOT NULL,
    `diglu_trainer_id` INT(11)      NOT NULL,
    FOREIGN KEY (`ministry_id`) REFERENCES `#__diler_school_ministry` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (`diglu_trainer_id`) REFERENCES `#__users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    PRIMARY KEY (`id`)
 ) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;
-- 08.01.2023 add first_school_enrollment_date, student_phase_actual, student_phase_target to #__dilerreg_registration_codes
ALTER TABLE `#__dilerreg_registration_codes`
    ADD COLUMN `first_school_enrollment_date` DATE DEFAULT NULL,
    ADD COLUMN `student_phase_actual` INT(10),
    ADD COLUMN `student_phase_target` INT(10);

-- 09-01-2023 create table for languages
CREATE TABLE IF NOT EXISTS `#__diler_languages`
(
    `id`            INT(11)      NOT NULL AUTO_INCREMENT,
    `code`          VARCHAR(10)  NOT NULL,
    `language_name` VARCHAR(255) NOT NULL,
    `native_name`   VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;

-- thanks to https://github.com/forxer/languages-list/blob/master/src/Languages.csv
INSERT INTO `#__diler_languages` (`code`, `language_name`, `native_name`)
values ('aa', 'Afar', 'Afaraf'),
       ('ab', 'Abkhaz', 'аҧсуа бызшәа, аҧсшәа'),
       ('ae', 'Avestan', 'avesta'),
       ('af', 'Afrikaans', 'Afrikaans'),
       ('ak', 'Akan', 'Akan'),
       ('am', 'Amharic', 'አማርኛ'),
       ('an', 'Aragonese', 'aragonés'),
       ('ar', 'Arabic', 'العربية '),
       ('as', 'Assamese', 'অসমীয়া'),
       ('av', 'Avaric', 'авар мацӀ, магӀарул мацӀ'),
       ('ay', 'Aymara', 'aymar aru'),
       ('az', 'Azerbaijani', 'azərbaycan dili'),
       ('az', 'South Azerbaijani ', 'تورکجه‎ '),
       ('ba', 'Bashkir', 'башҡорт теле'),
       ('be', 'Belarusian', 'беларуская мова'),
       ('bg', 'Bulgarian', 'български език'),
       ('bh', 'Bihari', 'भोजपुरी'),
       ('bi', 'Bislama', 'Bislama'),
       ('bm', 'Bambara', 'bamanankan'),
       ('bn', 'Bengali; Bangla ', 'বাংলা'),
       ('bo', 'Tibetan Standard, Tibetan, Central ', 'བོད་ཡིག'),
       ('br', 'Breton', 'brezhoneg'),
       ('bs', 'Bosnian', 'bosanski jezik'),
       ('ca', 'Catalan; Valencian ', 'català, valencià'),
       ('ce', 'Chechen', 'нохчийн мотт'),
       ('ch', 'Chamorro', 'Chamoru'),
       ('co', 'Corsican', 'corsu, lingua corsa'),
       ('cr', 'Cree', 'ᓀᐦᐃᔭᐍᐏᐣ'),
       ('cs', 'Czech', 'čeština, český jazyk'),
       ('cu', 'Old Church Slavonic, Church Slavonic, Old Bulgarian ', 'ѩзыкъ словѣньскъ'),
       ('cv', 'Chuvash', 'чӑваш чӗлхи '),
       ('cy', 'Welsh', 'Cymraeg'),
       ('da', 'Danish', 'dansk'),
       ('de', 'German', 'Deutsch'),
       ('dv', 'Divehi; Dhivehi; Maldivian; ', 'ދިވެހި '),
       ('dz', 'Dzongkha', 'རྫོང་ཁ'),
       ('ee', 'Ewe', 'Eʋegbe'),
       ('el', 'Greek, Modern ', 'ελληνικά'),
       ('en', 'English', 'English'),
       ('eo', 'Esperanto', 'Esperanto'),
       ('es', 'Spanish; Castilian ', 'español, castellano'),
       ('et', 'Estonian', 'eesti, eesti keel'),
       ('eu', 'Basque', 'euskara, euskera'),
       ('fa', 'Persian (Farsi) ', 'فارسی '),
       ('ff', 'Fula; Fulah; Pulaar; Pular ', 'Fulfulde, Pulaar, Pular'),
       ('fi', 'Finnish', 'suomi, suomen kieli'),
       ('fj', 'Fijian', 'vosa Vakaviti'),
       ('fo', 'Faroese', 'føroyskt'),
       ('fr', 'French', 'français, langue française'),
       ('fy', 'Western Frisian ', 'Frysk'),
       ('ga', 'Irish', 'Gaeilge'),
       ('gd', 'Scottish Gaelic; Gaelic ', 'Gàidhlig'),
       ('gl', 'Galician', 'galego'),
       ('gn', 'Guaraní ', 'Avañe''ẽ'),
       ('gu', 'Gujarati', 'ગુજરાતી'),
       ('gv', 'Manx', 'Gaelg, Gailck'),
       ('ha', 'Hausa', 'Hausa, هَوُسَ '),
       ('he', 'Hebrew (modern)', 'עברית'),
       ('hi', 'Hindi', 'हिन्दी, हिंदी'),
       ('ho', 'Hiri Motu ', 'Hiri Motu'),
       ('hr', 'Croatian', 'hrvatski jezik'),
       ('ht', 'Haitian; Haitian Creole ', 'Kreyòl ayisyen'),
       ('hu', 'Hungarian', 'magyar'),
       ('hy', 'Armenian', 'Հայերեն'),
       ('hz', 'Herero', 'Otjiherero'),
       ('ia', 'Interlingua', 'Interlingua'),
       ('id', 'Indonesian', 'Bahasa Indonesia'),
       ('ie', 'Interlingue', 'Originally called Occidental; then Interlingue after WWII'),
       ('ig', 'Igbo', 'Asụsụ Igbo'),
       ('ii', 'Nuosu', 'ꆈꌠ꒿ Nuosuhxop'),
       ('ik', 'Inupiaq', 'Iñupiaq, Iñupiatun'),
       ('io', 'Ido', 'Ido'),
       ('is', 'Icelandic', 'Íslenska'),
       ('it', 'Italian', 'italiano'),
       ('iu', 'Inuktitut', 'ᐃᓄᒃᑎᑐᑦ'),
       ('ja', 'Japanese', '日本語 (にほんご)'),
       ('jv', 'Javanese', 'basa Jawa'),
       ('ka', 'Georgian', 'ქართული'),
       ('kg', 'Kongo', 'KiKongo'),
       ('ki', 'Kikuyu, Gikuyu ', 'Gĩkũyũ'),
       ('kj', 'Kwanyama, Kuanyama ', 'Kuanyama'),
       ('kk', 'Kazakh', 'қазақ тілі'),
       ('kl', 'Kalaallisut, Greenlandic', 'kalaallisut, kalaallit oqaasii'),
       ('km', 'Khmer', 'ខ្មែរ, ខេមរភាសា, ភាសាខ្មែរ'),
       ('kn', 'Kannada', 'ಕನ್ನಡ'),
       ('ko', 'Korean', '한국어 (韓國語), 조선어 (朝鮮語)'),
       ('kr', 'Kanuri', 'Kanuri'),
       ('ks', 'Kashmiri', 'कश्मीरी, كشميري‎'),
       ('ku', 'Kurdish', 'Kurdî, كوردی‎'),
       ('kv', 'Komi', 'коми кыв'),
       ('kw', 'Cornish', 'Kernewek'),
       ('ky', 'Kyrgyz', 'Кыргызча, Кыргыз тили'),
       ('la', 'Latin', 'latine, lingua latina'),
       ('lb', 'Luxembourgish, Letzeburgesch', 'Lëtzebuergesch'),
       ('lg', 'Ganda', 'Luganda'),
       ('li', 'Limburgish, Limburgan, Limburger', 'Limburgs'),
       ('ln', 'Lingala', 'Lingála'),
       ('lo', 'Lao', 'ພາສາລາວ'),
       ('lt', 'Lithuanian', 'lietuvių kalba'),
       ('lu', 'Luba-Katanga', 'Tshiluba'),
       ('lv', 'Latvian', 'latviešu valoda'),
       ('mg', 'Malagasy', 'fiteny malagasy'),
       ('mh', 'Marshallese', 'Kajin M̧ajeļ'),
       ('mi', 'Māori ', 'te reo Māori'),
       ('mk', 'Macedonian', 'македонски јазик'),
       ('ml', 'Malayalam', 'മലയാളം'),
       ('mn', 'Mongolian', 'монгол'),
       ('mr', 'Marathi (Marāṭhī) ', 'मराठी'),
       ('ms', 'Malay', 'bahasa Melayu, بهاس ملايو‎'),
       ('mt', 'Maltese', 'Malti'),
       ('my', 'Burmese', 'ဗမာစာ'),
       ('na', 'Nauru', 'Ekakairũ Naoero'),
       ('nb', 'Norwegian Bokmål ', 'Norsk bokmål'),
       ('nd', 'North Ndebele', 'isiNdebele'),
       ('ne', 'Nepali', 'नेपाली'),
       ('ng', 'Ndonga', 'Owambo'),
       ('nl', 'Dutch', 'Nederlands, Vlaams'),
       ('nn', 'Norwegian Nynorsk', 'Norsk nynorsk'),
       ('no', 'Norwegian', 'Norsk'),
       ('nr', 'South Ndebele', 'isiNdebele'),
       ('nv', 'Navajo, Navaho', 'Diné bizaad, Dinékʼehǰí'),
       ('ny', 'Chichewa; Chewa; Nyanja', 'chiCheŵa, chinyanja'),
       ('oc', 'Occitan', 'occitan, lenga d''òc'),
       ('oj', 'Ojibwe, Ojibwa ', 'ᐊᓂᔑᓈᐯᒧᐎᓐ'),
       ('om', 'Oromo', 'Afaan Oromoo'),
       ('or', 'Oriya', 'ଓଡ଼ିଆ'),
       ('os', 'Ossetian, Ossetic', 'ирон æвзаг'),
       ('pa', 'Panjabi, Punjabi', 'ਪੰਜਾਬੀ, پنجابی‎'),
       ('pi', 'Pāli', 'पाऴि'),
       ('pl', 'Polish', 'język polski, polszczyzna'),
       ('ps', 'Pashto, Pushto', 'پښتو '),
       ('pt', 'Portuguese', 'português'),
       ('qu', 'Quechua', 'Runa Simi, Kichwa'),
       ('rm', 'Romansh', 'rumantsch grischun'),
       ('rn', 'Kirundi', 'Ikirundi'),
       ('ro', 'Romanian', 'limba română'),
       ('ru', 'Russian', 'русский язык'),
       ('rw', 'Kinyarwanda', 'Ikinyarwanda'),
       ('sa', 'Sanskrit (Saṁskṛta)', 'संस्कृतम्'),
       ('sc', 'Sardinian', 'sardu'),
       ('sd', 'Sindhi', 'सिन्धी, سنڌي، سندھی‎'),
       ('se', 'Northern Sami ', 'Davvisámegiella'),
       ('sg', 'Sango', 'yângâ tî sängö'),
       ('si', 'Sinhala, Sinhalese', 'සිංහල'),
       ('sk', 'Slovak', 'slovenčina, slovenský jazyk'),
       ('sl', 'Slovene', 'slovenski jezik, slovenščina'),
       ('sm', 'Samoan', 'gagana fa''a Samoa'),
       ('sn', 'Shona', 'chiShona'),
       ('so', 'Somali', 'Soomaaliga, af Soomaali'),
       ('sq', 'Albanian', 'gjuha shqipe'),
       ('sr', 'Serbian', 'српски језик'),
       ('ss', 'Swati', 'SiSwati'),
       ('st', 'Southern Sotho', 'Sesotho'),
       ('su', 'Sundanese', 'Basa Sunda'),
       ('sv', 'Swedish', 'Svenska'),
       ('sw', 'Swahili', 'Kiswahili'),
       ('ta', 'Tamil', 'தமிழ்'),
       ('te', 'Telugu', 'తెలుగు'),
       ('tg', 'Tajik', 'тоҷикӣ, toğikī, تاجیکی‎'),
       ('th', 'Thai', 'ไทย'),
       ('ti', 'Tigrinya', 'ትግርኛ'),
       ('tk', 'Turkmen', 'Türkmen, Түркмен'),
       ('tl', 'Tagalog', 'Wikang Tagalog, ᜏᜒᜃᜅ᜔ ᜆᜄᜎᜓᜄ᜔'),
       ('tn', 'Tswana', 'Setswana'),
       ('to', 'Tonga (Tonga Islands) ', 'faka Tonga'),
       ('tr', 'Turkish', 'Türkçe'),
       ('ts', 'Tsonga', 'Xitsonga'),
       ('tt', 'Tatar', 'татар теле, tatar tele'),
       ('tw', 'Twi', 'Twi'),
       ('ty', 'Tahitian', 'Reo Tahiti '),
       ('ug', 'Uyghur, Uighur', 'Uyƣurqə, ئۇيغۇرچە‎'),
       ('uk', 'Ukrainian', 'українська мова'),
       ('ur', 'Urdu', 'اردو '),
       ('uz', 'Uzbek', 'O‘zbek, Ўзбек, أۇزبېك‎'),
       ('ve', 'Venda', 'Tshivenḓa'),
       ('vi', 'Vietnamese', 'Tiếng Việt'),
       ('vo', 'Volapük ', 'Volapük'),
       ('wa', 'Walloon', 'walon'),
       ('wo', 'Wolof', 'Wollof'),
       ('xh', 'Xhosa', 'isiXhosa'),
       ('yi', 'Yiddish', 'ייִדיש '),
       ('yo', 'Yoruba', 'Yorùbá'),
       ('za', 'Zhuang, Chuang', 'Saɯ cueŋƅ, Saw cuengh'),
       ('zh', 'Chinese', '中文 (Zhōngwén), 汉语, 漢語'),
       ('zu', 'Zulu', 'isiZulu');

-- 09-01-2023 add column for storing native language that's related to `#__diler_languages`
ALTER TABLE `#__dilerreg_users`
    ADD COLUMN `native_language_id` INT(11) AFTER `swimmer`;

-- 10-01-2023 create table to store related states and diler groups
CREATE TABLE IF NOT EXISTS `#__diler_group_state_map`
(
    `state_id`        INT(11) NOT NULL,
    `joomla_group_id` INT(10) UNSIGNED NOT NULL,
    CONSTRAINT sate_id_group_id_key UNIQUE (state_id, joomla_group_id),
    CONSTRAINT FK_diler_group_state_map_state_id FOREIGN KEY (state_id)
        REFERENCES `#__diler_state` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_diler_group_state_map_group_id FOREIGN KEY (joomla_group_id)
        REFERENCES `#__usergroups` (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4;

-- 13-01-2023 add column for storing native language that's related to `#__diler_languages`
ALTER TABLE `#__diler_school`
    ADD COLUMN `principal_user_id` INT(11) AFTER `principal_name`;

-- 05-02-2023 remove family emails set by students
UPDATE `#__dilerreg_users` AS family
    INNER JOIN `#__dilerreg_users` AS email_owner ON email_owner.user_id = family.family_email_user_id
SET family.family_email_user_id = 0
WHERE family.family_email_user_id != 0
  AND email_owner.role = 'student';


-- 02-02-2023 add column `created` and `created_by` to `#__dilerreg_registration_codes`
ALTER TABLE `#__dilerreg_registration_codes`
    ADD COLUMN `created`    DATETIME     NOT NULL DEFAULT NOW(),
    ADD COLUMN `created_by` INT(11);

-- change the type to  time for the  field 'start_time' and 'end_time' in diler_class_schedule_time_slot
ALTER TABLE `#__diler_class_schedule_time_slot`
    CHANGE COLUMN  `start_time` `start_time_obsolete`  VARCHAR(10),
    CHANGE  COLUMN `end_time` `end_time_obsolete` VARCHAR(10);

ALTER TABLE `#__diler_class_schedule_time_slot`
    ADD COLUMN `start_time` TIME NOT NULL,
    ADD COLUMN `end_time`  TIME NOT NULL;

# -- change the type to  time for the  field 'start_time' and 'end_time' in diler_group_schedule
ALTER TABLE `#__diler_group_schedule`
    CHANGE COLUMN  `start_time` `start_time_obsolete`  VARCHAR(10),
    CHANGE  COLUMN `end_time` `end_time_obsolete` VARCHAR(10);

ALTER TABLE `#__diler_group_schedule`
    ADD COLUMN `id` INT NOT NULL AUTO_INCREMENT,
    ADD PRIMARY KEY (`id`),
    ADD COLUMN `start_time` TIME NOT NULL,
    ADD COLUMN `end_time`  TIME NOT NULL;

-- 10-02-2023 add default value for `checked_out` field in tables: `#__diler_group`, `#__diler_studentrecord` and `#__dilerreg_users`
ALTER TABLE `#__diler_group` CHANGE COLUMN `checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0;
ALTER TABLE `#__diler_studentrecord` CHANGE COLUMN `checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0;
ALTER TABLE `#__dilerreg_users` CHANGE COLUMN `checked_out` `checked_out` INT(10) NOT NULL DEFAULT 0;