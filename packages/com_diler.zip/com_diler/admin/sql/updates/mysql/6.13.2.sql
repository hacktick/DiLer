-- 09-02-2023 add column for storing assigned user id
ALTER TABLE `#__diler_school_ministry`
    ADD COLUMN `assigned_user_id` INT(11) AFTER `email`;


-- 09-02-2023 make foreign key assigned_user_id related to #__users table
SET FOREIGN_KEY_CHECKS=0;
ALTER TABLE `#__diler_school_ministry`
    ADD CONSTRAINT `diler_school_ministry_assigned_user__fk`
        FOREIGN KEY (`assigned_user_id`) REFERENCES `#__users` (`id`)
            ON UPDATE CASCADE ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;