ALTER TABLE `#__diler_school`
    ADD `data_protection_officer_position` VARCHAR(255) DEFAULT '' AFTER `contract_file_name`,
    ADD `data_protection_officer_address` VARCHAR(255) DEFAULT '' AFTER `data_protection_officer_name`,
    ADD `data_protection_officer_deputy_position` VARCHAR(255) DEFAULT '' AFTER `data_protection_officer_email`,
    ADD `data_protection_officer_deputy_address` VARCHAR(255) DEFAULT '' AFTER `data_protection_officer_deputy_name`,
    ADD `data_protection_officer_deputy_phone` VARCHAR(255) DEFAULT '' AFTER `data_protection_officer_deputy_address`,
    ADD `data_protection_officer_deputy_email` VARCHAR(100) DEFAULT '' AFTER `data_protection_officer_deputy_phone`,
    ADD COLUMN `school_authorizing_officer_forename` VARCHAR(255) DEFAULT '' AFTER `data_protection_officer_deputy_email`,
    ADD COLUMN `school_authorizing_officer_surname` VARCHAR(255) DEFAULT '' AFTER `school_authorizing_officer_forename`,
    ADD COLUMN `school_authorizing_officer_department` VARCHAR(255) DEFAULT '' AFTER `school_authorizing_officer_surname`,
    ADD COLUMN `school_authorizing_officer_address` VARCHAR(255) DEFAULT '' AFTER `school_authorizing_officer_department`,
    ADD COLUMN `school_authorizing_officer_phone` VARCHAR(255) DEFAULT '' AFTER `school_authorizing_officer_address`,
    ADD COLUMN `school_authorizing_officer_email` VARCHAR(100) DEFAULT '' AFTER `school_authorizing_officer_phone`;

ALTER TABLE `#__diler_school_ministry`
    ADD `deputy_data_protection_officer_position` VARCHAR(255) DEFAULT '' AFTER `data_protection_officer_website`,
    ADD `deputy_data_protection_officer_name` VARCHAR(255) DEFAULT '' AFTER `deputy_data_protection_officer_position`,
    ADD `deputy_data_protection_officer_address` VARCHAR(255) DEFAULT '' AFTER `deputy_data_protection_officer_name`,
    ADD `deputy_data_protection_officer_postal_code` VARCHAR(255) DEFAULT '' AFTER `deputy_data_protection_officer_address`,
    ADD `deputy_data_protection_officer_city` VARCHAR(255) DEFAULT '' AFTER `deputy_data_protection_officer_postal_code`,
    ADD `deputy_data_protection_officer_phone` VARCHAR(100) DEFAULT '' AFTER `deputy_data_protection_officer_city`,
    ADD `deputy_data_protection_officer_email` VARCHAR(100) DEFAULT '' AFTER `deputy_data_protection_officer_phone`,
    ADD `deputy_data_protection_officer_website` VARCHAR(255) DEFAULT '' AFTER `deputy_data_protection_officer_email`,
    ADD `ministry_authorizing_officer_forename` VARCHAR(255) DEFAULT '' AFTER `deputy_data_protection_officer_website`,
    ADD `ministry_authorizing_officer_surname` VARCHAR(255) DEFAULT '' AFTER `ministry_authorizing_officer_forename`,
    ADD `ministry_authorizing_officer_department` VARCHAR(255) DEFAULT '' AFTER `ministry_authorizing_officer_surname`,
    ADD `ministry_authorizing_officer_address` VARCHAR(255) DEFAULT '' AFTER `ministry_authorizing_officer_department`,
    ADD `ministry_authorizing_officer_phone` VARCHAR(255) DEFAULT '' AFTER `ministry_authorizing_officer_address`,
    ADD `ministry_authorizing_officer_email` VARCHAR(100) DEFAULT '' AFTER `ministry_authorizing_officer_phone`,
    ADD `legal_basis` TEXT AFTER `ministry_authorizing_officer_email`;

UPDATE `#__diler_school_ministry`
    SET `legal_basis` = '§§ 98b und 98 i.V.m. § 28 Abs. 2 HmbSG (Hamburgisches Schulgesetz)'
    WHERE `state_iso` = 'HH';

UPDATE `#__diler_school_ministry`
    SET `legal_basis` = '§ 58 Abs. 1 - NSchG (Niedersächsisches Schulgesetz), § 31 Abs. 1 Satz 3 NSchG,§ 31 Abs. 10 NSchGRdErl. „Beschulung von Kindern beruflich Reisender an allgemeinbildenden Schulen“ RdErl. d. MK v. 11.3.2023 – 25-81624/2 – VORIS 22410, Nr.  5.2'
    WHERE `state_iso` = 'NI';

UPDATE `#__diler_school_ministry`
    SET `legal_basis` = '§ 120 Schulgesetz NRW (Abs. 1, 2 und 5) vom 23.2.2022, Verordnung über die zur Verarbeitung zugelassenen Daten von Schülerinnen, Schülern und Eltern (VO-DV I)'
    WHERE `state_iso` = 'NW';

UPDATE `#__diler_school_ministry`
    SET `legal_basis` = '§ 67 Schulgesetz,§ 33 Abs. 4 der Übergreifenden Schulordnung, § 19 Abs. 4 der Schulordnung für die öffentlichen Grundschulen, § 19 Abs. 4 der Schulordnung für die öffentlichen berufsbildenden Schulen, § 30 Abs. 4 der Schulordnung für die öffentliche Förderschulen,'
    WHERE `state_iso` = 'RP';

UPDATE `#__diler_school_ministry`
    SET `legal_basis` = 'Gesetz über den Schutz personenbezogener Daten im Schulwesen(Schulwesen-Datenschutzgesetz)Schulordnungsgesetz'
    WHERE `state_iso` = 'SL';

UPDATE `#__diler_school_ministry`
    SET `legal_basis` = 'Artikel 6 Absatz 1 Buchst. c DSGVO i.V.m. mit § 30 Abs. 1 SchulG,§ 30 Abs. 2a Satz 1 SchulG i.V.m. § 6 der Zentrale-Stelle-Verordnung Schule'
    WHERE `state_iso` = 'SH';

UPDATE `#__diler_school_ministry`
    SET `legal_basis` = '§ 45a Thüringer Schulgesetz, § 139 „Kinder beruflich Reisender“ Thüringer Schulordnung,§ 57 „Datenschutz“ Thüringer Schulordnung'
    WHERE `state_iso` = 'TH';

