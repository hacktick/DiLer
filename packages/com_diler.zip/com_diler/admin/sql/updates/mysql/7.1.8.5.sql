CREATE TABLE IF NOT EXISTS `#__region_teacher_search_tracking`
(
    id             int auto_increment
        primary key,
    time_of_saving timestamp default CURRENT_TIMESTAMP null,
    event_type     varchar(255)                        null,
    seconds        int                                 null,
    times          int                                 null
);

