ALTER TABLE `#__diler_school`
    ALTER COLUMN `contact_name` SET DEFAULT '',
    ALTER COLUMN `contact_department` SET DEFAULT '',
    ALTER COLUMN `contact_address` SET DEFAULT '',
    ALTER COLUMN `contact_city` SET DEFAULT '',
    ALTER COLUMN `contact_postal_code` SET DEFAULT '',
    ALTER COLUMN `contact_phone` SET DEFAULT '',
    ALTER COLUMN `contact_email` SET DEFAULT ''
;