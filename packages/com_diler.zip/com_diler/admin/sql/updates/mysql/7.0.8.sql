alter table `#__diler_class_schedule`
    add standard_class_schedule int default 0 not null;