-- 2020-10-19 following lines remove report_type from params field in dilerreg_users table to take away student report type from table
UPDATE `#__dilerreg_users` SET params = REPLACE(params,'"report_type":"",','');
UPDATE `#__dilerreg_users` SET params = REPLACE(params,'"report_type":"1",','');
UPDATE `#__dilerreg_users` SET params = REPLACE(params,'"report_type":"2",','');
UPDATE `#__dilerreg_users` SET params = REPLACE(params,'"report_type":"3",','');

-- 2020-10-23 Add contract flag to reporttypes table
ALTER TABLE `#__diler_report_type` ADD COLUMN `report_or_contract` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0-report; 1-contract' AFTER `name`;

-- 2020-10-18 New table for storing teachers are responsible for which groups.
CREATE TABLE IF NOT EXISTS `#__diler_group_responsible_teacher` (
  `teacher_id` int(11) NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  FOREIGN KEY (`teacher_id`) REFERENCES `#__users` (`id`)
      ON DELETE CASCADE
      ON UPDATE CASCADE,
  FOREIGN KEY (`group_id`) REFERENCES `#__usergroups` (`id`)
      ON DELETE CASCADE
      ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 2020-10-16 New table for storing teacher student notes map.
CREATE TABLE IF NOT EXISTS `#__diler_teacher_mynotes` (
  `teacher_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `note` text NOT NULL,
  FOREIGN KEY (`teacher_id`) REFERENCES `#__users` (`id`)
      ON DELETE CASCADE
      ON UPDATE CASCADE,
  FOREIGN KEY (`student_id`) REFERENCES `#__users` (`id`)
      ON DELETE CASCADE
      ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 2020-10-26 Alter #__diler_phase to add `ordering` field
ALTER TABLE `#__diler_phase` ADD COLUMN `ordering` INT(11) NOT NULL DEFAULT '0' AFTER `params`;

