-- 2020-11-01 Add columns for Diglu base school activation
ALTER TABLE `#__diler_school` ADD COLUMN `data_protection_officer_deputy_name` varchar(255) AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `data_protection_officer_email` varchar(255) AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `data_protection_officer_phone` varchar(255) AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `data_protection_officer_name` varchar(255) AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `contract_file_name` varchar(255) AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `contract_signed_date` datetime AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `contract_signed_by` int(11) NOT NULL AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `contract_type_id` int(11) NOT NULL AFTER `base_school`;
ALTER TABLE `#__diler_school` ADD COLUMN `region_teacher_id` int(11) NOT NULL AFTER `email`;
ALTER TABLE `#__dilerreg_registration_codes` ADD COLUMN `base_school_id` varchar(255);
ALTER TABLE `#__dilerreg_registration_codes` ADD COLUMN `report_type_id` int(11);

-- 2020-11-05 change all `@example.org` to `@bounce.digitale-lernumgebung.de`
UPDATE `#__users`
SET `email` = REPLACE(`email`,'@example.org','@bounce.digitale-lernumgebung.de');

-- 2020-11-05 change all `@digitale-lernumgebung.de` to `@bounce.digitale-lernumgebung.de`
UPDATE `#__users`
SET `email` = REPLACE(`email`,'@digitale-lernumgebung.de','@bounce.digitale-lernumgebung.de');
UPDATE `#__users`
SET `email` = REPLACE(`email`,'@bounce.digitale-lernumgebung.de','@digitale-lernumgebung.de')
WHERE `email` LIKE 'support@bounce.digitale-lernumgebung.de';
