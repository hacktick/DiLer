-- 2021-04-01 Add base_school_teacher column to map table to support base school activation workflow
ALTER TABLE  `#__dilerreg_registration_code_user_map` ADD COLUMN `base_school_teacher` tinyint(3) NOT NULL DEFAULT 0 COMMENT '1=Base School Teacher';

-- 2021-04-02 Add email dates to school history to support automatic group unassign plugin for Diglu
ALTER TABLE  `#__diler_user_school_history` ADD COLUMN `leaving_email_date` datetime;
ALTER TABLE  `#__diler_user_school_history` ADD COLUMN `group_unassign_date` datetime;
