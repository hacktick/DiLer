alter table `#__diler_class_schedule`
    modify `publish_up` datetime null;

alter table `#__diler_class_schedule`
    modify `publish_down` datetime null;

alter table `#__diler_class_schedule`
    modify `created` datetime null;

alter table `#__diler_class_schedule`
    modify `created_by` int null;

alter table `#__diler_class_schedule`
    modify `modified` datetime null;

alter table `#__diler_class_schedule`
    modify `modified_by` int null;

alter table `#__diler_class_schedule`
    modify `checked_out` int null;

alter table `#__diler_class_schedule`
    modify `checked_out_time` datetime null;

alter table `#__diler_class_schedule`
    modify `language` char(7) null;

alter table `#__diler_class_schedule`
    modify `ordering` int null;