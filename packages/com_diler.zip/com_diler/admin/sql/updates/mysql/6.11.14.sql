-- 2020-06-19 Schema changes for activity type default show media download on task, remove default_show_media_download column
ALTER TABLE `#__diler_activity_type` DROP COLUMN `default_show_media_download`;

-- 2022-01-14 Schema changes for activity task default show media download on task, remove show_media_download column
ALTER TABLE `#__diler_activity_task_grid_media_map` DROP COLUMN `show_media_download`;
-- 2021-06-12 Add `nickname` to dilerreg_users table.
ALTER TABLE `#__dilerreg_users` ADD COLUMN `nickname` varchar(255) DEFAULT '' AFTER `forename`;
ALTER TABLE `#__dilerreg_registration_codes` ADD COLUMN `nickname` varchar(255) DEFAULT '' AFTER `first_name`;
