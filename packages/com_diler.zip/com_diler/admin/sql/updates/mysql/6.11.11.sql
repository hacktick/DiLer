-- 2021-09-17 add evaluation_criteria field to pep table
ALTER TABLE `#__diler_pep` ADD COLUMN `evaluation_criteria` TEXT NOT NULL AFTER `result`;

-- 2021-09-17 delete spam users
DELETE FROM `#__users` WHERE username LIKE '%https://apple.com%';

-- 2921-09-25 Changes to region & school table for issue 3140
ALTER TABLE `#__diler_region` DROP COLUMN `name`;

ALTER TABLE `#__diler_region` ADD COLUMN `longitude` DECIMAL(8,5) AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `latitude` DECIMAL(8,5) AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `community_code` varchar(10) NOT NULL AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `community` varchar(255) NOT NULL AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `province_code` varchar(10) NOT NULL AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `province` varchar(255) NOT NULL AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `state_iso` varchar(10) NOT NULL AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `city` varchar(255) NOT NULL AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `postal_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `id`;
ALTER TABLE `#__diler_region` ADD COLUMN `country_iso2` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `id`;

DELETE FROM `#__diler_region_user_map`;
DELETE FROM `#__diler_region`;

CREATE UNIQUE INDEX `idx_region_country_postal_code` ON `#__diler_region` (`country_iso2`, `postal_code`);

ALTER TABLE `#__diler_school` DROP COLUMN `region_id`;
CREATE INDEX `idx_school_country_postal_code` ON `#__diler_school` (`country_iso2`, `postal_code`);

