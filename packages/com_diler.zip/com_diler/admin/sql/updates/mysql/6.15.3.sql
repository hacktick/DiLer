-- 14-06-2023 add field to #__diler_cloud to mark is file upload to private folder
ALTER TABLE `#__diler_cloud`
    ADD COLUMN `is_user_to_user_upload` TINYINT(1) DEFAULT 0 AFTER `catid`;