ALTER TABLE `#__dilerreg_users`
    ALTER COLUMN `native_language_id` SET DEFAULT 0;