ALTER TABLE `#__diler_region`
    DROP KEY `idx_region_country_postal_code`;

CREATE UNIQUE INDEX `idx_region_country_state_postal_code_city`
    ON `#__diler_region` (`country_iso2`,`state_iso`, `postal_code`, `city`);