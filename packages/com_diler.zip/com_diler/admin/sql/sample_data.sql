INSERT INTO `dmql_diler_subject` (`id`, `asset_id`, `name`, `description`, `points`, `lowest`, `highest`, `catid`, `params`) VALUES
(1, 341, 'Sport', '//description', 50, 2, 8, 0, '{"show_category":""}'),
(2, 342, 'Musik', '//description', 0, 0, 0, 0, '{"show_category":""}'),
(3, 343, 'Kunst', '//description', 0, 0, 0, 0, '{"show_category":""}'),
(4, 344, 'ITG', '//description', 0, 0, 0, 0, '{"show_category":""}'),
(5, 345, 'Religion', '//description', 0, 0, 0, 0, '{"show_category":""}'),
(6, 346, 'Maths', '//description', 0, 0, 0, 0, '{"show_category":""}'),
(7, 0, 'German', '//description', 70, 2, 9, 0, '{"show_category":""}'),
(8, 0, 'Englisch', '//description', 0, 0, 0, 0, '{"show_category":""}'),
(9, 0, 'Geschichte', '//description', 0, 0, 0, 0, '{"show_category":""}'),
(10, 0, 'Technik', '//description', 60, 3, 8, 0, '{"show_category":""}');

INSERT INTO `dmql_diler_competence` (`id`, `asset_id`, `name`, `description`, `icon`, `params`) VALUES
(1, 0,  'Calculation', '//description', 'images/calculation_icons.png', '{"show_competence":""}'),
(2, 0,  'Space  and  shape', '//description', 'images/space_and_shape.png', '{"show_competence":""}'),
(3, 0, 'Units', '//description', 'images/unites.png', '{"show_competence":""}'),
(4, 347,  'Messuring', '//description', 'images/dilermanager/messuring.png', '{"show_competence":""}'),
(5, 348,  'numbers', '//description', 'images/dilermanager/numbers.png', '{"show_competence":""}'),
(6, 349,  'Kopf- rechnen', '//description', 'images/dilermanager/kopf_rechen.png', '{"show_competence":""}'),
(7, 350, 'EKM', '//description', 'images/dilermanager/ekm.png', '{"show_competence":""}');

INSERT INTO `dmql_diler_level` (`id`, `asset_id`, `name`, `description`, `params`) VALUES
(1, 0, 'Expert (E)', '//description', '{"show_category":""}'),
(2, 0, 'Minimum  (M)', '//description', '{"show_category":""}'),
(3, 0, 'Regular (R)', '//description', '{"show_category":""}');

INSERT INTO `dmql_diler_compchar` (`id`, `asset_id`,`subject_id`, `name`, `description`, `competence_id`, `level_id`, `params`) VALUES
(1, 0, 6, 'I can calculate small numbers', '//description', 1, 1, '{"show_COMPCHAR":""}'),
(2, 0, 6, 'I can calculate normal numbers', '//description', 1, 2, '{"show_COMPCHAR":""}'),
(3, 0, 6, 'I can calculate big numbers', '//description', 1, 3, '{"show_COMPCHAR":""}'),
(4, 0, 6, 'Ich kann zueinander parallele und senkrechte Geraden und Strecken erkennen und zeichnen.\r\n', '//description', 2, 1, '{"show_COMPCHAR":""}'),
(5, 0, 6, 'Ich kann geometrische Figuren der Ebene benennen, zeichnen und miteinander in Beziehung setzen\r\n', '//description', 2, 2, '{"show_COMPCHAR":""}'),
(6, 0, 6, 'Ich kann geometrische Figuren zu Körpern erweitern. Diese Körper kann ich benennen, zeichnen, herstellen und sie miteinander in Beziehung setzen. \r\n', '//description', 2, 3, '{"show_COMPCHAR":""}'),
(7, 0, 6, 'Ich habe eine Vorstellung von den mathematischen Größen „Längen“, „Massen“, „Zeit“ und „Geld“.\r\n', '//description', 3, 1, '{"show_COMPCHAR":""}'),
(8, 0, 6, 'Ich kenne mathematische Größen mit den dazugehörigen Einheiten und kann damit Anwendungsaufgaben lösen.\r\n', '//description', 3, 2, '{"show_COMPCHAR":""}'),
(9, 0, 6, 'Ich gehe sicher mit den mathematischen Größen um und kann verschiedene Einheiten ineinander umwandeln. Mein Vorgehen kann ich begründen. \r\n', '//description', 3, 3, '{"show_COMPCHAR":""}'),
(10, 0, 6, 'Ich kenne den Unterschied zwischen Flächeninhalt und Umfang einer Figur und kann verschiedene Flächen miteinander vergleichen.\r\n', '//description', 4, 1, '{"show_COMPCHAR":""}'),
(11, 0, 6, 'Ich kann Flächeninhalt und Umfang von Rechtecken berechnen und damit Anwendungsaufgaben lösen. \r\n', '//description', 4, 2, '{"show_COMPCHAR":""}'),
(12, 351, 6, 'Ich kann die Formeln für die Berechnung von Flächeninhalt und Umfang von Rechtecken nachvollziehen und erklären.\r\n', '//description', 4, 3, '{"show_COMPCHAR":""}'),
(13, 352, 6, 'Ich kann erklären, was natürliche Zahlen sind und kann diese der Größe nach ordnen\r\n', '//description', 5, 1, '{"show_COMPCHAR":""}'),
(14, 353, 6, 'Ich kann Zahlen sinnvoll runden und anschaulich darstellen.\r\n', '//description', 5, 2, '{"show_COMPCHAR":""}'),
(15, 354, 6, 'Ich kann Zahlen aus verschiedenen Darstellungen herauslesen und mathematisch deuten.\r\n', '//description', 5, 3, '{"show_COMPCHAR":""}'),
(16, 355, 6, 'Ich kann einfache Kopfrechenaufgaben lösen.\r\n', '//description', 6, 1, '{"show_COMPCHAR":""}'),
(17, 356, 6, 'Ich kann schwierigere Kopfrechenaufgaben lösen, indem ichKopfrechenstrategien anwende. \r\n', '//description', 6, 2, '{"show_COMPCHAR":""}'),
(18, 357, 6, 'Ich kann Kopfrechenstrategien verständlich erläutern.\r\n', '//description', 6, 3, '{"show_COMPCHAR":""}'),
(19, 358, 6, 'Ich kann einfache offene Problemstellungen nach vorgegebenen Strategien lösen, dies präsentieren und meine Vorgehensweise erklären.\r\n', '//description', 7, 1, '{"show_COMPCHAR":""}'),
(20, 359, 6, 'Ich kann einfache offene Problemstellungen mit eigenen Strategien lösen, dies präsentieren und meine Vorgehensweise erklären.\r\n', '//description', 7, 2, '{"show_COMPCHAR":""}'),
(21, 360, 6, 'Ich kann komplexere offene Problemstellungen mit eigenen Strategien lösen, dies präsentieren und meine Vorgehensweise erklären.\r\n', '//description', 7, 3, '{"show_COMPCHAR":""}');

INSERT INTO `dmql_diler_exercise` (`id`, `asset_id`, `compchar_id`, `name`, `description`, `task`, `params`) VALUES
(1, 0, 1, 'Exercise 1', '//description', '', '{"show_exercise":""}'),
(2, 0, 1, 'Exercise 2', '//description', '', '{"show_exercise":""}'),
(3, 0, 1, 'Exercise 3', '//description', '', '{"show_exercise":""}'),
(4, 0, 1, 'Exercise 4', '//description', '', '{"show_exercise":""}'),
(5, 0, 1, 'Exercise 5', '//description', '', '{"show_exercise":""}');



/*Table structure for table `dmql_newsfeeds` */

DROP TABLE IF EXISTS `dmql_newsfeeds`;

CREATE TABLE `dmql_newsfeeds` (
  `catid` int(11) NOT NULL default '0',
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `alias` varchar(255) character set utf8 collate utf8_bin NOT NULL default '',
  `link` varchar(200) NOT NULL default '',
  `filename` varchar(200) default NULL,
  `published` tinyint(1) NOT NULL default '0',
  `numarticles` int(10) unsigned NOT NULL default '1',
  `cache_time` int(10) unsigned NOT NULL default '3600',
  `checked_out` int(10) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `rtl` tinyint(4) NOT NULL default '0',
  `access` int(10) unsigned NOT NULL default '0',
  `language` char(7) NOT NULL default '',
  `params` text NOT NULL,
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL default '0',
  `created_by_alias` varchar(255) NOT NULL default '',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL default '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dmql_newsfeeds` */



/*Table structure for table `dmql_raster_test` */

DROP TABLE IF EXISTS `dmql_raster_test`;

CREATE TABLE `dmql_raster_test` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(256) NOT NULL,
  `status` tinyint(1) NOT NULL default '0',
  `category_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `created_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `dmql_raster_test` */

insert  into `dmql_raster_test`(`id`,`title`,`status`,`category_id`,`user_id`,`created_date`) values (2,'Test 1',1,1,43,'2012-09-01'),(3,'Test 2',1,1,43,'2012-09-02'),(4,'Test 3',-1,1,43,'2012-09-03');



/*Table structure for table `dmql_raster_pretest_screen` */

DROP TABLE IF EXISTS `dmql_raster_pretest_screen`;

CREATE TABLE `dmql_raster_pretest_screen` (
  `id` int(10) NOT NULL auto_increment,
  `category_id` int(10) NOT NULL,
  `title` varchar(256) NOT NULL,
  `image_src` varchar(256) default NULL,
  `no_of_test` tinyint(2) NOT NULL,
  `min_description` varchar(1024) default NULL,
  `reg_description` varchar(1024) default NULL,
  `exp_description` varchar(1024) default NULL,
  `publish` tinyint(1) NOT NULL default '0',
  `created_date` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `dmql_raster_pretest_screen` */

insert  into `dmql_raster_pretest_screen`(`id`,`category_id`,`title`,`image_src`,`no_of_test`,`min_description`,`reg_description`,`exp_description`,`publish`,`created_date`) values (1,1,'Calculation',NULL,5,'I can calculate small numbers\r\n','I can calculate normal numbers','I can calculate big numbers\r\n',1,'2012-09-01'),(2,1,'SPACE AND Shape',NULL,5,'Ich kann zueinander parallele und senkrechte Geraden und Strecken erkennen und zeichnen.','Ich kann geometrische Figuren der Ebene benennen, zeichnen und miteinander in Beziehung setzen\r\n','Ich kann geometrische Figuren zu KÃ¶rpern erweitern. Diese KÃ¶rper kann ich benennen, zeichnen, herstellen und sie miteinander in Beziehung setzen. \r\n',1,'2012-09-01'),(3,1,'Units',NULL,5,'Ich habe eine Vorstellung von den mathematischen GrÃ¶ÃŸen â€žLÃ¤ngenâ€œ, â€žMassenâ€œ, â€žZeitâ€œ und â€žGeldâ€œ.','Ich kenne mathematische GrÃ¶ÃŸen mit den dazugehÃ¶rigen Einheiten und kann damit Anwendungsaufgaben lÃ¶sen.','Ich gehe sicher mit den mathematischen GrÃ¶ÃŸen um und kann verschiedene Einheiten ineinander umwandeln. Mein Vorgehen kann ich begrÃ¼nden. ',1,'2012-09-01'),(4,1,'Messuring',NULL,5,'Ich kenne den Unterschied zwischen FlÃ¤cheninhalt und Umfang einer Figur und kann verschiedene FlÃ¤chen miteinander vergleichen.','Ich kann FlÃ¤cheninhalt und Umfang von Rechtecken berechnen und damit Anwendungsaufgaben lÃ¶sen. ','Ich kann die Formeln fÃ¼r die Berechnung von FlÃ¤cheninhalt und Umfang von Rechtecken nachvollziehen und erklÃ¤ren.',1,'2012-09-01'),(5,1,'Numbers',NULL,5,'Ich kann erklÃ¤ren, was natÃ¼rliche Zahlen sind und kann diese der GrÃ¶ÃŸe nach ordnen\r\n','Ich kann Zahlen sinnvoll runden und anschaulich darstellen.\r\n','Ich kann Zahlen aus verschiedenen Darstellungen herauslesen und mathematisch deuten.\r\n',1,'2012-09-01'),(6,2,'Kopf-rechnen',NULL,5,'Ich kann einfache Kopfrechenaufgaben lÃ¶sen.\r\n','Ich kann schwierigere Kopfrechenaufgaben lÃ¶sen, indem ichKopfrechenstrategien anwende. \r\n','Ich kann Kopfrechenstrategien verstÃ¤ndlich erlÃ¤utern.\r\n',1,'2012-09-01'),(7,2,'EKM',NULL,5,'Ich kann einfache offene Problemstellungen nach vorgegebenen Strategien lÃ¶sen, dies prÃ¤sentieren und meine Vorgehensweise erklÃ¤ren.','Ich kann einfache offene Problemstellungen mit eigenen Strategien lÃ¶sen, dies prÃ¤sentieren und meine Vorgehensweise erklÃ¤ren.\r\n','Ich kann komplexere offene Problemstellungen mit eigenen Strategien lÃ¶sen, dies prÃ¤sentieren und meine Vorgehensweise erklÃ¤ren.\r\n',1,'2012-09-01');


/*Table structure for table `dmql_raster_exercise_result` */

DROP TABLE IF EXISTS `dmql_raster_exercise_result`;

CREATE TABLE `dmql_raster_exercise_result` (
  `id` int(10) NOT NULL auto_increment,
  `exercise_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `exercise_result` tinyint(1) NOT NULL default '0',
  `publish` tinyint(1) NOT NULL default '0',
  `created_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `dmql_raster_exercise_result` */

insert  into `dmql_raster_exercise_result`(`id`,`exercise_id`,`user_id`,`exercise_result`,`publish`,`created_date`) values (1,1,43,1,1,NULL),(2,2,43,1,1,NULL),(3,3,43,-1,1,NULL);

/*Table structure for table `dmql_raster_exercise_table` */

DROP TABLE IF EXISTS `dmql_raster_exercise_table`;

CREATE TABLE `dmql_raster_exercise_table` (
  `id` int(10) NOT NULL auto_increment,
  `category_id` int(10) NOT NULL,
  `test_category_id` int(10) NOT NULL,
  `title` varchar(256) NOT NULL,
  `publish` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `dmql_raster_exercise_table` */

insert  into `dmql_raster_exercise_table`(`id`,`category_id`,`test_category_id`,`title`,`publish`) values (1,6,1,'Exercise 1',1),(2,6,1,'Exercise 2',1),(3,6,1,'Exercise 3',1),(4,6,1,'Exercise 4',1);


/*Table structure for table `dmql_raster_category` */

DROP TABLE IF EXISTS `dmql_raster_category`;

CREATE TABLE `dmql_raster_category` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `dmql_raster_category` */

insert  into `dmql_raster_category`(`id`,`name`) values (1,'Sports'),(2,'Musik'),(3,'Kunst'),(4,'ITG'),(5,'Religion'),(6,'Maths'),(7,'German'),(8,'Englisch'),(9,'Geschichte'),(10,'Technik');

/*Table structure for table `dmql_raster_news` */

DROP TABLE IF EXISTS `dmql_raster_news`;

CREATE TABLE `dmql_raster_news` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(256) NOT NULL,
  `category_id` int(10) NOT NULL,
  `teacher_id` int(10) NOT NULL,
  `student_id` int(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `dmql_raster_news` */

