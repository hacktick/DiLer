SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Table structure for table `#__diler_compchar`
--

CREATE TABLE IF NOT EXISTS `#__diler_compchar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) DEFAULT NULL,
  `name` text NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) NOT NULL,
  `checked_out` int(10) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `access` int(10) NOT NULL,
  `language` char(7) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `subject_id` int(11) NOT NULL,
  `competence_id` int(11) NOT NULL,
  `level_id` int(10) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_competence_level` (`competence_id`,`level_id`),
  KEY `idx_level_id` (`level_id`),
  KEY `idx_competence_id` (`competence_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_competence`
--

CREATE TABLE IF NOT EXISTS `#__diler_competence` (
  `asset_id` int(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `phase_id` int(11) NOT NULL DEFAULT '1',
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `created_by` int(10) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) NOT NULL,
  `checked_out` int(10) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `access` int(10) NOT NULL,
  `language` char(7) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_phase_id` (`phase_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_exercise`
--

CREATE TABLE IF NOT EXISTS `#__diler_exercise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) DEFAULT NULL,
  `compchar_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `task` varchar(255) NOT NULL,
  `duration` text NOT NULL,
  `params` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(10) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) NOT NULL,
  `checked_out` int(10) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `access` int(10) NOT NULL,
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_compchar_id` (`compchar_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_exercise_completed`
--

CREATE TABLE IF NOT EXISTS `#__diler_exercise_completed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exercise_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `confirmed_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_exercise_id` (`exercise_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_extra_curricular`
--

CREATE TABLE IF NOT EXISTS `#__diler_extra_curricular` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `created_by` int(10) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) NOT NULL,
  `checked_out` int(10) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `language` char(7) NOT NULL,
  `catid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC ;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_input`
--

CREATE TABLE IF NOT EXISTS `#__diler_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `linktext` varchar(255) NOT NULL,
  `iframe` varchar(255) NOT NULL,
  `published` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `compchar_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `media` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_compchar_id` (`compchar_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_inputs_completed`
--

CREATE TABLE IF NOT EXISTS `#__diler_inputs_completed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `input_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_input_id` (`input_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_level`
--

CREATE TABLE IF NOT EXISTS `#__diler_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `checked_out` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `langauge` char(7) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `colour` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_phase`
--

CREATE TABLE IF NOT EXISTS `#__diler_phase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `checked_out` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_result`
--

CREATE TABLE IF NOT EXISTS `#__diler_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `points` float NOT NULL,
  `mark` int(11) DEFAULT NULL,
  `test_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_test_id` (`test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_student_reports`
--

CREATE TABLE IF NOT EXISTS `#__diler_student_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) NOT NULL,
  `teacherid` int(11) NOT NULL,
  `freetexhead` text NOT NULL,
  `freetextfoot` text NOT NULL,
  `textbox1` text NOT NULL,
  `textbox2` text NOT NULL,
  `textbox3` text NOT NULL,
  `textbox4` text NOT NULL,
  `textbox5` text NOT NULL,
  `textbox6` text NOT NULL,
  `textbox7` text NOT NULL,
  `textbox8` text NOT NULL,
  `textbox9` text NOT NULL,
  `textbox10` text NOT NULL,
  `textbox11` text NOT NULL,
  `textbox12` text NOT NULL,
  `textbox13` text NOT NULL,
  `textbox14` text NOT NULL,
  `textbox15` text NOT NULL,
  `textbox16` text NOT NULL,
  `textbox17` text NOT NULL,
  `textbox18` text NOT NULL,
  `textbox19` text NOT NULL,
  `textbox20` text NOT NULL,
  `lastmodifieddate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_subject`
--

CREATE TABLE IF NOT EXISTS `#__diler_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `created_by` int(10) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) NOT NULL,
  `checked_out` int(10) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `language` char(7) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `points` int(10) NOT NULL DEFAULT '30',
  `lowest` int(10) NOT NULL DEFAULT '1',
  `highest` int(10) NOT NULL DEFAULT '6',
  `catid` int(11) DEFAULT NULL,
  `colour` varchar(10) DEFAULT NULL,
  `comprasterView` varchar(20) NOT NULL DEFAULT 'vertical',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_cat_id` (`catid`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_subject_competence_map`
--

CREATE TABLE IF NOT EXISTS `#__diler_subject_competence_map` (
  `subject_id` int(11) NOT NULL,
  `competence_id` int(11) NOT NULL,
  UNIQUE KEY `idx_subject_competence` (`subject_id`,`competence_id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_competence_id` (`competence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_task`
--

CREATE TABLE IF NOT EXISTS `#__diler_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `description` text,
  `link` varchar(255) NOT NULL,
  `linktext` varchar(255) NOT NULL,
  `iframe` varchar(255) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(25) NOT NULL,
  `media` varchar(255) NOT NULL,
  `submit_type` tinyint(4) NOT NULL,
  `params` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(10) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) NOT NULL,
  `checked_out` int(10) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `access` int(10) NOT NULL,
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rel_type` (`rel_type`),
  KEY `idx_rel_id` (`rel_id`),
  KEY `idx_rel_type_rel_id` (`rel_type`,`rel_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_task_answer`
--

CREATE TABLE IF NOT EXISTS `#__diler_task_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'student id',
  `teacher_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `answer_from_student` text NOT NULL,
  `reply_from_teacher` text,
  `task_result` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_test`
--

CREATE TABLE IF NOT EXISTS `#__diler_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) DEFAULT NULL,
  `compchar_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `offline` tinyint(3) NOT NULL,
  `maxpoints` text NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `task` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(10) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(10) NOT NULL,
  `checked_out` int(10) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `access` int(10) NOT NULL,
  `language` char(7) NOT NULL,
  `duration` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_compchar` (`compchar_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_test_request`
--

CREATE TABLE IF NOT EXISTS `#__diler_test_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `accept_deny` tinyint(4) DEFAULT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_test_id` (`test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_texter`
--

CREATE TABLE IF NOT EXISTS `#__diler_texter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL DEFAULT 0,
  `compchar_id` int(11) NOT NULL DEFAULT 0,
  `value` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `read_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message` text NOT NULL,
  `type` int(11) NOT NULL COMMENT '0-manual, 1-test request, 2-test request reply, 3-test finished, 4-test graded, 5-exercise finished, 6-test reset, 7-test started.',
  `receiver_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0-active, 1-trashed, 2-deleted', 
  `sender_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0-active, 1-trashed, 2-deleted', 
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`),
  KEY `idx_sender` (`sender`),
  KEY `idx_receiver_status` (`receiver_status`),
  KEY `idx_sender_status` (`sender_status`),
  KEY `idx_created_date` (`created_date`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC ;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_user_extra_curricular_map`
--

CREATE TABLE IF NOT EXISTS `#__diler_user_extra_curricular_map` (
  `user_id` int(11) unsigned NOT NULL,
  `extra_curricular_id` int(11) NOT NULL,
  UNIQUE KEY `idx_user_extra_curricular_id` (`user_id`,`extra_curricular_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_extra_curricular_id` (`extra_curricular_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__diler_user_phase_map`
--

CREATE TABLE IF NOT EXISTS `#__diler_user_phase_map` (
  `user_id` int(11) unsigned NOT NULL,
  `subject_id` int(11) NOT NULL,
  `phase_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`subject_id`,`phase_id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_phase_id` (`phase_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `#__diler_subject_competence_map`
--
ALTER TABLE `#__diler_subject_competence_map`
  ADD CONSTRAINT `FK_competence_map_competence` FOREIGN KEY (`competence_id`) REFERENCES `#__diler_competence` (`id`),
  ADD CONSTRAINT `FK_competence_map_subject` FOREIGN KEY (`subject_id`) REFERENCES `#__diler_subject` (`id`);

--
-- Constraints for table `#__diler_user_phase_map`
--
ALTER TABLE `#__diler_user_phase_map`
  ADD CONSTRAINT `FK_phase_map_phase_id` FOREIGN KEY (`phase_id`) REFERENCES `#__diler_phase` (`id`),
  ADD CONSTRAINT `FK_phase_map_subject_id` FOREIGN KEY (`subject_id`) REFERENCES `#__diler_subject` (`id`),
  ADD CONSTRAINT `FK_phase_map_user_id` FOREIGN KEY (`user_id`) REFERENCES `#__dilerreg_users` (`user_id`);

--
-- Constraints for table `#__diler_user_extra_curricular_map`
--
ALTER TABLE `#__diler_user_extra_curricular_map`
  ADD CONSTRAINT `FK_user_extra_curricular_map_id` FOREIGN KEY (`extra_curricular_id`) REFERENCES `#__diler_extra_curricular` (`id`);

--
-- set check
--
SET FOREIGN_KEY_CHECKS=1;
