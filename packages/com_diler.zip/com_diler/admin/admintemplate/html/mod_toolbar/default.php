<?php
/**
 * Override admin toolbar for DiLer category views.
 *
 * @package DiLer.Administrator
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;

// Check to see if we need to substitute the DiLer help button for the standard category button
$input = Factory::getApplication()->input;
$option = $input->get('option');
$extension = $input->get('extension');
if ($option == "com_diler" || ($option == 'com_categories' && substr($extension, 0, 9) == 'com_diler')) {
    $view = $input->get('view', 'Categories');
    $extensionArray = explode('.', $extension);
    if ($option == 'com_categories'){
        $helpText = isset($extensionArray[1]) ? $extensionArray[1] : 'Subject';
        $helpText = $helpText . '_' . $view;
    }else {
        $helpText = $view;
    }
	// Get the markup for the Help button
	JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');
	$helpHtml = HTMLHelper::_('diler.helpButton', $helpText, 'btn btn-small', true, 'icon-question-sign');
	preg_match('/id=\"toolbar-help\".*(<button.*<\/button>)/s', $toolbar, $matches);
	if (isset($matches[1]))
	{
		$toolbar = str_replace($matches[1], $helpHtml, $toolbar);
	}
}

echo $toolbar;



