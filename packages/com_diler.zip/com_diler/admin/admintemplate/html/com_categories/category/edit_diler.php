<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_categories
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * Template override for DiLer Categories
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');

$app   = Factory::getApplication();
$input = $app->input;

$assoc = Associations::isEnabled();
// Are associations implemented for this extension?
$extensionassoc = array_key_exists('item_associations', $this->form->getFieldsets());

// Fieldsets to not automatically render by /layouts/joomla/edit/params.php
$this->ignore_fieldsets = [
	'jmetadata',
	'item_associations'
];

$this->useCoreUI = true;

// In case of modal
$isModal = $input->get('layout') === 'modal';
$layout  = $isModal ? 'modal' : 'edit';
$tmpl    = $isModal || $input->get('tmpl', '', 'cmd') === 'component' ? '&tmpl=component' : '';

$form      = $this->getForm();
$fieldSets = $form->getFieldsets();

Factory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
		if (task == "category.cancel" || document.formvalidator.isValid(document.getElementById("item-form")))
		{
			// IMPORTANT: Disables permissions fields so we do not blow up the number of posted fields on save.
			jQuery("#permissions-sliders select").attr("disabled", "disabled");
			jQuery(\'#jform_params_group_type\').removeAttr("disabled");
			Joomla.submitform(task, document.getElementById("item-form"));
		}
	};
');
?>

<form
        action="<?php echo Route::_('index.php?option=com_categories&extension=' . $input->getCmd('extension', 'com_content') . '&layout=edit&id=' . (int) $this->item->id); ?>"
        method="post" name="adminForm" id="item-form" class="form-validate">
	<?php echo LayoutHelper::render('joomla.edit.title_alias', $this); ?>
    <hr>
    <div class="form-horizontal">
		<?php echo HTMLHelper::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>
		<?php echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'general', Text::_('JCATEGORY')); ?>
        <br>
        <div class="control-group">
            <div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
            <div class="controls">
                <textarea class="form-control" filter="safehtml" name="jform[description]" id="jform_description"
                          rows="3"><?php echo $this->form->getField('description')->value; ?></textarea>
            </div>
        </div>
        <div class="control-group">
            <div class="control-label"><?php echo $this->form->getLabel('published'); ?></div>
            <div class="controls"><?php echo $this->form->getInput('published'); ?></div>
        </div>
		<?php $fieldSet = $form->getFieldset('basic'); ?>
		<?php $ignoreFields = array(
			'jform[params][category_layout]',
			'jform[params][image]',
			'jform[params][image_alt]',
			'jform[params][image_alt_empty]'
		); ?>
		<?php foreach ($fieldSet as $field) : ?>
			<?php if (!in_array($field->name, $ignoreFields)) : ?>
				<?php if ($form->getValue('id') && ($field->name === 'jform[params][group_type]' || $field->name === 'jform[params][multiple_subjects]')) : ?>
					<?php $field->disabled = "true"; ?>
				<?php endif; ?>
				<?php echo $field->renderField(); ?>
			<?php endif; ?>
		<?php endforeach; ?>
		<?php echo HTMLHelper::_('bootstrap.endTab'); ?>
		<?php if ($this->canDo->get('core.admin') && $this->item->extension === 'com_diler.cloud') : ?>
			<?php echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'rules', Text::_('COM_CATEGORIES_FIELDSET_RULES')); ?>
			<?php echo $form->renderField('dilerrules'); ?>
			<?php echo HTMLHelper::_('bootstrap.endTab'); ?>
		<?php endif; ?>
		<?php echo HTMLHelper::_('bootstrap.endTabSet'); ?>
		<?php echo $this->form->getInput('extension'); ?>
        <input type="hidden" name="task" value=""/>
		<?php echo HTMLHelper::_('form.token'); ?>
    </div>
    <input type="hidden" name="jform[parent_id]" value="<?php echo $this->form->getField('parent_id')->value; ?>"/>
    <input type="hidden" name="jform[language]" value="*"/>
</form>
<script>
	jQuery(document).ready(function () {
		jQuery('#jform_params_group_type input').change(function () {
			if (jQuery('#jform_params_group_type1').prop('checked')) {
				jQuery('#jform_params_multiple_subjects-lbl').closest('div.control-group').show();
			} else {
				jQuery('#jform_params_multiple_subjects-lbl').closest('div.control-group').hide();
			}
			toggleEnablePepCategory();
		});
		toggleEnablePepCategory();
		if (!jQuery('#jform_params_group_type1').prop('checked')) {
			jQuery('#jform_params_multiple_subjects-lbl').closest('div.control-group').hide();
		}
		jQuery('#jform_params_use_marks_levels input').change(function () {
			if (jQuery('#jform_params_use_marks_levels0').prop('checked')) {
				jQuery('#jform_params_marks_levels-lbl').closest('div.control-group').show();
			} else {
				jQuery('#jform_params_marks_levels-lbl').closest('div.control-group').hide();
			}
		});

		function toggleEnablePepCategory() {
			var pepCategoryElement = jQuery('#jform_params_is_pep_category');
			var subjectGroupSelected = jQuery('#jform_params_group_type1').prop('checked');
			pepCategoryElement.prop('disabled', !subjectGroupSelected);
			pepCategoryElement.toggleClass('disabled', !subjectGroupSelected);
		}
	});
</script>
