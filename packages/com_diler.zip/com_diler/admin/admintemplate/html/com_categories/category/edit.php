<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_categories
 *
 * @copyright   Copyright (C) 2005 - 2022 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * Template override for DiLer Categories
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate')
	->useScript('jquery');

$app       = Factory::getApplication();
$input     = $app->input;
$extension = $input->get('extension');
if (substr($extension, 0, 9) == 'com_diler')
{
	echo $this->loadTemplate('diler');
}
else
{
	// Load standard joomla edit.php view for non-Diler categories.
	ob_start();
	include JPATH_ROOT . '/administrator/components/com_categories/tmpl/category/edit.php';
	$this->_output = ob_get_contents();
	ob_end_clean();
	echo $this->_output;
}
