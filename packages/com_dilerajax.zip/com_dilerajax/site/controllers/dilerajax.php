<?php
/**
 *
 * @package DiLer.Site
 * @subpackage com_diler
 * @filesource
 *
 * @copyright @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */
defined('_JEXEC') or die('Restricted Access!');

use DiLer\DConst;
use DiLer\Lang\DText;
use DiLer\Responses\SendMessage;
use DiLer\Users\PersonalDataHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Menu;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Session\Session;
use DiLer\DDateTime;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\Registry\Registry;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;

JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');
JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
JLoader::register('DilerLogger', JPATH_ROOT . '/components/com_diler/helpers/logger.php');
JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

class DilerajaxControllerDilerajax extends BaseController
{
	/**
	 * @since 6.12.0
	 */
	private $response;

	public function __construct()
	{
		$this->response = new SendMessage;
		parent::__construct();
	}

	/**
	 * Logs out user automatically.
	 * Called after timeout.
	 */
	public function autoLogoutUser()
	{
		$userId = Factory::getUser()->id;
		$app = Factory::getApplication();
		$app->logout($userId);
		BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_dilerreg/models');
		$itemId = BaseDatabaseModel::getInstance('Login', 'DilerregModel')->getLoggedOutMenuItem();
		if ($app->input->getUint('autoLogout', 0))
		{
			$app->redirect(Route::_('index.php?option=com_dilerreg&view=loggedout&Itemid=' . $itemId . '&autoLogout=1', false));
		}
		else
		{
			$app->redirect(Route::_('index.php?option=com_dilerreg&view=loggedout&Itemid=' . $itemId, false));
		}
	}

	public function checkEventPublished()
	{
		$db = Factory::getDbo();
		$id = Factory::getApplication()->input->getUint('id');
		$db->setQuery("SELECT for_users FROM #__rseventspro_events WHERE id=" . $id);
		die($db->loadResult());
	}

	protected function checkSenderReceiver(int $senderId, int $receiverId) : bool
	{
		if (DilerHelperUser::isUserTeacher($receiverId) || DilerHelperUser::isUserTeacher($senderId)) return true;

		if (! ComponentHelper::getParams('com_diler')->get('showTexterTab', 1))
		{
			$this->response->setMessage(DText::_('DONT_SHOW_TEXTER_TAB'));

			return false;
		}

		$receiverRole = DilerHelperUser::getDilerRole($receiverId);
		if (Factory::getUser($senderId)->authorise('contacts.view.' . $receiverRole . 's', 'com_diler')) return true;

		$this->response->setMessage(DText::sprintf('FORBIDDEN_VIEW_CONTACTS', $receiverRole . 's'));

		return false;
	}

	public function countUnreadMessages()
	{
		$uid = Factory::getUser()->id;
		JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
		$msg = new Messages();
		$count = $msg->countUnreadMessages($uid);
		Factory::getApplication()->close(json_encode($count));
	}

	/**
	 * Flags messages for deletion and permanently deletes if they have been flagged by the other user.
	 * Messages are only physically deleted when both receiver and sender have deleted them.
	 */
	public function deleteMessages()
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$input = Factory::getApplication()->input;
		$mid = json_decode($input->getString('mid'));
		$uid = Factory::getUser()->id;
		JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
		$msg = new Messages();
		$msg->deleteMessages($mid, $uid);
        echo '{}';
		Factory::getApplication()->close(1);
	}

	public function displayOldie()
	{
		$oldieNote = '
			<div id="oldieNote" style="display:none">
				<div class="vertMiddle">
					<img style="display:block;margin:40px auto;" src="' . Uri::root() . '/media/com_diler/images/logos/logo.png" alt="DiLer logo" style="width:164px">
					<div>
						<div id="dilerMainNoscript" class="well floorBox" role="main">
							<div id="system-message-container">
								<div id="system-message">
									<div class="alert alert-error">
										<h4 class="alert-heading">' . DText::_('OLD_BROWSER_HEADING') . '</h4>
									</div>
								</div>
							</div>
							' . DText::_('OLD_BROWSER_MESSAGE') . '
						</div>
					</div>
				</div>
			</div>';
		die($oldieNote);
	}

	public function getInteractiveSearchResults()
	{
		$input = Factory::getApplication()->input;
		$studentGroups = ComponentHelper::getParams('com_diler')->get('student_group_ids');
		$search_word = $input->getString('search_word');
		$menuItemId = $input->getUint('Itemid');
		$db = Factory::getDBO();

		$menu = Factory::getApplication()->getMenu();
		$items = $menu->getMenu();
		$urlLang = $input->get('lang');

		$query = $db->getQuery(true)
			->select('u.*')
			->from('#__dilerreg_users AS u')
			->innerJoin('#__user_usergroup_map AS m ON m.user_id = u.user_id')
			->where('(forename LIKE ' . $db->quote('%' . $search_word . '%') . ' OR surname LIKE ' . $db->quote('%' . $search_word . '%') . ')')
			->where('m.group_id IN(' . implode(',', $studentGroups) . ')')
			->group('u.user_id')
			->order('u.surname ASC, u.forename ASC');
		$students = $db->setQuery($query)->loadObjectList();

		$role = DilerHelperUser::getDilerRole();

		$results = "";
		foreach ($students as $item)
		{
			$results .= "<li><a tabindex='-1' href='index.php?option=com_diler&view=" . $role . "_student&user_id=$item->user_id&Itemid=$menuItemId&lang=$urlLang'>$item->surname, $item->forename</a></li>";
		}

		Factory::getApplication()->close($results);
	}

	public function getMessages()
	{
		if (!Factory::getUser()->authorise('texter.view', 'com_diler')){
			echo 'not authorised';
			Factory::getApplication()->close();
		}

		$input = Factory::getApplication()->input;
		$subjectId = $input->getUint('subject_id', '');
		$compcharId = $input->getUint('compchar_id');
		$filterOnUserArray = json_decode($input->getString('filter_on_user_array'));
		$period = $input->getUint('period', '');
		$typeselect = $input->get('typeselect', '');
		$studentSelect = $input->getInt('studentselect', '-1');
		$trashStatus = $input->getUint('trash_status');
		$learningGroup = $input->getInt('learninggroup');
		$messageType = $input->getInt('message_type', -1);
		$unreadMessages = $input->getInt('unread_messages', 0);
		$Itemid = $input->getUint('Itemid');
		$lang = $input->get('lang');
		$pagingValuesString = $input->getString('pagingValues');
		$pagingValues = ($pagingValuesString === null) ? (object) ['start' => 0, 'limit' => 100] : json_decode($pagingValuesString);
		$orderingString = $input->getString('ordering');
		$ordering = ($orderingString === null) ? (object) ['start' => 0, 'limit' => 100] : json_decode($orderingString);
        $filterReplies = $input->get('filter_replies', null);
		$searchText = $input->get('search_text', '');
		DilerHelperUser::loadLanguage($lang);

		$db = Factory::getDbo();

		$session = Factory::getSession();

		$user = Factory::getUser();
		$userId = $user->id;

		if ($period != '')
		{
			$session->set('period', $period);
            $user->setParam('period', $period);
		}
		if ($typeselect != '')
		{
			$session->set('typeselect', $typeselect);
		}
		if ($studentSelect != '-1')
		{
			$session->set('studentselect', $studentSelect);
		}

		JLoader::register('Messages', 'components/com_diler/helpers/texter.php');
		$msg = new Messages();
		try
		{
			$messages = $msg->getMessages($period, $typeselect, $filterOnUserArray, $subjectId, $compcharId, $trashStatus, $learningGroup, $messageType, $studentSelect, $filterReplies, $pagingValues, $ordering, $searchText, $unreadMessages);
			$messageCount = $msg->getMessageCountForFilter($period, $typeselect, $filterOnUserArray, $subjectId, $compcharId, $trashStatus, $learningGroup, $messageType, $studentSelect, $filterReplies, $pagingValues, $searchText, $unreadMessages);
		}
		catch (Exception $e)
		{
			header('HTTP/1.0 404 Not found');
			if (ComponentHelper::getParams('com_diler')->get('showDetailError', 2) == 1)
			{
				echo $e->getMessage();
			}
			else
			{
				echo DText::_('SYSTEM_ERROR');
			}
			Factory::getApplication()->close();
		}

		$isTeacher = false;
		$isStudent = false;
		$isParent = false;

		$role = DilerHelperUser::getDilerRole();
		if ($role == 'teacher')
		{
			$isTeacher = true;
		}
		elseif ($role == 'student')
		{
			$isStudent = true;
		}
		elseif ($role == 'parent')
		{
			$isParent = true;
		}


		$db->setQuery("select forename,surname,salutation,role from #__dilerreg_users where user_id = " . Factory::getUser()->id);
		$loggedinname = $db->loadObject();
		$result = '';

		if ($messages) {
			foreach ($messages as $message)
			{
				$receiverLink = DText::_('TEXTER_MESSAGE_ME');
				$senderOnlineStatus = !$message->sender_online_status ? '' : '<div class="user-online-status ' . $message->sender_online_status . '"></div>';
				$receiverOnlineStatus = !$message->receiver_online_status ? '' : '<div class="user-online-status ' . $message->receiver_online_status . '"></div>';
				if ($isTeacher)
				{
					if ($userId == $message->sender)
					{
						$senderLink = DText::_('TEXTER_MESSAGE_ME');
						if ($message->receiver_role == 'student')
						{
							$receiverLink = '<a href="index.php?option=com_diler&view=teacher_student&user_id=' . $message->receiver . '&Itemid=' . $Itemid . '&lang=' . $lang . '">' . $message->receiver_name . '</a>';
						}
						else
						{
							$receiverLink = $message->receiver_name;
						}
					}
					elseif ($message->sender_role == 'student')
					{
						$senderLink = '<a href="index.php?option=com_diler&view=teacher_student&user_id=' . $message->sender . '&Itemid=' . $Itemid . '&lang=' . $lang . '">' . $message->sender_name . '</a>';
					}
					elseif ($message->sender_role == 'parent')
					{
						$senderLink = $message->sender_name;
						if(is_array($message->sender_children)) {
							foreach($message->sender_children as $child) {
								$senderLink .= '<div class="children text-link small"><a href="index.php?option=com_diler&view=teacher_student&user_id=' .
												$child->user_id . '&Itemid=' . $Itemid . '&lang=' . $lang . '">' . PersonalDataHelper::studentFullName($child) . '</a></div>';
							}
						}
					}
					else
					{
						$senderLink = $message->sender_name;
					}
				}
				elseif ($isStudent || $isParent)
				{
					$senderLink = $message->sender_name;
					$receiverLink = $message->receiver_name;
				}

				$messageRead = !($message->read_date == '0000-00-00 00:00:00' || $message->read_date == '');

				if($messageRead){
					$readIcon = 'fal fa-eye fa-fw';
					$markReadText = DText::_('TEXTER_MESSAGE_MARK_AS_UNREAD');
					$messageDateRead = date_timestamp_get(new DateTime($message->read_date));
					$stringDateRead = DDateTime::DilerDateTimeShort($message->read_date);
				}else{
					$readIcon = 'fal fa-eye-slash fa-fw';
					$markReadText = DText::_('TEXTER_MESSAGE_MARK_AS_READ');
					$messageDateRead = '0';
					$stringDateRead = '';
				}
				if($messageRead || ($message->receiver != $userId)){
					$readClass = '';
				}else{
					$readClass = 'info';
				}
				$readClass = ($trashStatus == 1) ? 'error' : $readClass;

				$receiverData = ($receiverLink == DText::_('TEXTER_MESSAGE_ME')) ? 'me' : 'not-me';
				$messageDate = date_timestamp_get(new DateTime($message->created_date));
				$messageDateString = DDateTime::DilerDateTimeShort($message->created_date);

				$messageText = $msg->display($message, $message->sender_name, $isTeacher);

				// Show shortcut buttons for activities. Only for teachers receiving unread messages
				$messageButtons = '';
				if ($isTeacher && $userId == $message->receiver && $message->rawType == 1 && $message->activity_request_id && $message->activity_accept_deny === '1')
				{
					$messageButtons = '<span id="testStatus'.$message->id.'" class="label label-success">'.DText::_('ACCESS_GRANTED').'</span>';
				}
				elseif ($isTeacher && $userId == $message->receiver && $message->rawType == 1 && $message->activity_request_id && $message->activity_accept_deny === '0')
				{
					$messageButtons = '<span id="testStatus'.$message->id.'" class="label label-important">'.DText::_('REJECTED').'</span>';
				}
				if ($isTeacher && $userId == $message->receiver && !$messageRead)
				{
					// controlled activity request
					if ($message->rawType == 1 && $message->activity_request_id && $message->activity_accept_deny == null)
					{
						$messageButton1 = '<a id="texterAcceptRequest' . $message->id . '" class="btn btn-primary btn-mini" data-activityId="' . $message->activity_id . '"' .
							'onclick="tx.answerRequestAccess(' . $message->activity_id . ',1,' . $message->activity_offline . ',' . $message->sender . ',' . $message->compchar_id . ','
								. $message->level_id . ',' . $message->subject_id . ',' . $message->id . '); tx.markReadToggleMessage(' . $message->id . ')" ' . 'title="'
									. DText::_('ACTIVITY_REQUEST_ACCEPT_DESC') . '"><i class="fas fa-check fa-fw"></i></a>';
									$messageButton2 = '<a id="texterRejectRequest' . $message->id . '" class="btn btn-danger btn-mini" data-activityId="' . $message->activity_id . '"' .
										' onclick="tx.answerRequestAccess(' . $message->activity_id . ',0,' . $message->activity_offline . ',' . $message->sender . ',' . $message->compchar_id . ','
											. $message->level_id . ',' . $message->subject_id . ',' . $message->id . '); tx.markReadToggleMessage(' . $message->id . ')" ' . 'title="' . DText::_('ACTIVITY_REQUEST_DENY_DESC')
											. '"><i class="fas fa-times fa-fw"></i></a>';
											$messageButtons = '<div class="btn-group">' . $messageButton1 . $messageButton2 . '</div>';
					}
				}

				// Set inline read and trash buttons
				$buttons = array();
				if ($trashStatus == 0 || $trashStatus == null)
				{
					if ($typeselect == 'received')
					{
						$canReply = $user->authorise('texter.create', 'com_diler');
						$senderSubject = "<small>" . DText::_('SUBJECT') . '</small>: ' . $message->subject_name;
						$senderDate = "<small>" . DText::_('TEXTER_REPLY_DATE_RECEIVED') . '</small>: ' . $messageDateString;
						$conversationId = $message->conversation_id ? $message->conversation_id : $message->id;
						$argumentArray = json_encode(
							(object) array(
								'id'   => $message->id,
								'sender_id' => $message->sender,
								'sender_name' => $message->sender_name,
								'subject' => $senderSubject,
								'text' => str_replace("\n", " ", html_entity_decode($messageText)),
								'date' => $senderDate,
								'conversation_id' => $conversationId,
								'subject_id' => $message->subject_id,
								'compchar_id' => $message->compchar_id
							)
						);
						if ($message->reply_id)
						{
							$buttons[] = '<div class="js---di-tooltip" title="' . DText::_('TEXTER_REPLY_COMPLETED') . '"><i class="fal fa-check-double fa-fw"></i></div></span>';
						}
                        if (! $filterReplies && ($message->conversation_id || $message->reply_id))
                        {
                            $buttons[] = '<div class="js---di-tooltip" title="' . DText::_('TEXTER_FILTER_BY_REPLIES') . '"><button type="button" class="unstyled icon link texterOption" onclick="tx.showRepliedMessages(' . $conversationId . ')"><i class="fal fa-comment-alt"></i></button></div></span>';
                        }

						if ($canReply)
						{
							if ($message->sender == $userId)
							{
								$buttons[] = '<i class="fal fa-reply fa-fw" disabled></i>';
							}
							else
							{
								$buttons[] = '<div class="js---di-tooltip" title="' . DText::_('TEXTER_REPLY') . '"><button type="button" id="reply' . $message->id . '" class="unstyled icon link texterOption" href="#texterWriteMessageReply" role="button" data-toggle="modal" '
									. 'onclick="tx.showReplyModal(\'' . rawurlencode($argumentArray) . '\')"' . '"><i class="fal fa-reply fa-fw"></i></button></div>';
							}
						}
					}
					else
					{
						$buttons[] = '<i class="fal fa-reply fa-fw" disabled></i>';
					}

					$buttons[] = '<div class="js---di-tooltip" title="' . DText::_('TEXTER_TRASH_MESSAGE') . '">' .
						'<button type="button" id="trash' . $message->id . '" class="unstyled icon link texterOption" onclick="tx.trashMessages(' .
						$message->id . ')"><i class="fal fa-trash-alt fa-fw"></i></button>'.
						'</div>';
						if ($message->receiver == $userId && !$message->reply_id)
						{
							$buttons[] = '<div class="js---di-tooltip" title="' . $markReadText . '">'.
								'<button type="button" id="read' . $message->id . '" class="unstyled icon link texterOption" onclick="tx.markReadToggleMessage(' .
								$message->id . ')"><i class="' . $readIcon . '"></i></button>'.
								'</div>';
						}
						else
						{
							$buttons[] = '<i class="' . $readIcon . '" disabled></i>';
						}
				}
				else
				{
					$buttons[] = '<div class="js---di-tooltip" data-title="' . Text::_('JACTION_DELETE') . '"><button type="button" id="delete' . $message->id . '" class="unstyled icon link texterOption" onclick="tx.deleteMessages(' . $message->id . ')"><i class="fal fa-times fa-fw"></i></button></div>';
					$buttons[] = '<div class="js---di-tooltip" data-title="' . DText::_('TEXTER_UNTRASH_MESSAGE') . '"><button type="button" id="untrash' . $message->id . '" class="unstyled icon link texterOption" onclick="tx.untrashMessages(' . $message->id . ')"><i class="fal fa-undo fa-fw"></i></button></div>';
				}
				$buttons[] = '<input id="checkBox' . $message->id . '" class="checkMessage icon" type="checkbox" value="' . $message->id . '">';

				$result .= '
				<tr id="' . $message->id . '" class="' . $readClass . '">
					<td class="date-time"><span class="hidden">' . $messageDate . '</span>' . $messageDateString . '</td>
					<td class="date-read" id="dateRead' . $message->id . '" data-display="full"><span class="hidden">' . $messageDateRead . '</span>' . $stringDateRead . '</td>
					<td class="message-type text-center" data-display="full">' . $message->type . '</td>
					<td class="subject" data-display="full">' . $message->subject_name . '</td>';

				if ($typeselect == 'sent')
				{
					$result .= '<td class="receiver" id="receiver' . $message->id . '" data-receiver="' . $receiverData . '">' . $receiverOnlineStatus . $receiverLink . '</td>';
					// Placeholder column for sender
					$result .= '<td style="display:none"></td>';
				}
				else if ($typeselect == 'conversations' || $filterReplies) {
					$result .= '<td class="receiver" id="receiver' . $message->id . '" data-receiver="' . $receiverData . '">' . $receiverOnlineStatus . $receiverLink . '</td>';
					$result .= '<td class="sender">' . $senderOnlineStatus . $senderLink . '</td>';
					// Check for student id (for parents only)
					if ($isParent && $message->student_id)
					{
						// Add student name column
						$result .= '<td class="child">' . PersonalDataHelper::texterStudentName($message) . '</td>';
					}
					elseif ($isParent)
					{
						$result .= '<td>-</td>';
					}
				}
				else
				{
					// Placeholder column for receiver
					$result .= '<td style="display:none"></td>';
					$result .= '<td class="sender">' . $senderOnlineStatus . $senderLink . '</td>';
					// Check for student id (for parents only)
					if ($isParent && $message->student_id)
					{
						// Add student name column
						$result .= '<td class="child">' . PersonalDataHelper::texterStudentName($message) . '</td>';
					}
					elseif ($isParent)
					{
						$result .= '<td>-</td>';
					}
				}
				$result .= '
					<td class="message-text desc"><div class="textCut texterMessage">' . html_entity_decode($messageText) . ' '.$messageButtons.'</div></td>
					<td class="actions"><div class="flex-container">' . implode("\n", $buttons) . '</div></td>
				</tr>';
			}
		} else {

			$messages = $msg->getMessagesCount($filterOnUserArray);
			if ($messages) {
				$result .= '<tr><td colspan=11>' . DText::_('NO_DATA_FOR_CURRENT_FILTER_SETTINGS') . '</td></tr>';
			} else {
				$result .= '<tr><td colspan=11>' . DText::_('NO_DATA_EXIST') . '</td></tr>';
			}

		}
		$countDisplayed = min($pagingValues->start + $pagingValues->limit, $messageCount);
		$pagingMessage = DText::sprintf('TEXTER_PAGING_COUNTS', $countDisplayed, $messageCount);
		$pagingMessage = ($countDisplayed === $messageCount) ? $pagingMessage : $pagingMessage . ' ' . DText::_('TEXTER_SCROLL_INFO');
		$resultObject = (object) ['markup' => $result, 'start' => $pagingValues->start, 'limit' => $pagingValues->limit, 'count' => $messageCount,
			'countDisplayed' => $countDisplayed, 'pagingMessage' => $pagingMessage];
		echo json_encode($resultObject);
		Factory::getApplication()->close();
	}

    /**
     * Gets the screen settings from the user params for loading the browser local storage
     *
     * @return void JSON string with current user's screen settings
     * @throws Exception
     */
	public function getScreenSettings()
	{
		$params = json_decode(Factory::getUser()->params);
		if (isset($params->tabs))
		{
			echo base64_decode(json_decode(Factory::getUser()->params)->tabs);
		}
		Factory::getApplication()->close();
	}

	public function getSubjectById($subject_id)
	{
		$db = Factory::getDBO();
		$query = "SELECT name FROM #__diler_subject WHERE id=$subject_id";
		$db->setQuery($query);

		return $db->loadResult();
	}

	public function getUploadLimit()
	{
		$max_upload = (int) (ini_get('upload_max_filesize'));
		$max_post = (int) (ini_get('post_max_size'));
		$memory_limit = (int) (ini_get('memory_limit'));
		$upload_mb = min($max_upload, $max_post, $memory_limit);

		print_r($upload_mb);
		die();
	}

	protected function isValidUrl($url)
	{
		// Make sure we have something
		if (! $url) return false;

		$uri = Uri::getInstance(urldecode($url));
		$itemId = $uri->getVar('Itemid');

		if (! $itemId) return false;

		Table::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_menus/tables');
		$menuTable = new Menu(Factory::getDbo());
		$menuTable->load($itemId);
		$result = strpos($menuTable->link, 'option=com_diler') !== false && strpos($menuTable->alias, 'bulletin') === false;
		return $result;
	}

	public function keepalive()
	{
		Factory::getApplication()->close();
	}

	public function markMessagesAsRead()
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$midArray = json_decode(Factory::getApplication()->input->getString('mid'));
		$uid = Factory::getUser()->id;
		JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
		$msg = new Messages();
		$newDate = $msg->markMessagesAsRead($midArray, $uid);
		$newDateString = DDateTime::DilerDateTimeShort($newDate);
		$newDateNumber = date_timestamp_get(new DateTime($newDate));
		echo json_encode(array('dateString' => $newDateString,'dateNumber' => $newDateNumber));
		Factory::getApplication()->close();
	}

	public function newMessageStatus()
	{
		$mid = Factory::getApplication()->input->getInt('mid');
		$uid = Factory::getUser()->id;
		JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
		$msg = new Messages();
		$msg->newMessageStatus($mid);
	}

	/**
	 * Remove some tags, for more security in the script
	 * @param $content
	 * @return false|string
	 */
	private function removeUnreliableTags($content)
	{
		$dom = new DOMDocument();
		$dom->loadHTML('<?xml encoding="utf-8" ?>'.$content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
		$xpath = new DOMXPath($dom);
		foreach ($xpath->query('//link|//style|//script|//iframe|//frameset|//frame') as $limitedTag) {
			while ($limitedTag->hasChildNodes()) {
				$child = $limitedTag->removeChild($limitedTag->firstChild);
				$limitedTag->parentNode->insertBefore($child, $limitedTag);
			}
			$limitedTag->parentNode->removeChild($limitedTag);
		}
		return $dom->saveHTML();
	}

	/**
	 * Add target=_blank and rel=noreferrer for all a tag
	 * @param $content
	 * @return false|string
	 */
	private function updateAnchorTagAttribute($content)
	{
		$dom = new DOMDocument();
		$dom->loadHTML('<?xml encoding="utf-8" ?>'.$content);
		foreach ($dom->getElementsByTagName('a') as $link) {
			$link->setAttribute('target', '_blank');
			$link->setAttribute('rel', 'noreferrer');
		}
		return $dom->saveHTML();
	}

	/**
	 * Sends a texter message. Called from tx.sendMessage() function.
	 */
	public function sendMessage()
	{
		$currentDate = Factory::getDate()->toSql();
		$app = Factory::getApplication();
		$input = $app->input;
		$user = Factory::getUser();
		$sender = $user->id;
		$receiverArray = $input->get('receiver', array(), 'array');
		$body = $input->get('message', '', 'raw');
		$body = str_replace('&quot;', '', $body);
		$body = $this->removeUnreliableTags($body);
		$body = $this->updateAnchorTagAttribute($body);
		$subject_id = $input->getUint('subject_id', 0);
		$compchar_id = $input->getUint('compchar_id', 0);
		$messageType = $input->getUint('messageType', 0);
		$replyToId = $input->getUint('reply_to_id', 0);
		$conversationId = $input->getUint('conversation_id');

		$receiverArray = ArrayHelper::toInteger($receiverArray);
		$isValidSenderAndReceiver = false;
		foreach ($receiverArray as $receiver)
		{
			$isValidSenderAndReceiver = $this->checkSenderReceiver($sender, $receiver);
			if (!$isValidSenderAndReceiver) break;
		}
		$params = ComponentHelper::getParams('com_diler');
		$texterMessageContentLength = $params->get('texterMessageContentLength', DConst::TEXTER_MESSAGE_CONTENT_DEFAULT_LENGTH);
		$canNotSendMessage = $messageType == '0' && !$user->authorise('texter.create', 'com_diler');
		$exceedMessageLength = strlen(str_replace("\n", "", strip_tags($body))) > $texterMessageContentLength;
		if ($exceedMessageLength || !$isValidSenderAndReceiver || $canNotSendMessage || !$user->id)
		{
			$this->response->setStatus(false);

			if ($exceedMessageLength)
				$this->response->setMessage(DText::_('EXCEED_MESSAGE_LENGTH'));
			if ($canNotSendMessage)
				$this->response->setMessage(DText::_('FORBIDDEN_TEXTER_CREATE'));
			if (!$user->id)
				$this->response->setMessage(DText::_('AUTO_LOGOUT_MESSAGE'));

			$logger = new DilerLogger('texter', 'send.message');
			$logger->addAction(array(
				'status' => 'error',
				'senderName' => Factory::getUser($sender)->name,
				'receiverIds' => json_encode($receiverArray),
				'exceedMessageLength' => $exceedMessageLength,
				'isValidSenderAndReceiver' => $isValidSenderAndReceiver,
				'texterCreatePermission' => $canNotSendMessage,
			), 'COM_DILER_LOG_ACTION_TEXTER_SEND_MESSAGE');

			header('HTTP/1.0 500 Internal Server Error');
			$app->close(json_encode($this->response));
		}

		if ($messageType == 0 && $subject_id != 0 && $compchar_id == 0)
		{
			$body = DText::sprintf('TEXTER_MANUAL_SUBJECT_MESSAGE', DText::_('SUBJECT'), $body);
		}
		elseif ($messageType == 0 && $subject_id != 0)
		{
			$body = DText::sprintf('TEXTER_MANUAL_COMPCHAR_MESSAGE', DText::_('SUBJECT'), $body);
		}

		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		foreach ($receiverArray as $receiver)
		{
			if (DilerHelperUser::isUserBlocked($receiver)) continue;
			$query->clear()
				->insert('#__diler_texter')
				->set('sender = ' . $sender)
                ->set('title = ' . '""')
                ->set('value = ' . '""')
                ->set('receiver_trash_date = ' . '"0000-00-00 00:00:00"')
                ->set('sender_trash_date = ' . '"0000-00-00 00:00:00"')
                ->set('activity_id = ' . 0)
                ->set('reply_id = ' . 0)
                ->set('student_id = ' . 0)
                ->set('cloud_id = ' . 0)
                ->set('cloud_catid = ' . 0)
                ->set('cloud_group_id = ' . 0)
                ->set('activity_type_id = ' . 0)
				->set('receiver = ' . $receiver)
				->set('subject_id = ' . $subject_id)
				->set('compchar_id = ' . $compchar_id)
				->set('type = ' . $messageType)
				->set('created_date = ' . $db->quote($currentDate))
				->set('message = ' . $db->quote($body))
                ->set('read_date = ' .  '"0000-00-00 00:00:00"');

			if ($conversationId)
				$query->set("conversation_id = $conversationId");

			try
			{
				$db->setQuery($query)->execute();

				// If this is a reply to another message, update that message with the new message id.
				$newMessageId = $db->insertid();
				if ($replyToId && $newMessageId)
				{
					$query = $db->getQuery(true)
						->update('#__diler_texter')
						->set('reply_id = ' . $newMessageId)
						->set('read_date = ' . $db->quote(Factory::getDate()->toSql()))
						->where('id = ' . $replyToId);
					$db->setQuery($query)->execute();
				}
				// @TODO logger - Check do we have anytime $subject_id, $compchar_id and $messageType, if Yes, add it to logger message
				$logger = new DilerLogger('texter', 'send.message');
				$logger->addAction(array(
					'senderName' => Factory::getUser($sender)->name,
					'receiverName' => Factory::getUser($receiver)->name
				), 'COM_DILER_LOG_ACTION_TEXTER_SEND_MESSAGE');
			}
			catch (Exception $e)
			{
				$this->response->setStatus(false);
				$this->response->setMessage($e->getMessage());
				header('HTTP/1.0 500 Internal Server Error');
				$app->close(json_encode($this->response));
			}
		}
		$app->close(json_encode($this->response));
	}

	public function toggleMessageRead()
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$mid = Factory::getApplication()->input->getInt('mid');
		$uid = Factory::getUser()->id;
		JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
		$msg = new Messages();
		$newDate = $msg->toggleMessageRead($mid, $uid);
		$message = Text::_($msg->getMessage($mid));
		$newDateString = $newDate ? DDateTime::DilerDateTimeShort($newDate) : 0;
		$newDateNumber = $newDate ? date_timestamp_get(new DateTime($newDate)) : 0;
		echo json_encode(array('dateString' => $newDateString,'dateNumber' => $newDateNumber,'message' => $message));
		Factory::getApplication()->close();
	}

	public function trashMessages()
	{
		Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
		$input = Factory::getApplication()->input;
		$mid = json_decode($input->getString('mid'));
		$action = $input->get('action');
		$uid = Factory::getUser()->id;
		JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
		$msg = new Messages();
		$msg->trashMessages($mid, $uid, $action);
		Factory::getApplication()->close(1);
	}

	/**
	 * Updates mod_latestmessages via AJAX.
	 * Used when message status is changed.
	 *
	 * Returns the updated <tbody> element via AJAX.
	 */
	public function updateLatestMessages()
	{
		$mod = ModuleHelper::getModule('latestmessages');
		$rawContent = ModuleHelper::renderModule($mod);
		$start = strpos($rawContent, '<tbody>');
		$end = strpos($rawContent, '</tbody>');
		$content = substr($rawContent, $start, ($end - $start) + 8);
		echo $content;
		Factory::getApplication()->close();
	}

	/**
	 * Updates the return URL for the user.
	 * Checks to make sure it is a valid return URL.
	 */
	public function updateReturnURL()
	{
		$db = Factory::getDbo();
		$input = Factory::getApplication()->input;
		$urlRaw = $input->getString('location');
		$selTabs = $input->getString('selTabs');
		$user = Factory::getUser();
		$query = $db->getQuery(true)
			->select('params')
			->from('#__users')
			->where('id = ' . $user->id);
		$rawParams = $db->setQuery($query)->loadResult();
		$params = new Registry($rawParams);

		$url = substr($urlRaw, strpos($urlRaw, 'index.php'));

		// Don't save anything if not valid URL
		$valid = $this->isValidUrl($url);
		if (! $valid)
		{
			Factory::getApplication()->close('Invalid URL');
		}

		$params->set('return_url', base64_encode($url));
		$params->set('tabs', base64_encode($selTabs));

		$query = $db->getQuery(true)
			->update('#__users')
			->set('params =' . $db->quote((string) $params))
			->where('id = ' . $user->id);
		$db->setQuery($query)->execute();

		// Delete the user's temp folder
		$tempFolder = Factory::getConfig()->get('tmp_path') . '/diler/' . $user->id;

		if (Folder::exists($tempFolder))
		{
			Folder::delete($tempFolder);
		}

		echo "URL Saved";
		Factory::getApplication()->close(1);
	}
}