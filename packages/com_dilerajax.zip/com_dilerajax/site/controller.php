<?php
/**
 * Controller for com_dilerajax.
 *
 * @package DiLer.Site
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2012 - 2014 DiLer. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

use Joomla\CMS\MVC\Controller\BaseController;



class DilerajaxController extends BaseController {
	function display($cachable = false, $urlparams = Array()) {
		parent::display($cachable,$urlparams);
	}
}