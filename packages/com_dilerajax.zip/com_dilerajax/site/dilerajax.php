<?php
/**
 * Ajax controller for ajax calls.
 *
 * @package DiLer.Site
 * @subpackage com_diler
 * @filesource
 *
 * @copyright Copyright (C) 2012 - 2014 DiLer. All rights reserved.
 * @license GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;

JLoader::register('DilerHelperUser', JPATH_COMPONENT . '/helpers/user.php');
$language = Factory::getLanguage();
$language->load('com_diler', JPATH_SITE . '/components/com_diler', null, true);

$controller = BaseController::getInstance('Dilerajax');
$controller->execute(Factory::getApplication()->input->get('task'));
$controller->redirect();