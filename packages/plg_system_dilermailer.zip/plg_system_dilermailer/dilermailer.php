<?php
/**
 * @copyright	Copyright (C) 2020 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use DiLer\DMailer;
use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Mail\MailHelper;
use Joomla\CMS\Plugin\CMSPlugin;

JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries/DiLer');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');

class PlgSystemDilerMailer extends CMSPlugin
{
	public function onAfterInitialise()
	{
		$this->overrideDefaultJoomlaMailerWithDilerMailer();
	}

	/**
	 * We override default Joomla mailer so we can use family email address.
	 * By default for all users we set dummy email. In case one user set valid email, then we give user an option
	 * to use this email as family email. In that case whenever we need to send email to family member with dummy
	 * email address, we will use valid one instead.
	 * @since 6.11.0
	 * @see Factory::createMailer for default usage
	 */
	private function overrideDefaultJoomlaMailerWithDilerMailer()
	{
		$conf       = Factory::getConfig();
		$smtpAuth   = ($conf->get('smtpauth') == 0) ? null : 1;
		$smtpUser   = $conf->get('smtpuser');
		$smtpPass   = $conf->get('smtppass');
		$smtpHost   = $conf->get('smtphost');
		$smtpSecure = $conf->get('smtpsecure');
		$smtpPort   = $conf->get('smtpport');
		$mailFrom   = $conf->get('mailfrom');
		$fromName   = $conf->get('fromname');
		$mailer     = $conf->get('mailer');
		$mail       = DMailer::getInstance();
		$mailFrom   = MailHelper::cleanLine($mailFrom);

		if (MailHelper::isEmailAddress($mailFrom))
		{
			try
			{
				if ($mail->setFrom($mailFrom, MailHelper::cleanLine($fromName), false) === false)
				{
					Log::add(__METHOD__ . '() could not set the sender data.', Log::WARNING, 'mail');
				}
			}
			catch (phpmailerException $e)
			{
				Log::add(__METHOD__ . '() could not set the sender data.', Log::WARNING, 'mail');
			}
		}

		switch ($mailer)
		{
			case 'smtp':
				$mail->useSmtp($smtpAuth, $smtpHost, $smtpUser, $smtpPass, $smtpSecure, $smtpPort);
				break;

			case 'sendmail':
				$mail->isSendmail();
				break;

			default:
				$mail->isMail();
				break;
		}

		Factory::$mailer = $mail;
	}
}