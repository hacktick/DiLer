<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

$doc             = Factory::getDocument();
$app             = Factory::getApplication();
$this->language  = $doc->language;
$this->direction = $doc->direction;
$doc->setGenerator('DiLer - digitale-lernumgebung.de');
$path						= $this->baseurl;

if (($this->error->getCode()) == '404') {
	header('HTTP/1.0 404 Not Found');?>
	<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
	<head>
		<title>DiLer 404</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="language" content="<?php echo $this->language; ?>" />
		<style type="text/css">
			html,body{border: none;padding:0;margin:0;height: 100vh; font-family: sans-serif;}
			body{background:#A1D6F5 url("<?php echo $path;?>/media/com_diler/images/logos/diler_404.png") center center no-repeat;background-size: cover;}
			.link{position: absolute; display: block; margin: 55vh 0 0 33vw; height: 40vh; width: 50vw; cursor: pointer}
		</style>
	</head>
	<body>
		<a class="link" href="/"></a>
	</body>
	</html>
<?php } else {?>
	<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
	<head>
		<title><?php echo $this->error->getCode();?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="language" content="<?php echo $this->language; ?>" />
		<style type="text/css">
			html,body{border: none;padding:0;margin:0; background: #ddd}
			h1 {padding: 30vh 20vw; text-align: center; color: #0f3a52; font-family: sans-serif; font-weight: normal;}
			div {margin: auto; max-width: 20em;}
		</style>
	</head>
	<body>
		<h1><?php echo $this->error->getCode();?></h1>
		<div><?php echo htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'); ?></div>
	</body>
	</html>
<?php }?>
