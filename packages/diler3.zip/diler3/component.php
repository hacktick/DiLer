<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  Templates.diler3
 *
 * @copyright   Copyright (C) 2012 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// preventing the display of pages via the browser back button after logout
// header('Cache-Control: no-store, private, no-cache, must-revalidate');                  // HTTP/1.1
// header('Cache-Control: pre-check=0, post-check=0, max-age=0, max-stale = 0', false);    // HTTP/1.1
// header('Pragma: public');
// header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');                                       // Date in the past
// header('Expires: 0', false);
// header('Last-Modified: '.gmdate('D, d M Y H:i:s') . ' GMT');
// header('Pragma: no-cache');

defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Component\ComponentHelper;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

HTMLHelper::_('diler.translateJs');
$dilerParams = ComponentHelper::getParams('com_diler');
$statisticId = $dilerParams->get('statistic_id','');
$schoollogo = $dilerParams->get('schoollogo','../../../images/diler/logos/logo400x138.png');
$editionClass = (DilerHelperUser::extendedFeatures()) ? 'edition-pe' : 'edition-ce';
$recommends =  DilerHelperUser::isDiglu() ? DText::_('DIGLU_RECOMMENDS') : DText::_('RECOMMENDS');

// Getting params from template
$tparams = Factory::getApplication()->getTemplate(true)->params;

$app			= Factory::getApplication();
$user			= Factory::getUser();
$doc			= Factory::getDocument();
$language		= $doc->language;
$v 				= $doc->getMediaVersion();
$params			= $app->getParams();
$path			= $this->baseurl;
$tpath			= $path.'/templates/'.$this->template;

$option			= $app->input->getCmd('option', '');
$view			= $app->input->getCmd('view', '');
$layout			= $app->input->getCmd('layout', '');
$task			= $app->input->getCmd('task', '');
$itemid			= $app->input->getCmd('Itemid', '');
$sitename		= $app->getCfg('sitename');

$pageclass		= $params->get('pageclass_sfx'); // parameter (menu entry)
$layoutVariation = $this->params->get('centered','0');
$bgImage		= $this->params->get('bgImage','0');

$doc->setGenerator('DiLer - digitale-lernumgebung.de');

// Load school and user specific background image
$deskBackground = DilerHelperUser::getUserBackground();

BaseDatabaseModel::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_diler/models/');
$versionInfo = MVCHelper::factory()->createModel('Dilers', 'Administrator')->getPackageVersionInfo();
$dilerVersion = $versionInfo->diler_version;
$dilerEdition = $versionInfo->diler_edition;

?>

<!DOCTYPE html>
<html class="site fluid <?php echo $pageclass.' '.$option.' view_'.$view . ' ' . $editionClass.($layout ? ' layout-'.$layout : ' no-layout').
	($task ? ' task-'. $task : ' no-task').($itemid ? ' itemid-'.$itemid : ''); ?>"
	xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $language; ?>" lang="<?php echo $language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<style>	<?php /* prevent unstyled content till the diler.css is fully loaded: */?>
		html{height:100%;background:#ddd none;}
		body{min-height: 100%;background:transparent none;}
		body.site {border-top: none;padding:0}
		body.site.fluid {/*background-color: transparent;*/}
		body.site.centered {height:100%}
		#bodyBg,#bgImage {display:block;background: #eee none center center no-repeat;background-size: cover;width: 100%;height: 100%;position:fixed}
		#bgImage{background-color: transparent;background-size: contain;background-position:center 10%}
		#bodyBg {background-image:url(<?php echo htmlspecialchars($path).'/'.$deskBackground;?>)}
		@media screen and (min-width: 960px){#bgImage{background-image:url(<?php echo htmlspecialchars($path); ?>/media/com_diler/images/logos/diler_rainbow_1280.png)}}
	</style>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<jdoc:include type="head" />

	<?php if ($option != 'com_diler'): ?>
		<?php $doc->addScript(Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js'); ?>
		<?php $doc->addScript(Uri::root(true) . '/media/com_diler/js/diler.js?v=' . $v ); ?>
	<?php endif; ?>

	<link rel="stylesheet" type="text/css" href="<?php echo htmlspecialchars($tpath); ?>/css/fontawesome.min.css"><!-- fa pro -->
	<link rel="stylesheet" type="text/css" href="<?php echo htmlspecialchars($tpath); ?>/css/diler.css?v=<?php echo $v?>">
	<link rel="apple-touch-icon" sizes="57x57" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" href="<?php echo htmlspecialchars($tpath); ?>/favicon-32x32.png" sizes="32x32">
	<link rel="icon" type="image/png" href="<?php echo htmlspecialchars($tpath); ?>/favicon-194x194.png" sizes="194x194">
	<link rel="icon" type="image/png" href="<?php echo htmlspecialchars($tpath); ?>/favicon-96x96.png" sizes="96x96">
	<link rel="icon" type="image/png" href="<?php echo htmlspecialchars($tpath); ?>/android-chrome-192x192.png" sizes="192x192">
	<link rel="icon" type="image/png" href="<?php echo htmlspecialchars($tpath); ?>/favicon-16x16.png" sizes="16x16">
	<link rel="manifest" href="<?php echo htmlspecialchars($tpath); ?>/manifest.json">
	<meta name="msapplication-config" content="<?php echo htmlspecialchars($tpath); ?>/browserconfig.xml" />
	<?php if (strpos(Uri::base(), 'diglu') !== false) : ?>
		<meta name="apple-mobile-web-app-title" content="DigLu">
	<?php else:?>
		<meta name="apple-mobile-web-app-title" content="DiLer">
	<?php endif;?>
	<meta name="application-name" content="DiLer">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="<?php echo htmlspecialchars($tpath); ?>/mstile-144x144.png">
	<meta name="theme-color" content="#ffffff">
	<script src="<?php echo htmlspecialchars($tpath); ?>/js/modernizr.custom.js"></script>
	<script>
		jQuery(document).ready(function(){
			jQuery('body').removeClass('nojs');

			// check for a modern browser
			if (
				Modernizr.backgroundsize
				 && Modernizr.cssgradients
				 && Modernizr.video
				 && Modernizr.audio
				 && Modernizr.boxsizing
				 && Modernizr.csscalc
				 && Modernizr.mq
				){
				// nothing to do here
			} else {
				jQuery('#bgImage').hide();
				jQuery('#center').hide();
				jQuery('#dilerContainer').hide();
				jQuery('body').css('height','100%');
				jQuery.ajax({
					type: "POST",
					url: "index.php?option=com_dilerajax&task=dilerajax.displayOldie",
					data: { templatePath: "<?php echo $tpath;?>"}
				}).done(function( data ) {
						jQuery('body').append(data);
						jQuery('#oldieNote').fadeIn(2000);
					});
			}
		});
	</script>
	<?php if($statisticId):?>
		<script type="text/javascript">
		  var _paq = window._paq || [];
		  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
		  _paq.push(['trackPageView']);
		  _paq.push(['enableLinkTracking']);
		  (function() {
		    var u="https://stats.digitale-lernumgebung.de/";
		    _paq.push(['setTrackerUrl', u+'matomo.php']);
		    _paq.push(['setSiteId', '<?php echo $statisticId;?>']);
		    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
		    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
		  })();
		</script>
	<?php endif;?>
</head>

<body id="top" class="site fluid nojs <?php echo $pageclass.' '.$option.' view-'.$view.($layout ? ' layout-'.$layout : ' no-layout').($task ? ' task-'. $task : ' no-task').($itemid ? ' itemid-'.$itemid : '').($layoutVariation == 1 ? ' centered' : ($layoutVariation == 2 ? ' bulletin' : '')); ?>">
	<div id="dist" style="position:fixed"></div>
	<?php if ($deskBackground != 'media/com_diler/images/logos/diler_sky_1280.png') {?>
		<div id="bodyBg" class="schoolBackground"></div>
	<?php } else {?>
    	<div id="bodyBg"></div>
    	<?php echo $bgImage ? '<div id="bgImage"></div>':'';?>
	<?php } ?>
	<noscript>
		<div class="vertMiddle">
			<div>
				<div id="dilerMainNoscript" class="well floorBox" role="main">
					<div id="system-message-container-noscript">
						<div id="system-message-noscript">
							<div class="alert alert-error">
								<h4 class="alert-heading"><?php echo Text::_('TPL_DILER3_NOSCRIPT_WARNING_HEADING'); ?></h4>
								<div><p><?php echo Text::_('TPL_DILER3_NOSCRIPT_WARNING_SHORT'); ?></p></div>
							</div>
						</div>
					</div>
					<?php echo Text::_('TPL_DILER3_NOSCRIPT_WARNING'); ?>
				</div>
			</div>
		</div>
	</noscript>
	<?php if (Factory::getApplication()->getMessageQueue()){ ?>
		<jdoc:include type="message" />
	<?php } ?>
	<jdoc:include type="component" />
	<jdoc:include type="modules" name="debug" style="basic" />
</body>
</html>
