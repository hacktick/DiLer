<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  Templates.diler3
 *
 * @copyright   Copyright (C) 2012 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// preventing the display of pages via the browser back button after logout
// header('Cache-Control: no-store, private, no-cache, must-revalidate');                  // HTTP/1.1
// header('Cache-Control: pre-check=0, post-check=0, max-age=0, max-stale = 0', false);    // HTTP/1.1
// header('Pragma: public');
// header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');                                       // Date in the past
// header('Expires: 0', false);
// header('Last-Modified: '.gmdate('D, d M Y H:i:s') . ' GMT');
// header('Pragma: no-cache');

defined('_JEXEC') or die;

use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;
use Audivisa\Component\DiLer\Site\Helper\VersionHelper;
use DiLer\DConst;
use DiLer\DPath;
use Joomla\CMS\Factory;
use DiLer\Lang\DText;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Component\ComponentHelper;
use DiLer\DGet;
use Joomla\CMS\Uri\Uri;

JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');
JLoader::registerNamespace('DiLer', JPATH_ROOT . '/components/com_diler/libraries');
JLoader::registerNamespace('Audivisa\\Component\\DiLer\\Site', JPATH_ROOT . '/components/com_diler/src', false, false, 'psr4');
Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/components/com_diler', null, true);
DText::script('AJAX_CALLS_LOADING_MESSAGE');

HTMLHelper::_('diler.translateJs');
$dilerParams = ComponentHelper::getParams('com_diler');
$bulletinRefresh = $dilerParams->get('bulletinRefresh',60);
$bulletinLeft = $dilerParams->get('bulletinBootstrapsizeLeft',5);
$bulletinRight = $dilerParams->get('bulletinBootstrapsizeRight',3);
$bulletinTop = $dilerParams->get('bulletinTop',1);
$bulletinTopFontsize = $dilerParams->get('bulletinTopFontsize',2);
$bulletinTopText = $dilerParams->get('bulletinTopText','');
$bulletinDeskRoles = $dilerParams->get('bulletinDesk',array());
$statisticId = $dilerParams->get('statistic_id','');
$schoollogo = $dilerParams->get('schoollogo',JPATH_ROOT.'/images/diler/logos/logo400x138.png');
$bulletinTopTextalign = $dilerParams->get('bulletinTopTextalign','center');
$bulletinTopLogo = $dilerParams->get('bulletinTopLogo','0');
$bulletinWeather = $dilerParams->get('bulletinWeather','1');
$editionClass = (DilerHelperUser::extendedFeatures()) ? 'edition-pe' : 'edition-ce';
$recommends =  DilerHelperUser::isDiglu() ? DText::_('DIGLU_RECOMMENDS') : DText::_('RECOMMENDS');

// Getting params from template
$tparams = Factory::getApplication()->getTemplate(true)->params;
$spanLeft = $this->params->get('spanLeft','4');
$spanRight = $this->params->get('spanRight','2');

$app = Factory::getApplication();
$componentParams = $app->getParams('com_diler');

$app			= Factory::getApplication();
$user			= Factory::getUser();
$doc			= Factory::getDocument();
$language		= $doc->language;
$v 				= $doc->getMediaVersion();
$params			= $app->getParams();
$path			= $this->baseurl;
$tpath			= $path.'/templates/'.$this->template;
$loggedIn		= DilerHelperUser::loggedIn();

$option			= $app->input->getCmd('option', '');
$view			= $app->input->getCmd('view', '');
$layout			= $app->input->getCmd('layout', '');
$task			= $app->input->getCmd('task', '');
$itemid			= $app->input->getCmd('Itemid', '');
$sitename		= $app->getCfg('sitename');

$pageclass		= $params->get('pageclass_sfx'); // parameter (menu entry)
$layoutVariation = $this->params->get('centered','0');
$bgImage		= $this->params->get('bgImage','0');

if ($view == DConst::TEACHER_SCHOOLS_LIST_VIEW)
{
	$spanLeft = 4;
	$spanRight = 2;
	$layoutVariation = 0;
	$bgImage = 0;
}

$doc->setGenerator('DiLer - digitale-lernumgebung.de');

if ($layoutVariation == 2 && (strpos($pageclass, 'bulletin') !== false)) {
	header('Refresh: '.$bulletinRefresh.';');
	//HTMLHelper::_('behavior.keepalive'); //probably not necessary since the reload seems to renew the session
}

if($task == "edit" || $layout == "form" ){$fullWidth = 1;}
else{$fullWidth = 0;}

// Add JavaScript Frameworks
if (!VersionHelper::isJoomla4())
{
	HTMLHelper::_('bootstrap.popover');
	HTMLHelper::_('bootstrap.modal');
	HTMLHelper::_('bootstrap.button');
}

if (VersionHelper::isJoomla4())
{
    $wa = Factory::getApplication()->getDocument()->getWebAssetManager();
    $wa->disableScript('bootstrap.popover');
    $wa->disableScript('jquery');
    $wa->disableScript('core');
    $wa->disableScript('jquery-noconflict');
	Factory::getDocument()->addScript(Uri::root(true) . '/media/com_diler/js/autosize.js');
}

// Load school and user specific background image
$deskBackground = DilerHelperUser::getUserBackground();

// Adjusting content width
if ($layoutVariation != 2){
	if ($this->countModules('diler-right') && ($this->countModules('diler-left-top') || $this->countModules('diler-left'))){$spanCenter = 12-$spanLeft-$spanRight;}
	elseif ($this->countModules('diler-right') && !$this->countModules('diler-left') && !$this->countModules('diler-left-top')){$spanCenter = 12-$spanRight;}
	elseif (!$this->countModules('diler-right') && ($this->countModules('diler-left') || $this->countModules('diler-left-top'))){$spanCenter = 12-$spanLeft;}
	else{$spanCenter = "span12";}
	//	$spanCenter = 12-$spanLeft-$spanRight;
}else{
	// Adjusting content width for bulletin
	$spanLeft = $bulletinLeft;
	$spanRight = $bulletinRight;
	$spanCenter = 12 - $spanLeft - $spanRight;
}

/* START Texter message indicator */
$dilerRole = false;
$bulletinDesk = false;
$absenceNotificationPermission = false;
if ($loggedIn){
	require_once JPATH_ROOT . '/modules/mod_latestmessages/helper.php';
	JLoader::register('Messages', JPATH_ROOT . '/components/com_diler/helpers/texter.php');
	JLoader::register('DilerHelperUser', JPATH_ROOT . '/components/com_diler/helpers/user.php');
	$dilerRole = DilerHelperUser::getDilerRole();
	$bulletinDesk = $user->authorise('bulletin.desk.view', 'com_diler');
    $absenceNotificationPermission = ($dilerRole == 'teacher' && $user->authorise('studentrecord.absencestats.view', 'com_diler'));
    $doc->addScriptOptions('absenceNotificationPermission', $absenceNotificationPermission);
	$newsContent = DilerHelperUser::getNewsContent();
	$feedContent = DilerHelperUser::getFeedContent();
	if (in_array($dilerRole, array('teacher', 'student', 'parent')))
	{
		$messages = modLatestmessagesHelper::getLatestMessages();
		$totalMessageCount = modLatestmessagesHelper::getMessageCount();

		JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

		// Get Diler newsfeed and local news information
		$feedClass = ($feedContent->unread) ? 'newNotification badge badge-warning' : 'newNotification badge';

		$newsClass = ($newsContent->unread) ? 'newNotification badge badge-warning' : 'newNotification badge';

		$date_format = DText::_('DATE_FORMAT_LC4');
		$urlLang = substr($language, 0, 2);
		$dilerItemId = DilerHelperUser::getDeskItemId($language);

		$anchorClassSystem = '';
		$badgeClassSystem = '';
		if ($totalMessageCount->system)
		{
			$anchorClassSystem = 'unreadMessages';
			$badgeClassSystem = 'newMessage badge badge-warning';
		}
		else
		{
			$anchorClassSystem = '';
			$badgeClassSystem = 'newMessage badge';
		}
		if ($totalMessageCount->manual)
		{
			$anchorClassManual = 'unreadMessages';
			$badgeClassManual = 'newMessage badge badge-warning';
		}
		else
		{
			$anchorClassManual = '';
			$badgeClassManual = 'newMessage badge';
		}
		if ($totalMessageCount->cloud)
		{
			$anchorClassCloud = 'unreadMessages';
			$badgeClassCloud = 'newMessage badge badge-warning';
		}
		else
		{
			$anchorClassCloud = '';
			$badgeClassCloud = 'newMessage badge';
		}
		/* END Texter message indicator */
	}
}

function getPackageVersionInfo()
	{
		$xmlContent = file_get_contents(JPATH_ADMINISTRATOR . '/manifests/packages/pkg_diler.xml', true);
		$extension = new \SimpleXMLElement($xmlContent);
		$dilerInstalledVersion = (string) $extension->version[0];
		$dilerInstalledEdition = (string) $extension->version[0]['data-edition'];
		$joomlaVersion = (string) $extension->dependencies->dependency[0]['version'];

		return (object) array('diler_version' => $dilerInstalledVersion,
			'diler_edition' => $dilerInstalledEdition,
			'minimum_joomla_version' => $joomlaVersion
		);
	}

BaseDatabaseModel::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_diler/models/');
$versionInfo = getPackageVersionInfo();
$dilerVersion = $versionInfo->diler_version;
$dilerEdition = $versionInfo->diler_edition;

BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models/');
/** @var DiLerModelDiLer $dilerModel */
$dilerModel = MVCHelper::factory()->createModel('Diler', 'Site');
$myAccountItemId = $dilerModel->getMenuItemByAlias('my-account')->id;
?>

<!DOCTYPE html>
<html class="site fluid <?php echo $pageclass.' '.$option.' view_'.$view . ' ' . $editionClass.($layout ? ' layout-'.$layout : ' no-layout').
	($task ? ' task-'. $task : ' no-task').($itemid ? ' itemid-'.$itemid : '').($layoutVariation == 1 ? ' centered' : ($layoutVariation == 2 ? ' bulletin' : '')); ?>"
	xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $language; ?>" lang="<?php echo $language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<style>	<?php /* prevent unstyled content till the diler.css is fully loaded: */?>
		html{height:100%;background:#ddd none;}
		body{min-height: 100%;background:transparent none;}
		body.site {border-top: none;padding:0}
		body.site.fluid {/*background-color: transparent;*/}
		body.site.centered {height:100%}
		#bodyBg,#bgImage {display:block;background: #eee none center center no-repeat;background-size: cover;width: 100%;height: 100%;position:fixed}
		#bgImage{background-color: transparent;background-size: contain;background-position:center 10%}
		#bodyBg {background-image:url(<?php echo htmlspecialchars($path).'/'.$deskBackground;?>)}
		@media screen and (min-width: 960px){#bgImage{background-image:url(<?php echo htmlspecialchars($path); ?>/media/com_diler/images/logos/diler_rainbow_1280.png)}}
	</style>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php if (VersionHelper::isJoomla4()) : ?>
        <script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/jui/js/jquery.min.js"></script>
        <script type="text/javascript">
			var $ = jQuery.noConflict();
			// Code that uses other library's $ can follow here.
        </script>
        <script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/jui/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo Uri::root(true) . '/media/com_diler/js/diler.js?v=' . $v ?>"></script>
        <script type="text/javascript" src="<?php echo Uri::root(true) . '/media/com_diler/js/selectize.js?v=' . $v ?>"></script>
        <script type="text/javascript" src="<?php echo Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js' ?>"></script>
        <script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/system/highlighter-uncompressed.js"></script>
	<?php else :  ?>
        <script type="text/javascript" src="<?php echo Uri::root(true) ?>/media/jui/js/jquery.min.js"></script>
	<?php endif; ?>

	<jdoc:include type="head" />

	<?php /*<script src="<?php echo htmlspecialchars($tpath); ?>/js/bs4/jquery-3.3.1.min.js"></script>
    <script src="<?php echo htmlspecialchars($tpath); ?>/js/bs4/popper.min.js"></script>
    <script src="<?php echo htmlspecialchars($tpath); ?>/js/bs4/bootstrap.min.js"></script>*/?>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/jquery.tablesorter.min.js"></script>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/jquery.base64.min.js"></script>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/jquery.plusanchor.js"></script>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/jquery.placeholder.min.js"></script>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/jquery.sticky.js"></script>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/clipboard.min.js"></script>
	<?php if ($option != 'com_diler' && !VersionHelper::isJoomla4()): ?>
		<?php $doc->addScript(Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js'); ?>
		<?php $doc->addScript(Uri::root(true) . '/media/com_diler/js/diler.js?v=' . $v ); ?>
    <?php endif; ?>
	<script type="text/javascript" src="<?php echo htmlspecialchars($tpath); ?>/js/diler_script.js?v=<?php echo $v?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo htmlspecialchars($tpath); ?>/css/bootstrap.min.css"><!-- includes .responsive -->

	<link rel="stylesheet" type="text/css" href="<?php echo htmlspecialchars($tpath); ?>/css/fontawesome.min.css"><!-- fa pro -->
	<link rel="stylesheet" type="text/css" href="<?php echo htmlspecialchars($tpath); ?>/css/diler.css?v=<?php echo $v?>">
	<link rel="apple-touch-icon" type="image/png" sizes="57x57" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon" type="image/png" sizes="60x60" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" type="image/png" sizes="72x72" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" type="image/png" sizes="76x76" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" type="image/png" sizes="114x114" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" type="image/png" sizes="120x120" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" type="image/png" sizes="144x144" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-144x144.png">
	<link rel="apple-touch-icon" type="image/png" sizes="152x152" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" type="image/png" sizes="180x180" href="<?php echo htmlspecialchars($tpath); ?>/apple-touch-icon-180x180.png">

	<link rel="manifest" href="<?php echo htmlspecialchars($tpath); ?>/manifest.json">
	<meta name="msapplication-config" content="<?php echo htmlspecialchars($tpath); ?>/browserconfig.xml" />
	<?php if (DilerHelperUser::isDiglu()) : ?>
		<meta name="apple-mobile-web-app-title" content="DigLu">
	<?php else:?>
		<meta name="apple-mobile-web-app-title" content="DiLer">
	<?php endif;?>
	<meta name="application-name" content="DiLer">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="<?php echo htmlspecialchars($tpath); ?>/mstile-144x144.png">
	<meta name="theme-color" content="#ffffff">
	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('body').removeClass('nojs');
		});
	</script>
</head>

<body id="top" class="site fluid nojs <?php echo $pageclass.' '.$option.' view-'.$view.($layout ? ' layout-'.$layout : ' no-layout').($task ? ' task-'. $task : ' no-task').
    ($itemid ? ' itemid-'.$itemid : '').($layoutVariation == 1 ? ' centered' : ($layoutVariation == 2 ? ' bulletin' : '')); ?>">
	<div id="dist" style="position:fixed"></div>
	<?php if ($deskBackground != 'media/com_diler/images/logos/diler_sky_1280.png') {?>
		<div id="bodyBg" class="schoolBackground"></div>
	<?php } else {?>
    	<div id="bodyBg"></div>
    	<?php echo $bgImage ? '<div id="bgImage"></div>':'';?>
	<?php } ?>
	<noscript>
		<div class="vertMiddle">
			<div>
				<div id="dilerMainNoscript" class="well floorBox" role="main">
					<div id="system-message-container-noscript">
                        <div id="system-message-noscript">
							<div class="alert alert-error">
								<h4 class="alert-heading"><?php echo DText::_('TPL_DILER3_NOSCRIPT_WARNING_HEADING'); ?></h4>
								<div><p><?php echo DText::_('TPL_DILER3_NOSCRIPT_WARNING_SHORT'); ?></p></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</noscript>
	<?php if ($layoutVariation == 1) { ?>
	<table id="center">
		<tbody>
			<tr>
				<td>
					<span id="dilerMain" role="main" class="<?php echo $deskBackground == 'media/com_diler/images/logos/diler_sky_1280.png' ? '':'customBg ';?><?php echo (($option==='com_users' && $view!=='login') || $option == 'com_dilerreg') ? 'well floorBox ' : ''; echo $option==='com_users' && $view==='login' ? 'login' : '';?>">
						<?php if (Factory::getApplication()->getMessageQueue()) : ?>
							<jdoc:include type="message" />
						<?php endif; ?>
						<jdoc:include type="component" />
						<?php if (DilerHelperUser::isDiglu()) : ?>
							<div id="siteName"><?php echo $sitename.' @ '.$dilerEdition.' '.$dilerVersion;?></div>
						<?php else:?>
							<div id="siteName"><?php echo $sitename.' @ DiLer '.$dilerEdition.' '.$dilerVersion;?></div>
						<?php endif;?>
						<div id="recommended"><?php echo $recommends; ?></div>
						<jdoc:include type="modules" name="diler-centered" style="html5" />
						<jdoc:include type="modules" name="diler-login-languages" style="basic" />
                        <?php
                        $schoolLogoFile = \Joomla\CMS\Helper\MediaHelper::getCleanMediaFieldValue($componentParams->get('schoollogo'));
                        if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT . '/' . $schoolLogoFile))
	                        $schoolLogoFileUrl = Uri::root() . $schoolLogoFile;
                        else
	                        $schoolLogoFileUrl = Uri::root() . '/images/diler/logos/logo400x138.png';
                        ?>
						<div class="LoginSchoologoWrapper" style="background-image: url(<?php echo $schoolLogoFileUrl; ?>)"></div>
					</span>
				</td>
			</tr>
		</tbody>
	</table>
	<?php }
	else if ($layoutVariation == 2) { ?>
		<div id="bulletinContainer">
			<?php if ($bulletinTop) { ?>
				<div id="bulletinTop" class="visible-bulletin" style="font-size:<?php echo $bulletinTopFontsize;?>vw !important">
					<div class="bulletinSchoolLogo">
						<?php echo $bulletinTopLogo ? '<img alt src="'.$schoollogo.'">' : '';?>
					</div>
					<div class="bulletinMessage text-<?php echo $bulletinTopTextalign;?>"><?php echo $bulletinTopText;?>&nbsp;</div>
				</div>
			<?php }?>
			<div class="container-fluid">
				<div class="row-fluid">
					<div class="span12">
						<?php if ($this->countModules('diler-bulletin-header')): ?>
							<header id="bulletinHeader" class="row-fluid">
								<jdoc:include type="modules" name="diler-bulletin-header" style="html5" />
							</header>
						<?php endif; ?>
						<div class="row-fluid">
							<?php if ($this->countModules('diler-bulletin-left')) : ?>
								<div id="bulletinLeft" class="span<?php echo $spanLeft;?>">
									<jdoc:include type="modules" name="diler-bulletin-left" style="html5" />
								</div>
							<?php endif; ?>
							<?php if ($this->countModules('diler-bulletin-main') || Factory::getApplication()->getMessageQueue()): ?>
								<div id="bulletinMain" class="span<?php echo $spanCenter;?>">
									<?php if (Factory::getApplication()->getMessageQueue()){ ?>
										<jdoc:include type="message" />
									<?php } ?>
									<jdoc:include type="modules" name="diler-bulletin-main" style="html5" />
								</div>
							<?php endif; ?>
							<?php if ($this->countModules('diler-bulletin-right')) : ?>
								<div id="bulletinRight" class="span<?php echo $spanRight;?>">
									<jdoc:include type="modules" name="diler-bulletin-right" style="html5" />
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			<div id="bulletinBottom" class="visible-bulletin">
				<div class="bulletinDateTime"><?php echo HTMLHelper::_('date',date("Y-m-d H:i:s"), 'l').', '.HTMLHelper::_('date',date("Y-m-d"), Text::_("DATE_FORMAT_LC4"));?>&nbsp;&nbsp;<span id="clock"><?php echo date(DText::_('H:i:s'));?></span></div>
				<div class="bulletinModulWrapper"><?php echo $bulletinWeather ? '<jdoc:include type="modules" name="diler-bulletin-bottom" style="html5" />' : '';?></div>
				<div class="bulletinLogo"></div>
			</div>
		</div>
		<jdoc:include type="modules" name="debug" style="basic" />
	<?php }
	else { ;?>
		<div id="topPanel" class="collapse">
		</div>
		<nav class="navbar fixed-top">
			<a class="logo-home" style="display:block;" href="index.php">
				<?php if (DilerHelperUser::isDiglu()) : ?>
					<img id="logo" class="js---di-tooltip divider" data-placement="right" title="<?php echo $sitename.' @ '.$dilerEdition.' '.$dilerVersion;?>" alt="DigLu Logo" src="media/com_diler/images/logos/diglu.png">
				<?php else:?>
					<img id="logo" class="js---di-tooltip divider" data-placement="right" data-title="<?php echo $sitename.' @ DiLer '.$dilerEdition.' '.$dilerVersion;?>" alt="DiLer Logo" src="media/com_diler/images/logos/diler.png">
				<?php endif;?>
			</a>
			<div id="messagesInboxLink" class="divider">
				<?php if ($user->authorise('texter.view', 'com_diler')) : ?>
					<div class="messagesBadgeWrapper">
						<i class="fal fa-check-square fa-fw hastooltip" data-placement="bottom" title="<?php echo DText::_('SYSTEM_MESSAGES'); ?>"></i>
						<?php // texter_default=-2 selects only system message. 0 selects only manual messages. ?>
						<?php if(true || (int) $totalMessageCount->system):?>
							<a id="texterLatestMessagesModuleBadge" class="<?php echo $anchorClassSystem;?>" href="<?php echo "index.php?option=com_diler&view=".$dilerRole."_desk&lang=" . $urlLang . '&tab_id=tab-texter&texter_default=-2&Itemid=' . $dilerItemId;?>">
								<span class="<?php echo $badgeClassSystem; ?>"><?php echo (int) $totalMessageCount->system > 9 ? '9+' : (int) $totalMessageCount->system; ?></span>
							</a>
						<?php endif; ?>
					</div>
					<div class="messagesBadgeWrapper">
						<i class="fal fa-envelope fa-fw hastooltip" data-placement="bottom" title="<?php echo DText::_('TEXTER_MANUAL_MESSAGES'); ?>"></i>
						<a id="texterLatestMessagesModuleBadgeManualMessages" class="<?php echo $anchorClassManual;?>" href="<?php echo "index.php?option=com_diler&view=".$dilerRole."_desk&lang=" . $urlLang . '&tab_id=tab-texter&texter_default=0&Itemid=' . $dilerItemId;?>">
							<span class="<?php echo $badgeClassManual; ?>"><?php echo (int) $totalMessageCount->manual > 9 ? '9+' : (int) $totalMessageCount->manual; ?></span>
						</a>
					</div>
					<?php /* this is to temporarily hide the cloud icon from the DigLu Stützpunktlehrkraft user group until we have the refactored UI where the cloud icon is only displayed to users that have access to at least 1 cloud category */?>
					<?php if (!DilerHelperUser::isDiglu() || (DilerHelperUser::isDiglu() && !in_array("58", $user->groups))) : ?>
						<div class="messagesBadgeWrapper">
							<i class="fal fal fa-cloud fa-fw hastooltip" data-placement="bottom" title="<?php echo DText::_('TEXTER_CLOUD_MESSAGES'); ?>"></i>
							<a id="texterLatestMessagesModuleBadgeCloudMessages" class="<?php echo $anchorClassCloud;?>" href="<?php echo "index.php?option=com_diler&view=".$dilerRole."_desk&lang=" . $urlLang . '&tab_id=tab-texter&texter_default=9&Itemid=' . $dilerItemId;?>">
								<span class="<?php echo $badgeClassCloud; ?>"><?php echo (int) $totalMessageCount->cloud > 9 ? '9+' : (int) $totalMessageCount->cloud; ?></span>
							</a>
						</div>
					<?php endif; ?>
				<?php endif; ?>
				<?php if ($dilerRole == 'teacher' && $user->authorise('studentrecord.absencestats.view', 'com_diler')) : ?>
					<div class="notificationAlertWrapper" id="notification-absence-stats">
						<i class="fal fa-clipboard-list fa-fw hastooltip" aria-hidden="true" data-placement="bottom" title=""></i>
						<a id="notificationAbsenceStatsBadge" href="#notificationAlertModal" class="notificationAlertBadge" data-toggle="modal" >
						</a>
					</div>
				<?php endif; ?>
				<?php if ($user->authorise('studentrecord.newentries.view', 'com_diler')
					&& $user->getParam('displayNewStudentRecord', '1') != 2) : ?>
				<div class="notificationAlertWrapper" id="notification-student-record">
					<i class="fal fa-list-alt fa-fw hastooltip" aria-hidden="true" data-placement="bottom" title=""></i>
					<a href="#studentRecordAlertModal" id="notificationStudentRecordBadge" class="notificationAlertBadge"
						data-toggle="modal">
						<span class=""></span>
					</a>
				</div>
				<?php endif; ?>
				<?php if ($loggedIn && $newsContent->enabled) : ?>
				<div id="notificationAlertNews" class="notificationAlertWrapper" tabindex="0" onblur="jQuery('#notificationAlertNewsBadge').popover('hide');">
					<i class="fal fa-building fa-fw hastooltip" aria-hidden="true" data-placement="bottom" title="<?php echo $newsContent->title; ?>"></i>
					<a id="notificationAlertNewsBadge" class="<?php echo $anchorClassManual;?> notificationAlertBadge" data-toggle="modal" href="#schoolNewsModal">
						<span class="<?php echo $newsClass; ?>"><?php echo (int) $newsContent->unread > 9 ? '9+' : (int) $newsContent->unread; ?></span>
					</a>
				</div>
				<?php endif; ?>
				<?php if ($loggedIn && $feedContent->enabled): ?>
				<div id="notificationAlertFeed" class="notificationAlertWrapper" tabindex="0" onblur="jQuery('#notificationAlertFeedBadge').popover('hide');">
					<i class="ico-di hastooltip" aria-hidden="true" data-placement="bottom" title="<?php echo $feedContent->title;?>"></i>
					<a id="notificationAlertFeedBadge" class="<?php echo $anchorClassManual;?> notificationAlertBadge" data-toggle="modal" href="#dilerNewsModal">
						<span class="<?php echo $feedClass; ?>"><?php echo (int) $feedContent->unread > 9 ? '9+' : (int) $feedContent->unread; ?></span>
					</a>
				</div>
				<?php endif; ?>
				<?php if ($bulletinDesk): ?>
					<a id="topPanelTrigger" class="collapsed" data-toggle="collapse" data-target="#topPanel" onclick="dilerGetDeskBulletin()">
						<i class="fal fa-window-maximize"></i>
					</a>
				<?php endif; ?>
			</div>
            <?php if ($loggedIn): ?>
			<?php echo LayoutHelper::render('profile_picture', array(
				'user'             => DGet::user($user->id),
				'containerClass'   => 'navbar-profile-picture',
				'link'             => Uri::root() . 'index.php?option=com_diler&view=diler&Itemid=' . $myAccountItemId,
			), DPath::LAYOUTS_USER);  ?>
            <?php endif; ?>
			<jdoc:include type="modules" name="diler-topnav4" style="wrapper" />
		</nav>
		<?php if ($this->countModules('diler-header')): ?>
			<header id="dilerHeader">
				<jdoc:include type="modules" name="diler-header" style="basic" />
			</header>
		<?php endif; ?>
		<div id="dilerContainer" class="container-fluid">
			<div class="row-fluid">
				<?php if ($this->countModules('diler-left-top') || $this->countModules('diler-mainmenu') || $this->countModules('diler-languages') || $this->countModules('diler-left')) : ?>
				<div id="dilerLeft" class="span<?php echo $spanLeft;?>">
					<?php if ($this->countModules('diler-left-top')) : ?>
						<div id="dilerLeftTop" class="well well-small floorBox">
							<jdoc:include type="modules" name="diler-left-top" style="wrapper" />
						</div>
					<?php endif; ?>
					<?php if ($this->countModules('diler-left')) : ?>
						<div id="dilerLeftMain"><jdoc:include type="modules" name="diler-left" style="wrapper" /></div>
					<?php endif; ?>
				</div>
				<?php endif; ?>
				<div id="content" class="span<?php echo $spanCenter;?>">
					<?php if ($this->countModules('diler-topcontent')): ?>
						<aside id="dilerTopContent">
							<jdoc:include type="modules" name="diler-topcontent" style="basic" />
						</aside>
					<?php endif; ?>
					<div id="dilerMainWrapper">
							<jdoc:include type="message" />
						<?php if (Factory::getApplication()->input->get('option') === 'com_dpcalendar' && Factory::getApplication()->input->get('layout') !== 'edit') : ?>
                            <jdoc:include type="message" />
						<?php endif; ?>
                        <?php if(Factory::getApplication()->input->get('option') === 'com_dpcalendar'):?>
                            <script>
                                $(document).ready(function() {
                                    $('div#imageModal_jform_images_image_full').removeClass('fade');
                                    $('div#imageModal_jform_images_image_intro').removeClass('fade');
                                    $('div#imageModal_jform_images_image_full>.modal-dialog>.modal-content>.modal-body').css('height','95%');
                                    $('div#imageModal_jform_images_image_intro>.modal-dialog>.modal-content>.modal-body').css('height','95%');
                                    $('button.button-clear>span').removeClass('visually-hidden');
                                });
                            </script>
                        <?php endif?>

						<div id="dilerMain" role="main" class="<?php echo ($option==='com_dpcalendar' || $option==='com_content') ? 'well well-small floorBox' : '';?>">
							<jdoc:include type="component" />
						</div>
					</div>
				</div>
				<?php if ($this->countModules('diler-right')) : ?>
					<aside id="dilerRightMain" class="span<?php echo $spanRight;?>">
						<jdoc:include type="modules" name="diler-right" style="basic" />
					</aside>
				<?php endif; ?>
			</div>
		</div>
		<?php if ($this->countModules('diler-footer')) : ?>
		<div id="dilerFooter" class="container-fluid footer">
			<jdoc:include type="modules" name="diler-footer" style="basic" />
		</div>
		<?php endif; ?>
	<?php } ?>
	<div id="disconnect-alert" class="hide">
		<i class="fas fa-exclamation-triangle"></i>
		<strong><?php echo DText::_('DISCONNECT_ALERT'); ?></strong>
		<?php echo DText::_('TRYING_AGAIN_IN'); ?>
		<span> 0 </span> <?php echo DText::_('SECONDS'); ?>
		<b onclick="dilerSystem.testConnection()"><?php echo DText::_('TRY_NOW'); ?></b>
	</div>
	<?php echo LayoutHelper::render(
		'modal',
		array(
			'id' => 'disconnect-alert-modal',
			'title' => DText::_('DISCONNECT_ALERT'),
			'content' => DText::_('DISCONNECT_ALERT_MODAL_BODY'),
		),
		DPath::LAYOUTS_NOTIFICATIONS
	); ?>

	<a href='#top'><i class="fal fa-chevron-up"></i></a>
	<div id="regionTeachersModalContainer"></div>
	<div id="emailModal"></div>
	<?php if ($this->countModules('diler-ribbon')) : ?>
	<div id="dilerRibbon" class="">
		<jdoc:include type="modules" name="diler-ribbon" style="basic" />
	</div>
	<?php endif; ?>
	<script type="text/javascript">
		jQuery(document).ready( function() {
			<?php if ($bulletinDesk): ?>
			jQuery('#topPanelTrigger').click(function() {
				setTimeout('jQuery("html").toggleClass("noScroll")', 120);
			});
			<?php endif; ?>
		});
	</script>
	<jdoc:include type="modules" name="debug" style="basic" />
	<?php if ($dilerRole === 'teacher') : ?>
		<div id="notificationAlertModal" class="modal hide fade notification-alert" tabindex="-1" role="dialog" aria-hidden="true"></div>
	<?php endif;?>
	<?php if (in_array($dilerRole, array('teacher', 'student', 'parent'))) : ?>
		<div id="studentRecordAlertModal" class="modal hide fade" tabindex="-1" role="dialog" aria-hidden="true"></div>
	<?php endif;?>

	<?php if ($loggedIn && $newsContent->enabled) : ?>
		<?php
			$displayData = [
				'id' => 'schoolNewsModal',
				'title' => DText::_('NOTIFICATION_ALERT_INTERNAL'),
				'content' => $newsContent->text,
			];
			$modalLayout = new FileLayout('modal', JPATH_ROOT . '/components/com_diler/layouts/notifications');
			echo $modalLayout->render($displayData);
		?>
	<?php endif;?>

	<?php if ($loggedIn && $feedContent->enabled): ?>
		<?php
			$displayData = [
				'id' => 'dilerNewsModal',
				'title' => DText::_('NOTIFICATION_ALERT_DILER_FEED'),
				'content' => $feedContent->text,
			];
			$modalLayout = new FileLayout('modal', JPATH_COMPONENT . '/layouts/notifications');
			echo $modalLayout->render($displayData);
		?>
	<?php endif; ?>
</body>
</html>
