/**
 * @package     Joomla.Administrator
 * @subpackage  Templates.diler3
 *
 * @copyright   Copyright (C) 2013 JordyMedia™. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

//Check Numeric
function IsNumeric(input){
    var RE = /^-{0,1}\d*\.{0,1}\d+$/;
    if(!RE.test(input.value))
	{
		alert('Please provide numeric value.');
		input.value="";
		input.focus();	
		return false
	}
	else
	{
		//its true
		return true;	
	}
}
