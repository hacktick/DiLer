/**
 * @package     Joomla.Site
 * @subpackage  Templates.diler3
 *
 * @copyright   Copyright (C) 2013 JordyMedia™. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

var lang = '';
var keyboardHelp = true;
var inputFocus = '#password';

// escaping user input (stackoverflow.com/questions/3561493/is-there-a-regexp-escape-function-in-javascript)
RegExp.escape = function( value ) {
	return value.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
};

var currentUrl = window.location.href.split('&');
	var queryStrings = '';
	for(var urlcoun = 0; urlcoun < currentUrl.length; urlcoun++)
	{
		queryStrings = currentUrl[urlcoun].split('=');
		if((queryStrings.length !== undefined&&queryStrings[0] !== undefined)&&(queryStrings.length > 1 && queryStrings[0] === 'lang'))
		{
			var lang = queryStrings[1];
		}
	}
function updateStudentRecordIds(studentRecordId) {
	url = jQuery(event.target).attr('data-href');
	var ajaxObject = {
			option: 'com_diler',
			task: 'diler.updateReadDate',
			type: 'studentRecordId'+ studentRecordId
		};
	dilerSystem.doAjax(ajaxObject, 'json', dilerSystem.checkoutRowSuccess, dilerSystem.checkoutRowSuccess);
	window.location.href = url;
};

function clearStudentRecordNotifications(type) {
    type = (typeof type === 'undefined') ? 'clearAllStudentRecords' : type;
    var ajaxObject = {
            option: 'com_diler',
            task: 'diler.updateReadDate',
            type: type
    };
    dilerSystem.doAjax(ajaxObject, 'json', clearStudentRecordNotificationsSuccess, dilerSystem.checkoutRowSuccess);
};

function clearAlertBadge(el) {
    var readType = jQuery(el).attr('id');
    jQuery('#' + readType).find('span.badge-warning').removeClass('badge-warning').html('0');
    var ajaxObject = {
            option: 'com_diler',
            task: 'diler.updateReadDate',
            type: readType
    };
    dilerSystem.doAjax(ajaxObject, 'json', dilerSystem.checkoutRowSuccess, dilerSystem.checkoutRowSuccess);
};

function clearStudentRecordNotificationsSuccess(data) {
    jQuery('#studentRecordAlertModal').html(data.modalHtml);
    jQuery('#notification-student-record').html(data.alertHtml);
};

jQuery(document).ready(function() {
    var url = window.location.href;
    // Update the student record alert if not com_users
	if (url.indexOf('com_users') === -1 && url.indexOf('com_dilerreg') === -1) {
		clearStudentRecordNotifications('displayOnly');
		if(Joomla.getOptions('absenceNotificationPermission')) {
			getAbsenceNotification();
		}
	}
 
    // Insert heading into dpcalendar module
    if (jQuery(".moduleWrapper.upcomingEvents").length && ! jQuery(".moduleWrapper.upcomingEvents h3").length) {
        dilerUpdateDpCalendarModuleGetTitle();
    }

	/* temp fix for redirect bug */
	jQuery('.site.com_diler.itemid-489.centered #center td').html('<a class="btn floorShadow item-510" href="index.php?option=com_diler"><i class="fal fa-desktop"></i> Schreibtisch</a>');
	jQuery('.notificationAlertBadge').click(function(event) {
            clearAlertBadge(jQuery(event.currentTarget));
	});

	// login / registration page / screen keyboard
	jQuery("#username").focus();
	jQuery("#registercode").focus(); // focus #registercode if it exists
	// screen keyboard
	jQuery("#keyboard .btn").click(function(e){
		window.clearTimeout(keyboardHelp);keyboardHelp = false;// now dont show the help since the user clicked a screen keyboard button
		jQuery(inputFocus).focus();
		jQuery(inputFocus).val(jQuery(inputFocus).val()+e.target.firstChild.nodeValue);
	});

	jQuery("#jform_password").focus(function(e){
		jQuery(this).removeAttr('readonly'); // readonly prevents Chrome from autocomplete
	});
	jQuery("#jform_password").blur(function(e){
		jQuery(this).attr('readonly'); // readonly prevents Chrome from autocomplete
	});
	jQuery("#jform_password2").focus(function(e){
		jQuery(this).removeAttr('readonly'); // readonly prevents Chrome from autocomplete
	});
	jQuery("#jform_password2").blur(function(e){
		jQuery(this).attr('readonly'); // readonly prevents Chrome from autocomplete
	});

	jQuery("#jform_passwordKeyboard").click(function(e){
		dilerRevealKeyboard("#jform_passwordKeyboard","#jform_password");
	});

	jQuery("#jform_password2").focus(function(e){
		dilerSwitchKeyboard("#jform_passwordKeyboard2","#jform_password2");
	});

	jQuery("#jform_password").focus(function(e){
		dilerSwitchKeyboard("#jform_passwordKeyboard","#jform_password");
	});

	jQuery("#passwordKeyboard").click(function(e){
		dilerRevealKeyboard("#passwordKeyboard","#password");
	});

	jQuery("#passwordKeyboardVerify").click(function(e){
		dilerRevealKeyboard("#passwordKeyboardVerify","#verify-password");
	});

	jQuery(".centered #showMore").click(function(e){
		jQuery(this).toggleClass("active");
		jQuery("#dilerLoginMore").slideToggle(100,function() {
			// Animation complete.
		});
		jQuery(".centered .dilerLanguages").slideToggle(300,function() {
			// Animation complete.
		});
	});

	// put the username in the username input after registration
	if(jQuery('.usernameRegSuccess').length){
		jQuery('#username').val(jQuery('.usernameRegSuccess').text());
	}

	// update the messages tab
//	jQuery('li a[href="tab-texter"]').click(function(){
//		tx.newMessageStatus('');
//	});

	jQuery("input, textarea").placeholder();

	// toggle left column
	jQuery('#dilerLeftHideButton').click(function(){
		jQuery('#dilerLeft').fadeOut('fast',function() {
			dilerInsertLeftDisplayButton();
			jQuery('#content').css({'margin-left':'0','float':'right'});
			jQuery('#content').addClass('fullWidth');
			jQuery('.breadcrumb').css('margin-left','48px');
			jQuery('.dilerLeftDisplayButton').fadeIn();
			jQuery('#content').animate({width:'100%'}, 300, function() {
				localStorage.setItem('leftColumn', 'hide');
			});
		});
	});
	var cookievalue =localStorage.getItem('leftColumn');
	if(cookievalue === 'hide'){
		jQuery('#dilerLeft').hide();
		jQuery('#content').css({'margin-left':'0','float':'right'});
		jQuery('#content').addClass('fullWidth');
		jQuery('#content').animate({width:'100%'}, 5, function() {
			dilerInsertLeftDisplayButton();
			jQuery('.breadcrumb').css('margin-left','48px');
			jQuery('.dilerLeftDisplayButton').fadeIn('fast');
		});
	}

	// If tab_id in the URL, save this in local storage
	var cookiesItems = {};
	var uniqueId = jQuery('.nav-tabs').attr('id');
	if( document.URL.indexOf("tab_id") !== -1 ) {
		var getItems = localStorage.getItem('com_diler_screen_settings');
		var cookiesItems = dilerSystem.getTabOptionsFromLocalStorage('com_diler_screen_settings');
		if (cookiesItems == null){
			cookiesItems = {};
		}
		var uri = document.URL.split("tab_id="); // look for tab_id and get the second part of the url
		uri = uri[1].split("&"); // cut everything after the tab_id and get the first string
		var targetTab = 'tab-' + uri[0];
		cookiesItems[uniqueId] = targetTab;
		localStorage.setItem('com_diler_screen_settings', JSON.stringify(cookiesItems));
	}

	// Get tab from local storage and set that tab as default
	var tabOptions = dilerSystem.getTabOptionsFromLocalStorage('com_diler_screen_settings');
	if (typeof tabOptions[uniqueId] !== 'undefined' && jQuery('a[href="#'+tabOptions[uniqueId]+'"]').length) {
		var lastTab = tabOptions[uniqueId];
		jQuery('a[href="#'+lastTab+'"]').parent().addClass('active');
		jQuery('#'+lastTab).addClass('active in');
	}
	else
	{
		// Nothing set in local storage so go to first tab
		jQuery('.nav-tabs li:first-child').addClass('active');
		jQuery('.tab-content .tab-pane:first-child').addClass('active in');
		var lastTab = jQuery('.tab-content .tab-pane:first-child').attr('id');
	}

	if (typeof tx == 'object') {
		tx.initializeTexter();
	}

	// Add tab name to breadcrumbs
	dilerBreadcrumbsUpdate(jQuery('a[href="#'+lastTab+'"]'));

	// Special processing for IE
	if(navigator.userAgent.match(/msie/i))
	{
		jQuery('.tab-content').find('div.tab-pane').each(function(){
			jQuery(this).removeClass('fade');
		});
	}

	// When a tab is clicked, save this as the last tab in the cookie for this uniqueid
	jQuery('.nav-tabs a').click(function(e){
		var cookiesItems = dilerSystem.getTabOptionsFromLocalStorage('com_diler_screen_settings');
		if (typeof cookiesItems === 'object') {
			cookiesItems[uniqueId] = jQuery(jQuery(this)).attr('href').slice(1);
		}
		else{
			cookiesItems[e.currentTarget.parentElement.parentElement.id] = jQuery(jQuery(this)).attr('href').slice(1);
		}
		localStorage.setItem('com_diler_screen_settings', JSON.stringify(cookiesItems));
		dilerBreadcrumbsUpdate(e.currentTarget);
	});

	// save & cancel buttons for Font Awesome 3.x
	jQuery('.saveButton').each(function( index ) {
		jQuery(this).html("<i class='fas fa-check'></i> "+jQuery(this).text());
	});
	jQuery('.cancelButton').each(function( index ) {
		jQuery(this).html("<i class='fal fa-times'></i> "+jQuery(this).text());
	});

	// back buttons
	jQuery( ".goback" ).click( function() {
		window.onbeforeunload = null;
		history.back();
		return false;
	});
	// flexible height for bootstrap modal popups
	//jQuery('.modal-body').css('max-height',jQuery(window).height()-260);

	// display the task iframe
	jQuery('.iframeiconwrapper').fadeOut(2000,'easeInExpo', function() {
		//jQuery('.iframeHolder').css('height','500px');
	});

	// language button
	jQuery("#dilerLanguagesButton").click( function() {
		jQuery(".moduleWrapper.dilerLanguages").slideToggle("fast");
	});

	if(jQuery('body').hasClass('bulletin')){
		setInterval('dilerUpdateClock()', 1000);
	}

	if(inIframe()){
		jQuery("html").addClass('inIframe');
	}else{
		jQuery("html").addClass('noIframe');
	}

	// scrollTop
	var scrollTop = jQuery("a[href='#top']");

	jQuery(window).scroll(function() {
		var topPos = jQuery(this).scrollTop();
		if (topPos > 100) {
			jQuery(scrollTop).css("opacity", "1");
		} else {
			jQuery(scrollTop).css("opacity", "0");
		}
	});
	jQuery(scrollTop).click(function() {
		jQuery('html, body').animate({
			scrollTop: 0
		}, 400);
		return false;
	});

	jQuery('.icon-calendar').replaceWith('<i class="fal fa-calendar-alt" aria-hidden="true"></i>');

});

function getAbsenceNotification() {
    var ajaxObject = {
            option: 'com_diler',
            task: 'diler.getAbsenceNotification'
    };
    dilerSystem.doAjax(ajaxObject, 'json', getAbsenceNotificationSuccess, dilerSystem.checkoutRowSuccess);	
};

function getAbsenceNotificationSuccess(data) {
    jQuery('#notificationAlertModal').html(data.modalHtml);
    jQuery('#notification-absence-stats').html(data.alertHtml);
};

// check if site is in iframe
function inIframe() {
    try {
        return window.self !== window.top;
    } catch (e) {
        return true;
    }
}

// digital clock
function dilerUpdateClock ( )
	{
	var currentTime = new Date ( );
	var currentHours = currentTime.getHours ( );
	var currentMinutes = currentTime.getMinutes ( );
	var currentSeconds = currentTime.getSeconds ( );
	var timeOfDay = '';

	// Pad the minutes and seconds with leading zeros, if required
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
	currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

	if(jQuery('html').attr('lang') == 'en-gb'){
		// Choose either "AM" or "PM" as appropriate
		timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

		// Convert the hours component to 12-hour format if needed
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

		// Convert an hours component of "0" to "12"
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	}

	// Compose the string for display
	var currentTimeString = currentHours + ":" + currentMinutes + ":" + currentSeconds + " " + timeOfDay;

	jQuery("#clock").html(currentTimeString);

}

function dilerAnchorScroll(this_obj, that_obj, base_speed, topOffset, addOffset) {
	var this_offset = jQuery(this_obj).offset();
	var that_offset = jQuery(that_obj).offset();
	var offset_diff = Math.abs(that_offset.top - this_offset.top);
	var speed       = (offset_diff * base_speed) / 1000;
	jQuery("html,body").animate({
		scrollTop: that_offset.top - topOffset - addOffset
	}, speed);
}

function dilerGetDeskBulletin() {
	jQuery('#sticky-wrapper').toggleClass('no-z');
	if (!jQuery('#topPanel #bulletinContainer').length) {
		jQuery('#topPanel').addClass('loading');
		dilerSystem.addResponseContainer('#topPanel', '', '4x');
		// Get bulletin content from server
	    var ajaxObject = {
	            option: 'com_diler',
	            task: 'diler.getDeskBulletin'
	    };
		dilerSystem.doAjax(ajaxObject, 'json', dilerGetDeskBulletinSuccess, dilerSystem.checkoutRowSuccess);		
	}
}

function dilerGetDeskBulletinSuccess(data) {
	jQuery('#topPanel').removeClass('loading');
	jQuery('#topPanel').html(data.html);
}

// inject the button to toggle the left template column next to the breadcrumbs
function dilerInsertLeftDisplayButton(){
	jQuery('#dilerTopContent').prepend(
		'<div class="custom dilerLeftDisplayButton">' +
			'<a id="dilerLeftDisplay" class="btn floor"><i class="fas fa-chevron-right" title="display navigation column"></i></a>' +
		'</div>'
	);
	jQuery('#dilerLeftDisplay').click(function(){
		jQuery('#content').animate({width:'65.95744680851064%'}, 300, function() {
			jQuery('#content').removeAttr('style');
			jQuery('#content').removeClass('fullWidth');
			jQuery('#dilerLeft').fadeIn('fast');
			jQuery('.breadcrumb').css('margin-left','0');
			jQuery('.dilerLeftDisplayButton').remove();
			localStorage.setItem('leftColumn', 'show');
		});
	});
}

function dilerShowHelp(){
	jQuery("#keyboardHelp").show("slow");
}

function dilerRevealKeyboard(senderButton,sender){
	inputFocus = sender;
	jQuery(sender).focus();
	if(jQuery(senderButton).hasClass('active')){
		jQuery('a[id*="passwordKeyboard"]').removeClass('active');
		jQuery("#keyboardWrapper").slideUp();
	}else{
		jQuery('a[id*="passwordKeyboard"]').removeClass('active');
		jQuery(senderButton).addClass('active');
		jQuery("#keyboardWrapper:hidden").slideDown(300,function() {
			// Animation complete.
			if(keyboardHelp) keyboardHelp = window.setTimeout(dilerShowHelp, 3000);
		});
	}
}

/**
 * Switches the keyboard based on the password focus
 * @param sender
 * @returns
 */
function dilerSwitchKeyboard(senderButton,sender) {
	inputFocus = sender;
}

function dilerBreadcrumbsUpdate(breadcrumbElement){
	var breadcrumb = jQuery(breadcrumbElement).text();
	jQuery('#addedAfter').remove();
	jQuery(".breadcrumb li").last().find('span :last').hasClass('divider');

	var devider = jQuery(".breadcrumb li:first-child").find('span:last').html();
	jQuery(".breadcrumb li").last().find('span.divider').remove();
	if(breadcrumb) {
		jQuery(".breadcrumb li").last().append('<span class="divider">'+devider+'</span>');
		jQuery(".breadcrumb").append('<li id="addedAfter"><span>'+breadcrumb+'</span></li>');
	}

	// Add tab name to help link
	if ((typeof jQuery('ul.nav-tabs[id!="cloud_media_group_list"] li>a').first().attr('data-tabName') == 'string') && (typeof jQuery('a[id^="dilerHelpButton"]') == 'object')) {
		// Get the data-tabName either from the event (after tab click) or the active class (on page load)
		var tabText = '';
		var helpEl = jQuery('a[id^="dilerHelpButton"]');
		if (jQuery(breadcrumbElement).is('a')) {
			tabText = jQuery(breadcrumbElement).attr('data-tabName');
		} else {
			tabText = jQuery('li[class="active"] a').attr('data-tabName');
		}
		// Get helpUrl from diler help button attributes
		var helpUrlNoLang = helpEl.attr('data-url-nolang');
		var language = helpEl.attr('data-lang');
		var newUrl = helpUrlNoLang + '_tab_' + tabText + '_' + language;
		if (typeof helpEl.attr('href') == 'undefined') {
			// We are using onclick instead
			helpEl.attr('onclick', 'Joomla.popupWindow("' + newUrl + '"' + helpEl.attr('data-onclick'));
		} else {
			helpEl.attr('href', newUrl);
		}
	}
}

function dilerUpdateDpCalendarModuleGetTitle() {
    var ajaxObject = {
        option: 'com_diler',
        task: 'diler.getDpCalendarModuleMarkup'
     };
    var myAjax = jQuery.ajax({
        url: 'index.php',
        type: 'POST',
        data: ajaxObject,
        dataType: 'json',
        async: true,
        cache: false
    });

    myAjax.done(function (data) {
        dilerUpdateDpCalendarModule(data, ajaxObject);
    });

    myAjax.fail(function (data) {
        dilerUpdateDpCalendarModule(data, ajaxObject);
    });
}

function dilerUpdateDpCalendarModule(data, ajaxObject) {
    if (data.status !== 1) return true;
    jQuery(".moduleWrapper.upcomingEvents").prepend(data.text);
}

function toggleLabelClass(el) {
    jQuery(el).parent().toggleClass('active');
}

