<?php
 /**
 * @package		DiLer.Site
 * @subpackage	mod_login.diler
 * @filesource
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;



?>

<form action="<?php echo Route::_('index.php', true, $params->get('usesecure')); ?>" method="post" id="login-form" class="form-vertical">
<?php if ($params->get('greeting')) : ?>
	<div class="login-greeting">
	<?php if ($params->get('name') == 0) : {
		echo htmlspecialchars($user->get('name'));
	} else : {
		echo htmlspecialchars($user->get('username'));
	} endif; ?>
	</div>
<?php endif; ?>
	<div class="logout-button">
		<button type="button" name="Submit" class="btn" onclick="dilerLogout();">
			<i class="fal fa-power-off" aria-hidden="true"></i> <span class="hidden-phone"><?php echo Text::_('JLOGOUT'); ?></span>
		</button>
		<input type="hidden" name="option" value="com_users" />
		<input type="hidden" name="task" value="user.logout" />
		<input type="hidden" name="return" value="<?php echo $return; ?>" />
		<?php echo HTMLHelper::_('form.token'); ?>

	</div>
</form>
<script>
	function dilerLogout() {
		dilerSystem.saveUserSettings();
		localStorage.setItem('com_diler_talkie_running', 0);
		jQuery('#login-form').submit();
	};

</script>
