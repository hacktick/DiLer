<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @copyright   Copyright (C) 2012 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

/**
 * This is an example of the student report layout file. This can be used to create a custom layout.
 * As with standard Joomla JLayout files, the data for the layout is contained in a standard class called $displayData, with the following fields:
 *
 * student:          stdClass   columns from the dilerreg_users table for this student (for example, student->surname).
 *                              We also include learningGroupName and learningGroupId in the student object.
 *
 * studentFields:    array      Associative array in format field_name => stdClass for each student type field definition. stdClass has field id, name,
 *                              published, description, label, type, locked, params, ordering, student_id, value.
 *                              Example: $displayData->studentFields['strengths']->label or $displayData->studentFields['strengths']->value.
 *
 * subjects:         array      Array of stdClass objects, one for each subject the student is assigned to. Each subject has name, id, and fields.
 *                              fields is an associative array of field_name => stdClass for each subject type field,
 *                              where stdClass has the same fields as for student type fields above.
 *                              Example: foreach ($displayData->subjects as $subject), then $subject->name or $subject->fields['subject_participation']->label.
 *
 * reportInfo:     stdClass    	report_type_id, report_type_name, report_type_published, report_type_description, layout_file_name, noDataWarning
 *                             	period_id, period_published, period_name, period_published, period_description, start_date, end_date,
 *                              edit_start_date, edit_end_date, fields.
 *                              fields is an associative array of field_name => stdClass with same fields as for student and subject field definitions.
 *                              Example: $displayData->reportInfo->report_type_name or $displayData->reportInfo->fields['report_footer']->field_value
 *                              where 'report_footer' is the name of a period-type field definition.
 *
 * @ subjectfilter				(no space after the @) This marker indicates that the report has support for the subject filter
 *								in the "print report" tab and hence the subject filter is displayed if that marker is found
 *								in a report within a comment like: // @ subjectfilter
 *
 * @ groupfilter				(no space after the @) This marker indicates that the report has support for the group filter
 *								in the "print report" tab and hence the  group select filter is displayed if that marker is found
 *								in a report within a comment like: // @ groupfilter. This is used to display the image from the selected group file.
 *								This is displayed on the report using the variable $groupImageSource. You can also display the Group Name with $groupName
 *								and the subject or subjects with implode(',', $groupSubjectNameArray).
 *
 * @ reportParameter			(no space after the @) This marker indicates that the report has support for the "report parameter"
 *								that gets set in the students account - if that marker is found in a report within a comment like: // @ reportParameter
 *
 * @ subjectList				e.g. ="Religion,EWG,English,Mathematics" (no space after the @). Use this tag to enter a semi static list of subjects. The subjects will be matched
 * 								against existing subjects based on a full name match. Order in the report will be based on ordering in the list.
 *
 * @ entryClass					e.g. ="height--1 width--2" (no space after the @). Use this to apply css classes to the corresponding textarea in the data entry form.
 *								Note that you can add class "autosizeBox" if there is no height. If there is height defined,
 *								DiLer automatically adds {oninput="noScroll(this)"} attribute.
 *
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use DiLer\DConst;
use DiLer\Lang\DText;
use DiLer\Users\PersonalDataHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

extract((array) $displayData);

/**
 * Safely get fields without notices if they don't exist.
 * This function should not be necessary since we do not export reports without making sure all fields are included in the export file.
 * Also, the report must be fixed or the field must be created if a field does not exist in order to make the report functional.
 *
 * @param stdClass  $displayData   object with the layout's data
 * @param string    $fieldType     report, student, or subject
 * @param string    $name          name of field
 * @param string    $labelOrValue  label or value
 * @param stdClass  $subject       if $fieldType is 'subject', the object with the subject fields.
 */
function getField($displayData, $fieldType, $name, $labelOrValue = 'value', $subject = null)
{
    $result = '';
    switch ($fieldType)
    {
        case 'student' :
            if (isset($displayData->studentFields->$name))
            {
                $result = ($labelOrValue == 'label') ? $displayData->studentFields->$name->label : $displayData->studentFields->$name->label;
            }
            break;

        case 'report' :
            if (isset($displayData->reportInfo->fields->$name))
            {
                $result = ($labelOrValue == 'label') ? $displayData->reportInfo->fields->$name->label : $displayData->reportInfo->fields->$name->value;
            }
            break;

        case 'subject' :
            if (isset($subject->fields->$name))
            {
                $result = ($labelOrValue == 'label') ? $subject->fields->$name->label : $subject->fields->$name->value;
            }
            break;
    }
    return $result;
}

// @subjectfilter
// @reportParameter
// @subjectList="Religion||Deutsch||Englisch||Mathematik"

// The following line uses the PHP extract command to pull all variables from the $displayData object.
// This means we can use either $displayData->name or just $name. For example: $student->forename is the same value as $displayData->student->forename.
// This is only for convenience. Either form can be used.\

// get the master data from the DiLer options
$schoolName = $dilerOptions->schoolname ? $dilerOptions->schoolname : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schooladdressState = $dilerOptions->schooladdressStateName ? $dilerOptions->schooladdressStateName : '<span class="label label-warning" style=" ">'.DText::_('MASTERDATA_MISSING').'</span>';
$schooladdressCountry = $dilerOptions->schooladdressCountryName ? $dilerOptions->schooladdressCountryName : '<span class="label label-warning" style=" ">'.DText::_('MASTERDATA_MISSING').'</span>';
$schooladdressZipcode = $dilerOptions->schooladdressZipcode? $dilerOptions->schooladdressZipcode: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolAddressCity= $dilerOptions->schooladdressCity? $dilerOptions->schooladdressCity: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolAddress = $dilerOptions->schooladdress ? $dilerOptions->schooladdress : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolphone = $dilerOptions->schoolphone ? $dilerOptions->schoolphone : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolhead = $dilerOptions->schoolhead ? $dilerOptions->schoolhead : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolheadPosition = $dilerOptions->schoolheadPosition ? $dilerOptions->schoolheadPosition : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schooloperatorName = $dilerOptions->schooloperatorname ? $dilerOptions->schooloperatorname : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schooloperatoraddressZipcode = $dilerOptions->schooloperatoraddressZipcode? $dilerOptions->schooloperatoraddressZipcode: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schooloperatorAddressCity= $dilerOptions->schooloperatoraddressCity? $dilerOptions->schooloperatoraddressCity: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schooloperatorAddress = $dilerOptions->schooloperatoraddress ? $dilerOptions->schooloperatoraddress : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$accidentinsuranceName = $dilerOptions->accidentinsurancename ? $dilerOptions->accidentinsurancename : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$accidentinsuranceaddressZipcode = $dilerOptions->accidentinsuranceaddressZipcode? $dilerOptions->accidentinsuranceaddressZipcode: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$accidentinsuranceaddressCity= $dilerOptions->accidentinsuranceaddressCity? $dilerOptions->accidentinsuranceaddressCity: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$accidentinsuranceaddress = $dilerOptions->accidentinsuranceaddress ? $dilerOptions->accidentinsuranceaddress : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$accidentinsuranceCustomerId = $dilerOptions->accidentinsuranceCustomerId ? $dilerOptions->accidentinsuranceCustomerId : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$reportPeriode = $reportInfo->period_description;
$schoolSeal = $dilerOptions->schoolseals;
$schoolLogo = $dilerOptions->schoollogo ? '<img style="height: 16mm" alt="" src="' . Uri::root() . $dilerOptions->schoollogo . '">' : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$stateArms = $dilerOptions->statearms ? '<img src="' . Uri::root() . $dilerOptions->statearms.'" alt="" style="height: 32mm">' : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$studentForename = $student->forename;
$studentSurname = $student->surname;
$studentLearninggroup = $student->learningGroupName;
$studentDob = date(Text::_('DATE_FORMAT_LC4'), strtotime($student->dob));

// get the first guardian
$guardian = HTMLHelper::_('diler.studentReport', $displayData, 'student', 'guardian', 'value', '');
if (is_object($student->guardian1)):
$guardian = $displayData->student->guardian1->forename[0] . '. ' .
$displayData->student->guardian1->surname . ', ' .
$displayData->student->guardian1->address .', '.
$displayData->student->guardian1->portalcode . ' ' .
$displayData->student->guardian1->city;
endif;

$appendix = array();
$appendixes = array();
function append_appendix($name, $appendix, &$appendixes) {
    if($appendix) {
        $entry = array('name' => $name, 'appendix' => $appendix);
        $appendixes[] = $entry;
    }
}
?>

<?php /*
	This section contains optional variables that control the PDF file generation. studentReportFilename allows you to control the name of the PDF file
	using optional plugins for student name, learning group name, report period name, and report layout name.

	Page margins:
	* For fixed-page-number reports with limited space for text entry fields like <div class="height--1 width--2"> the page breaks are hard coded.
	* The page margins are part of the HTML markup of an inner div which represents e.g. the standard DIN letter format on an A4 sheet.
	* The domPDF page margins set like id="studentReportPageMargin" type="hidden" value="20mm 9mm .01mm 15mm"> need to correspond with the css
		for the .page-area container of that report type.

*/?>
<input id="studentReportPageMargin" type="hidden" value="20mm 10mm 0 15mm"><?php /* must correspond with page-area padding in example.css */?>
<input id="studentReportHeaderText" type="hidden" value="">
<input id="studentReportFooterText" type="hidden" value="<?php echo $studentForename.' '.$studentSurname.' | '.$studentLearninggroup.' | '.$reportPeriode.' | '.DText::_('REPORT_PAGE'); ?> {PAGE_NUM} von {PAGE_COUNT}">
<input id="studentReportHeaderPositionH" type="hidden" value="42">
<input id="studentReportFooterPositionH" type="hidden" value="42">
<input id="studentReportHeaderPositionV" type="hidden" value="25">
<input id="studentReportFooterPositionV" type="hidden" value="50">
<input id="studentReportHeaderStartPage" type="hidden" value="1">
<input id="studentReportFooterStartPage" type="hidden" value="1">
<input id="studentReportPageCountStart" type="hidden" value="1">
<input id="studentReportOrientation" type="hidden" value="portrait">
<input id="studentReportFilename" type="hidden" value="{STUDENT_NAME}_{LEARNING_GROUP}_{REPORT_PERIOD}_{LAYOUT_NAME}">

<div class="page-container page-1">

	<?php /* use these print marks to adjust the HTML to the generated pdf
    <div style="position: absolute; top: 0; left: 0;  width: 24mm; height: 10mm; border-right: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 100mm; height: 10mm; border-right: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 123mm; height: 10mm; border-right: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 200mm; height: 10mm; border-right: .1mm solid red"></div>

    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: .2mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 10mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 20mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 30mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 40mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 50mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 60mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 70mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 80mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 90mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 100mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 110mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 120mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 130mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 140mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 150mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 160mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 170mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 180mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 190mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 200mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 30mm; height: 295mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 50mm; height: 45mm; border-bottom: .1mm solid red"></div>
    <div style="position: absolute; top: 0; left: 0;  width: 50mm; height: 85mm; border-bottom: .1mm solid red"></div>
    */ ?>

	<div class="folding-mark-A4-top"></div>
	<div class="hole-puncher-mark-A4"></div>
	<div class="folding-mark-A4-bottom"></div>
	<div class="page-area">
		<div class="font--bold font-size--7" style="margin: 0 0 10mm;">This is an example PHP file. The layout for this report type and its accompanying css file is found in the folder called templates/diler3/html/com_diler/report_layouts. The full file name is example.php, but the ".php" is omitted in the Layout File Name above.</div>
		<div class="font--bold font-size--20">Test report for: <?php echo PersonalDataHelper::studentFullNameWithNicknameAtTheEnd((object)(array)$displayData->student) ?></div>
		<div class="font-size--12">Learning Group: <?php echo $displayData->student->learningGroupName; ?></div>
        <div style="margin:30mm 0 0; text-align: center;"><?php echo $stateArms;?></div>
        <div style="margin:30mm 0 0; text-align: center;"><?php echo $schoolLogo;?></div>
		<div>
			<div style="margin: 10mm 0;">
				School Name:<br>
				<?php echo $displayData->dilerOptions->schoolname; ?><br>
				<?php echo $schoolAddress; ?>
                <div class="font-size--14" style="margin:3mm 0; text-align: center;"><?php echo $schooladdressState . ', ' . $schooladdressCountry;?></div>
			</div>
			<div>Report Type Name: <?php echo $displayData->reportInfo->report_type_name; ?></div>
			<div>Description: <?php echo $displayData->reportInfo->report_type_description; ?></div>
			<div>Report Name: <?php echo getField($displayData, 'report', 'name_of_report'); ?></div>
			<div><?php echo HTMLHelper::_('diler.studentReport', $displayData, 'period', 'name_of_report', 'value', 'font-size: 10mm;margin: 60px 0 10px;'); ?></div>
		</div>
	</div>
</div>
<div class="page-container">
	<div class="page-area" style="min-height: 297mm;">
		<div style="margin: 0 0 5mm;">Student Fields</div>
		<div style="margin: 0 0 10mm;">Parent of this Student:<br>
			<?php if (is_object($student->guardian1)) : ?>
				<?php echo PersonalDataHelper::fullNameExcludeSalutation($displayData->student->guardian1, DConst::USER_ROLE_PARENT) . ', ' . $displayData->student->guardian1->address .', '.
						$displayData->student->guardian1->portalcode . ' ' . $displayData->student->guardian1->city; ?>
			<?php else : ?>
				<div>No guardian information is available.</div>
			<?php endif; ?>
		</div>
		<div class="height--1 width--1" style="margin: 0 0 10mm;">
			<?php echo HTMLHelper::_('diler.studentReport', $displayData, 'student', 'lernen', 'label', ''); ?>:<br>
			<?php echo HTMLHelper::_('diler.studentReport', $displayData, 'student', 'lernen', 'value', ''); // @entryClass="height--1 width--1" ?>
		</div>
		<div class="autosizeBox width--1" style="margin: 0 0 10mm;">
			<?php echo HTMLHelper::_('diler.studentReport', $displayData, 'student', 'bemerkungen', 'label', ''); ?>:<br>
			<?php echo HTMLHelper::_('diler.studentReport', $displayData, 'student', 'bemerkungen', 'value', ''); // @entryClass="autosizeBox width--1" ?>
		</div>
		<div style="margin: 0 0 10mm;">
			<?php echo HTMLHelper::_('diler.studentReport', $displayData, 'student', 'group_field', 'value', ''); ?>
		</div>
		<div>
			<?php /* The next two lines show the use of the "teacher" type field for students. The field "teacher_list_students" is set up as a "Student" entry type
			 * and "Teacher" element type. You use the function diler.studentReportGetValueObject to get the object. The object has the following properties:
			 * salutation, forename, surname, nickname, id (Joomla user id).
			 *
			 * Once you have the object, you just echo the desired values. 
			 */ ?>
			<?php echo HTMLHelper::_('diler.studentReport', $displayData, 'student', 'teacher_list_students', 'label', ''); ?>:<br>
			<?php $teacherObject = HTMLHelper::_('diler.studentReportGetValueObject', $displayData, 'student', 'teacher_list_students'); ?>
			<?php echo PersonalDataHelper::teacherFullName($teacherObject); ?>
		</div>
	</div>
</div>
<div class="page-container">
	<div class="page-area" style="min-height: 297mm;">
		<div class="font--bold font-size--14" style="margin: 0 0 3mm;">Subject Fields</div>
		<table class="report-table border">
			<tbody>
				<?php foreach ($displayData->subjects as $subject) : ?>
					<?php append_appendix($subject->name, HTMLHelper::_('diler.studentReport', $subject, 'subject', 'beurteilungstext_anlage', 'value', ''), $appendixes); ?>
					<tr>
						<td class="heading border-top border-right">
							<?php echo $subject->name; ?>
						</td>
						<td class="heading border-top">
							Niveaustufe *
						</td>
					</tr>
					<tr>
					    <td class="border-top border-right">
							<div class="height--1 width--1">
							    <?php echo HTMLHelper::_('diler.studentReport', $subject, 'subject', 'beurteilungstext', 'value', ''); // @entryClass="height--1 width--1" ?>
							</div>
					    </td>
					    <td class="border-top border-right" style="vertical-align: middle; padding: 2mm;">
							<div class="width--2">
								<?php echo HTMLHelper::_('diler.studentReport', $subject, 'subject', 'niveau_gme', 'value', ''); ?>
								<br><br>
								<?php echo $student->display_mark ? HTMLHelper::_('diler.studentReport', $subject, 'subject', 'zensur_bereich_note', 'value', ''):''; ?>
							</div>
					    </td>
					</tr>
				<?php endforeach; ?>
			</tbody>
	    </table>
	</div>
</div>
<div class="page-container">
	<div class="page-area font-size--8" style="min-height: 297mm;">
		<?php foreach ($displayData->subjects as $subject) : ?>
    		<div style="margin: 0 0 5mm;">
    			Subject: <?php echo $subject->name; ?> <?php echo ($reportInfo->report_type_subjects_pagination == 1) ? 'New page for each subject.' : 'No new page for each subject.'; ?>
            	<?php // The following command injects the achievement grid into the student report. It uses the layout called ?>
            	<?php // student_report_achieve_grid.php in the components/com_diler/layouts folder. ?>
            	<?php // achieveGrid shows the achievement grid for a student and subject. Arguments are: subject id, student id, show only completed (true or false or $statusCodeArray to get user input), options (array) ?>
            	<?php // options 'reportInfo' is needed to pass the period start and end dates. Otherwise, the current school year dates are used. ?>
            	<?php // $reportInfo->report_type_achievements_completed is used to indicate whether or not to show only completed achievements. ?>
            	<?php echo HTMLHelper::_('diler.achieveGrid', $subject->id, $displayData->student->id, $statusCodeArray,
            		array('showPhase' => true, 'layout' => 'student_report_achieve_grid', 'reportInfo' => $reportInfo)); ?>
			</div>
		<?php endforeach; ?>
    </div>
</div>
