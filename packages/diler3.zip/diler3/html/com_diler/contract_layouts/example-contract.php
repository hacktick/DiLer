<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 *
 * @copyright   Copyright (C) 2012 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 * @conent		template for the "verbindliche Vorlage für den Lernentwicklungsbericht in Gemeinschaftsschulen; Ministerium für Kultus, Jugend und Sport Baden-Württemberg"
 */

/**
 * As with standard Joomla JLayout files, the data for the layout is contained in a standard class called $displayData, with the following fields:
 *
 * student:          stdClass   columns from the dilerreg_users table for this student (for example, student->surname).
 *                              We also include learningGroupName and learningGroupId in the student object.
 *
 * studentFields:    array      Associative array in format field_name => stdClass for each student type field definition. stdClass has field id, name,
 *                              published, description, label, type, locked, params, ordering, student_id, value.
 *                              Example: $displayData->studentFields['strengths']->label or $displayData->studentFields['strengths']->value.
 *
 * subjects:         array      Array of stdClass objects, one for each subject the student is assigned to. Each subject has name, id, and fields.
 *                              fields is an associative array of field_name => stdClass for each subject type field,
 *                              where stdClass has the same fields as for student type fields above.
 *                              Example: foreach ($displayData->subjects as $subject), then $subject->name or $subject->fields['subject_participation']->label.
 *
 * reportInfo:     stdClass    	report_type_id, report_type_name, report_type_published, report_type_description, layout_file_name, noDataWarning
 *                             	period_id, period_published, period_name, period_published, period_description, start_date, end_date,
 *                              edit_start_date, edit_end_date, fields.
 *                              fields is an associative array of field_name => stdClass with same fields as for student and subject field definitions.
 *                              Example: $displayData->reportInfo->report_type_name or $displayData->reportInfo->fields['report_footer']->field_value
 *                              where 'report_footer' is the name of a period-type field definition.
 *
 * @ subjectfilter				(no space after the @) This marker indicates that the report has support for the subject filter
 *								in the "print report" tab and hence the subject filter is displayed if that marker is found
 *								in a report within a comment like: // @ subjectfilter
 *
 * @ reportParameter			(no space after the @) This marker indicates that the report has support for the "report parameter"
 *								that gets set in the students account - if that marker is found in a report within a comment like: // @ reportParameter
 *
 * @ subjectList				e.g. ="Religion,EWG,English,Mathematics" (no space after the @). Use this tag to enter a semi static list of subjects. The subjects will be matched
 * 								against existing subjects based on a full name match. Order in the report will be based on ordering in the list.
 *
 * @ entryClass					e.g. ="height--1 width--2" (no space after the @). Use this to apply css classes to the corresponding textarea in the data entry form.
 *
 */

// No direct access to this file

defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;

extract((array) $displayData);

// these need to come from the schools table referenced by the school id
$schoolName = $schoolInfo->school_name ? $schoolInfo->school_name : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolAddress = $schoolInfo->school_address ? $schoolInfo->school_address : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolCity= $schoolInfo->school_city ? $schoolInfo->school_city: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolState = $schoolInfo->school_state ? $schoolInfo->school_state : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolPostalCode = $schoolInfo->school_postal_code ? $schoolInfo->school_postal_code: '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolCountry = $schoolInfo->school_country ? $schoolInfo->school_country : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
$schoolPrincipal = $schoolInfo->school_principal ? $schoolInfo->school_principal : '<span class="label label-warning">'.DText::_('MASTERDATA_MISSING').'</span>';
?>

<input id="contractPageMargin" type="hidden" value="21mm 10mm 10mm 16mm">
<input id="contractHeaderText" type="hidden" value="Auftragsverarbeitungsvertrag">
<input id="contractFooterText" type="hidden" value="PAGE {PAGE_NUM} von {PAGE_COUNT}">
<input id="contractHeaderPositionH" type="hidden" value="42">
<input id="contractFooterPositionH" type="hidden" value="270">
<input id="contractHeaderPositionV" type="hidden" value="15">
<input id="contractFooterPositionV" type="hidden" value="28">
<input id="contractHeaderStartPage" type="hidden" value="2">
<input id="contractFooterStartPage" type="hidden" value="1">
<input id="contractPageCountStart" type="hidden" value="1">
<input id="contractFilename" type="hidden" value="avv-diglu_{SCHOOLSTATE}_{SCHOOLCITY}_{SCHOOLNAME}_{SCHOOLID}">

<div class="page-container avv">
	<div class="page-area">
		<div style="text-align:center;margin: 0 0 10mm 0;">
			<div style="font-size: 8mm;margin: 20mm 0 10mm 0;">Digitales Lernen unterwegs</div>
			<div style="font-size: 6mm;">Auftragsverarbeitungsvertrag</div>
			<div style="margin: 20mm 0 1mm 0;">zwischen den</div>
			<div style="font-size: 4mm;">Verantwortlichen</div>
			<table class="report-table" style="text-align:center; margin: 5mm 0;">
				<tbody>
					<tr>
						<td style="width:45%; color: blue;"><?php echo $schoolInfo->ministry_name; ?></td>
						<td style="width:10%">und</td>
						<td style="width:45%; color: blue;"><?php echo $schoolName; ?></td>
					</tr>
					<tr>
						<td style="color: blue;"><?php echo $schoolInfo->ministry_address; ?></td>
						<td> </td>
						<td style="color: blue;"><?php echo $schoolAddress; ?></td>
					</tr>
					<tr>
						<td style="color: blue;"><?php echo $schoolInfo->ministry_postal_code . ' ' . $schoolInfo->ministry_city; ?></td>
						<td> </td>
						<td style="color: blue;"><?php echo $schoolPostalCode . ' ' . $schoolCity; ?></td>
					</tr>
				</tbody>
			</table>
			<div style="margin: 2mm 0 10mm 0;">nachfolgend Bildungsministerium und Stammschule genannt</div>
			<div>und dem</div>
			<div style="margin: 1mm 0 5mm 0;font-size: 4mm;">Auftragsverabeiter</div>
			<div>a u d i v i s a &nbsp;Deutsche Gesellschaft für E-Learning mbH<br>Bertolt-Brecht-Allee 24<br>01309 Dresden</div>
		</div>
		<div class="heading--1">1. Verantwortlicher i.S. des Art. 4 Nr. 7 DS-GVO</div>
		<p class="textRed">(1) Für das Pilotprojekt DigLu sind gemeinsam für die Verarbeitung der personenbezogenen Daten Verantwortliche (Art. 26 DS-GVO) das Bildungsministerium und die Stammschule</p>

		<div class="heading--1">6. Weisungsbefugnisse der Verantwortlichen</div>
		<p class="textBlue">(1) Die Verantwortlichen erteilen alle Aufträge, Teilaufträge und Weisungen in der Regel schriftlich oder in einem dokumentierten elektronischen Format. Mündliche Weisungen sind unverzüglich schriftlich oder in einem dokumentierten elektronischen Format zu bestätigen. Soweit Aufträge, Teilaufträge und Weisungen von der Stammschule erteilt werden, so ist das Bildungsministerium darüber unverzüglich zu informieren.</p>
		<p>(2) Der Auftragsverarbeiter hat die Verantwortlichen unverzüglich zu informieren, wenn er der Meinung ist, eine Weisung verstoße gegen die DS-GVO oder andere Datenschutzbestimmungen (Art. 28 Abs. 3 S. 3 DS-GVO). Der Auftragsverarbeiter ist berechtigt, die Durchführung der entsprechenden Weisung solange auszusetzen, bis sie durch die Verantwortlichen geprüft und im Anschluss bestätigt oder geändert wird.</p>
		<p>(3) Weisungsberechtigte Personen der Verantwortlichen sind:</p>
		<p>für das Bildungsministerium (Ministry of Education):</p>
		<table class="report-table" style="margin: 1mm 0 3mm;">
			<tbody>
				<tr>
					<td style="width:40mm;">Name</td>
					<td style="color: blue;"><?php echo $schoolInfo->ministry_contact_name; ?></td>
				</tr>
				<tr>
					<td>Organisationseinheit</td>
					<td style="color: blue;"><?php echo $schoolInfo->ministry_contact_department; ?></td>
				</tr>
				<tr>
					<td>postalische Adresse</td>
					<td style="color: blue;"><?php echo $schoolInfo->ministry_contact_address . ', ' . $schoolInfo->ministry_contact_postal_code . ' ' . $schoolInfo->ministry_contact_city; ?></td>
				</tr>
				<tr>
					<td>Telefon</td>
					<td style="color: blue;"><?php echo $schoolInfo->ministry_contact_phone; ?></td>
				</tr>
				<tr>
					<td>E-Mail</td>
					<td style="color: blue;"><?php echo $schoolInfo->ministry_contact_email; ?></td>
				</tr>
			</tbody>
		</table>
		<p>für die Stammschule (For the Base School):</p>
		<table class="report-table" style="margin: 1mm 0 3mm;">
			<tbody>
				<tr>
					<td style="width:40mm;">Name</td>
					<td style="color: blue;"><?php echo $schoolPrincipal; ?></td>
				</tr>
				<tr>
					<td>Organisationseinheit</td>
					<td style="color: blue;"><?php echo $schoolInfo->school_contact_department; ?></td>
				</tr>
				<tr>
					<td>postalische Adresse</td>
					<td style="color: blue;"><?php echo $schoolInfo->school_contact_address . ', ' . $schoolInfo->school_contact_postal_code . ' ' . $schoolInfo->school_contact_city; ?></td>
				</tr>
				<tr>
					<td>Telefon</td>
					<td style="color: blue;"><?php echo $schoolInfo->school_contact_phone; ?></td>
				</tr>
				<tr>
					<td>E-Mail</td>
					<td style="color: blue;"><?php echo $schoolInfo->school_contact_email; ?></td>
				</tr>
			</tbody>
		</table>
		<p>(4) Weisungsempfänger beim Auftragsverarbeiter ist:</p>
		<table class="report-table" style="margin: 1mm 0 3mm;">
			<tbody>
				<tr>
					<td style="width:40mm;">Name</td>
					<td>Herr Carsten Rabeneck</td>
				</tr>
				<tr>
					<td>Organisationseinheit</td>
					<td>Geschäftsführung</td>
				</tr>
				<tr>
					<td>postalische Adresse</td>
					<td>Bertolt-Brecht-Allee 24, 01309 Dresden</td>
				</tr>
				<tr>
					<td>Telefon</td>
					<td>+49 351 418 931 68</td>
				</tr>
				<tr>
					<td>E-Mail</td>
					<td>office@audivisa.de</td>
				</tr>
			</tbody>
		</table>
		<p>(6) Bei einem Wechsel oder einer längerfristigen Verhinderung der Ansprechpartner sind demVertragspartner unverzüglich und grundsätzlich schriftlich oder elektronisch die Nachfolger bzw. die Vertreter mitzuteilen. Die Weisungen sind für ihre Geltungsdauer und anschließend noch für drei volle Kalenderjahre aufzubewahren.	</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Leo urna molestie at elementum eu facilisis sed odio morbi. Nec ullamcorper sit amet risus nullam eget felis eget nunc. Fermentum et sollicitudin ac orci phasellus. Enim nunc faucibus a pellentesque sit. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sit amet porttitor eget dolor morbi non arcu risus. Tristique senectus et netus et malesuada fames ac turpis egestas. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor. Dictum at tempor commodo ullamcorper a lacus vestibulum. Tellus in hac habitasse platea dictumst vestibulum rhoncus est pellentesque. Vitae sapien pellentesque habitant morbi tristique. At lectus urna duis convallis convallis tellus id interdum velit. Penatibus et magnis dis parturient montes nascetur ridiculus. Amet nisl purus in mollis. Tortor at auctor urna nunc id.</p>

    </div>
</div>
