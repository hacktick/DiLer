<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 *
 * @copyright   Copyright (C) 2012 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 * @conent		template for the "verbindliche Vorlage für den Lernentwicklungsbericht in Gemeinschaftsschulen; Ministerium für Kultus, Jugend und Sport Baden-Württemberg"
 */

/**
 * As with standard Joomla JLayout files, the data for the layout is contained in a standard class called $displayData, with the following fields:
 *
 * student:          stdClass   columns from the dilerreg_users table for this student (for example, student->surname).
 *                              We also include learningGroupName and learningGroupId in the student object.
 *
 * studentFields:    array      Associative array in format field_name => stdClass for each student type field definition. stdClass has field id, name,
 *                              published, description, label, type, locked, params, ordering, student_id, value.
 *                              Example: $displayData->studentFields['strengths']->label or $displayData->studentFields['strengths']->value.
 *
 * subjects:         array      Array of stdClass objects, one for each subject the student is assigned to. Each subject has name, id, and fields.
 *                              fields is an associative array of field_name => stdClass for each subject type field,
 *                              where stdClass has the same fields as for student type fields above.
 *                              Example: foreach ($displayData->subjects as $subject), then $subject->name or $subject->fields['subject_participation']->label.
 *
 * reportInfo:     stdClass    	report_type_id, report_type_name, report_type_published, report_type_description, layout_file_name, noDataWarning
 *                             	period_id, period_published, period_name, period_published, period_description, start_date, end_date,
 *                              edit_start_date, edit_end_date, fields.
 *                              fields is an associative array of field_name => stdClass with same fields as for student and subject field definitions.
 *                              Example: $displayData->reportInfo->report_type_name or $displayData->reportInfo->fields['report_footer']->field_value
 *                              where 'report_footer' is the name of a period-type field definition.
 *
 * @ subjectfilter				(no space after the @) This marker indicates that the report has support for the subject filter
 *								in the "print report" tab and hence the subject filter is displayed if that marker is found
 *								in a report within a comment like: // @ subjectfilter
 *
 * @ reportParameter			(no space after the @) This marker indicates that the report has support for the "report parameter"
 *								that gets set in the students account - if that marker is found in a report within a comment like: // @ reportParameter
 *
 * @ subjectList				e.g. ="Religion,EWG,English,Mathematics" (no space after the @). Use this tag to enter a semi static list of subjects. The subjects will be matched
 * 								against existing subjects based on a full name match. Order in the report will be based on ordering in the list.
 *
 * @ entryClass					e.g. ="height--1 width--2" (no space after the @). Use this to apply css classes to the corresponding textarea in the data entry form.
 *
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

extract((array) $displayData);
?>

<input id="contractPageMargin" type="hidden" value="20mm 0mm 0mm 15mm"><?php /* must correspond with page-area padding */?>
<input id="contractHeaderText" type="hidden" value="<?php echo "Anlage A zum VVT";?>">
<input id="contractFooterText" type="hidden" value="<?php echo JText::_('COM_DILER_REPORT_PAGE'); ?> {PAGE_NUM} von {PAGE_COUNT}">
<input id="contractHeaderPositionH" type="hidden" value="42">
<input id="contractFooterPositionH" type="hidden" value="270">
<input id="contractHeaderPositionV" type="hidden" value="15">
<input id="contractFooterPositionV" type="hidden" value="28">
<input id="contractHeaderStartPage" type="hidden" value="2">
<input id="contractFooterStartPage" type="hidden" value="1">
<input id="contractPageCountStart" type="hidden" value="1">
<input id="contractFilename" type="hidden" value="VVT-Anlage_A-DigLu_{SCHOOLSTATE}_{SCHOOLCITY}_{SCHOOLNAME}_{SCHOOLID}">

<div class="page-container page-1 vvt-anlage-a-diglu">
	<div class="page-area">
		<div class="font-size--14">Anlage A zum VVT</div>
		<p class="font-size--12" style="margin: 10mm 0 0;">1.1 Name und Kontaktdaten der gemeinsam für die Verabeitung Verantwortlichen gem. Art 26 Abs. 1 DS-GVO:</p>
		<p class="font-size--10">
			<?php echo $schoolInfo->ministry_name; ?><br>
			<?php echo $schoolInfo->ministry_address; ?>, <?php echo $schoolInfo->ministry_postal_code; ?> <?php echo $schoolInfo->ministry_city; ?><br>
			<?php echo $schoolInfo->ministry_phone; ?><br>
			<?php echo $schoolInfo->ministry_email; ?>
		</p>
		<p class="font-size--10">
			<?php echo $schoolInfo->school_name; ?><br>
			<?php echo $schoolInfo->school_address; ?>, <?php echo $schoolInfo->school_postal_code; ?> <?php echo $schoolInfo->school_city; ?><br>
			<?php echo $schoolInfo->school_phone; ?><br>
			<?php echo $schoolInfo->school_email; ?>
		</p>
		<p class="font-size--12" style="margin: 10mm 0 0;">1.2 Name und Kontaktdaten des Datenschutzbeauftragten (und seiner Stellvertreter)</p>
		<p class="font-size--10">
			 a) Zuständige/r Datenschutzbeauftragte/r für das <?php echo $schoolInfo->ministry_name; ?>:<br>
			<?php echo $schoolInfo->ministry_privacy_officer_name; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_address; ?>, <?php echo $schoolInfo->ministry_privacy_officer_postal_code; ?> <?php echo $schoolInfo->ministry_privacy_officer_city; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_phone; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_email; ?>
		</p>
		<p class="font-size--10">
			 Stellvertretung:<br>
			<?php echo $schoolInfo->ministry_privacy_officer_deputy_name; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_deputy_address; ?>, <?php echo $schoolInfo->ministry_privacy_officer_deputy_postal_code; ?> <?php echo $schoolInfo->ministry_privacy_officer_deputy_city; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_deputy_phone; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_deputy_email; ?>
		</p>
		<p class="font-size--10">
			b) Kontaktdaten des Zuständige/r Datenschutzbeauftragte/r für die Stammschule nach Landesrecht:<br>
			<?php echo $schoolInfo->ministry_privacy_officer_name; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_address; ?>, <?php echo $schoolInfo->ministry_privacy_officer_postal_code; ?> <?php echo $schoolInfo->ministry_privacy_officer_city; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_phone; ?><br>
			<?php echo $schoolInfo->ministry_privacy_officer_email; ?>
		</p>
    </div>
</div>
<div class="page-container page-2 avv-diglu">
	<div class="page-area">
		<div class="font-size--16" style="text-align: center; margin: 0 0 20mm;">Vertragsinhalt</div>
		<div class="font-size--12">
			&nbsp;&nbsp;Vertragspartner<br><br>
			<ol>
				<li>Verantwortlicher i.S. des Art. 4 Nr. 7 DS-GV</li>
				<li>Gegenstand und Dauer des Vertrages</li>
				<li>Art und Zweck der Verarbeitung</li>
				<li>Art der personenbezogenen Daten und Kategorien betroffener Personen</li>
				<li>Allgemeine Pflichten der Verantwortlichen und des Auftragsverarbeiters</li>
				<li>Weisungsbefugnisse der Verantwortlichen</li>
				<li>Mitteilungs- und Unterstützungspflichten des Auftragsverarbeiters und der Verantwortlichen</li>
				<li>Datenschutzbeauftragte/r und Beschäftigte des Auftragsverarbeiters</li>
				<li>Kontrollrechte der Verantwortlichen</li>
				<li>Kontrollen der Aufsichtsbehörde</li>
				<li>Unterauftragsverhältnisse</li>
				<li>Umgang mit personenbezogenen Daten</li>
				<li>Technische und organisatorische Maßnahmen</li>
				<li>Haftung</li>
				<li>Sonstiges</li>
				<li>Wirksamkeit des Vertrages</li>
			</ol>
			&nbsp;&nbsp;Anlagen<br><br>
			&nbsp;&nbsp;Unterschriften
	    </div>
    </div>
</div>
<div class="page-container avv-diglu">
	<div class="page-area">
		<div style="text-align:center;margin: 0 0 10mm 0;">
			<div style="font-size: 6mm;">Auftragsverarbeitungsvertrag</div>
			<div style="margin: 10mm 0 1mm 0;">zwischen den</div>
			<div style="font-size: 4mm;">Verantwortlichen</div>
			<table class="report-table" style="text-align:center; margin: 5mm 0;">
				<tbody>
					<tr>
						<td style="width:45%;"><?php echo $schoolInfo->ministry_name; ?></td>
						<td style="width:10%;">und</td>
						<td style="width:45%;"><?php echo $schoolInfo->school_name; ?></td>
					</tr>
					<tr>
						<td><?php echo $schoolInfo->ministry_address; ?></td>
						<td> </td>
						<td><?php echo $schoolInfo->school_address; ?></td>
					</tr>
					<tr>
						<td><?php echo $schoolInfo->ministry_postal_code . ' ' . $schoolInfo->ministry_city; ?></td>
						<td> </td>
						<td><?php echo $schoolInfo->school_postal_code . ' ' . $schoolInfo->school_city; ?></td>
					</tr>
				</tbody>
			</table>
			<div style="margin: 2mm 0 10mm 0;">nachfolgend Bildungsministerium und Stammschule genannt</div>
			<div>und dem</div>
			<div style="margin: 1mm 0 5mm 0;font-size: 4mm;">Auftragsverabeiter</div>
			<div>a u d i v i s a &nbsp;Deutsche Gesellschaft für E-Learning mbH<br>Bertolt-Brecht-Allee 24<br>01309 Dresden</div>
		</div>
		<div class="heading--1">1. Verantwortlicher i.S. des Art. 4 Nr. 7 DS-GVO</div>
		<p>(1) Für das Pilotprojekt DigLu sind gemeinsam für die Verarbeitung der personenbezogenen Daten Verantwortliche (Art. 26 DS-GVO) das Bildungsministerium und die Stammschule</p>
		<p>Die gem. Art. 26 Abs. 1 und Abs. 2 DS-GVO erforderlichen Festlegungen, welcher Veranwortliche im Rahmen der gemeinsamen Verantwortlichkeit, welche einzelnen Rechte und Verpflichtungen gem. DS-GVO erfüllt, werden in diesem Vertrag nachfolgend verbindlich geregelt.</p>
		<p>(2) Das Bildungsministerium bestimmt grundsätzlich den Zweck und die Mittel der Verarbeitung der personenbezogenen Daten, in dem es der Stammschule verbindlich die Nutzung von DigLu vorgibt. Das Bildungsministerium ist gegenüber dem Auftragsverarbeiter grundsätzlich weisungsberechtigt und hat geprüft, ob der Auftragsverarbeiter hinreichende Garantien dafür bietet, dass er geeignete technische und organisatorische Maßnahmen so durchführt, dass die Verarbeitung gemäß den Anforderungen der DS-GVO erfolgt und der Schutz der Rechte der Betroffenen gewährleistet wird.</p>
		<p>(3) Die Stammschule ist für die ordnungsgemäße Einpflege und Verarbeitung sowie die Richtigkeit der personenbezogenen Daten der Schülerinnen und Schüler, Eltern und Lehrkräfte in DigLu verantwortlich. Zudem hat sie die Informationspflichten gem. Art. 13 und Art. 14 DS-GVO gegenüber den Betroffenen zu erfüllen.</p>
		<p>(4) Im Benehmen mit den Pilotländern erfolgt die Durchführung des Pilotprojekts DigLu und die Betreuung als Fachverfahren federführend durch das Land Nordrhein-Westfalen, vertreten durch das Ministerium für Schule und Bildung Nordrhein-Westfalen (MSB NRW). Diese dient insbesondere der einheitlichen Kommunikation und Information zwischen den Pilotländern und dem Auftragsverarbeiter.</p>
		<p>Entsprechend werden im Vertrag einzelne Festlegungen benannt, die zwar die Verantwortlichen betreffen, die aber ausschließlich von und gegenüber dem zur Federführung beauftragten MSB NRW in Vertretung wahrgenommen werden.</p>
		<div class="heading--1">2. Gegenstand und Dauer des Vertrages</div>
		<p>(1) Der Gegenstand des Vertrages ist die Verarbeitung von personenbezogenen Daten im Auftrag des Verantwortlichen im Sinne von Art. 4 Nr. 2 und Art. 28 DS-GVO auf Grundlage dieses Vertrages. Inhalt und Umfang der Verarbeitung von personenbezogenen Daten werden in der Leistungsvereinbarung (Anlage 1) bestimmt.</p>
		<p>(2) Die Laufzeit des Vertrags beginnt am 1. Februar 2020 und endet am 31. August 2023. Die Verantwortlichen können den Vertrag jederzeit ohne Einhaltung einer Frist kündigen, wenn ein schwerwiegender Verstoß des Auftragsverarbeiters gegen Datenschutzvorschriften oder die Bestimmungen dieses Vertrages vorliegt, der Auftragsverarbeiter eine Weisung der Verantwortlichen nicht ausführen kann oder will oder der Auftragsverarbeiter Kontrollrechte der Verantwortlichen vertragswidrig verweigert. Insbesondere die Nichteinhaltung der in diesem Vertrag vereinbarten und aus Art. 28 DS-GVO abgeleiteten Pflichten stellt einen schweren Verstoß dar. Das Kündigungsrecht kann nur durch das MSB NRW in Vertretung der Verantwortlichen wahrgenommen werden. Stellt die Stammschule einen der vorgenannten Pflichtverstöße fest, hat sie dies unverzüglich dem Bildungsministerium mitzuteilen, das über die Wahrnehmung des Kündigungsrechts im Einvernehmen mit dem MSB NRW entscheidet.</p>
		<div class="heading--1">3. Art und Zweck der Verarbeitung</div>
		<p>(1) Art und Zweck der Verarbeitung personenbezogener Daten durch den Auftragsverarbeiter für die Verantwortlichen sind konkret beschrieben in der Leistungsvereinbarung (Anlage 1).</p>
		<p>(2) Die vertraglich vereinbarte Datenverarbeitung wird ausschließlich in einem Mitgliedsstaat der Europäischen Union oder in einem Vertragsstaat des Abkommens über den Europäischen Wirtschaftsraum erbracht. Eine Verlagerung der Datenverarbeitung oder Teilarbeiten davon in ein Drittland darf nicht erfolgen.</p>
		<div class="heading--1">4. Art der personenbezogenen Daten und Kategorien betroffener Personen</div>
		<p>Art und Kategorien der personenbezogenen Daten sind in der Leistungsvereinbarung (Anlage1) konkret unter 4.) beschrieben.</p>
		<div class="heading--1">5. Allgemeine Pflichten der Verantwortlichen und des Auftragsverarbeiters</div>
		<p>(1) Für die Beurteilung der Zulässigkeit der Verarbeitung gemäß Art. 6 Abs. 1 DS-GVO sowie für die Wahrung der Rechte der betroffenen Personen nach den Art. 12 bis 22 DS-GVO sind allein die Verantwortlichen zuständig. Diese Aufgaben der Verantwortlichen werden im Rahmen der gemeinsamen Verantwortung von der Stammschule wahrgenommen. Sofern Anfragen an den Auftragsverarbeiter gerichtet werden, die erkennbar die Verantwortlichen (des jeweiligen Landes) betreffen, hat der Auftragsverarbeiter diese an die Stammschule weiterzuleiten.</p>
		<p>(2) Änderungen des Verarbeitungsgegenstandes und Verfahrensänderungen sind gemeinsam zwischen den Verantwortlichen und dem Auftragsverarbeiter abzustimmen und schriftlich oder in einem dokumentierten elektronischen Format festzulegen. Derartige Festlegungen erfolgen in Vertretung für die Verantwortlichen durch das MSB NRW in Abstimmung mit den Bildungsministerien der Pilotländer.</p>
		<p>(3) Die Verantwortlichen sind verpflichtet, alle im Rahmen des Vertragsverhältnisses erlangten Kenntnisse von Geschäftsgeheimnissen und Datensicherheitsmaßnahmen des Auftragsverarbeiters vertraulich zu behandeln. Diese Verpflichtung besteht nach Beendigung dieses Vertrages fort.</p>
		<p>(4) Der Auftragsverarbeiter bestätigt, dass ihm die für die Auftragsverarbeitung einschlägigen datenschutzrechtlichen Vorschriften der DS-GVO bekannt sind.</p>
		<div class="heading--1">6. Weisungsbefugnisse der Verantwortlichen</div>
		<p>(1) Die Verantwortlichen erteilen alle Aufträge, Teilaufträge und Weisungen in der Regel schriftlich oder in einem dokumentierten elektronischen Format. Mündliche Weisungen sind unverzüglich schriftlich oder in einem dokumentierten elektronischen Format zu bestätigen. Soweit Aufträge, Teilaufträge und Weisungen von der Stammschule erteilt werden, so ist das Bildungsministerium darüber unverzüglich zu informieren.</p>
		<p>(2) Der Auftragsverarbeiter hat die Verantwortlichen unverzüglich zu informieren, wenn er der Meinung ist, eine Weisung verstoße gegen die DS-GVO oder andere Datenschutzbestimmungen (Art. 28 Abs. 3 S. 3 DS-GVO). Der Auftragsverarbeiter ist berechtigt, die Durchführung der entsprechenden Weisung solange auszusetzen, bis sie durch die Verantwortlichen geprüft und im Anschluss bestätigt oder geändert wird.</p>
		<p>(3) Weisungsberechtigte Personen der Verantwortlichen sind:</p>
		<p>für das Bildungsministerium:</p>
		<table class="report-table" style="text-align: left; margin: 1mm 0 3mm;">
			<tbody>
				<tr>
					<td style="width:40mm;">Name</td>
					<td><?php echo $schoolInfo->ministry_contact_name; ?></td>
				</tr>
				<tr>
					<td>Organisationseinheit</td>
					<td><?php echo $schoolInfo->ministry_contact_department; ?></td>
				</tr>
				<tr>
					<td>postalische Adresse</td>
					<td><?php echo $schoolInfo->ministry_contact_address . ', ' . $schoolInfo->ministry_contact_postal_code . ' ' . $schoolInfo->ministry_contact_city; ?></td>
				</tr>
				<tr>
					<td>Telefon</td>
					<td><?php echo $schoolInfo->ministry_contact_phone; ?></td>
				</tr>
				<tr>
					<td>E-Mail</td>
					<td><?php echo $schoolInfo->ministry_contact_email; ?></td>
				</tr>
			</tbody>
		</table>
		<p>für die Stammschule:</p>
		<table class="report-table" style="margin: 1mm 0 3mm;">
			<tbody>
				<tr>
					<td style="width:40mm;">Name</td>
					<td><?php echo $schoolInfo->school_contact_name ? $schoolInfo->school_contact_name : $schoolInfo->school_name; ?></td>
				</tr>
				<tr>
					<td>Organisationseinheit</td>
					<td><?php echo $schoolInfo->school_contact_department ? $schoolInfo->school_contact_department : DText::_('SCHOOL_HEAD'); ?></td>
				</tr>
				<tr>
					<td>postalische Adresse</td>
					<td>
						<?php echo $schoolInfo->school_contact_address ? $schoolInfo->school_contact_address : $schoolInfo->school_address. ', ' . 
							$schoolInfo->school_contact_postal_code ? $schoolInfo->school_contact_postal_code : $schoolInfo->school_postal_code . ' ' . 
							$schoolInfo->school_contact_city ? $schoolInfo->school_contact_city : $schoolInfo->school_city; 
						?>
					</td>
				</tr>
				<tr>
					<td>Telefon</td>
					<td><?php echo $schoolInfo->school_contact_phone ? $schoolInfo->school_contact_phone : $schoolInfo->school_phone; ?></td>
				</tr>
				<tr>
					<td>E-Mail</td>
					<td><?php echo $schoolInfo->school_contact_email ? $schoolInfo->school_contact_email : $schoolInfo->school_email; ?></td>
				</tr>
			</tbody>
		</table>
		<p>(4) Weisungsempfänger beim Auftragsverarbeiter ist:</p>
		<table class="report-table" style="margin: 1mm 0 3mm;">
			<tbody>
				<tr>
					<td style="width:40mm;">Name</td>
					<td>Carsten Rabeneck</td>
				</tr>
				<tr>
					<td>Organisationseinheit</td>
					<td>Geschäftsführung</td>
				</tr>
				<tr>
					<td>postalische Adresse</td>
					<td>Bertolt-Brecht-Allee 24, 01309 Dresden</td>
				</tr>
				<tr>
					<td>Telefon</td>
					<td>+49 351 418 931 68</td>
				</tr>
				<tr>
					<td>E-Mail</td>
					<td>office@audivisa.de</td>
				</tr>
			</tbody>
		</table>
		<p>(6) Bei einem Wechsel oder einer längerfristigen Verhinderung der Ansprechpartner sind dem Vertragspartner unverzüglich und grundsätzlich schriftlich oder elektronisch die Nachfolger bzw. die Vertreter mitzuteilen. Die Weisungen sind für ihre Geltungsdauer und anschließend noch für drei volle Kalenderjahre aufzubewahren.</p>
		<div class="heading--1">7. Mitteilungs- und Unterstützungspflichten des Auftragsverarbeiters und der Verantwortlichen</div>
		<p>(1) Der Auftragsverarbeiter teilt den Verantwortlichen unverzüglich Störungen, Verstöße des Auftragsverarbeiters oder der bei ihm beschäftigten Personen gegen datenschutzrechtliche Bestimmungen oder gegen die im Auftrag getroffenen Festlegungen sowie den Verdacht auf Datenschutzverletzungen oder Unregelmäßigkeiten bei der Verarbeitung personenbezogener Daten mit. Dies gilt vor allem auch im Hinblick auf eventuelle Melde- und Benachrichtigungspflichten der Verantwortlichen nach Art. 33 und Art. 34 DS-GVO an die Landesdatenschutzbehörden unter Einhaltung der Fristen. Meldungen nach Art. 33 oder 34 DS-GVO für die Verantwortlichen darf der Auftragsverarbeiter nur nach vorheriger Weisung gemäß Ziffer 6 dieses Vertrages durchführen.</p>
		<p>(2) Der Auftragsverarbeiter unterstützt die Verantwortlichen bei der Einhaltung der in den Artikeln 32 bis 36 der DS-GVO genannten Pflichten zur Sicherheit personenbezogener Daten, bei der Erfüllung der Rechte der betroffenen Personen nach den Art. 12 bis 22 DS-GVO, bei Meldepflichten bei Datenpannen, bei der Erstellung der Verzeichnisse von Verarbeitungstätigkeiten, bei Datenschutz-Folgeabschätzungen und vorherigen Konsultationen. Hierzu gehören u.a.</p>
		<ul>
			<li>die Sicherstellung eines angemessenen Schutzniveaus durch technische und organisatorische Maßnahmen, die die Umstände und Zwecke der Verarbeitung sowie die prognostizierte Wahrscheinlichkeit und Schwere einer möglichen Rechtsverletzung durch Sicherheitslücken berücksichtigen und eine sofortige Feststellung von relevanten Verletzungsereignissen ermöglichen,</li>
			<li>die Verpflichtung, Verletzungen personenbezogener Daten unverzüglich an die Verantwortlichen zu melden,</li>
			<li>die Verpflichtung, die Verantwortlichen im Rahmen ihrer Informationspflicht gegenüber dem Betroffenen zu unterstützen und ihm in diesem Zusammenhang sämtliche relevanten Informationen unverzüglich zur Verfügung zu stellen,</li>
			<li>die Unterstützung der Verantwortlichen für ihre Datenschutz-Folgenabschätzung,</li>
			<li>die Unterstützung der Verantwortlichen im Rahmen vorheriger Konsultationen mit der Aufsichtsbehörde.</li>
		</ul>
		<div class="heading--1">8. Datenschutzbeauftragte/r und Beschäftigte des Auftragsverarbeiters</div>
		<p>(1) Beim Auftragsverarbeiter ist folgende/r Beauftragte/r für den Datenschutz bestellt, der/die seine/ihre Tätigkeit gemäß Art. 38 und Art. 39 DS-GVO ausübt.</p>
		<table class="report-table" style="margin: 1mm 0 3mm;">
			<tbody>
				<tr>
					<td style="width:40mm;">Name</td>
					<td>Felicitas Berger</td>
				</tr>
				<tr>
					<td>Organisationseinheit</td>
					<td>TÜV SÜD Sec-IT GmbH</td>
				</tr>
				<tr>
					<td>postalische Adresse</td>
					<td>Ridlerstraße 57, 80339 München</td>
				</tr>
				<tr>
					<td>Telefon</td>
					<td>+49 89 50084-686</td>
				</tr>
				<tr>
					<td>E-Mail</td>
					<td>felicitas.berger@tuev-sued.de</td>
				</tr>
			</tbody>
		</table>
		<p>Ein Wechsel des/der Datenschutzbeauftragten ist den Verantwortlichen unverzüglich mitzuteilen.</p>
		<p>(2) Zur Wahrung der Vertraulichkeit (Art. 28 Abs. 3 S. 2 lit. b, 29, 32 Abs. 4 DS-GVO) setzt der Auftragsverarbeiter bei der Durchführung der Arbeiten nur Beschäftigte ein, die vor Aufnahme ihrer Tätigkeit auf die Vertraulichkeit, die sie während und nach Beendigung des Beschäftigungsverhältnisses zu wahren haben, verpflichtet wurden. Sie sind mit den für sie relevanten Bestimmungen zum Datenschutz vertraut zu machen.</p>
		<p>(3) Der Auftragsverarbeiter und jede dem Auftragsverarbeiter unterstellte Person, die Zugang zu personenbezogenen Daten hat, dürfen diese Daten ausschließlich entsprechend der Weisung der Verantwortlichen verarbeiten einschließlich der in diesem Vertrag eingeräumten Befugnisse, es sei denn, dass sie gesetzlich zur Verarbeitung verpflichtet sind.</p>
		<p>(4) Die Verarbeitung personenbezogener Daten in Privatwohnungen (mobile Tele- bzw. Heimarbeit von Beschäftigten des Auftragsverarbeiters) ist unter der Voraussetzung gestattet, dass die Maßnahmen nach Art. 32 DS-GVO auch in diesem Fall sichergestellt sind. Soweit die personenbezogenen Daten in einer Privatwohnung verarbeitet werden, ist der Zugang zur Wohnung des Beschäftigten zu Kontrollzwecken des Auftragsverarbeiters als Arbeitgeber vertraglich sicherzustellen.</p>
		<div class="heading--1">9. Kontrollrechte der Verantwortlichen</div>
		<p>(1) Die Verantwortlichen haben das Recht vor Beginn der Verarbeitung und sodann regelmäßig in angemessener Weise und im Benehmen mit dem Auftragsverarbeiter - grundsätzlich nach Terminvereinbarung - Überprüfungen durchzuführen oder durch die von den Verantwortlichen beauftragte Dritte durchführen zu lassen. Sie haben das Recht, sich durch Stichprobenkontrollen, die in der Regel rechtzeitig anzumelden sind, von der Einhaltung dieses Vertrages sowie der Einhaltung der Vorschriften über Datenschutz und Datensicherheit durch den Auftragsverarbeiter in dessen Geschäftsbetrieb zu überzeugen. Die Wahrnehmung dieses Rechts erfolgt für die Verantwortlichen durch das Bildungsministerium.</p>
		<p>(2) Die Kontrollen umfassen insbesondere die Einholung von Auskünften und die Einsichtnahme in die gespeicherten Daten und die Datenverarbeitungsprogramme durch Überprüfungen und Inspektionen vor Ort (Art. 28 Abs. 3 Satz 2 lit. h DS-GVO). Der Auftragsverarbeiter sichert zu, dass er, soweit erforderlich, bei diesen Kontrollen unterstützend mitwirkt, dem Verantwortlichen die erforderlichen Auskünfte erteilt und insbesondere die Umsetzung der technischen und organisatorischen Maßnahmen nachweist.</p>
		<div class="heading--1">10. Kontrollen der Aufsichtsbehörde</div>
		<p>(1) Die Verantwortlichen und der Auftragsverarbeiter arbeiten auf Anfrage mit der Aufsichtsbehörde bei der Erfüllung ihrer Aufgaben zusammen.</p>
		<p>(2) Der Auftragsverarbeiter informiert die Verantwortlichen unverzüglich über Kontrollhandlungen und Maßnahmen der Aufsichtsbehörde, soweit sie sich auf diesen Auftrag beziehen. Dies gilt auch, soweit eine zuständige Behörde im Rahmen eines Ordnungswidrigkeits- oder Strafverfahrens in Bezug auf die Verarbeitung personenbezogener Daten bei der Auftragsverarbeitung beim Auftragsverarbeiter ermittelt.</p>
		<p>(3) Soweit die Verantwortlichen ihrerseits einer Kontrolle der Aufsichtsbehörde, einem Ordnungswidrigkeits- oder Strafverfahren, dem Haftungsanspruch einer betroffenen Person oder eines Dritten oder einem anderen Anspruch im Zusammenhang mit der Auftragsverarbeitung beim Auftragsverarbeiter ausgesetzt sind, hat sie der Auftragsverarbeiter soweit möglich zu unterstützen. Sind solche Handlungen oder Maßnahmen gegen die Stammschule gerichtet, meldet sie dies unverzüglich an das Bildungsministerium, das soweit möglich die Stammschule unterstützt.</p>
		<div class="heading--1">11. Unterauftragsverhältnisse</div>
		<p>(1) Die Beauftragung von Unterauftragsverarbeitern (weitere Auftragsverarbeiter) zur Verarbeitung von Daten der Verantwortlichen ist dem Auftragsverarbeiter nur mit Genehmigung der Verantwortlichen gestattet, Art. 28 Abs. 2 DS-GVO.</p>
		<p>Die Vertragsparteien - für die Verantwortlichen das Bildungsministerium bestimmen den nachfolgenden Unterauftragsverarbeiter für Diglu:</p>
		<p>FC Hosting<br>Uhlenbruch 18<br>31535 Neustadt</p>
		<p>Die Auslagerung auf weitere Unterauftragsverarbeiter oder der Wechsel des bestehenden Unterauftragsverarbeiters ist nur mit Genehmigung der Verantwortlichen gestattet. Die Genehmigung erfolgt in Vertretung der Verantwortlichen durch das MSB NRW.</p>
		<p>(2) Der Auftragsverarbeiter hat vertraglich sicherzustellen, dass dieselben Datenschutzpflichten zwischen den Verantwortlichen und Auftragsverarbeiter auch gegenüber Unterauftragsverarbeitern gelten. Der Vertrag mit dem Unterauftragsverarbeiter muss schriftlich abgefasst werden, was auch in einem elektronischen Format erfolgen kann (Art. 28 Abs. 4 und Abs. 9 DS-GVO).</p>
		<p>(3) Der Auftragsverarbeiter trägt dafür Sorge, dass er den Unterauftragsverarbeiter unter besonderer Berücksichtigung der Eignung der von diesem getroffenen technischen und organisatorischen Maßnahmen im Sinne von Art. 32 DS-GVO sorgfältig auswählt. Die relevanten Prüfunterlagen dazu sind den Verantwortlichen auf Anfrage zur Verfügung zu stellen.</p>
		<p>(4) Als Unterauftragsverhältnisse im Sinne dieser Regelung sind solche Dienstleistungen zu verstehen, die sich unmittelbar auf die Erbringung der Hauptleistung beziehen. Nicht hierzu gehören Nebenleistungen, die der Auftragsverarbeiter z.B. als Telekommunikationsleistungen, Post-/ Transportdienstleistungen, Wartung und Benutzerservice oder die Entsorgung von Datenträgern sowie sonstige Maßnahmen zur Sicherstellung der Vertraulichkeit, Verfügbarkeit, Integrität und Belastbarkeit der Hard- und Software von Datenverarbeitungsanlagen in Anspruch nimmt. Der Auftragsverarbeiter ist jedoch verpflichtet, zur Gewährleistung des Datenschutzes und der Datensicherheit der Daten der Verantwortlichen auch bei ausgelagerten Nebenleistungen angemessene und gesetzeskonforme vertragliche Vereinbarungen zu ergreifen.</p>
		<p>(5) Eine Beauftragung von Unterauftragsverabeitern zur Erbringung der vereinbarten Leistung in Drittstaaten (außerhalb der EU/des EWR) darf nicht erfolgen.</p>
		<p>(6) Die Weitergabe von personenbezogenen Daten der Verantwortlichen an den Unterauftragsverarbeiter und dessen erstmaliges Tätigwerden sind erst mit Vorliegen aller Voraussetzungen für eine Unterbeauftragung gestattet. Zur Datenweiterleitung müssen insbesondere die Verpflichtungen nach Art. 29 und Art. 32 Abs. 4 DS-GVO bezüglich seiner Beschäftigten erfüllt sein.</p>
		<p>(7) Der Auftragsverarbeiter hat die Einhaltung der Pflichten des Unterauftragsverarbeiters zu überprüfen. Das Ergebnis der Überprüfungen ist zu dokumentieren und den Verantwortlichen auf Verlangen zugänglich zu machen. Die Überprüfung durch den Auftragsverarbeiter kann ersetzt werden durch die Einhaltung genehmigter Verhaltensregeln oder eines genehmigten Zertifizierungsverfahrens (siehe Art. 32 Abs. 3 DSGVO) und anderer Datenschutzprüfungen, die die Unterauftragsverarbeiter in Auftrag geben und dem Auftragsverarbeiter zur Verfügung stellen.</p>
		<p>(8) Der Auftragsverarbeiter haftet gegenüber den Verantwortlichen dafür, dass der Unterauftragsverabeiter den Datenschutzpflichten nachkommt, die ihm durch den Auftragsverarbeiter im Einklang mit dem vorliegenden Vertragsabschnitt vertraglich auferlegt wurden.</p>
		<div class="heading--1">12. Umgang mit personenbezogenen Daten</div>
		<p>(1) Der Auftragsverarbeiter verarbeitet personenbezogene Daten ausschließlich im Rahmen der getroffenen Vereinbarungen und nach Weisungen der Verantwortlichen, sofern er nicht zu einer anderen Verarbeitung durch das Recht der Union oder der Mitgliedstaaten, dem der Auftragsverarbeiter unterliegt, hierzu verpflichtet ist (z. B. Ermittlungen von Strafverfolgungs- oder Staatsschutzbehörden). In einem solchen Fall teilt der Auftragsverarbeiter den Verantwortlichen diese rechtlichen Anforderungen vor der Verarbeitung mit, sofern das betreffende Recht eine solche Mitteilung nicht wegen eines wichtigen öffentlichen Interesses verbietet (Art. 28 Abs. 3 Satz 2 lit. a DS-GVO).</p>
		<p>(2) Der Auftragsverarbeiter verwendet die zur Verarbeitung überlassenen personenbezogenen Daten für keine anderen, insbesondere nicht für eigene Zwecke. Kopien oder Duplikate der personenbezogenen Daten werden ohne Wissen der Verantwortlichen nicht erstellt. Hiervon ausgenommen sind Sicherheitskopien, soweit sie zur Gewährleistung einer ordnungsgemäßen Datenverarbeitung erforderlich sind, sowie Daten, die im Hinblick auf die Einhaltung gesetzlicher Aufbewahrungspflichten erforderlich sind.</p>
		<p>(3) Der Auftragsverarbeiter darf die Daten, die im Auftrag verarbeitet werden, nicht eigenmächtig, sondern nur nach dokumentierter Weisung der Verantwortlichen und sofern berechtigte Interessen des Auftragsverarbeiters nicht entgegenstehen, berichtigen, löschen oder deren Verarbeitung einschränken. Das Löschkonzept (Anlage 3), die Rechte auf Vergessenwerden, Berichtigung, Datenportabilität und Auskunft nach dokumentierter Weisung der Verantwortlichen sind unmittelbar durch den Auftragsverarbeiter sicherzustellen.</p>
		<p>(4) Auskünfte über personenbezogene Daten aus dem Auftragsverhältnis an Dritte oder den Betroffenen darf der Auftragsverarbeiter nur nach vorheriger Weisung oder Zustimmung durch die Verantwortlichen erteilen. Soweit eine betroffene Person sich diesbezüglich unmittelbar an den Auftragsverarbeiter wendet, hat der Auftragsverarbeiter dieses Ersuchen unverzüglich an die Stammschule weiterzuleiten.</p>
		<p>(5) Der Auftragsverarbeiter sichert zu, dass die für die Verantwortlichen verarbeiteten Daten von sonstigen Datenbeständen strikt getrennt werden. Die Datenträger, die von den Verantwortlichen stammen bzw. für die Verantwortlichen genutzt werden, werden besonders gekennzeichnet. Eingang und Ausgang sowie die laufende Verwendung werden dokumentiert.</p>
		<p>(6) Nach Abschluss der vertraglich vereinbarten Arbeiten oder früher nach Aufforderung durch die Verantwortlichen – spätestens mit Beendigung der Leistungsvereinbarung – hat der Auftragsverarbeiter sämtliche in seinen Besitz gelangten Unterlagen, erstellte Verarbeitungs- und Nutzungsergebnisse sowie Datenbestände, die im Zusammenhang mit dem Auftragsverhältnis stehen, an die Stammschule auszuhändigen oder nach ihrer vorherigen Zustimmung datenschutzgerecht zu vernichten bzw. zu löschen. Gleiches gilt für Test- und Ausschussmaterial. Die Löschung bzw. Vernichtung ist der Stammschule mit Datumsangabe schriftlich oder in einem dokumentierten elektronischen Format zu bestätigen. Das Protokoll der Löschung bzw. Vernichtung ist auf Anforderung vorzulegen.</p>
		<p>(7) Dokumentationen, die dem Nachweis der auftrags- und ordnungsgemäßen Datenverarbeitung dienen, sind durch den Auftragsverarbeiter entsprechend der jeweiligen Aufbewahrungsfristen über das Vertragsende hinaus aufzubewahren. Er kann sie zu seiner Entlastung bei Vertragsende an das Bildungsministerium übergeben.</p>
		<div class="heading--1">13. Technische und organisatorische Maßnahmen</div>
		<p>(1) Der Auftragsverarbeiter gewährleistet die Umsetzung und Einhaltung aller für diesen Auftrag erforderlichen technischen und organisatorischen Maßnahmen (Anlage 2) gemäß Art. 32 DS-GVO (Art. 28 Abs. 3 S. 2 lit. c DS-GVO). Er sorgt für die Nachweisbarkeit der getroffenen technischen und organisatorischen Maßnahmen gegenüber dem Bildungsministerium zwecks Wahrnehmung der Kontrollbefugnisse aus diesem Vertrag.</p>
		<p>(2) Bei den zu treffenden technischen und organisatorischen Maßnahmen handelt es sich um Maßnahmen der Datensicherheit und zur Gewährleistung eines dem Risiko angemessenen Schutzniveaus hinsichtlich der Vertraulichkeit, der Integrität, der Verfügbarkeit sowie der Belastbarkeit der Systeme. Dabei sind der Stand der Technik, die Implementierungskosten und die Art, der Umfang und die Zwecke der Verarbeitung sowie die unterschiedliche Eintrittswahrscheinlichkeit und Schwere des Risikos für die Rechte und Freiheiten natürlicher Personen im Sinne von Art. 32 Abs. 1 DS-GVO zu berücksichtigen.</p>
		<p>(3) Für die Verantwortlichen hat das Bildungsministerium die Umsetzung der im Vorfeld der Auftragsvergabe vom Auftragsverarbeiter dargelegten und erforderlichen technischen und organisatorischen Maßnahmen vor Beginn der Verarbeitung geprüft. Weitere Prüfungen erfolgen anlassbezogen durch das Bildungsministerium in Abstimmung mit den Bildungsministerien der Pilotländer.</p>
		<p>(4) Für die Sicherheit erhebliche Entscheidungen zur Organisation der Datenverarbeitung und zu den angewandten Verfahren sind zwischen Auftragsverarbeiter und den Verantwortlichen abzustimmen. Derartige Festlegungen erfolgen in Vertretung für die Verantwortlichen durch das MSB NRW in Abstimmung mit dem Bildungsministerium.</p>
		<p>(5) Soweit die beim Auftragsverarbeiter getroffenen Maßnahmen den Anforderungen der Verantwortlichen nicht genügen, benachrichtigt er unverzüglich das Bildungsministerium.</p>
		<p>(6) Die technischen und organisatorischen Maßnahmen beim Auftragsverarbeiter unterliegen dem technischen Fortschritt und der Weiterentwicklung. Insoweit ist es dem Auftragsverarbeiter gestattet, alternative adäquate Maßnahmen umzusetzen. Dabei darf das Sicherheitsniveau bzw. die vereinbarten Standards der festgelegten Maßnahmen nicht unterschritten werden. Wesentliche Änderungen muss der Auftragsverarbeiter mit den Verantwortlichen in dokumentierter Form (schriftlich, elektronisch) abstimmen. Solche Abstimmungen sind für die Dauer dieses Vertrages aufzubewahren. Derartige Abstimmungen erfolgen für die Verantwortlichen durch das Bildungsministerium.</p>
		<p>(7) Der Nachweis von technischen und organisatorischen Maßnahmen, die nicht nur den konkreten Auftrag betreffen, kann erfolgen durch </p>
		<ul>
			<li>die Einhaltung genehmigter Verhaltensregeln gemäß Art. 40 DS-GVO;</li>
			<li>die Zertifizierung nach einem genehmigten Zertifizierungsverfahren gemäß Art. 42 DS-GVO;</li>
			<li>aktuelle Testate, Berichte oder Berichtsauszüge unabhängiger Instanzen (z.B. Wirtschaftsprüfer, Revision, Datenschutzbeauftragter, IT-Sicherheitsabteilung, Datenschutzauditoren, Qualitätsauditoren);</li>
			<li>eine geeignete Zertifizierung durch IT-Sicherheits- oder Datenschutzaudit (z.B. nach BSI-Grundschutz).</li>
		</ul>
		<p>(8) Der Nachweis bei Zertifizierungen nach Absatz 9 wird dem Bildungsministerium vorgelegt.</p>
		<p>(9) Der Auftragsverarbeiter hat bei gegebenem Anlass, mindestens aber jährlich, eine Überprüfung, Bewertung und Evaluation der Wirksamkeit der technischen und organisatorischen Maßnahmen zur Gewährleistung der Sicherheit der Verarbeitung durchzuführen (Art. 32 Abs. 1 lit. d DS -GVO). Das Ergebnis samt vollständigem Auditbericht ist dem Bildungsministerium mitzuteilen.</p>
		<p>(10) Der Auftragsverarbeiter kontrolliert regelmäßig die internen Prozesse sowie die technischen und organisatorischen Maßnahmen, um zu gewährleisten, dass die Verarbeitung in seinem Verantwortungsbereich im Einklang mit den Anforderungen des geltenden Datenschutzrechts erfolgt und der Schutz der Rechte der betroffenen Person gewährleistet wird.</p>
		<div class="heading--1">14. Haftung</div>
		<p>Auf Art. 82 DS-GVO wird verwiesen.</p>
		<div class="heading--1">15. Sonstiges</div>
		<p>(1) Vereinbarungen zu den technischen und organisatorischen Maßnahmen sowie Kontroll- und Prüfungsunterlagen (auch zu Unterauftragsverarbeitern) sind vom Auftragsverarbeiter und vom Bildungsministerium für ihre Geltungsdauer und anschließend noch für drei volle Kalenderjahre aufzubewahren.</p>
		<p>(2) Für Nebenabreden ist grundsätzlich die Schriftform oder ein dokumentiertes elektronisches Format erforderlich. Sie werden ausschließlich zwischen dem Auftragsverabeiter und dem MSB NRW in Vertretung für die Verantwortlichen festgelegt. Nebenabreden sind sodann der Stammschule und dem Bildungsministerium als Vertragsbestandteil zuzuleiten.</p>
		<p>(3) Sollte das Eigentum oder die zu verarbeitenden personenbezogenen Daten der Verantwortlichen beim Auftragsverarbeiter durch Maßnahmen Dritter (etwa durch Pfändung oder Beschlagnahme), durch ein Insolvenz - oder Vergleichsverfahren oder durch sonstige Ereignisse gefährdet werden, so hat der Auftragsverarbeiter die Verantwortlichen unverzüglich zu verständigen.</p>
		<p>(4) Die Einrede des Zurückbehaltungsrechts i. S. v. § 273 BGB wird hinsichtlich der für die Verantwortlichen verarbeiteten Daten und der zugehörigen Datenträger ausgeschlossen.</p>
		<div class="heading--1">16. Wirksamkeit des Vertrages</div>
		<p>Sollten einzelne Teile dieser Vereinbarung unwirksam sein, so berührt dies die Wirksamkeit der Vereinbarung im Übrigen nicht.</p>
		<div class="heading--1">Anlagen:</div>
		<p>
		- Leistungsvereinbarung<br>
		- Kategorien und Arten betroffener Personen und personenbezogener Daten in den Verarbeitungsvorgängen in DigLu<br>
		- Allgemeine Beschreibung der Technischen und organisatorischen Maßnahmen<br>
		- Löschungskonzept
		</p>
    </div>
</div><?php echo '<pre>'; print_r($schoolInfo);?>
<div class="page-container page-3 avv-diglu">
	<div class="page-area">
		<table class="report-table" style="margin: 40mm 0 0;">
			<tbody>
				<tr>
					<td class="font-size--14" style="width:90mm;"><?php echo $schoolInfo->ministry_city . ', ' . date("d.m.Y"); ?></td>
					<td> </td>
					<td class="font-size--14" style="width:90mm;"><?php echo $schoolInfo->school_city . ', ' . date("d.m.Y"); ?></td>
				</tr>
				<tr>
					<td class="font-size--8" style="height: 10mm; border-top: .1mm dotted;">Ort, Datum</td>
					<td> </td>
					<td class="font-size--8" style="height: 10mm; border-top: .1mm dotted;">Ort, Datum</td>
				</tr>
				<tr>
					<td class="font-size--14"><?php echo $schoolInfo->ministry_contact_name; ?></td>
					<td> </td>
					<td class="font-size--14"><?php echo $schoolInfo->school_contact_name; ?></td>
				</tr>
				<tr>
					<td class="font-size--8" style="height: 10mm; border-top: .1mm dotted;">Verantwortlicher<br>Bildungsministerium</td>
					<td> </td>
					<td class="font-size--8" style="height: 10mm; border-top: .1mm dotted;">Verantwortlicher<br>Stammschule</td>
				</tr>
			</tbody>
		</table>
		<table class="report-table" style="width:90mm; margin: 20mm 0 0;">
			<tbody>
				<tr>
					<td class="font-size--14">Dresden, <?php echo date("d.m.Y"); ?></td>
				</tr>
				<tr>
					<td class="font-size--8" style="height: 10mm; border-top: .1mm dotted;">Ort, Datum</td>
				</tr>
				<tr>
					<td class="font-size--14">Rabeneck</td>
				</tr>
				<tr>
					<td class="font-size--8" style="height: 10mm; border-top: .1mm dotted;">Auftragsverarbeiter<br>a u d i v i s a Deutsche Gesellschaft für E-Learning mbH</td>
				</tr>
			</tbody>
		</table>
    </div>
</div>
