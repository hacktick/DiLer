<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright   Copyright (C) 2012 digitale-lernumgebung.de. All rights reserved.
 * @license     GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 * @conent		template for "Staudinger-Gesamtschule Freiburg"
 */

/**
 * As with standard Joomla JLayout files, the data for the layout is contained in a standard class called $displayData, with the following fields:
 *
 * student:          stdClass   columns from the dilerreg_users table for this student (for example, student->surname).
 *                              We also include learningGroupName and learningGroupId in the student object.
 *
 * studentFields:    array      Associative array in format field_name => stdClass for each student type field definition. stdClass has field id, name,
 *                              published, description, label, type, locked, params, ordering, student_id, value.
 *                              Example: $studentFields['strengths']->label or $studentFields['strengths']->value.
 *
 * subjects:         array      Array of stdClass objects, one for each subject the student is assigned to. Each subject has name, id, and fields.
 *                              fields is an associative array of field_name => stdClass for each subject type field,
 *                              where stdClass has the same fields as for student type fields above.
 *                              Example: foreach ($subjects as $subject), then $subject->name or $subject->fields['subject_participation']->label.
 *
 * reportInfo:     stdClass    	report_type_id, report_type_name, report_type_published, report_type_description, layout_file_name,
 *                             	period_id, period_published, period_name, period_published, period_description, start_date, end_date,
 *                              edit_start_date, edit_end_date, fields.
 *                              fields is an associative array of field_name => stdClass with same fields as for student and subject field definitions.
 *                              Example: $reportInfo->report_type_name or $reportInfo->fields['report_footer']->field_value
 *                              where 'report_footer' is the name of a period-type field definition.
 */

// No direct access to this file

defined('_JEXEC') or die('Restricted access');

use DiLer\Lang\DText;

extract((array) $displayData);

$showPhase = isset($options['showPhase']) && $options['showPhase'];
$coloriseAchievegridHeading = isset($options['coloriseAchievegridHeading']) && $options['coloriseAchievegridHeading'];
$coloriseAchievegridCompetencies = isset($options['coloriseAchievegridCompetencies']) && $options['coloriseAchievegridCompetencies'];
?>

<?php
if (! isset($phases) || ! is_array($phases) || ! $phases){
	echo '<div style="margin: 0 auto 30px; text-align: left">'.DText::sprintf('STUDENTREPORT_NO_COMPETENCIES_MATCH').'</div>';
}else{?>
	<table class="reportTable studentReportAchieveGrid" style="font-size: 9pt">
		<thead>
			<tr class="tablecontainerrow">
				<th class="column col1" style="width: 25%">Kompetenz</th>
				<?php foreach($levelList as $litem) : ?>
					<th style="text-align: center;" class="column heading <?php echo $coloriseAchievegridHeading ? $litem['colour']:'';?>">
						<?php echo count($levelList) == 1 ? 'G/M/E':$litem['name']; ?>
					</th>
				<?php endforeach; ?>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($phases as $phaseId => $phase) :
				if ($showPhase) : ?>
					<tr>
						<td class="column col1 level">
							<?php echo DText::sprintf('STUDENT_COMPETENCE_STATUS_HEADING', DText::_('PHASE'), $phase['value']);?>
						</td>
						<td colspan="<?php echo count($levelList);?>" class="<?php echo $statusArray[$phase['studentStatus']]['tdClass']; ?>"> </td>
					</tr>
				<?php endif; ?>
				<?php foreach ($phase['competences'] as $competenceId => $competence) : ?>
					<tr>
						<td class="column col1 <?php echo $statusArray[$competence['studentStatus']]['tdClass'];?>">
							<?php echo $competence['name']; ?>
						</td>
					<?php foreach ($competence['levels'] as $levelId => $level) : ?>
						<td class="<?php echo $statusArray[$level['studentStatus']]['tdClass']; ?>" style="<?php echo $coloriseAchievegridCompetencies ? $statusArray[$level['studentStatus']]['style']:''; ?>">
							<?php echo $level['compcharName']; ?>
							<?php echo $statusArray[$level['studentStatus']]['value'] == 5 ? '<br><div style="display:inline-block;margin:0.7em 0 0;font-size:8pt;padding:0.3em;border:1px solid #000">'.DText::_('STATUS_SUCCEEDED_WITH_SUPPORT').'</div>':''; ?>
						</td>
					<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</tbody>
	</table>
<?php }?>