<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/*
 * $displayData is a stdClass as follows:
 *
 *    $label          subform field label
 *    $memberFields   associative array of the subform member fields as <field name> => <stdClass of field info: displayEmpty, element_type, id, label>.
 *    $options        stdClass: cssStyles, displayVariation (from HTML function call), noData (markup for no data), subjectName (from JHTML function call in layout)
 *    $value          acciative array of subform instances in format: <subform name + sequence> => <associative array of member fields as: <field name> => <field value> >
 */

extract((array) $displayData);

?>

<?php if (! $value) : ?>
	<?php return; ?>
<?php endif; ?>
<div class="headingSubform"><?php echo $label; ?><?php echo $options->subjectName; ?></div>
<div style="width: 49%; margin-right: 1%; display: inline-block; vertical-align: top;">
	<table class="reportTable" style="width: 100%; text-align: center; margin-bottom: 5mm">
		<thead>
			<tr>
				<?php foreach ($value as $formInstance) :
					$i = 1;
					foreach ($formInstance as $fieldName => $fieldValue) : ?>
						<th class="column col<?php echo $i;?>" <?php echo $i > 1 ? ' style="min-width: 0; text-align: center;"':'';?>><?php echo $memberFields[$fieldName]->label; ?></th>
					<?php $i++;
					endforeach;
				break;endforeach; ?>
			</tr>
		</thead>
		<tbody>
			<?php $index = -1; ?>
			<?php foreach ($value as $formInstance) :?>
				<?php $index++; ?>
				<?php if (count($value) > 3) : ?>
					<?php if($index >= count($value)/2) continue; ?>
				<?php endif; ?>
				<tr>
					<?php
					$i = 1;
					foreach ($formInstance as $fieldName => $fieldValue) : ?>
						<td class="column col<?php echo $i;?>" <?php echo $i > 1 ? ' style="min-width: 0; text-align: center;"':'';?>><?php echo $fieldValue; ?></td>
					<?php
					$i++;
					endforeach; ?>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php if (count($value) > 3) : ?>
	<div style="width: 49%; display: inline-block; vertical-align: top;">
		<table class="reportTable" style="width: 100%; text-align: center; margin-bottom: 5mm">
			<thead>
				<tr>
					<?php foreach ($value as $formInstance) :
						$i = 1;
						foreach ($formInstance as $fieldName => $fieldValue) : ?>
							<th class="column col<?php echo $i;?>" <?php echo $i > 1 ? ' style="min-width: 0; text-align: center;"':'';?>><?php echo $memberFields[$fieldName]->label; ?></th>
						<?php $i++;
						endforeach;
					break;endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<?php $index = -1; ?>
				<?php foreach ($value as $formInstance) :?>
					<?php $index++; ?>
					<?php if($index < count($value)/2) continue; ?>
					<tr>
						<?php
						$i = 1;
						foreach ($formInstance as $fieldName => $fieldValue) : ?>
							<td class="column col<?php echo $i;?>" <?php echo $i > 1 ? ' style="min-width: 0; text-align: center;"':'';?>><?php echo $fieldValue; ?></td>
						<?php
						$i++;
						endforeach; ?>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
