<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/*
 * $displayData is a stdClass as follows:
 *
 *    $label          subform field label
 *    $memberFields   associative array of the subform member fields as <field name> => <stdClass of field info: displayEmpty, element_type, id, label>.
 *    $options        stdClass: cssStyles, displayVariation (from HTML function call), noData (markup for no data)
 *    $value          acciative array of subform instances in format: <subform name + sequence> => <associative array of member fields as: <field name> => <field value> >
 */

extract((array) $displayData);
?>

<?php foreach ($value as $formInstance) : ?>	
	<tr>
		<?php
		$i = 0;
		foreach ($formInstance as $fieldName => $value) : ?>
			<td<?php echo $i == 0 ? ' class="column col1"':' style="text-align: center;"';?>"><?php echo $value; ?></td>
		<?php 
		$i++;
		endforeach; ?>
	</tr>
<?php endforeach; ?>