<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
use DiLer\Lang\DText;

defined('_JEXEC') or die('Restricted access');

/*
 * $displayData is a stdClass as follows:
 *
 *    $subjectId      id of subject
 *    $phases         associative array as <id> => <phase>.
 *                    phase is array 'value' => <phase value>, 'studentStatus' => <student status for the phase>,
 *                        'competences' => associative array as <competence id> => <competence>.
 *                           competence is array as 'id' => <competence id>, 'name' => <competence name>,
 *                          'studentStatus' => <student status for the competence>,
 *                          'levels' => associative array as <level id> => <level>
 *                          level is array as 'name' => <name>, 'colour' => <colour code>, 'compcharId' => compcharId if it exists (0 otherwise),
 *                             'compcharName' => <name of compchar if it exists, blank otherwise>
 *                             'studentStatus' => <student status for this compchar, if it exists, 1 otherwise>
 *   $levelList     associative array of levels as <levelId> => 'name' => <name>, 'colour' => <level colour code>
 *   $statusArray   associative array of status codes as <status code> => 'value' => <status value>, 'languageTag' => <language tag for status name, for example, 'COM_DILER_STATUS_AVAILABLE' >,
 *                     'iconClass' => <label icon class, for example, label-available>
 *                     'tdClass' => <CSS class for table td element, for example, available>
 */

extract($displayData);

$showPhase = isset($options['showPhase']) && $options['showPhase'];
$coloriseAchievegridHeading = isset($options['coloriseAchievegridHeading']) && $options['coloriseAchievegridHeading'];
$coloriseAchievegridCompetencies = isset($options['coloriseAchievegridCompetencies']) && $options['coloriseAchievegridCompetencies'];
$subject = isset($options['subject']) ? $options['subject'] : '';
?>

<?php
if (! isset($phases) || ! is_array($phases) || ! $phases){
	echo '<div style="margin: 0 auto 30px; text-align: left">'.DText::_('STUDENTREPORT_NO_COMPETENCIES_MATCH').'</div>';
}else{?>
	<table class="report-table studentReportAchieveGrid">
		<thead>
			<tr class="tablecontainerrow">
				<th class="font-size--14 column col1 border-bottom"><?php echo $subject;?></th>
				<?php foreach($levelList as $litem) : ?>
					<th class="column heading font--bold border-bottom <?php echo $coloriseAchievegridHeading ? $litem['colour']:'';?>">
						<div>
							<?php echo $litem['name']; ?>
						</div>
					</th>
				<?php endforeach; ?>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($phases as $phaseId => $phase) :
				if ($showPhase) : ?>
					<tr>
						<td class="column col1 level font-size--8">
							<?php echo DText::sprintf('STUDENT_COMPETENCE_STATUS_HEADING', DText::_('PHASE'), $phase['value']);?>
						</td>
						<td class="column level <?php echo $statusArray[$phase['studentStatus']]['tdClass']; ?>" colspan="<?php echo count($levelList);?>"> </td>
					</tr>
				<?php endif; ?>
				<?php foreach ($phase['competences'] as $competenceId => $competence) : ?>
					<tr>
						<td class="column col1 <?php echo $statusArray[$competence['studentStatus']]['tdClass'];?>">
							<?php echo $competence['name']; ?>
						</td>
					<?php foreach ($competence['levels'] as $levelId => $level) : ?>
						<td class="<?php echo $statusArray[$level['studentStatus']]['tdClass']; ?>" style="<?php echo $coloriseAchievegridCompetencies ? $statusArray[$level['studentStatus']]['style'] . ';padding:2mm;' : ''; ?>">
							<?php echo $level['compcharName']; ?>
							<?php echo $statusArray[$level['studentStatus']]['value'] == 5 ? '<br><div style="display:inline-block;width:90%;margin:0.7em 0 0;font-size:8pt;padding:0.3em;border:.25pt solid #000">'.DText::_('STATUS_SUCCEEDED_WITH_SUPPORT').'</div>':''; ?>
						</td>
					<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</tbody>
	</table>
<?php }?>
