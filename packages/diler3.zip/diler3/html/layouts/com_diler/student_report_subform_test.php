<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2016 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU Affero General Public License version 3 or later; see media/com_diler/images/agpl-3.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/*
 * $displayData is a stdClass as follows:
 *
 *    $label          subform field label
 *    $memberFields   associative array of the subform member fields as <field name> => <stdClass of field info: displayEmpty, element_type, id, label>.
 *    $options        stdClass: cssStyles, displayVariation (from HTML function call), noData (markup for no data)
 *    $value          acciative array of subform instances in format: <subform name + sequence> => <associative array of member fields as: <field name> => <field value> >
 */

extract((array) $displayData);
?>


<h3><?php echo $label; ?> <?php echo (! count($value)) ? $options->noData : ''; ?></h3>
<?php if (! $value) : ?>
	<?php return; ?>
<?php endif; ?>
<table>
	<th><tr><td>Label</td><td>Value</td>
<?php foreach ($value as $formInstance) : ?>

	<?php foreach ($formInstance as $fieldName => $value) : ?>
		<tr>
			<td><?php echo $memberFields[$fieldName]->label; ?></td>
			<td><?php echo $value; ?></td>
		</tr>
	<?php endforeach; ?>

<?php endforeach; ?>
</table>
