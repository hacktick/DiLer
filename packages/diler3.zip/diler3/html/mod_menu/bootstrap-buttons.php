<?php
/**
 * @package		DiLer.Site
 * @subpackage	mod_menu.bootstrap-buttons
 * @filesource
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use DiLer\DConst;
use DiLer\DUrl;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

JLoader::register('JHtmlDiler',      JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

// Get the view for the help button.
$input = Factory::getApplication()->input;
$user = Factory::getUser();
$talkieView = $user->authorise('talkie.view', 'com_diler');
$extendedFeatures = DilerHelperUser::extendedFeatures();
$document = Factory::getDocument();
if ($extendedFeatures)
{
	$document->addScript(Uri::root(true) . '/media/com_diler/js/eventemitter.min.js');
	$document->addScript(Uri::root(true) . '/media/com_diler/js/palava.min.js');
	$document->addScript(Uri::root(true) . '/media/com_diler/js/talkie_util.js');
}
$view = $input->get('view');
$task = $input->get('task');
$option = $input->get('option');
$lang = $input->get('lang');
$autoTalkie = $input->getUint('autoTalkie');
$role = DilerHelperUser::getDilerRole();
if ($option == 'com_dpcalendar' && $view == 'calendar')
{
	$view = $role . '_' . $view;
}
if ($option == 'com_users' || $option == 'com_loginguard')
{
	$view = ($view == '' && $task > '') ? $task : $view;
	$view = $option . '_' . $view;
}

// Note. It is important to remove spaces between elements.
?>

<div class="btn-toolbar"<?php
	$tag = '';
	if ($params->get('tag_id') != null)
	{
		$tag = $params->get('tag_id').'';
		echo ' id="'.$tag.'"';
	}
?>>
<?php
if (strpos($params->get('moduleclass_sfx'),'extrabuttons') !== false) {?>
	<a id="dilerLeftHideButton" class="btn floorShadow" title="<?php echo DText::_('BUTTON_LEFTCOL_HIDE'); ?>"><i class="fas fa-chevron-left"></i></a>
<?php } ?>

<?php

$isSchoolStatisticsView = ($view == DConst::TEACHER_SCHOOLS_LIST_VIEW);
if ($isSchoolStatisticsView)
	$active_id = 0;

foreach ($list as $i => &$item)
{
	if (! DilerHelperUser::canView($item)) continue;
	$class = $class_sfx.' item-'.$item->id;
	if ($item->id == $active_id) {
		$class .= ' current';
	}

	if ($item->id && $path && !$isSchoolStatisticsView) {
		if (in_array($item->id, $path)) {
			$class .= ' active';
		}
		elseif ($item->type == 'alias') {
			$aliasToId = $item->getParams()->get('aliasoptions');
			if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
				$class .= ' active';
			}
			elseif (in_array($aliasToId, $path)) {
				$class .= ' alias-parent-active';
			}
		}
	}

	if ($item->type == 'separator') {
		$class .= ' divider';
	}

	if ($item->deeper) {
		$class .= ' deeper';
	}

	if ($item->parent) {
		$class .= ' parent';
	}

	if (!empty($class)) {
		$class = ' class="'.trim($class) .'"';
	}

	echo '<a'.$class;

	// Render the menu item.
	switch ($item->type) :
		case 'separator':
		case 'url':
		case 'component':
		case 'heading':
			require ModuleHelper::getLayoutPath('mod_menu', 'bootstrap-buttons_'.$item->type);
			break;

		default:
			require ModuleHelper::getLayoutPath('mod_menu', 'bootstrap-buttons_url');
			break;
	endswitch;

	// The next item is deeper.
	if ($item->deeper) {
		echo '<ul class="nav-child unstyled small">';
	}
	// The next item is shallower.
	elseif ($item->shallower) {
		echo '</li>';
		echo str_repeat('</ul></li>', $item->level_diff);
	}
	// The next item is on the same level.
	else {
		echo '</a>';
	}
}
?>
<?php if (strpos($params->get('moduleclass_sfx'),'extrabuttons') !== false) : ?>
	<?php if ($talkieView && $extendedFeatures) :?>
		<a class="btn floorShadow"
			onclick="talkieWindow('<?php echo $lang; ?>', '<?php echo DText::_('TALKIE_RUNNING'); ?>'); return false;"
			onkeypress="talkieWindow('<?php echo $lang; ?>', '<?php echo DText::_('TALKIE_RUNNING'); ?>'); return false;"
			type="button" class="btn floorShadow"
			>
			<i class="fas fa-comments-alt"></i> <?php echo DText::_('TALKIE_START_CALL_BUTTON'); ?>
		</a>
	<?php endif; ?>
	<?php if ($extendedFeatures && $user->authorise('wiki.view', 'com_diler')) :?>
		<a id="dilerWikiButton" class="btn floorShadow" href="wiki/doku.php?id=start" target=_blank>
			<i class="fas fa-book"></i> Wiki
		</a>
	<?php endif; ?>
	<a id="dilerLanguagesButton" class="btn floorShadow"><i class="fas fa-flag-alt"></i> <?php echo DText::_('BUTTON_LANGUAGES'); ?></a>
	<?php if ($role == 'teacher' && $user->authorise('tutorials.view', 'com_diler')) :?>
		<a id="dilerTutorialsButton" class="btn floorShadow"
			href="https://www.dilertube.de/diler-tutorials.html" target=_blank>
			<i class="fas fa-question-circle"></i> <?php echo DText::_('BUTTON_TUTORIALS'); ?></a>
	<?php endif; ?>
	<?php if (DilerHelperUser::hasAccessToSchoolsList()) : ?>
		<a class="btn floorShadow <?php echo $isSchoolStatisticsView ? 'active' : '' ?>" href="<?php echo DUrl::teacherSchoolsList($lang) ?>">
			<i class="fas fa-school"></i> <?php echo DText::_('SCHOOLS_LIST'); ?>
		</a>
	<?php endif; ?>
	<?php echo HTMLHelper::_('diler.helpButton', $view, "btn floorShadow", true, "fas fa-question-circle", false); ?>
<?php endif; ?>

</div>
<?php
$document = Factory::getDocument();
if ($extendedFeatures && $user->getParam('autoTalkie', 2) === 1 && in_array($role, ['teacher','student','parent']) && $autoTalkie === 1)
{
	$document->addScriptDeclaration("
		jQuery(document).ready(function() {
			dilerSystem.talkieStart('" . $lang . "');
		});
	");
}
?>
