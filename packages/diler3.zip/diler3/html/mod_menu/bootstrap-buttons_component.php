<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	@copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Note. It is important to remove spaces between elements.
$item->anchor_css = $item->anchor_css == 'calendar' ? 'calendar-alt' : $item->anchor_css;
$class = $item->anchor_css ? 'class="'.$item->anchor_css.'" ' : '';
$title = $item->anchor_title ? 'title="'.$item->anchor_title.'" ' : '';
if ($item->menu_image) {
		$item->getParams()->get('menu_text', 1) ?
		$linktype = '<img src="'.$item->menu_image.'" alt="'.$item->title.'" /><span class="image-title">'.$item->title.'</span> ' :
		$linktype = '<img src="'.$item->menu_image.'" alt="'.$item->title.'" />';
}
else { $linktype = $item->title;
}

switch ($item->browserNav) :
	default:
	case 0:
		//echo $class; ?> href="<?php echo $item->flink; ?>" <?php echo $title; ?>><i class="fas fa-<?php echo $item->anchor_css;?>"></i> <?php echo $linktype;
		break;
	case 1:
		// _blank
		//echo $class; ?> href="<?php echo $item->flink; ?>" target="_blank" rel="noopener" <?php echo $title; ?>><i class="fas fa-<?php echo $item->anchor_css;?>"></i> <?php echo $linktype;
		break;
	case 2:
		// window.open
		//echo $class; ?> href="<?php echo $item->flink; ?>" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes');return false;" <?php echo $title; ?>><i class="fas fa-largefal fa-<?php echo $item->anchor_css;?>"></i> <?php echo $linktype;
		break;
endswitch;
