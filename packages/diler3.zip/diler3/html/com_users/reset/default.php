<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_users
 *
 * @copyright   Copyright (C) 2005 - 2021 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('behavior.formvalidator');
Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/components/com_diler');
BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');

/** @var BaseDatabaseModel $dilerModel */
$dilerModel = MVCHelper::factory()->createModel('Diler', 'Site');
$wa = Factory::getApplication()->getDocument()->getWebAssetManager();

/** @var Form $form */
$form = $this->form;
$input = Factory::getApplication()->input;
$view = $input->get('view');
$option = $input->get('option');
if ($form instanceof Form)
{
    $formName = $form->getName();
}

$isUserReset = ($formName === 'com_users.reset_request' && $option === 'com_users' && $view === 'reset');

if ($isUserReset) {
    $form->setFieldAttribute('email', 'class', 'validate-username');
    $form->setFieldAttribute('email', 'type', 'text');
	$wa->addInlineStyle('span.form-control-feedback { display: none !important }');
}

// Override label and description of email field
$form->setFieldAttribute('email', 'label', Text::_('JGLOBAL_USERNAME'));
$form->setFieldAttribute('email', 'description', DText::_('FIELD_PASSWORD_RESET_DESC'));
?>
<div class="reset<?php echo $this->pageclass_sfx; ?>">
	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1>
				<?php echo $this->escape($this->params->get('page_heading')); ?>
			</h1>
		</div>
	<?php endif; ?>
	<form id="user-registration" action="<?php echo Route::_('index.php?option=com_dilerreg&task=reset.request'); ?>" method="post" class="form-validate form-horizontal well">
		<?php foreach ($form->getFieldsets() as $fieldset) : ?>
			<fieldset>
				<?php if (isset($fieldset->label) && $fieldset->name == 'default') : ?>
					<div class="control-group">
						<div class="controls">
							<?php echo DText::_('RESET_REQUEST_LABEL'); ?>
						</div>
					</div>
				<?php endif; ?>
				<?php echo $form->renderFieldset($fieldset->name); ?>
			</fieldset>
		<?php endforeach; ?>
		<div class="control-group">
			<div class="controls">
				<button type="submit" class="btn btn-primary validate">
					<?php echo DText::_('REQUEST_PASSWORD_RESET_BTN'); ?>
				</button>
				<a type="button" class="btn btn-default" href="<?php echo $dilerModel->getLoginLink(); ?>">
					<?php echo Text::_('JCANCEL'); ?>
				</a>
			</div>
		</div>
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>
