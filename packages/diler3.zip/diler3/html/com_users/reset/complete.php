<?php

/**
 * @package     Joomla.Site
 * @subpackage  com_users
 *
 * @copyright   Copyright (C) 2005 - 2021 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Audivisa\Component\DiLer\Administrator\Helper\MVCHelper;

defined('_JEXEC') or die;

HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('behavior.formvalidator');
BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_diler/models');

/** @var BaseDatabaseModel $dilerModel */
$dilerModel = MVCHelper::factory()->createModel('Diler', 'Site');
$wa = Factory::getApplication()->getDocument()->getWebAssetManager();

/** @var Form $form */
$form = $this->form;
$input = Factory::getApplication()->input;
$view = $input->get('view');
$option = $input->get('option');
$layout = $input->get('layout');
if ($form instanceof Form)
{
	$formName = $form->getName();
}

$isUserResetComplete = ($formName === 'com_users.reset_complete' && $option === 'com_users' && $view === 'reset' && $layout === 'complete');

if ($isUserResetComplete)
{
    $form->setFieldAttribute('password1', 'strengthmeter', false);
    $wa->addInlineStyle('.input-password-toggle { display: none !important }');
    $wa->addInlineStyle('span.form-control-feedback { display: none !important }');
}

?>
<div class="reset-complete<?php echo $this->pageclass_sfx; ?>">
	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1>
				<?php echo $this->escape($this->params->get('page_heading')); ?>
			</h1>
		</div>
	<?php endif; ?>
	<form action="<?php echo Route::_('index.php?option=com_users&task=reset.complete'); ?>" 
			method="post" class="form-validate form-horizontal well">
		<?php foreach ($this->form->getFieldsets() as $fieldset) : ?>
			<fieldset>
				<?php if (isset($fieldset->label)) : ?>
					<p><?php echo Text::_($fieldset->label); ?></p>
				<?php endif; ?>
				<?php echo $this->form->renderFieldset($fieldset->name); ?>
			</fieldset>
		<?php endforeach; ?>
		<div class="control-group">
			<div class="controls">
				<button type="submit" class="btn btn-primary validate">
					<?php echo Text::_('JSUBMIT'); ?>
				</button>
				<a type="button" class="btn btn-default" href="<?php echo $dilerModel->getLoginLink(); ?>">
					<?php echo Text::_('JCANCEL'); ?>
				</a>
			</div>
		</div>
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>
