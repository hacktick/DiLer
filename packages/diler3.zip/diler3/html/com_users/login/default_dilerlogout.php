<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	@copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

// @TODO Find out is this file used at all, if not we should delete it.
JLoader::register('DilerLogger', JPATH_ROOT .  '/components/com_diler/helpers/logger.php');
$showSchoolHomepage = Factory::getApplication()->input->getUint('showSchoolHomepage');
// Debugging: Figure out how you got here:


$logMessage = 'User ' . Factory::getUser()->username . ' got to default_dilerlogout screen.';
$logData = array('message' => $logMessage, 'extension' => 'com_users');
$logger = new DilerLogger('user', 'logout');
$logger->addAction($logData);
?>
<div class="logout <?php echo $this->pageclass_sfx?> well floorShadow floorBox">
	<form action="<?php echo Route::_('index.php?option=com_users&task=user.logout'); ?>" method="post" class="form-horizontal">
		<button type="submit" class="btn btn-primary" value="Log Out"><?php echo Text::_('JLOGIN'); ?></button>
		<?php if($showSchoolHomepage) : ?>
			<a class="btn btn-info" href="<?php echo Uri::root().'index.php?lang='.Factory::getApplication()->input->get('lang');?>">Website</a> <?php // there might never be a scenario where this button is displayed ?>
		<?php endif; ?>
		<input type="hidden" name="return" value="<?php echo base64_encode($this->params->get('logout_redirect_url', $this->form->getValue('return'))); ?>" />
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>
