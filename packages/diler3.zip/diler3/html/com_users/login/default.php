<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
$role = DilerHelperUser::getDilerRole();
if ($this->user->id && in_array($role, array('teacher', 'student', 'parent')))
{
	// The user is already logged into Diler so we should present the logout
	echo $this->loadTemplate('dilerlogout');
}
else
{
	echo $this->loadTemplate('dilerlogin');
}

