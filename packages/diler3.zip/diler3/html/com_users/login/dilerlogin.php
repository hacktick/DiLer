<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_dilerreg
 *
 * @copyright	Copyright (C) 2013 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

BaseDatabaseModel::addIncludePath(JPATH_ROOT . '/components/com_dilerreg/models');
$approved = BaseDatabaseModel::getInstance('Login', 'DilerregModel')->getApproved($this->user->id);
$role = DilerHelperUser::getDilerRole($this->user->id);
Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/components/com_diler', null, true);

if ($this->user->id && $role && $approved)
{
	// The user is already logged into Diler so we should present the logout
	echo $this->loadTemplate('dilerlogout');
}
elseif ($this->user->id)
{
	Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/components/com_diler/language');
	// Logged in user but not DiLer user so we should show the applicable messages
	if (! $role)
	{
		Factory::getApplication()->enqueueMessage(Text::_('PLG_USER_DILERREG_NO_ROLE'), 'warning');
	}
	if (! $approved)
	{
		Factory::getApplication()->enqueueMessage(Text::_('PLG_USER_DILERREG_NOT_REGISTERED'), 'warning');
	}
	$redirect = 'index.php?lang=' . Factory::getApplication()->input->get('lang');
	Factory::getApplication()->redirect($redirect);
}
else
{
	echo $this->loadTemplate('dilerlogin');
}

