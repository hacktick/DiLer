<?php
/**
 * @package		DiLer.Site
 * @subpackage	com_diler
 * @filesource
 * @copyright	Copyright (C) 2014 digitale-lernumgebung.de. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */



defined('_JEXEC') or die;
use Audivisa\Component\DiLer\Site\Helper\VersionHelper;
use DiLer\DPath;
use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Layout\FileLayout;

JLoader::registerNamespace('Audivisa\\Component\\DiLer\\Site', JPATH_ROOT . '/components/com_diler/src/', false, false, 'psr4');

$app = Factory::getApplication();
$componentParams = $app->getParams('com_diler');
$document = Factory::getDocument();
if (!VersionHelper::isJoomla4()) :
    $document->addScript(Uri::root(true) . '/templates/diler3/jui/js/jquery.js');
endif;
$document->addScript(Uri::root(true) . '/media/com_diler/js/jquery.fitvids.js');
$document->addScript(Uri::root(true) . '/media/com_diler/js/diler.js');
$document->addScript(Uri::root(true) . '/media/com_diler/js/region-teacher-list.js');
JLoader::register('JHtmlDiler', JPATH_ROOT . '/components/com_diler/helpers/html/diler.php');

$user = Factory::getUser();
$loginGuardRecords = array();
$loginGuardMethods = array();
if (file_exists(JPATH_ROOT . '/components/com_loginguard/helpers/tfa.php'))
{
    require_once JPATH_ROOT . '/components/com_loginguard/helpers/tfa.php';
	$loginGuardRecords = LoginGuardHelperTfa::getUserTfaRecords($user->id);
	$loginGuardMethods = LoginGuardHelperTfa::getTfaMethods();
}

HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('diler.jqvalidate');
HTMLHelper::_('diler.translateJs');
DText::script('COOKIES_DISABLED_HEADER');
DText::script('COOKIES_DISABLED_BODY');
DText::script('CLOSE');
DText::script('SEARCH_REGION_TEACHERS');

$lang = Factory::getLanguage();
$lang->load('com_dilerreg', JPATH_BASE . '/components/com_dilerreg/', $lang->get('tag'), false);
$lang->load('com_diler', JPATH_BASE . '/components/com_diler/', $lang->get('tag'), false);
Factory::getDocument()->setTitle(DText::sprintf('LOGIN', Text::_('COM_DILER')));
$remindItemid = $app->input->getUint('remindItem');
$registerItemid = $app->input->getUint('registerItem');
$showSchoolHomepage = $app->input->getUint('showSchoolHomepage', false);
$loginContactformDisplay = $componentParams->get('loginContactformDisplay', true);
$openRegionTeachersModal = $app->input->getUint('openRegionTeachersModal');
$isDiglu = DilerHelperUser::isDiglu();
$langFull = $app->input->get('lang');
$lang = substr($langFull, 0, 2);
$itemId = $app->input->getUint('Itemid');
?>
<div id="dilerModalTarget"></div>
<form action="index.php?option=com_users&amp;task=user.login&Itemid=<?php echo $itemId; ?>&lang=<?php echo $lang; ?>" method="post" name="dilerLoginForm" id="dilerLoginForm" class="">
	<fieldset>
		<div class="input-prepend input-append floorShadow narrow">
			<span class="add-on">
				<i title="" data-placement="left" class="fal fa-user hastooltip" data-original-title="Benutzername"></i>
			</span>
			<input id="username" class="inputbox" type="text" name="username" placeholder="<?php echo Text::_('COM_DILER_LOGIN_USERNAME_LABEL')?>" tabindex=1 required>
			<span class="add-on"> </span>
		</div>
		<?php
			$myaccountPage = false;
			$registrationPage = false;
			$loginPage = true;
			require("components/com_diler/helpers/screenkeyboard.php");
		?>
		<?php if ($this->tfa && !$loginGuardMethods): ?>
			<div class="input-prepend input-append floorShadow narrow">
				<span class="add-on">
					<i title="" data-placement="left" class="fal fa-lock hastooltip" data-original-title="Benutzername"></i>
				</span>
				<input id="secretkey" class="inputbox" type="text" name="secretkey" value="" placeholder="<?php echo Text::_('JGLOBAL_SECRETKEY');?>">
				<span class="add-on hastooltip" title="<?php echo Text::_('JGLOBAL_SECRETKEY_HELP');?>">
					<i class="fal fa-question-circle"></i>
				</span>
			</div>
		<?php endif; ?>
		<div id="loginButtons" class="clearfix narrow">
			<div class="first"><input class="btn btn-large btn-block btn-primary floorShadow" type="submit" name="Submit" value="<?php echo Text::_('JLOGIN'); ?>"></div>
			<div class="last" style="margin-bottom:.5rem"><input id="showMore" class="btn btn-large btn-block floorShadow" type="button" value="<?php echo Text::_('COM_DILERREG_MORE'); ?>"></div>
			<?php if (DilerHelperUser::isDiglu()) : ?>
                <button type="button" class="btn btn-large btn-block btn-default floorShadow"
                        onclick="openRegionTeachersModal();">
					<?php echo DText::_('SEARCH_REGION_TEACHERS') ?>
                </button>
			<?php endif; ?>
		</div>
	</fieldset>
	<input type="hidden" name="component" value="com_diler">
	<?php echo HTMLHelper::_('form.token'); ?>
	<input type="hidden" name="formToken" value="<?php echo Factory::getSession()->getFormToken(); ?>">
</form>
<div id="dilerLoginMore" class="clearfix hide">
	<?php if ($isDiglu) : ?>
		<div class="digluLoginMore">
			<p class="text-center"><?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_HEADING'); ?></p>
			<div class="btn-toolbar">
				<a class="btn btn-block btn-info floorShadow"
					href="index.php?option=com_dilerreg&view=baseschoolactivation&Itemid=<?php echo $registerItemid; ?>">
					<?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_ACTIVATION_BTN'); ?>
				</a>
				<a class="btn btn-block btn-info floorShadow"
					href="index.php?option=com_dilerreg&view=registerteacher&base_school=1&principal=1&Itemid=<?php echo $registerItemid; ?>">
					<?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_REGISTRATION_BTN'); ?>
				</a>
			</div>
			<p class="text-center" style="margin-top: 20px;"><?php echo DText::_('LOGIN_FORM_DIGLU_BASE_SCHOOL_TEACHER_HEADING'); ?></p>
			<div class="btn-toolbar">
				<a class="btn btn-block btn-info floorShadow"
					href="index.php?option=com_dilerreg&view=enrollstudent&base_school=1&Itemid=<?php echo $registerItemid; ?>">
					<?php echo DText::sprintf('LOGIN_FORM_DIGLU_BASE_TEACHER_ACTIVATION_BTN', DText::_('STUDENT')); ?>
				</a>
				<a class="btn btn-block btn-info floorShadow"
					href="index.php?option=com_dilerreg&view=registerteacher&base_school=1&Itemid=<?php echo $registerItemid; ?>">
					<?php echo DText::_('LOGIN_FORM_DIGLU_BASE_TEACHER_REG_BTN'); ?>
				</a>
			</div>
		</div>
		<div class="digluLoginMore">
			<p class="text-center"><?php echo DText::_('LOGIN_FORM_DIGLU_BRANCH_SCHOOL_ACTIVATION_HEADING'); ?></p>
			<div class="btn-toolbar">
				<a class="btn btn-block btn-info floorShadow"
					href="index.php?option=com_dilerreg&view=enrollstudent&Itemid=<?php echo $registerItemid; ?>">
					<?php echo DText::sprintf('LOGIN_FORM_DIGLU_BRANCH_SCHOOL_ACTIVATION_BTN', DText::_('STUDENT')); ?>
				</a>
				<a class="btn btn-block btn-info floorShadow"
					href="index.php?option=com_dilerreg&view=registerteacher&Itemid=<?php echo $registerItemid; ?>">
					<?php echo DText::sprintf('LOGIN_FORM_DIGLU_BRANCH_TEACHER_REG_BTN'); ?>
				</a>
			</div>
		</div>
		<div class="digluLoginMore">
			<p class="text-center"><?php echo Text::_('COM_USERS_REGISTER_PARENTS_STUDENTS_HEADING'); ?></p>
			<div class="btn-toolbar">
                <a class="btn btn-block btn-info floorShadow"
                   href="index.php?option=com_dilerreg&view=registrationdigluuser&Itemid=<?php echo $registerItemid; ?>">
					<?php echo Text::_('COM_USERS_REGISTER_DEFAULT_LABEL'); ?>
                </a>
			</div>
		</div>
		<div class="digluLoginMore">
			<p class="text-center"><?php echo DText::_('LOGIN_FORM_DIGLU_BRANCH_SCHOOL_ACTIVATION_SERVICE_HEADING'); ?></p>
			<div class="btn-toolbar">
				<?php if($loginContactformDisplay) : ?>
					<button type="button" class="btn btn-block btn-default floorShadow" onclick="openEmailModal();">
						<?php echo Text::_('COM_DILERREG_DIGLU_CONTACT_ADMIN'); ?>
					</button>
				<?php endif; ?>
				<a class="btn btn-block btn-default floorShadow" href="//www.diglu.de/#anmeldung" target=_blank><?php echo Text::_('COM_DILERREG_HELP_DIGLU_FAQ'); ?></a>
			</div>
		</div>
	<?php else: ?>
		<div class="btn-toolbar">
			<a class="btn btn-block btn-info floorShadow"
				style="margin-bottom: 14px;"
				href="index.php?option=com_dilerreg&view=registration&Itemid=<?php echo $registerItemid; ?>">
				<?php echo Text::_('COM_USERS_REGISTER_DEFAULT_LABEL'); ?>
			</a>
			<?php if($loginContactformDisplay) : ?>
				<button type="button" class="btn btn-block btn-default floorShadow" onclick="openEmailModal();">
					<?php echo Text::_('COM_DILERREG_CONTACT_ADMIN'); ?>
				</button>
			<?php endif; ?>
			<a class="btn btn-block btn-default floorShadow" href="//digitale-lernumgebung.de/elternbereich/hilfe-fuer-eltern.html" target=_blank><?php echo Text::_('COM_DILERREG_HELP_PARENTS'); ?></a>
			<?php if($showSchoolHomepage) : ?>
				<a class="btn btn-block btn-default floorShadow" href="<?php echo Uri::root().'index.php?lang=' . $lang;?>"><?php echo Text::_('COM_DILERREG_SITE_HOMEPAGE'); ?></a>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</div>
<?php $emailFormLayout = new FileLayout('login_email_modal', JPATH_ROOT . '/components/com_diler/layouts'); ?>
<?php $emailFormHtml = $emailFormLayout->render(array());?>
<?php $bodyJSON = json_encode($emailFormHtml); ?>

<?php
$searchRegionTeachersModal = new FileLayout('search_region_teachers_modal', DPath::LAYOUTS);
$searchRegionTeachersForm = json_encode($searchRegionTeachersModal->render());

?>
<script>
    jQuery(document).ready(function(){
        <?php if ($openRegionTeachersModal == 1 && DilerHelperUser::isDiglu()): ?>
        openRegionTeachersModal();
        <?php endif;?>
    });
function openEmailModal() {
	var options = {
		targetDiv: "emailModal",
		header: "<?php echo $isDiglu ? Text::_('COM_DILERREG_DIGLU_CONTACT_ADMIN') : Text::_('COM_DILERREG_CONTACT_ADMIN'); ?>",
		cancelButton: "<?php echo Text::_('JCANCEL'); ?>",
		closeButton: "<?php echo DText::_('CLOSE'); ?>",
		confirmButton: "<?php echo Text::_('JSUBMIT'); ?>",
		confirmOnclick: "sendEmail()"
	};
	options.body = <?php echo $bodyJSON; ?>;
	dilerSystem.modalCreate(options);
	setTimeout(function(){jQuery("#emailForm textarea").focus()},700);
};
    function openRegionTeachersModal() {

        var options = {
            targetDiv: "regionTeachersModalContainer",
            header: Joomla.Text._('COM_DILER_SEARCH_REGION_TEACHERS'),
            modalId: "regionTeachersModal",
            closeButton: Joomla.Text._('COM_DILER_CLOSE'),
            body: <?php echo $searchRegionTeachersForm ?>,
        };

        dilerSystem.modalCreate(options);
    }

    jQuery(document).ready(function($) {
        window.openRegionTeachersModal = function() {
            var openCount = parseInt(sessionStorage.getItem('regionTeachersModalOpenCount')) || 0;
            openCount++;
            sessionStorage.setItem('regionTeachersModalOpenCount', openCount);

            var options = {
                targetDiv: "regionTeachersModalContainer",
                header: Joomla.Text._('COM_DILER_SEARCH_REGION_TEACHERS'),
                modalId: "regionTeachersModal",
                closeButton: Joomla.Text._('COM_DILER_CLOSE'),
                body: <?php echo $searchRegionTeachersForm ?>,
            };

            dilerSystem.modalCreate(options);

            jQuery('#' + options.modalId).on('shown.bs.modal', function () {
                jQuery("#regionTeacherCity").focus();
            });
        };

        function initializeModalOpenCount() {
            sessionStorage.setItem('regionTeachersModalOpenCount', 0);
        }

        window.addEventListener('load', initializeModalOpenCount);

        window.addEventListener('beforeunload', function() {
            var openCount = parseInt(sessionStorage.getItem('regionTeachersModalOpenCount')) || 0;

            if (openCount > 0) {
                const data = {
                    'option': 'com_dilerreg',
                    'task': 'saveModalOpenCount',
                    'description': 'modal_open_times',
                    'modal_open_per_session': openCount,
                    [Joomla.getOptions('csrf.token')]: Joomla.getOptions('csrf.token')
                };

                $.ajax({
                    url: 'index.php',
                    method: 'POST',
                    data: data,
                    dataType: 'json',
                    async: false,
                    cache: false,
                    });
            }
        });
    });

    function sendEmail() {
	jQuery('#emailForm').validate();
	if (jQuery('#emailForm').valid()) {
		// Do AJAX email send
		var myData = {
				'option': 'com_dilerreg',
				'task' : 'sendEmail',
				'userReplyEmail' : jQuery('#userReplyEmail').val(),
				'userMessage' : jQuery('#userMessage').val(),
				'last_name' : jQuery('#last_name').val()
			};
			myData[jQuery('input[name="formToken"]').val()] = '1';
			var emailResult = jQuery.ajax({
				url: 'index.php',
				method: 'POST',
				data: myData,
				dataType: 'json',
				async: true,
				cache: false
			});

			emailResult.always(function(data) {
				jQuery('#dilerModalConfirmButton').hide();
				jQuery('#dilerModalCancelButton').hide();
				jQuery('#dilerModalCloseButton').show();
				if (data.result == 'error') {
					dilerSystem.modalMessage('dilerModal', '<?php echo Text::_('ERROR'); ?>', data.message, 'error');
				} else if (data.result == 'success') {
					dilerSystem.modalMessage('dilerModal', '<?php echo Text::_('SUCCESS'); ?>', '<?php echo Text::_('COM_DILERREG_LOGIN_EMAIL_SUCCESS_MESSAGE')?>', 'success');
				}
			});
	}
};
</script>
