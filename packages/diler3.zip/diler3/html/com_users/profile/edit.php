<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_users
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('formbehavior.chosen', 'select');

// Check that 2fa is allowed for this user type
JLoader::register('DilerHelperUser', JPATH_BASE. '/components/com_diler/helpers/user.php');
$app = Factory::getApplication();
$itemId = $app->input->getUint('Itemid');
$groups = array('teacher' => 1, 'student' => 2, 'parent' => 3);
$dilerRole = DilerHelperUser::getDilerRole();
$redirect = 'index.php?option=com_diler&view=' . $dilerRole . '_myaccount&Itemid=' . $itemId;
if (! isset($groups[$dilerRole]))
{
	$app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'));

	$app->redirect(Route::_($redirect, false));
}

// Load user_profile plugin language
$lang = Factory::getLanguage();
$lang->load('plg_user_profile', JPATH_ADMINISTRATOR);
$lang->load('com_diler', JPATH_BASE . '/components/com_diler/');

// Check if akeeba loginguard is enabled
$fieldSets = $this->form->getFieldSets();
$loginGuardCount = 0;

if (!\Joomla\CMS\Plugin\PluginHelper::isEnabled('multifactorauth'))
{
	$app->enqueueMessage(DText::_('2FA_NO_PLUGIN'), 'error');
	$app->redirect(Route::_($redirect, false));
}

$app->setUserState('com_diler.edit.profile.redirect', $redirect);

?>
<div class="profile-edit<?php echo $this->pageclass_sfx?> well well-small floorBox">

	<script type="text/javascript">
		Joomla.twoFactorMethodChange = function(e)
		{
			var selectedPane = 'com_users_twofactor_' + jQuery('#jform_twofactor_method').val();

			jQuery.each(jQuery('#com_users_twofactor_forms_container>div'), function(i, el) {
				if (el.id != selectedPane)
				{
					jQuery('#' + el.id).hide(0);
				}
				else
				{
					jQuery('#' + el.id).show(0);
				}
			});
		}
	</script>

	<form id="member-profile" action="<?php echo Route::_('index.php?option=com_users&task=profile.save'); ?>" method="post" class="form-validate form-horizontal" enctype="multipart/form-data">

	<?php if (isset($fieldSets['loginguard']) && $loginGuardCount > 0) : ?>
		<?php $fieldSet = $fieldSets['loginguard']; ?>
		<?php $fields = $this->form->getFieldset('loginguard'); ?>
		<fieldset>
			<?php if (isset($fieldset->label)) : ?>
				<legend>
					<?php echo Text::_($fieldset->label); ?>
				</legend>
			<?php endif; ?>
			<?php if (isset($fieldset->description) && trim($fieldset->description)) : ?>
				<?php echo '<p>' . $this->escape(Text::_($fieldset->description)) . '</p>'; ?>
			<?php endif; ?>
			<?php // Iterate through the fields in the set and display them. ?>
			<?php foreach ($fields as $field) : ?>
				<?php // If the field is hidden, just display the input. ?>
				<?php if ($field->hidden) : ?>
					<?php echo $field->input; ?>
				<?php else : ?>
							<?php echo $field->input; ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</fieldset>
	<?php elseif ($this->mfaConfigurationUI) : ?>
        <fieldset>
            <legend><?php echo Text::_('COM_USERS_PROFILE_TWO_FACTOR_AUTH'); ?></legend>
            <?php echo $this->mfaConfigurationUI ?>
        </fieldset>

        <div class="control-group">
			<button type="submit" class="btn btn-primary saveButton validate"><?php echo Text::_('JSUBMIT'); ?></button>
			<a class="btn" href="<?php echo Route::_('index.php?option=com_diler'); ?>" title="<?php echo Text::_('JCANCEL'); ?>"><?php echo Text::_('JCANCEL'); ?></a>
			<input type="hidden" name="option" value="com_users" />
			<input type="hidden" name="task" value="profile.save" />
			<input type="hidden" name="jform[name]" id="jform_name" value="<?php echo $this->form->getField('name')->value;?>" >
			<input type="hidden" name="jform[email1]" id="jform_email1" value="<?php echo $this->form->getField('email1')->value;?>" >
			<input type="hidden" name="jform[email2]" id="jform_email2" value="<?php echo $this->form->getField('email2')->value;?>" >
		</div>
	<?php endif; ?>

	<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>
