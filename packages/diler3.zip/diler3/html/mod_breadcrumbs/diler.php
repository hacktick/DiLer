<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_breadcrumbs
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

// load language from com_diler
$language = Factory::getLanguage();
$language->load('com_diler', JPATH_SITE.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_diler', 'de-DE', true);
$language->load('com_diler', JPATH_SITE.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_diler', null, true);

$app		= Factory::getApplication();
$urlLang	= $app->input->get('lang');
$option = $app->input->get('option');
$view = $app->input->get('view');
$layout = $app->input->get('layout');

$pathway	= $app->getPathWay();
$menuitemId = '';
//$pathway->setPathway(null);
$menu = Factory::getApplication()->getMenu();
$items = $menu->getItems(array('title'), DText::_('DASHBOARD'));

foreach($items as $menuItem)
{
	if($menuItem->title === DText::_('DASHBOARD'))
	{
		$menuitemId = $menuItem->id;
	}
}
?>

<ul class="breadcrumb<?php echo $moduleclass_sfx; ?>">
	<?php
	if ($params->get('showHere', 1))
	{
		echo '<li class="active"><span class="divider fal fa-location hasTooltip" title="' . Text::_('MOD_BREADCRUMBS_HERE') . '"></span></li>';
	}
    if ($option == 'com_users' && $view == 'methods' && $layout == 'firsttime')
	    echo '<li><span>' . Text::_('COM_USERS_MFA_FIRSTTIME_PAGE_HEAD') . '</span></li>';

	// Get rid of duplicated entries on trail including home page when using multilanguage
	for ($i = 0; $i < $count; $i++)
	{
		if ($i == 1 && !empty($list[$i]->link) && !empty($list[$i - 1]->link) && $list[$i]->link == $list[$i - 1]->link)
		{
			unset($list[$i]);
		}
	}

	// Find last and penultimate items in breadcrumbs list
	end($list);
	$last_item_key = key($list);
	prev($list);
	$penult_item_key = key($list);

	// Generate the trail
	foreach ($list as $key => $item) :
	// Make a link if not the last item in the breadcrumbs
	$show_last = $params->get('showLast', 1);
	if ($key != $last_item_key || $option != 'com_diler')
	{
		// Render all but last item - along with separator
		echo '<li>';
		if (!empty($item->link))
		{
			echo '<a href="' . $item->link . '" class="pathway">' . $item->name . '</a>';
		}
		else
		{
			echo '<span>' . $item->name . '</span>';
		}

		if (($key != $penult_item_key) || $show_last)
		{
			echo '<span class="divider">' . $separator . '</span>';
		}

		echo '</li>';
	}
	elseif ($show_last)
	{
		// Render last item if reqd.
		echo '<li>';
		echo '<span>' . $item->name . '</span>';
		echo '<span class="divider">' . $separator . '</span>';
		echo '</li>';
	}
	endforeach; ?>
</ul>
