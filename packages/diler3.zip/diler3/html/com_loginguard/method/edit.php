<?php
/**
 * @package   AkeebaLoginGuard
 * @copyright Copyright (c)2016-2017 Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Prevent direct access
defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

/** @var  \Akeeba\LoginGuard\Site\View\Method\Html  $this */

HTMLHelper::_('bootstrap.tooltip');

$app = Factory::getApplication();
$urlParsed = parse_url(base64_decode($this->returnURL));
parse_str($urlParsed['query'], $queryArray);
$itemId = isset($queryArray['Itemid']) ? $queryArray['Itemid'] : '';
$cancelURL = Route::_('index.php?option=com_loginguard&Itemid='.$itemId.'&view=Methods&user_id=' . $this->user->id, false);
Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/components/com_diler');

if (!empty($this->returnURL))
{
	$cancelURL = $this->escape(base64_decode($this->returnURL));
}

$token = Session::getFormToken();

?>
<div class="profile-edit well well-small floorBox">
    <form action="<?= Uri::base() ?>index.php" method="post" id="loginguard-method-edit" class="akeeba-form--horizontal akeeba-panel--info">
        <input type="hidden" name="option" value="com_loginguard">
        <input type="hidden" name="view" value="Method">
        <input type="hidden" name="task" value="save">
        <input type="hidden" name="id" value="<?= (int) $this->record->id ?>">
        <input type="hidden" name="method" value="<?= $this->record->method ?>">
        <input type="hidden" name="user_id" value="<?= $this->user->id ?>">
        <input type="hidden" name="<?= $token ?>" value="1">
		<?php if (!empty($this->returnURL)): ?>
            <input type="hidden" name="returnurl" value="<?= $this->escape($this->returnURL) ?>">
		<?php endif; ?>
        <input type="hidden" name="<?php echo $token ?>" value="1">
		<?php if (!empty($this->returnURL)): ?>
            <input type="hidden" name="returnurl" value="<?php echo $this->escape($this->returnURL) ?>">
		<?php endif; ?>

		<?php if (!empty($this->renderOptions['hidden_data'])): ?>
			<?php foreach ($this->renderOptions['hidden_data'] as $key => $value): ?>
                <input type="hidden" name="<?php echo $this->escape($key) ?>" value="<?php echo $this->escape($value) ?>">
			<?php endforeach; ?>
		<?php endif; ?>

        <div class="control-group form-group">
            <div class="controls">
                <input type="text" class="form-control input-xxlarge" id="loginguard-method-edit-title"
                       name="title"
                       value="<?php echo $this->escape($this->record->title) ?>"
                       placeholder="<?php echo Text::_('COM_LOGINGUARD_LBL_EDIT_FIELD_TITLE_DESC') ?>">
            </div>
        </div>

        <div class="control-group form-group">
            <div class="controls">
                <label class="control-label hasTooltip"
                       title="<?php echo $this->escape(Text::_('COM_LOGINGUARD_LBL_EDIT_FIELD_DEFAULT_DESC')); ?>">
                    <input type="checkbox" <?php echo $this->record->default ? 'checked="checked"' : ''; ?> name="default">
					<?php echo Text::_('COM_LOGINGUARD_LBL_EDIT_FIELD_DEFAULT'); ?>
                </label>
            </div>
        </div>

		<?php if (!empty($this->renderOptions['tabular_data'])): ?>
            <div class="loginguard-method-edit-tabular-container">
				<?php if (!empty($this->renderOptions['table_heading'])): ?>
                    <h4>
						<?php echo $this->renderOptions['table_heading'] ?>
                    </h4>
                    <p><?php echo DText::_('LOGINGUARD_GOOGLE_AUTH_PRE_MESSAGE'); ?></p>
				<?php endif; ?>
                <table class="table table-striped">
                    <tbody>
					<?php foreach ($this->renderOptions['tabular_data'] as $cell1 => $cell2): ?>
                        <tr>
                            <td>
								<?php echo $cell1 ?>
                            </td>
                            <td>
								<?php echo $cell2 ?>
                            </td>
                        </tr>
					<?php endforeach; ?>
                    </tbody>
                </table>
            </div>
		<?php endif; ?>

		<?php if ($this->renderOptions['field_type'] == 'custom'): ?>
			<?php echo $this->renderOptions['html']; ?>
		<?php else: ?>
            <div class="control-group form-group">
				<?php if ($this->renderOptions['label']): ?>
                    <label class="control-label hasTooltip" for="loginguard-method-edit-code">
						<?php echo $this->renderOptions['label']; ?>
                    </label>
				<?php endif; ?>
                <div class="controls">
                    <input type="<?php echo $this->renderOptions['input_type']; ?>"
                           class="form-control" id="loginguard-method-code"
                           name="code"
                           value="<?php echo $this->escape($this->renderOptions['input_value']) ?>"
                           placeholder="<?php echo $this->escape($this->renderOptions['placeholder']) ?>">
                </div>
            </div>
		<?php endif; ?>

        <div class="control-group">
            <div class="controls">
				<?php if ($this->renderOptions['show_submit'] || $this->isEditExisting): ?>
                    <button type="submit" class="btn btn-primary saveButton">
                        <span class="icon icon-ok" aria-hidden="true"></span>
						<?= Text::_('COM_LOGINGUARD_LBL_EDIT_SUBMIT'); ?>
                    </button>
				<?php endif; ?>

                <a href="<?php echo $cancelURL ?>"
                   class="btn btn-small btn-sm btn-default">
                    <span class="icon fal fa-cancel-2 glyphicon glyphfal fa-cancel-2"></span>
					<?php echo Text::_('COM_LOGINGUARD_LBL_EDIT_CANCEL'); ?>
                </a>
            </div>
        </div>

		<?php if (!empty($this->renderOptions['post_message'])): ?>
            <div class="loginguard-method-edit-post-message">
				<?php echo $this->renderOptions['post_message'] ?>
            </div>
		<?php endif; ?>
    </form>
</div>
