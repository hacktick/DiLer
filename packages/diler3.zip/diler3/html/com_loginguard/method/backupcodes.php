<?php
/**
 * @package   AkeebaLoginGuard
 * @copyright Copyright (c)2016-2017 Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Prevent direct access
defined('_JEXEC') or die;

use DiLer\Lang\DText;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var  \Akeeba\LoginGuard\Site\View\Method\Html $this */

HTMLHelper::_('bootstrap.tooltip');
Factory::getLanguage()->load('com_diler', JPATH_ROOT . '/components/com_diler');

$urlParsed = parse_url(base64_decode($this->returnURL));
parse_str($urlParsed['query'], $queryArray);
$itemId = isset($queryArray['Itemid']) ? (int) $queryArray['Itemid'] : '';
$cancelURL = Route::_('index.php?option=com_loginguard&view=Method&user_id=' . $this->user->id . 'Itemid=' . $itemId);

if (!empty($this->returnURL))
{
	$cancelURL = $this->escape(base64_decode($this->returnURL));
}

if ($this->record->method != 'backupcodes')
{
	throw new RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
}

?>
<div class="profile-edit well well-small floorBox">
    <h1><?php echo Text::_('COM_LOGINGUARD_LBL_BACKUPCODES') ?></h1>
    <p><a href="<?php echo Route::_('index.php?option=com_diler&view=diler&Itemid='.$itemId);?>" class="btn"><?php echo DText::_('BACK_TO_MY_ACCOUNT'); ?></a></p>


    <div class="alert alert-info">
		<?php echo Text::_('COM_LOGINGUARD_LBL_BACKUPCODES_INSTRUCTIONS') ?>
    </div>

    <table class="table table-striped">
		<?php for ($i = 0; $i < ((is_array($this->backupCodes) || $this->backupCodes instanceof \Countable ? count($this->backupCodes) : 0) / 2); $i++): ?>
            <tr>
                <td>
					<?php if (!empty($this->backupCodes[2 * $i])): ?>
                        &#128273;
						<?php echo $this->backupCodes[2 * $i] ?>
					<?php endif; ?>
                </td>
                <td>
					<?php if (!empty($this->backupCodes[1 + 2 * $i])): ?>
                        &#128273;
						<?php echo $this->backupCodes[1 + 2 * $i] ?>
					<?php endif ;?>
                </td>
            </tr>
		<?php endfor; ?>
    </table>

    <p>
		<?php echo Text::_('COM_LOGINGUARD_LBL_BACKUPCODES_RESET_INFO'); ?>
    </p>

    <a class="btn btn-danger" href="<?php echo Route::_('index.php?option=com_loginguard&view=Method&task=regenbackupcodes&user_id=' . $this->user->id . (empty($this->returnURL) ? '' : '&returnurl=' . $this->returnURL .
			'&Itemid=' . (int) $itemId), false); ?>">
		<?php echo Text::_('COM_LOGINGUARD_LBL_BACKUPCODES_RESET'); ?>
    </a>

    <a href="<?php echo $cancelURL ?>"
       class="btn btn-default">
        <span class="icon fal fa-cancel-2 glyphicon glyphfal fa-cancel-2"></span>
		<?php echo Text::_('COM_LOGINGUARD_LBL_EDIT_CANCEL'); ?>
    </a>
</div>
